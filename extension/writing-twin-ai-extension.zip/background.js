"use strict";
(() => {
  // src/lib/auth.ts
  var STORAGE_KEY = "wt_auth";
  async function getTokens() {
    const result = await chrome.storage.local.get(STORAGE_KEY);
    return result[STORAGE_KEY] ?? null;
  }
  async function setTokens(tokens) {
    await chrome.storage.local.set({ [STORAGE_KEY]: tokens });
  }
  async function clearTokens() {
    await chrome.storage.local.remove(STORAGE_KEY);
  }

  // src/lib/api.ts
  var API_BASE = "https://api.writingtwinai.com/v1";
  async function rawFetch(path, options, token) {
    const headers = { "Content-Type": "application/json" };
    if (token) headers["Authorization"] = `Bearer ${token}`;
    return fetch(`${API_BASE}${path}`, { ...options, headers });
  }
  async function rawFetchMultipart(path, body, token) {
    return fetch(`${API_BASE}${path}`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
      body
    });
  }
  async function tryRefresh() {
    const stored = await getTokens();
    if (!stored?.refresh_token) return null;
    try {
      const res = await rawFetch("/auth/refresh", {
        method: "POST",
        body: JSON.stringify({ refresh_token: stored.refresh_token })
      });
      if (!res.ok) return null;
      const data = await res.json();
      await setTokens({ ...stored, access_token: data.access_token, refresh_token: data.refresh_token });
      return data.access_token;
    } catch {
      return null;
    }
  }
  async function request(path, options, token) {
    let res = await rawFetch(path, options, token);
    if (res.status === 401 && token) {
      const newToken = await tryRefresh();
      if (newToken) {
        res = await rawFetch(path, options, newToken);
      }
    }
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
      if (res.status === 429) throw new Error(`LIMIT_REACHED:${err.detail}`);
      throw new Error(err.detail);
    }
    if (res.status === 204) return void 0;
    return res.json();
  }
  async function login(email, password) {
    return request("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password })
    });
  }
  async function register(email, password) {
    await request("/auth/register", {
      method: "POST",
      body: JSON.stringify({ email, password })
    });
    return login(email, password);
  }
  async function submitDnaSamples(rawTexts, token) {
    const samples = rawTexts.map((body) => ({ source: "email", body }));
    await request("/dna/samples", {
      method: "POST",
      body: JSON.stringify({ samples })
    }, token);
  }
  async function getDnaProfile(token) {
    try {
      return await request("/dna/profile", { method: "GET" }, token);
    } catch {
      return null;
    }
  }
  async function humanize(text, tone, token, ctx) {
    return request("/humanize", {
      method: "POST",
      body: JSON.stringify({ text, tone, ...ctx })
    }, token);
  }
  async function detectContext(platform, recipientDomain, threadSubject, token) {
    return request("/context/detect", {
      method: "POST",
      body: JSON.stringify({
        platform,
        recipient_domain: recipientDomain,
        thread_subject: threadSubject
      })
    }, token);
  }
  async function submitFeedback(rewriteId, action, token) {
    await request(`/humanize/${rewriteId}/feedback`, {
      method: "POST",
      body: JSON.stringify({ action })
    }, token);
  }
  async function voiceDraft(audioBlob, outputType, token) {
    const form = new FormData();
    form.append("audio", audioBlob, "recording.webm");
    form.append("output_type", outputType);
    let res = await rawFetchMultipart("/voice/draft", form, token);
    if (res.status === 401) {
      const newToken = await tryRefresh();
      if (newToken) {
        const form2 = new FormData();
        form2.append("audio", audioBlob, "recording.webm");
        form2.append("output_type", outputType);
        res = await rawFetchMultipart("/voice/draft", form2, newToken);
      }
    }
    if (!res.ok) {
      const err = await res.json().catch(() => ({ detail: `HTTP ${res.status}` }));
      if (res.status === 429) throw new Error(`LIMIT_REACHED:${err.detail}`);
      throw new Error(err.detail);
    }
    return res.json();
  }
  async function recordContextOverride(detectedContext, selectedContext, platform, recipientDomain, token) {
    await request("/context/override", {
      method: "POST",
      body: JSON.stringify({
        detected_context: detectedContext,
        selected_context: selectedContext,
        platform,
        recipient_domain: recipientDomain
      })
    }, token);
  }
  async function submitVoiceFeedback(sessionId, accepted, editedDraft, token) {
    await request(`/voice/draft/${sessionId}/feedback`, {
      method: "POST",
      body: JSON.stringify({ accepted, edited_draft: editedDraft })
    }, token);
  }
  async function autoDraft(incomingText, tone, token, ctx) {
    return request("/humanize/auto-draft", {
      method: "POST",
      body: JSON.stringify({ incoming_text: incomingText, tone, ...ctx })
    }, token);
  }
  async function submitAutoDraftFeedback(draftId, kept, token) {
    await request(`/humanize/auto-draft/${draftId}/feedback`, {
      method: "POST",
      body: JSON.stringify({ kept })
    }, token);
  }

  // src/background.ts
  chrome.runtime.onMessage.addListener(
    (message, _sender, sendResponse) => {
      handleMessage(message).then(sendResponse).catch((err) => sendResponse({ error: err.message }));
      return true;
    }
  );
  async function handleMessage(msg) {
    switch (msg.type) {
      case "LOGIN": {
        const resp = await login(msg.payload.email, msg.payload.password);
        const tokens = {
          access_token: resp.access_token,
          refresh_token: resp.refresh_token,
          email: msg.payload.email
        };
        await setTokens(tokens);
        updateBadge(true);
        return { success: true, tokens };
      }
      case "REGISTER": {
        const resp = await register(msg.payload.email, msg.payload.password);
        const tokens = {
          access_token: resp.access_token,
          refresh_token: resp.refresh_token,
          email: msg.payload.email
        };
        await setTokens(tokens);
        updateBadge(true);
        return { success: true, tokens };
      }
      case "LOGOUT": {
        await clearTokens();
        updateBadge(false);
        return { success: true };
      }
      case "GET_AUTH_STATE": {
        const tokens = await getTokens();
        return { success: true, authenticated: tokens !== null, tokens: tokens ?? void 0 };
      }
      case "HUMANIZE": {
        const tokens = await getTokens();
        if (!tokens) throw new Error("Not logged in. Please log in via the extension popup.");
        const result = await humanize(
          msg.payload.text,
          msg.payload.tone,
          tokens.access_token,
          msg.payload.ctx
        );
        return { success: true, result };
      }
      case "FEEDBACK": {
        const tokens = await getTokens();
        if (!tokens) throw new Error("Not authenticated");
        await submitFeedback(msg.payload.rewriteId, msg.payload.action, tokens.access_token);
        return { success: true };
      }
      case "SUBMIT_DNA": {
        const tokens = await getTokens();
        if (!tokens) throw new Error("Not authenticated");
        await submitDnaSamples(msg.payload.samples, tokens.access_token);
        return { success: true };
      }
      case "GET_DNA_STATUS": {
        const tokens = await getTokens();
        if (!tokens) return { success: true, dnaProfile: null };
        const profile = await getDnaProfile(tokens.access_token);
        return { success: true, dnaProfile: profile };
      }
      case "VOICE_DRAFT": {
        const tokens = await getTokens();
        if (!tokens) throw new Error("Not logged in. Please log in via the extension popup.");
        const { audioData, mimeType, outputType } = msg.payload;
        const binary = atob(audioData);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
        const blob = new Blob([bytes], { type: mimeType });
        const result = await voiceDraft(blob, outputType, tokens.access_token);
        return { success: true, result };
      }
      case "DETECT_CONTEXT": {
        const tokens = await getTokens();
        if (!tokens) return { success: true, result: { context_twin: "professional", tone_guidance: "" } };
        const result = await detectContext(
          msg.payload.platform ?? "unknown",
          msg.payload.recipient_domain ?? null,
          msg.payload.thread_subject ?? null,
          tokens.access_token
        );
        return { success: true, result };
      }
      case "CONTEXT_OVERRIDE": {
        const tokens = await getTokens();
        if (!tokens) return { success: true };
        recordContextOverride(
          msg.payload.detected_context,
          msg.payload.selected_context,
          msg.payload.platform,
          msg.payload.recipient_domain,
          tokens.access_token
        ).catch(() => {
        });
        return { success: true };
      }
      case "VOICE_FEEDBACK": {
        const tokens = await getTokens();
        if (!tokens) throw new Error("Not authenticated");
        await submitVoiceFeedback(
          msg.payload.sessionId,
          msg.payload.accepted,
          msg.payload.editedDraft,
          tokens.access_token
        );
        return { success: true };
      }
      case "AUTO_DRAFT": {
        const tokens = await getTokens();
        if (!tokens) throw new Error("Not logged in. Please log in via the extension popup.");
        const result = await autoDraft(
          msg.payload.incomingText,
          msg.payload.tone,
          tokens.access_token,
          msg.payload.ctx
        );
        return { success: true, result };
      }
      case "AUTO_DRAFT_FEEDBACK": {
        const tokens = await getTokens();
        if (!tokens) return { success: true };
        submitAutoDraftFeedback(msg.payload.draftId, msg.payload.kept, tokens.access_token).catch(() => {
        });
        return { success: true };
      }
      default:
        throw new Error("Unknown message type");
    }
  }
  function updateBadge(authenticated) {
    chrome.action.setBadgeText({ text: authenticated ? "" : "" });
  }
  getTokens().then((t) => updateBadge(t !== null));
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2xpYi9hdXRoLnRzIiwgIi4uL3NyYy9saWIvYXBpLnRzIiwgIi4uL3NyYy9iYWNrZ3JvdW5kLnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJjb25zdCBTVE9SQUdFX0tFWSA9ICd3dF9hdXRoJztcblxuZXhwb3J0IGludGVyZmFjZSBBdXRoVG9rZW5zIHtcbiAgYWNjZXNzX3Rva2VuOiBzdHJpbmc7XG4gIHJlZnJlc2hfdG9rZW46IHN0cmluZztcbiAgZW1haWw6IHN0cmluZztcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFRva2VucygpOiBQcm9taXNlPEF1dGhUb2tlbnMgfCBudWxsPiB7XG4gIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChTVE9SQUdFX0tFWSk7XG4gIHJldHVybiAocmVzdWx0W1NUT1JBR0VfS0VZXSBhcyBBdXRoVG9rZW5zKSA/PyBudWxsO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0VG9rZW5zKHRva2VuczogQXV0aFRva2Vucyk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBbU1RPUkFHRV9LRVldOiB0b2tlbnMgfSk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjbGVhclRva2VucygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwucmVtb3ZlKFNUT1JBR0VfS0VZKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGlzQXV0aGVudGljYXRlZCgpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgcmV0dXJuIChhd2FpdCBnZXRUb2tlbnMoKSkgIT09IG51bGw7XG59XG4iLCAiaW1wb3J0IHsgZ2V0VG9rZW5zLCBzZXRUb2tlbnMgfSBmcm9tICcuL2F1dGgnO1xuXG5leHBvcnQgY29uc3QgQVBJX0JBU0UgPSAnaHR0cHM6Ly9hcGkud3JpdGluZ3R3aW5haS5jb20vdjEnO1xuXG5leHBvcnQgdHlwZSBUb25lID0gJ2Nhc3VhbCcgfCAncHJvZmVzc2lvbmFsJyB8ICdleGVjdXRpdmUnIHwgJ2ZyaWVuZGx5JyB8ICdkaXJlY3QnIHwgJ2RpcGxvbWF0aWMnO1xuXG5leHBvcnQgaW50ZXJmYWNlIFJld3JpdGVSZXNwb25zZSB7XG4gIGlkOiBzdHJpbmc7XG4gIG91dHB1dF90ZXh0OiBzdHJpbmc7XG4gIGNhY2hlX2hpdDogYm9vbGVhbjtcbiAgcHJvdmlkZXI6IHN0cmluZztcbiAgbW9kZWw6IHN0cmluZztcbiAgbGF0ZW5jeV9tczogbnVtYmVyO1xuICBjb3N0X3VzZDogbnVtYmVyO1xuICBxdWFsaXR5X3Njb3JlOiBudW1iZXIgfCBudWxsO1xuICBjb250ZXh0X2RldGVjdGVkOiBzdHJpbmcgfCBudWxsO1xuICBpbnRlbnRfZGV0ZWN0ZWQ6IHN0cmluZyB8IG51bGw7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgTG9naW5SZXNwb25zZSB7XG4gIGFjY2Vzc190b2tlbjogc3RyaW5nO1xuICByZWZyZXNoX3Rva2VuOiBzdHJpbmc7XG4gIHRva2VuX3R5cGU6IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBEbmFQcm9maWxlUmVzcG9uc2Uge1xuICBleHRyYWN0aW9uX3N0YXR1czogc3RyaW5nO1xuICB2ZXJzaW9uOiBudW1iZXIgfCBudWxsO1xuICBzYW1wbGVfY291bnQ6IG51bWJlcjtcbn1cblxuZXhwb3J0IHR5cGUgVm9pY2VPdXRwdXRUeXBlID1cbiAgfCAnZW1haWwnXG4gIHwgJ3JlcGx5J1xuICB8ICdjdXN0b21lcl91cGRhdGUnXG4gIHwgJ2ppcmFfdGlja2V0J1xuICB8ICd0ZWNobmljYWxfcmVwb3J0J1xuICB8ICdsaW5rZWRpbl9jb21tZW50J1xuICB8ICdyZWRkaXRfcmVwbHknO1xuXG5leHBvcnQgaW50ZXJmYWNlIFZvaWNlRHJhZnRSZXNwb25zZSB7XG4gIGlkOiBzdHJpbmc7XG4gIHRyYW5zY3JpcHQ6IHN0cmluZyB8IG51bGw7XG4gIGRyYWZ0OiBzdHJpbmc7XG4gIG91dHB1dF90eXBlOiBzdHJpbmc7XG4gIHByb3ZpZGVyOiBzdHJpbmc7XG4gIG1vZGVsOiBzdHJpbmc7XG4gIGxhdGVuY3lfbXM6IG51bWJlcjtcbiAgY29zdF91c2Q6IG51bWJlcjtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmF3RmV0Y2gocGF0aDogc3RyaW5nLCBvcHRpb25zOiBSZXF1ZXN0SW5pdCwgdG9rZW4/OiBzdHJpbmcpOiBQcm9taXNlPFJlc3BvbnNlPiB7XG4gIGNvbnN0IGhlYWRlcnM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfTtcbiAgaWYgKHRva2VuKSBoZWFkZXJzWydBdXRob3JpemF0aW9uJ10gPSBgQmVhcmVyICR7dG9rZW59YDtcbiAgcmV0dXJuIGZldGNoKGAke0FQSV9CQVNFfSR7cGF0aH1gLCB7IC4uLm9wdGlvbnMsIGhlYWRlcnMgfSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJhd0ZldGNoTXVsdGlwYXJ0KFxuICBwYXRoOiBzdHJpbmcsXG4gIGJvZHk6IEZvcm1EYXRhLFxuICB0b2tlbjogc3RyaW5nLFxuKTogUHJvbWlzZTxSZXNwb25zZT4ge1xuICAvLyBEbyBOT1Qgc2V0IENvbnRlbnQtVHlwZSBcdTIwMTQgYnJvd3NlciBzZXRzIGl0IHdpdGggdGhlIGNvcnJlY3QgbXVsdGlwYXJ0IGJvdW5kYXJ5XG4gIHJldHVybiBmZXRjaChgJHtBUElfQkFTRX0ke3BhdGh9YCwge1xuICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgIGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Rva2VufWAgfSxcbiAgICBib2R5LFxuICB9KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gdHJ5UmVmcmVzaCgpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgZ2V0VG9rZW5zKCk7XG4gIGlmICghc3RvcmVkPy5yZWZyZXNoX3Rva2VuKSByZXR1cm4gbnVsbDtcbiAgdHJ5IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCByYXdGZXRjaCgnL2F1dGgvcmVmcmVzaCcsIHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyByZWZyZXNoX3Rva2VuOiBzdG9yZWQucmVmcmVzaF90b2tlbiB9KSxcbiAgICB9KTtcbiAgICBpZiAoIXJlcy5vaykgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCkgYXMgeyBhY2Nlc3NfdG9rZW46IHN0cmluZzsgcmVmcmVzaF90b2tlbjogc3RyaW5nIH07XG4gICAgYXdhaXQgc2V0VG9rZW5zKHsgLi4uc3RvcmVkLCBhY2Nlc3NfdG9rZW46IGRhdGEuYWNjZXNzX3Rva2VuLCByZWZyZXNoX3Rva2VuOiBkYXRhLnJlZnJlc2hfdG9rZW4gfSk7XG4gICAgcmV0dXJuIGRhdGEuYWNjZXNzX3Rva2VuO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiByZXF1ZXN0PFQ+KHBhdGg6IHN0cmluZywgb3B0aW9uczogUmVxdWVzdEluaXQsIHRva2VuPzogc3RyaW5nKTogUHJvbWlzZTxUPiB7XG4gIGxldCByZXMgPSBhd2FpdCByYXdGZXRjaChwYXRoLCBvcHRpb25zLCB0b2tlbik7XG5cbiAgLy8gQXV0by1yZWZyZXNoIG9uIDQwMSB0aGVuIHJldHJ5IG9uY2VcbiAgaWYgKHJlcy5zdGF0dXMgPT09IDQwMSAmJiB0b2tlbikge1xuICAgIGNvbnN0IG5ld1Rva2VuID0gYXdhaXQgdHJ5UmVmcmVzaCgpO1xuICAgIGlmIChuZXdUb2tlbikge1xuICAgICAgcmVzID0gYXdhaXQgcmF3RmV0Y2gocGF0aCwgb3B0aW9ucywgbmV3VG9rZW4pO1xuICAgIH1cbiAgfVxuXG4gIGlmICghcmVzLm9rKSB7XG4gICAgY29uc3QgZXJyID0gYXdhaXQgcmVzLmpzb24oKS5jYXRjaCgoKSA9PiAoeyBkZXRhaWw6IGBIVFRQICR7cmVzLnN0YXR1c31gIH0pKSBhcyB7IGRldGFpbDogc3RyaW5nIH07XG4gICAgaWYgKHJlcy5zdGF0dXMgPT09IDQyOSkgdGhyb3cgbmV3IEVycm9yKGBMSU1JVF9SRUFDSEVEOiR7ZXJyLmRldGFpbH1gKTtcbiAgICB0aHJvdyBuZXcgRXJyb3IoZXJyLmRldGFpbCk7XG4gIH1cbiAgaWYgKHJlcy5zdGF0dXMgPT09IDIwNCkgcmV0dXJuIHVuZGVmaW5lZCBhcyBUO1xuICByZXR1cm4gcmVzLmpzb24oKSBhcyBQcm9taXNlPFQ+O1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbG9naW4oZW1haWw6IHN0cmluZywgcGFzc3dvcmQ6IHN0cmluZyk6IFByb21pc2U8TG9naW5SZXNwb25zZT4ge1xuICByZXR1cm4gcmVxdWVzdDxMb2dpblJlc3BvbnNlPignL2F1dGgvbG9naW4nLCB7XG4gICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBlbWFpbCwgcGFzc3dvcmQgfSksXG4gIH0pO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVnaXN0ZXIoZW1haWw6IHN0cmluZywgcGFzc3dvcmQ6IHN0cmluZyk6IFByb21pc2U8TG9naW5SZXNwb25zZT4ge1xuICBhd2FpdCByZXF1ZXN0PHVua25vd24+KCcvYXV0aC9yZWdpc3RlcicsIHtcbiAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IGVtYWlsLCBwYXNzd29yZCB9KSxcbiAgfSk7XG4gIHJldHVybiBsb2dpbihlbWFpbCwgcGFzc3dvcmQpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc3VibWl0RG5hU2FtcGxlcyhyYXdUZXh0czogc3RyaW5nW10sIHRva2VuOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3Qgc2FtcGxlcyA9IHJhd1RleHRzLm1hcCgoYm9keSkgPT4gKHsgc291cmNlOiAnZW1haWwnLCBib2R5IH0pKTtcbiAgYXdhaXQgcmVxdWVzdDx2b2lkPignL2RuYS9zYW1wbGVzJywge1xuICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgc2FtcGxlcyB9KSxcbiAgfSwgdG9rZW4pO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RG5hUHJvZmlsZSh0b2tlbjogc3RyaW5nKTogUHJvbWlzZTxEbmFQcm9maWxlUmVzcG9uc2UgfCBudWxsPiB7XG4gIHRyeSB7XG4gICAgcmV0dXJuIGF3YWl0IHJlcXVlc3Q8RG5hUHJvZmlsZVJlc3BvbnNlPignL2RuYS9wcm9maWxlJywgeyBtZXRob2Q6ICdHRVQnIH0sIHRva2VuKTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cblxuZXhwb3J0IGludGVyZmFjZSBIdW1hbml6ZUNvbnRleHQge1xuICBwbGF0Zm9ybT86IHN0cmluZztcbiAgcmVjaXBpZW50X2RvbWFpbj86IHN0cmluZztcbiAgdGhyZWFkX3N1YmplY3Q/OiBzdHJpbmc7XG4gIGNvbnRleHRfdHdpbl9vdmVycmlkZT86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBDb250ZXh0RGV0ZWN0UmVzcG9uc2Uge1xuICBjb250ZXh0X3R3aW46IHN0cmluZztcbiAgdG9uZV9ndWlkYW5jZTogc3RyaW5nO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaHVtYW5pemUoXG4gIHRleHQ6IHN0cmluZyxcbiAgdG9uZTogVG9uZSxcbiAgdG9rZW46IHN0cmluZyxcbiAgY3R4PzogSHVtYW5pemVDb250ZXh0LFxuKTogUHJvbWlzZTxSZXdyaXRlUmVzcG9uc2U+IHtcbiAgcmV0dXJuIHJlcXVlc3Q8UmV3cml0ZVJlc3BvbnNlPignL2h1bWFuaXplJywge1xuICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgdGV4dCwgdG9uZSwgLi4uY3R4IH0pLFxuICB9LCB0b2tlbik7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXRlY3RDb250ZXh0KFxuICBwbGF0Zm9ybTogc3RyaW5nLFxuICByZWNpcGllbnREb21haW46IHN0cmluZyB8IG51bGwsXG4gIHRocmVhZFN1YmplY3Q6IHN0cmluZyB8IG51bGwsXG4gIHRva2VuOiBzdHJpbmcsXG4pOiBQcm9taXNlPENvbnRleHREZXRlY3RSZXNwb25zZT4ge1xuICByZXR1cm4gcmVxdWVzdDxDb250ZXh0RGV0ZWN0UmVzcG9uc2U+KCcvY29udGV4dC9kZXRlY3QnLCB7XG4gICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgcGxhdGZvcm0sXG4gICAgICByZWNpcGllbnRfZG9tYWluOiByZWNpcGllbnREb21haW4sXG4gICAgICB0aHJlYWRfc3ViamVjdDogdGhyZWFkU3ViamVjdCxcbiAgICB9KSxcbiAgfSwgdG9rZW4pO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc3VibWl0RmVlZGJhY2soXG4gIHJld3JpdGVJZDogc3RyaW5nLFxuICBhY3Rpb246ICdhY2NlcHRlZCcgfCAncmVqZWN0ZWQnLFxuICB0b2tlbjogc3RyaW5nLFxuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHJlcXVlc3Q8dm9pZD4oYC9odW1hbml6ZS8ke3Jld3JpdGVJZH0vZmVlZGJhY2tgLCB7XG4gICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBhY3Rpb24gfSksXG4gIH0sIHRva2VuKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHZvaWNlRHJhZnQoXG4gIGF1ZGlvQmxvYjogQmxvYixcbiAgb3V0cHV0VHlwZTogVm9pY2VPdXRwdXRUeXBlLFxuICB0b2tlbjogc3RyaW5nLFxuKTogUHJvbWlzZTxWb2ljZURyYWZ0UmVzcG9uc2U+IHtcbiAgY29uc3QgZm9ybSA9IG5ldyBGb3JtRGF0YSgpO1xuICBmb3JtLmFwcGVuZCgnYXVkaW8nLCBhdWRpb0Jsb2IsICdyZWNvcmRpbmcud2VibScpO1xuICBmb3JtLmFwcGVuZCgnb3V0cHV0X3R5cGUnLCBvdXRwdXRUeXBlKTtcblxuICBsZXQgcmVzID0gYXdhaXQgcmF3RmV0Y2hNdWx0aXBhcnQoJy92b2ljZS9kcmFmdCcsIGZvcm0sIHRva2VuKTtcblxuICBpZiAocmVzLnN0YXR1cyA9PT0gNDAxKSB7XG4gICAgY29uc3QgbmV3VG9rZW4gPSBhd2FpdCB0cnlSZWZyZXNoKCk7XG4gICAgaWYgKG5ld1Rva2VuKSB7XG4gICAgICBjb25zdCBmb3JtMiA9IG5ldyBGb3JtRGF0YSgpO1xuICAgICAgZm9ybTIuYXBwZW5kKCdhdWRpbycsIGF1ZGlvQmxvYiwgJ3JlY29yZGluZy53ZWJtJyk7XG4gICAgICBmb3JtMi5hcHBlbmQoJ291dHB1dF90eXBlJywgb3V0cHV0VHlwZSk7XG4gICAgICByZXMgPSBhd2FpdCByYXdGZXRjaE11bHRpcGFydCgnL3ZvaWNlL2RyYWZ0JywgZm9ybTIsIG5ld1Rva2VuKTtcbiAgICB9XG4gIH1cblxuICBpZiAoIXJlcy5vaykge1xuICAgIGNvbnN0IGVyciA9IGF3YWl0IHJlcy5qc29uKCkuY2F0Y2goKCkgPT4gKHsgZGV0YWlsOiBgSFRUUCAke3Jlcy5zdGF0dXN9YCB9KSkgYXMgeyBkZXRhaWw6IHN0cmluZyB9O1xuICAgIGlmIChyZXMuc3RhdHVzID09PSA0MjkpIHRocm93IG5ldyBFcnJvcihgTElNSVRfUkVBQ0hFRDoke2Vyci5kZXRhaWx9YCk7XG4gICAgdGhyb3cgbmV3IEVycm9yKGVyci5kZXRhaWwpO1xuICB9XG4gIHJldHVybiByZXMuanNvbigpIGFzIFByb21pc2U8Vm9pY2VEcmFmdFJlc3BvbnNlPjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlY29yZENvbnRleHRPdmVycmlkZShcbiAgZGV0ZWN0ZWRDb250ZXh0OiBzdHJpbmcsXG4gIHNlbGVjdGVkQ29udGV4dDogc3RyaW5nLFxuICBwbGF0Zm9ybTogc3RyaW5nIHwgdW5kZWZpbmVkLFxuICByZWNpcGllbnREb21haW46IHN0cmluZyB8IHVuZGVmaW5lZCxcbiAgdG9rZW46IHN0cmluZyxcbik6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCByZXF1ZXN0PHZvaWQ+KCcvY29udGV4dC9vdmVycmlkZScsIHtcbiAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICBkZXRlY3RlZF9jb250ZXh0OiBkZXRlY3RlZENvbnRleHQsXG4gICAgICBzZWxlY3RlZF9jb250ZXh0OiBzZWxlY3RlZENvbnRleHQsXG4gICAgICBwbGF0Zm9ybSxcbiAgICAgIHJlY2lwaWVudF9kb21haW46IHJlY2lwaWVudERvbWFpbixcbiAgICB9KSxcbiAgfSwgdG9rZW4pO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc3VibWl0Vm9pY2VGZWVkYmFjayhcbiAgc2Vzc2lvbklkOiBzdHJpbmcsXG4gIGFjY2VwdGVkOiBib29sZWFuLFxuICBlZGl0ZWREcmFmdDogc3RyaW5nIHwgbnVsbCxcbiAgdG9rZW46IHN0cmluZyxcbik6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCByZXF1ZXN0PHZvaWQ+KGAvdm9pY2UvZHJhZnQvJHtzZXNzaW9uSWR9L2ZlZWRiYWNrYCwge1xuICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgYWNjZXB0ZWQsIGVkaXRlZF9kcmFmdDogZWRpdGVkRHJhZnQgfSksXG4gIH0sIHRva2VuKTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBBdXRvRHJhZnRSZXNwb25zZSB7XG4gIGlkOiBzdHJpbmc7XG4gIGRyYWZ0OiBzdHJpbmc7XG4gIG1vZGVsOiBzdHJpbmc7XG4gIGxhdGVuY3lfbXM6IG51bWJlcjtcbiAgY29zdF91c2Q6IG51bWJlcjtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGF1dG9EcmFmdChcbiAgaW5jb21pbmdUZXh0OiBzdHJpbmcsXG4gIHRvbmU6IFRvbmUsXG4gIHRva2VuOiBzdHJpbmcsXG4gIGN0eD86IHsgcGxhdGZvcm0/OiBzdHJpbmc7IHJlY2lwaWVudF9kb21haW4/OiBzdHJpbmc7IHRocmVhZF9zdWJqZWN0Pzogc3RyaW5nIH0sXG4pOiBQcm9taXNlPEF1dG9EcmFmdFJlc3BvbnNlPiB7XG4gIHJldHVybiByZXF1ZXN0PEF1dG9EcmFmdFJlc3BvbnNlPignL2h1bWFuaXplL2F1dG8tZHJhZnQnLCB7XG4gICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBpbmNvbWluZ190ZXh0OiBpbmNvbWluZ1RleHQsIHRvbmUsIC4uLmN0eCB9KSxcbiAgfSwgdG9rZW4pO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc3VibWl0QXV0b0RyYWZ0RmVlZGJhY2soXG4gIGRyYWZ0SWQ6IHN0cmluZyxcbiAga2VwdDogYm9vbGVhbixcbiAgdG9rZW46IHN0cmluZyxcbik6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCByZXF1ZXN0PHZvaWQ+KGAvaHVtYW5pemUvYXV0by1kcmFmdC8ke2RyYWZ0SWR9L2ZlZWRiYWNrYCwge1xuICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsga2VwdCB9KSxcbiAgfSwgdG9rZW4pO1xufVxuIiwgImltcG9ydCB7IGdldFRva2Vucywgc2V0VG9rZW5zLCBjbGVhclRva2VucywgdHlwZSBBdXRoVG9rZW5zIH0gZnJvbSAnLi9saWIvYXV0aCc7XG5pbXBvcnQge1xuICBsb2dpbiwgcmVnaXN0ZXIsIGh1bWFuaXplLCBzdWJtaXRGZWVkYmFjaywgc3VibWl0RG5hU2FtcGxlcywgZ2V0RG5hUHJvZmlsZSxcbiAgdm9pY2VEcmFmdCwgc3VibWl0Vm9pY2VGZWVkYmFjaywgZGV0ZWN0Q29udGV4dCwgcmVjb3JkQ29udGV4dE92ZXJyaWRlLFxuICBhdXRvRHJhZnQsIHN1Ym1pdEF1dG9EcmFmdEZlZWRiYWNrLFxuICB0eXBlIFRvbmUsIHR5cGUgVm9pY2VPdXRwdXRUeXBlLCB0eXBlIEh1bWFuaXplQ29udGV4dCxcbn0gZnJvbSAnLi9saWIvYXBpJztcblxudHlwZSBNZXNzYWdlID1cbiAgfCB7IHR5cGU6ICdMT0dJTic7IHBheWxvYWQ6IHsgZW1haWw6IHN0cmluZzsgcGFzc3dvcmQ6IHN0cmluZyB9IH1cbiAgfCB7IHR5cGU6ICdSRUdJU1RFUic7IHBheWxvYWQ6IHsgZW1haWw6IHN0cmluZzsgcGFzc3dvcmQ6IHN0cmluZyB9IH1cbiAgfCB7IHR5cGU6ICdMT0dPVVQnIH1cbiAgfCB7IHR5cGU6ICdHRVRfQVVUSF9TVEFURScgfVxuICB8IHsgdHlwZTogJ0hVTUFOSVpFJzsgcGF5bG9hZDogeyB0ZXh0OiBzdHJpbmc7IHRvbmU6IFRvbmU7IGN0eD86IEh1bWFuaXplQ29udGV4dCB9IH1cbiAgfCB7IHR5cGU6ICdGRUVEQkFDSyc7IHBheWxvYWQ6IHsgcmV3cml0ZUlkOiBzdHJpbmc7IGFjdGlvbjogJ2FjY2VwdGVkJyB8ICdyZWplY3RlZCcgfSB9XG4gIHwgeyB0eXBlOiAnU1VCTUlUX0ROQSc7IHBheWxvYWQ6IHsgc2FtcGxlczogc3RyaW5nW10gfSB9XG4gIHwgeyB0eXBlOiAnR0VUX0ROQV9TVEFUVVMnIH1cbiAgfCB7IHR5cGU6ICdWT0lDRV9EUkFGVCc7IHBheWxvYWQ6IHsgYXVkaW9EYXRhOiBzdHJpbmc7IG1pbWVUeXBlOiBzdHJpbmc7IG91dHB1dFR5cGU6IFZvaWNlT3V0cHV0VHlwZSB9IH1cbiAgfCB7IHR5cGU6ICdWT0lDRV9GRUVEQkFDSyc7IHBheWxvYWQ6IHsgc2Vzc2lvbklkOiBzdHJpbmc7IGFjY2VwdGVkOiBib29sZWFuOyBlZGl0ZWREcmFmdDogc3RyaW5nIHwgbnVsbCB9IH1cbiAgfCB7IHR5cGU6ICdERVRFQ1RfQ09OVEVYVCc7IHBheWxvYWQ6IHsgcGxhdGZvcm0/OiBzdHJpbmc7IHJlY2lwaWVudF9kb21haW4/OiBzdHJpbmc7IHRocmVhZF9zdWJqZWN0Pzogc3RyaW5nIH0gfVxuICB8IHsgdHlwZTogJ0NPTlRFWFRfT1ZFUlJJREUnOyBwYXlsb2FkOiB7IGRldGVjdGVkX2NvbnRleHQ6IHN0cmluZzsgc2VsZWN0ZWRfY29udGV4dDogc3RyaW5nOyBwbGF0Zm9ybT86IHN0cmluZzsgcmVjaXBpZW50X2RvbWFpbj86IHN0cmluZyB9IH1cbiAgfCB7IHR5cGU6ICdBVVRPX0RSQUZUJzsgcGF5bG9hZDogeyBpbmNvbWluZ1RleHQ6IHN0cmluZzsgdG9uZTogVG9uZTsgY3R4PzogSHVtYW5pemVDb250ZXh0IH0gfVxuICB8IHsgdHlwZTogJ0FVVE9fRFJBRlRfRkVFREJBQ0snOyBwYXlsb2FkOiB7IGRyYWZ0SWQ6IHN0cmluZzsga2VwdDogYm9vbGVhbiB9IH07XG5cbmltcG9ydCB0eXBlIHsgRG5hUHJvZmlsZVJlc3BvbnNlLCBWb2ljZURyYWZ0UmVzcG9uc2UsIENvbnRleHREZXRlY3RSZXNwb25zZSwgQXV0b0RyYWZ0UmVzcG9uc2UgfSBmcm9tICcuL2xpYi9hcGknO1xuXG50eXBlIE1lc3NhZ2VSZXNwb25zZSA9XG4gIHwgeyBzdWNjZXNzOiB0cnVlOyB0b2tlbnM/OiBBdXRoVG9rZW5zOyBhdXRoZW50aWNhdGVkPzogYm9vbGVhbjsgZG5hUHJvZmlsZT86IERuYVByb2ZpbGVSZXNwb25zZSB8IG51bGwgfVxuICB8IHsgc3VjY2VzczogdHJ1ZTsgcmVzdWx0OiBBd2FpdGVkPFJldHVyblR5cGU8dHlwZW9mIGh1bWFuaXplPj4gfVxuICB8IHsgc3VjY2VzczogdHJ1ZTsgcmVzdWx0OiBWb2ljZURyYWZ0UmVzcG9uc2UgfVxuICB8IHsgc3VjY2VzczogdHJ1ZTsgcmVzdWx0OiBDb250ZXh0RGV0ZWN0UmVzcG9uc2UgfVxuICB8IHsgc3VjY2VzczogdHJ1ZTsgcmVzdWx0OiBBdXRvRHJhZnRSZXNwb25zZSB9XG4gIHwgeyBzdWNjZXNzOiB0cnVlIH1cbiAgfCB7IGVycm9yOiBzdHJpbmcgfTtcblxuY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKFxuICAobWVzc2FnZTogTWVzc2FnZSwgX3NlbmRlciwgc2VuZFJlc3BvbnNlOiAocjogTWVzc2FnZVJlc3BvbnNlKSA9PiB2b2lkKSA9PiB7XG4gICAgaGFuZGxlTWVzc2FnZShtZXNzYWdlKVxuICAgICAgLnRoZW4oc2VuZFJlc3BvbnNlKVxuICAgICAgLmNhdGNoKChlcnI6IEVycm9yKSA9PiBzZW5kUmVzcG9uc2UoeyBlcnJvcjogZXJyLm1lc3NhZ2UgfSkpO1xuICAgIHJldHVybiB0cnVlOyAvLyBrZWVwIGNoYW5uZWwgb3BlbiBmb3IgYXN5bmMgcmVzcG9uc2VcbiAgfSxcbik7XG5cbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZU1lc3NhZ2UobXNnOiBNZXNzYWdlKTogUHJvbWlzZTxNZXNzYWdlUmVzcG9uc2U+IHtcbiAgc3dpdGNoIChtc2cudHlwZSkge1xuICAgIGNhc2UgJ0xPR0lOJzoge1xuICAgICAgY29uc3QgcmVzcCA9IGF3YWl0IGxvZ2luKG1zZy5wYXlsb2FkLmVtYWlsLCBtc2cucGF5bG9hZC5wYXNzd29yZCk7XG4gICAgICBjb25zdCB0b2tlbnM6IEF1dGhUb2tlbnMgPSB7XG4gICAgICAgIGFjY2Vzc190b2tlbjogcmVzcC5hY2Nlc3NfdG9rZW4sXG4gICAgICAgIHJlZnJlc2hfdG9rZW46IHJlc3AucmVmcmVzaF90b2tlbixcbiAgICAgICAgZW1haWw6IG1zZy5wYXlsb2FkLmVtYWlsLFxuICAgICAgfTtcbiAgICAgIGF3YWl0IHNldFRva2Vucyh0b2tlbnMpO1xuICAgICAgdXBkYXRlQmFkZ2UodHJ1ZSk7XG4gICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCB0b2tlbnMgfTtcbiAgICB9XG5cbiAgICBjYXNlICdSRUdJU1RFUic6IHtcbiAgICAgIGNvbnN0IHJlc3AgPSBhd2FpdCByZWdpc3Rlcihtc2cucGF5bG9hZC5lbWFpbCwgbXNnLnBheWxvYWQucGFzc3dvcmQpO1xuICAgICAgY29uc3QgdG9rZW5zOiBBdXRoVG9rZW5zID0ge1xuICAgICAgICBhY2Nlc3NfdG9rZW46IHJlc3AuYWNjZXNzX3Rva2VuLFxuICAgICAgICByZWZyZXNoX3Rva2VuOiByZXNwLnJlZnJlc2hfdG9rZW4sXG4gICAgICAgIGVtYWlsOiBtc2cucGF5bG9hZC5lbWFpbCxcbiAgICAgIH07XG4gICAgICBhd2FpdCBzZXRUb2tlbnModG9rZW5zKTtcbiAgICAgIHVwZGF0ZUJhZGdlKHRydWUpO1xuICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgdG9rZW5zIH07XG4gICAgfVxuXG4gICAgY2FzZSAnTE9HT1VUJzoge1xuICAgICAgYXdhaXQgY2xlYXJUb2tlbnMoKTtcbiAgICAgIHVwZGF0ZUJhZGdlKGZhbHNlKTtcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcbiAgICB9XG5cbiAgICBjYXNlICdHRVRfQVVUSF9TVEFURSc6IHtcbiAgICAgIGNvbnN0IHRva2VucyA9IGF3YWl0IGdldFRva2VucygpO1xuICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgYXV0aGVudGljYXRlZDogdG9rZW5zICE9PSBudWxsLCB0b2tlbnM6IHRva2VucyA/PyB1bmRlZmluZWQgfTtcbiAgICB9XG5cbiAgICBjYXNlICdIVU1BTklaRSc6IHtcbiAgICAgIGNvbnN0IHRva2VucyA9IGF3YWl0IGdldFRva2VucygpO1xuICAgICAgaWYgKCF0b2tlbnMpIHRocm93IG5ldyBFcnJvcignTm90IGxvZ2dlZCBpbi4gUGxlYXNlIGxvZyBpbiB2aWEgdGhlIGV4dGVuc2lvbiBwb3B1cC4nKTtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGh1bWFuaXplKFxuICAgICAgICBtc2cucGF5bG9hZC50ZXh0LCBtc2cucGF5bG9hZC50b25lLCB0b2tlbnMuYWNjZXNzX3Rva2VuLCBtc2cucGF5bG9hZC5jdHhcbiAgICAgICk7XG4gICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlLCByZXN1bHQgfTtcbiAgICB9XG5cbiAgICBjYXNlICdGRUVEQkFDSyc6IHtcbiAgICAgIGNvbnN0IHRva2VucyA9IGF3YWl0IGdldFRva2VucygpO1xuICAgICAgaWYgKCF0b2tlbnMpIHRocm93IG5ldyBFcnJvcignTm90IGF1dGhlbnRpY2F0ZWQnKTtcbiAgICAgIGF3YWl0IHN1Ym1pdEZlZWRiYWNrKG1zZy5wYXlsb2FkLnJld3JpdGVJZCwgbXNnLnBheWxvYWQuYWN0aW9uLCB0b2tlbnMuYWNjZXNzX3Rva2VuKTtcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcbiAgICB9XG5cbiAgICBjYXNlICdTVUJNSVRfRE5BJzoge1xuICAgICAgY29uc3QgdG9rZW5zID0gYXdhaXQgZ2V0VG9rZW5zKCk7XG4gICAgICBpZiAoIXRva2VucykgdGhyb3cgbmV3IEVycm9yKCdOb3QgYXV0aGVudGljYXRlZCcpO1xuICAgICAgYXdhaXQgc3VibWl0RG5hU2FtcGxlcyhtc2cucGF5bG9hZC5zYW1wbGVzLCB0b2tlbnMuYWNjZXNzX3Rva2VuKTtcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcbiAgICB9XG5cbiAgICBjYXNlICdHRVRfRE5BX1NUQVRVUyc6IHtcbiAgICAgIGNvbnN0IHRva2VucyA9IGF3YWl0IGdldFRva2VucygpO1xuICAgICAgaWYgKCF0b2tlbnMpIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGRuYVByb2ZpbGU6IG51bGwgfTtcbiAgICAgIGNvbnN0IHByb2ZpbGUgPSBhd2FpdCBnZXREbmFQcm9maWxlKHRva2Vucy5hY2Nlc3NfdG9rZW4pO1xuICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgZG5hUHJvZmlsZTogcHJvZmlsZSB9O1xuICAgIH1cblxuICAgIGNhc2UgJ1ZPSUNFX0RSQUZUJzoge1xuICAgICAgY29uc3QgdG9rZW5zID0gYXdhaXQgZ2V0VG9rZW5zKCk7XG4gICAgICBpZiAoIXRva2VucykgdGhyb3cgbmV3IEVycm9yKCdOb3QgbG9nZ2VkIGluLiBQbGVhc2UgbG9nIGluIHZpYSB0aGUgZXh0ZW5zaW9uIHBvcHVwLicpO1xuICAgICAgLy8gUmVjb25zdHJ1Y3QgQmxvYiBmcm9tIGJhc2U2NCBkYXRhIFVSTCBwYXNzZWQgZnJvbSBjb250ZW50IHNjcmlwdFxuICAgICAgY29uc3QgeyBhdWRpb0RhdGEsIG1pbWVUeXBlLCBvdXRwdXRUeXBlIH0gPSBtc2cucGF5bG9hZDtcbiAgICAgIGNvbnN0IGJpbmFyeSA9IGF0b2IoYXVkaW9EYXRhKTtcbiAgICAgIGNvbnN0IGJ5dGVzID0gbmV3IFVpbnQ4QXJyYXkoYmluYXJ5Lmxlbmd0aCk7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGJpbmFyeS5sZW5ndGg7IGkrKykgYnl0ZXNbaV0gPSBiaW5hcnkuY2hhckNvZGVBdChpKTtcbiAgICAgIGNvbnN0IGJsb2IgPSBuZXcgQmxvYihbYnl0ZXNdLCB7IHR5cGU6IG1pbWVUeXBlIH0pO1xuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdm9pY2VEcmFmdChibG9iLCBvdXRwdXRUeXBlLCB0b2tlbnMuYWNjZXNzX3Rva2VuKTtcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIHJlc3VsdCB9O1xuICAgIH1cblxuICAgIGNhc2UgJ0RFVEVDVF9DT05URVhUJzoge1xuICAgICAgY29uc3QgdG9rZW5zID0gYXdhaXQgZ2V0VG9rZW5zKCk7XG4gICAgICBpZiAoIXRva2VucykgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgcmVzdWx0OiB7IGNvbnRleHRfdHdpbjogJ3Byb2Zlc3Npb25hbCcsIHRvbmVfZ3VpZGFuY2U6ICcnIH0gfTtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGRldGVjdENvbnRleHQoXG4gICAgICAgIG1zZy5wYXlsb2FkLnBsYXRmb3JtID8/ICd1bmtub3duJyxcbiAgICAgICAgbXNnLnBheWxvYWQucmVjaXBpZW50X2RvbWFpbiA/PyBudWxsLFxuICAgICAgICBtc2cucGF5bG9hZC50aHJlYWRfc3ViamVjdCA/PyBudWxsLFxuICAgICAgICB0b2tlbnMuYWNjZXNzX3Rva2VuLFxuICAgICAgKTtcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIHJlc3VsdCB9O1xuICAgIH1cblxuICAgIGNhc2UgJ0NPTlRFWFRfT1ZFUlJJREUnOiB7XG4gICAgICBjb25zdCB0b2tlbnMgPSBhd2FpdCBnZXRUb2tlbnMoKTtcbiAgICAgIGlmICghdG9rZW5zKSByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XG4gICAgICByZWNvcmRDb250ZXh0T3ZlcnJpZGUoXG4gICAgICAgIG1zZy5wYXlsb2FkLmRldGVjdGVkX2NvbnRleHQsXG4gICAgICAgIG1zZy5wYXlsb2FkLnNlbGVjdGVkX2NvbnRleHQsXG4gICAgICAgIG1zZy5wYXlsb2FkLnBsYXRmb3JtLFxuICAgICAgICBtc2cucGF5bG9hZC5yZWNpcGllbnRfZG9tYWluLFxuICAgICAgICB0b2tlbnMuYWNjZXNzX3Rva2VuLFxuICAgICAgKS5jYXRjaCgoKSA9PiB7fSk7IC8vIGZpcmUtYW5kLWZvcmdldFxuICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xuICAgIH1cblxuICAgIGNhc2UgJ1ZPSUNFX0ZFRURCQUNLJzoge1xuICAgICAgY29uc3QgdG9rZW5zID0gYXdhaXQgZ2V0VG9rZW5zKCk7XG4gICAgICBpZiAoIXRva2VucykgdGhyb3cgbmV3IEVycm9yKCdOb3QgYXV0aGVudGljYXRlZCcpO1xuICAgICAgYXdhaXQgc3VibWl0Vm9pY2VGZWVkYmFjayhcbiAgICAgICAgbXNnLnBheWxvYWQuc2Vzc2lvbklkLFxuICAgICAgICBtc2cucGF5bG9hZC5hY2NlcHRlZCxcbiAgICAgICAgbXNnLnBheWxvYWQuZWRpdGVkRHJhZnQsXG4gICAgICAgIHRva2Vucy5hY2Nlc3NfdG9rZW4sXG4gICAgICApO1xuICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xuICAgIH1cblxuICAgIGNhc2UgJ0FVVE9fRFJBRlQnOiB7XG4gICAgICBjb25zdCB0b2tlbnMgPSBhd2FpdCBnZXRUb2tlbnMoKTtcbiAgICAgIGlmICghdG9rZW5zKSB0aHJvdyBuZXcgRXJyb3IoJ05vdCBsb2dnZWQgaW4uIFBsZWFzZSBsb2cgaW4gdmlhIHRoZSBleHRlbnNpb24gcG9wdXAuJyk7XG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBhdXRvRHJhZnQoXG4gICAgICAgIG1zZy5wYXlsb2FkLmluY29taW5nVGV4dCxcbiAgICAgICAgbXNnLnBheWxvYWQudG9uZSxcbiAgICAgICAgdG9rZW5zLmFjY2Vzc190b2tlbixcbiAgICAgICAgbXNnLnBheWxvYWQuY3R4LFxuICAgICAgKTtcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIHJlc3VsdCB9O1xuICAgIH1cblxuICAgIGNhc2UgJ0FVVE9fRFJBRlRfRkVFREJBQ0snOiB7XG4gICAgICBjb25zdCB0b2tlbnMgPSBhd2FpdCBnZXRUb2tlbnMoKTtcbiAgICAgIGlmICghdG9rZW5zKSByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XG4gICAgICBzdWJtaXRBdXRvRHJhZnRGZWVkYmFjayhtc2cucGF5bG9hZC5kcmFmdElkLCBtc2cucGF5bG9hZC5rZXB0LCB0b2tlbnMuYWNjZXNzX3Rva2VuKVxuICAgICAgICAuY2F0Y2goKCkgPT4ge30pOyAvLyBmaXJlLWFuZC1mb3JnZXRcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcbiAgICB9XG5cbiAgICBkZWZhdWx0OlxuICAgICAgdGhyb3cgbmV3IEVycm9yKCdVbmtub3duIG1lc3NhZ2UgdHlwZScpO1xuICB9XG59XG5cbmZ1bmN0aW9uIHVwZGF0ZUJhZGdlKGF1dGhlbnRpY2F0ZWQ6IGJvb2xlYW4pOiB2b2lkIHtcbiAgY2hyb21lLmFjdGlvbi5zZXRCYWRnZVRleHQoeyB0ZXh0OiBhdXRoZW50aWNhdGVkID8gJycgOiAnJyB9KTtcbn1cblxuLy8gUmVzdG9yZSBiYWRnZSBvbiBzdGFydHVwXG5nZXRUb2tlbnMoKS50aGVuKCh0KSA9PiB1cGRhdGVCYWRnZSh0ICE9PSBudWxsKSk7XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7QUFBQSxNQUFNLGNBQWM7QUFRcEIsaUJBQXNCLFlBQXdDO0FBQzVELFVBQU0sU0FBUyxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksV0FBVztBQUN6RCxXQUFRLE9BQU8sV0FBVyxLQUFvQjtBQUFBLEVBQ2hEO0FBRUEsaUJBQXNCLFVBQVUsUUFBbUM7QUFDakUsVUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEdBQUcsT0FBTyxDQUFDO0FBQUEsRUFDMUQ7QUFFQSxpQkFBc0IsY0FBNkI7QUFDakQsVUFBTSxPQUFPLFFBQVEsTUFBTSxPQUFPLFdBQVc7QUFBQSxFQUMvQzs7O0FDakJPLE1BQU0sV0FBVztBQWlEeEIsaUJBQWUsU0FBUyxNQUFjLFNBQXNCLE9BQW1DO0FBQzdGLFVBQU0sVUFBa0MsRUFBRSxnQkFBZ0IsbUJBQW1CO0FBQzdFLFFBQUksTUFBTyxTQUFRLGVBQWUsSUFBSSxVQUFVLEtBQUs7QUFDckQsV0FBTyxNQUFNLEdBQUcsUUFBUSxHQUFHLElBQUksSUFBSSxFQUFFLEdBQUcsU0FBUyxRQUFRLENBQUM7QUFBQSxFQUM1RDtBQUVBLGlCQUFlLGtCQUNiLE1BQ0EsTUFDQSxPQUNtQjtBQUVuQixXQUFPLE1BQU0sR0FBRyxRQUFRLEdBQUcsSUFBSSxJQUFJO0FBQUEsTUFDakMsUUFBUTtBQUFBLE1BQ1IsU0FBUyxFQUFFLGVBQWUsVUFBVSxLQUFLLEdBQUc7QUFBQSxNQUM1QztBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFFQSxpQkFBZSxhQUFxQztBQUNsRCxVQUFNLFNBQVMsTUFBTSxVQUFVO0FBQy9CLFFBQUksQ0FBQyxRQUFRLGNBQWUsUUFBTztBQUNuQyxRQUFJO0FBQ0YsWUFBTSxNQUFNLE1BQU0sU0FBUyxpQkFBaUI7QUFBQSxRQUMxQyxRQUFRO0FBQUEsUUFDUixNQUFNLEtBQUssVUFBVSxFQUFFLGVBQWUsT0FBTyxjQUFjLENBQUM7QUFBQSxNQUM5RCxDQUFDO0FBQ0QsVUFBSSxDQUFDLElBQUksR0FBSSxRQUFPO0FBQ3BCLFlBQU0sT0FBTyxNQUFNLElBQUksS0FBSztBQUM1QixZQUFNLFVBQVUsRUFBRSxHQUFHLFFBQVEsY0FBYyxLQUFLLGNBQWMsZUFBZSxLQUFLLGNBQWMsQ0FBQztBQUNqRyxhQUFPLEtBQUs7QUFBQSxJQUNkLFFBQVE7QUFDTixhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFFQSxpQkFBZSxRQUFXLE1BQWMsU0FBc0IsT0FBNEI7QUFDeEYsUUFBSSxNQUFNLE1BQU0sU0FBUyxNQUFNLFNBQVMsS0FBSztBQUc3QyxRQUFJLElBQUksV0FBVyxPQUFPLE9BQU87QUFDL0IsWUFBTSxXQUFXLE1BQU0sV0FBVztBQUNsQyxVQUFJLFVBQVU7QUFDWixjQUFNLE1BQU0sU0FBUyxNQUFNLFNBQVMsUUFBUTtBQUFBLE1BQzlDO0FBQUEsSUFDRjtBQUVBLFFBQUksQ0FBQyxJQUFJLElBQUk7QUFDWCxZQUFNLE1BQU0sTUFBTSxJQUFJLEtBQUssRUFBRSxNQUFNLE9BQU8sRUFBRSxRQUFRLFFBQVEsSUFBSSxNQUFNLEdBQUcsRUFBRTtBQUMzRSxVQUFJLElBQUksV0FBVyxJQUFLLE9BQU0sSUFBSSxNQUFNLGlCQUFpQixJQUFJLE1BQU0sRUFBRTtBQUNyRSxZQUFNLElBQUksTUFBTSxJQUFJLE1BQU07QUFBQSxJQUM1QjtBQUNBLFFBQUksSUFBSSxXQUFXLElBQUssUUFBTztBQUMvQixXQUFPLElBQUksS0FBSztBQUFBLEVBQ2xCO0FBRUEsaUJBQXNCLE1BQU0sT0FBZSxVQUEwQztBQUNuRixXQUFPLFFBQXVCLGVBQWU7QUFBQSxNQUMzQyxRQUFRO0FBQUEsTUFDUixNQUFNLEtBQUssVUFBVSxFQUFFLE9BQU8sU0FBUyxDQUFDO0FBQUEsSUFDMUMsQ0FBQztBQUFBLEVBQ0g7QUFFQSxpQkFBc0IsU0FBUyxPQUFlLFVBQTBDO0FBQ3RGLFVBQU0sUUFBaUIsa0JBQWtCO0FBQUEsTUFDdkMsUUFBUTtBQUFBLE1BQ1IsTUFBTSxLQUFLLFVBQVUsRUFBRSxPQUFPLFNBQVMsQ0FBQztBQUFBLElBQzFDLENBQUM7QUFDRCxXQUFPLE1BQU0sT0FBTyxRQUFRO0FBQUEsRUFDOUI7QUFFQSxpQkFBc0IsaUJBQWlCLFVBQW9CLE9BQThCO0FBQ3ZGLFVBQU0sVUFBVSxTQUFTLElBQUksQ0FBQyxVQUFVLEVBQUUsUUFBUSxTQUFTLEtBQUssRUFBRTtBQUNsRSxVQUFNLFFBQWMsZ0JBQWdCO0FBQUEsTUFDbEMsUUFBUTtBQUFBLE1BQ1IsTUFBTSxLQUFLLFVBQVUsRUFBRSxRQUFRLENBQUM7QUFBQSxJQUNsQyxHQUFHLEtBQUs7QUFBQSxFQUNWO0FBRUEsaUJBQXNCLGNBQWMsT0FBbUQ7QUFDckYsUUFBSTtBQUNGLGFBQU8sTUFBTSxRQUE0QixnQkFBZ0IsRUFBRSxRQUFRLE1BQU0sR0FBRyxLQUFLO0FBQUEsSUFDbkYsUUFBUTtBQUNOLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQWNBLGlCQUFzQixTQUNwQixNQUNBLE1BQ0EsT0FDQSxLQUMwQjtBQUMxQixXQUFPLFFBQXlCLGFBQWE7QUFBQSxNQUMzQyxRQUFRO0FBQUEsTUFDUixNQUFNLEtBQUssVUFBVSxFQUFFLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQztBQUFBLElBQzdDLEdBQUcsS0FBSztBQUFBLEVBQ1Y7QUFFQSxpQkFBc0IsY0FDcEIsVUFDQSxpQkFDQSxlQUNBLE9BQ2dDO0FBQ2hDLFdBQU8sUUFBK0IsbUJBQW1CO0FBQUEsTUFDdkQsUUFBUTtBQUFBLE1BQ1IsTUFBTSxLQUFLLFVBQVU7QUFBQSxRQUNuQjtBQUFBLFFBQ0Esa0JBQWtCO0FBQUEsUUFDbEIsZ0JBQWdCO0FBQUEsTUFDbEIsQ0FBQztBQUFBLElBQ0gsR0FBRyxLQUFLO0FBQUEsRUFDVjtBQUVBLGlCQUFzQixlQUNwQixXQUNBLFFBQ0EsT0FDZTtBQUNmLFVBQU0sUUFBYyxhQUFhLFNBQVMsYUFBYTtBQUFBLE1BQ3JELFFBQVE7QUFBQSxNQUNSLE1BQU0sS0FBSyxVQUFVLEVBQUUsT0FBTyxDQUFDO0FBQUEsSUFDakMsR0FBRyxLQUFLO0FBQUEsRUFDVjtBQUVBLGlCQUFzQixXQUNwQixXQUNBLFlBQ0EsT0FDNkI7QUFDN0IsVUFBTSxPQUFPLElBQUksU0FBUztBQUMxQixTQUFLLE9BQU8sU0FBUyxXQUFXLGdCQUFnQjtBQUNoRCxTQUFLLE9BQU8sZUFBZSxVQUFVO0FBRXJDLFFBQUksTUFBTSxNQUFNLGtCQUFrQixnQkFBZ0IsTUFBTSxLQUFLO0FBRTdELFFBQUksSUFBSSxXQUFXLEtBQUs7QUFDdEIsWUFBTSxXQUFXLE1BQU0sV0FBVztBQUNsQyxVQUFJLFVBQVU7QUFDWixjQUFNLFFBQVEsSUFBSSxTQUFTO0FBQzNCLGNBQU0sT0FBTyxTQUFTLFdBQVcsZ0JBQWdCO0FBQ2pELGNBQU0sT0FBTyxlQUFlLFVBQVU7QUFDdEMsY0FBTSxNQUFNLGtCQUFrQixnQkFBZ0IsT0FBTyxRQUFRO0FBQUEsTUFDL0Q7QUFBQSxJQUNGO0FBRUEsUUFBSSxDQUFDLElBQUksSUFBSTtBQUNYLFlBQU0sTUFBTSxNQUFNLElBQUksS0FBSyxFQUFFLE1BQU0sT0FBTyxFQUFFLFFBQVEsUUFBUSxJQUFJLE1BQU0sR0FBRyxFQUFFO0FBQzNFLFVBQUksSUFBSSxXQUFXLElBQUssT0FBTSxJQUFJLE1BQU0saUJBQWlCLElBQUksTUFBTSxFQUFFO0FBQ3JFLFlBQU0sSUFBSSxNQUFNLElBQUksTUFBTTtBQUFBLElBQzVCO0FBQ0EsV0FBTyxJQUFJLEtBQUs7QUFBQSxFQUNsQjtBQUVBLGlCQUFzQixzQkFDcEIsaUJBQ0EsaUJBQ0EsVUFDQSxpQkFDQSxPQUNlO0FBQ2YsVUFBTSxRQUFjLHFCQUFxQjtBQUFBLE1BQ3ZDLFFBQVE7QUFBQSxNQUNSLE1BQU0sS0FBSyxVQUFVO0FBQUEsUUFDbkIsa0JBQWtCO0FBQUEsUUFDbEIsa0JBQWtCO0FBQUEsUUFDbEI7QUFBQSxRQUNBLGtCQUFrQjtBQUFBLE1BQ3BCLENBQUM7QUFBQSxJQUNILEdBQUcsS0FBSztBQUFBLEVBQ1Y7QUFFQSxpQkFBc0Isb0JBQ3BCLFdBQ0EsVUFDQSxhQUNBLE9BQ2U7QUFDZixVQUFNLFFBQWMsZ0JBQWdCLFNBQVMsYUFBYTtBQUFBLE1BQ3hELFFBQVE7QUFBQSxNQUNSLE1BQU0sS0FBSyxVQUFVLEVBQUUsVUFBVSxjQUFjLFlBQVksQ0FBQztBQUFBLElBQzlELEdBQUcsS0FBSztBQUFBLEVBQ1Y7QUFVQSxpQkFBc0IsVUFDcEIsY0FDQSxNQUNBLE9BQ0EsS0FDNEI7QUFDNUIsV0FBTyxRQUEyQix3QkFBd0I7QUFBQSxNQUN4RCxRQUFRO0FBQUEsTUFDUixNQUFNLEtBQUssVUFBVSxFQUFFLGVBQWUsY0FBYyxNQUFNLEdBQUcsSUFBSSxDQUFDO0FBQUEsSUFDcEUsR0FBRyxLQUFLO0FBQUEsRUFDVjtBQUVBLGlCQUFzQix3QkFDcEIsU0FDQSxNQUNBLE9BQ2U7QUFDZixVQUFNLFFBQWMsd0JBQXdCLE9BQU8sYUFBYTtBQUFBLE1BQzlELFFBQVE7QUFBQSxNQUNSLE1BQU0sS0FBSyxVQUFVLEVBQUUsS0FBSyxDQUFDO0FBQUEsSUFDL0IsR0FBRyxLQUFLO0FBQUEsRUFDVjs7O0FDbFBBLFNBQU8sUUFBUSxVQUFVO0FBQUEsSUFDdkIsQ0FBQyxTQUFrQixTQUFTLGlCQUErQztBQUN6RSxvQkFBYyxPQUFPLEVBQ2xCLEtBQUssWUFBWSxFQUNqQixNQUFNLENBQUMsUUFBZSxhQUFhLEVBQUUsT0FBTyxJQUFJLFFBQVEsQ0FBQyxDQUFDO0FBQzdELGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUVBLGlCQUFlLGNBQWMsS0FBd0M7QUFDbkUsWUFBUSxJQUFJLE1BQU07QUFBQSxNQUNoQixLQUFLLFNBQVM7QUFDWixjQUFNLE9BQU8sTUFBTSxNQUFNLElBQUksUUFBUSxPQUFPLElBQUksUUFBUSxRQUFRO0FBQ2hFLGNBQU0sU0FBcUI7QUFBQSxVQUN6QixjQUFjLEtBQUs7QUFBQSxVQUNuQixlQUFlLEtBQUs7QUFBQSxVQUNwQixPQUFPLElBQUksUUFBUTtBQUFBLFFBQ3JCO0FBQ0EsY0FBTSxVQUFVLE1BQU07QUFDdEIsb0JBQVksSUFBSTtBQUNoQixlQUFPLEVBQUUsU0FBUyxNQUFNLE9BQU87QUFBQSxNQUNqQztBQUFBLE1BRUEsS0FBSyxZQUFZO0FBQ2YsY0FBTSxPQUFPLE1BQU0sU0FBUyxJQUFJLFFBQVEsT0FBTyxJQUFJLFFBQVEsUUFBUTtBQUNuRSxjQUFNLFNBQXFCO0FBQUEsVUFDekIsY0FBYyxLQUFLO0FBQUEsVUFDbkIsZUFBZSxLQUFLO0FBQUEsVUFDcEIsT0FBTyxJQUFJLFFBQVE7QUFBQSxRQUNyQjtBQUNBLGNBQU0sVUFBVSxNQUFNO0FBQ3RCLG9CQUFZLElBQUk7QUFDaEIsZUFBTyxFQUFFLFNBQVMsTUFBTSxPQUFPO0FBQUEsTUFDakM7QUFBQSxNQUVBLEtBQUssVUFBVTtBQUNiLGNBQU0sWUFBWTtBQUNsQixvQkFBWSxLQUFLO0FBQ2pCLGVBQU8sRUFBRSxTQUFTLEtBQUs7QUFBQSxNQUN6QjtBQUFBLE1BRUEsS0FBSyxrQkFBa0I7QUFDckIsY0FBTSxTQUFTLE1BQU0sVUFBVTtBQUMvQixlQUFPLEVBQUUsU0FBUyxNQUFNLGVBQWUsV0FBVyxNQUFNLFFBQVEsVUFBVSxPQUFVO0FBQUEsTUFDdEY7QUFBQSxNQUVBLEtBQUssWUFBWTtBQUNmLGNBQU0sU0FBUyxNQUFNLFVBQVU7QUFDL0IsWUFBSSxDQUFDLE9BQVEsT0FBTSxJQUFJLE1BQU0sdURBQXVEO0FBQ3BGLGNBQU0sU0FBUyxNQUFNO0FBQUEsVUFDbkIsSUFBSSxRQUFRO0FBQUEsVUFBTSxJQUFJLFFBQVE7QUFBQSxVQUFNLE9BQU87QUFBQSxVQUFjLElBQUksUUFBUTtBQUFBLFFBQ3ZFO0FBQ0EsZUFBTyxFQUFFLFNBQVMsTUFBTSxPQUFPO0FBQUEsTUFDakM7QUFBQSxNQUVBLEtBQUssWUFBWTtBQUNmLGNBQU0sU0FBUyxNQUFNLFVBQVU7QUFDL0IsWUFBSSxDQUFDLE9BQVEsT0FBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQ2hELGNBQU0sZUFBZSxJQUFJLFFBQVEsV0FBVyxJQUFJLFFBQVEsUUFBUSxPQUFPLFlBQVk7QUFDbkYsZUFBTyxFQUFFLFNBQVMsS0FBSztBQUFBLE1BQ3pCO0FBQUEsTUFFQSxLQUFLLGNBQWM7QUFDakIsY0FBTSxTQUFTLE1BQU0sVUFBVTtBQUMvQixZQUFJLENBQUMsT0FBUSxPQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDaEQsY0FBTSxpQkFBaUIsSUFBSSxRQUFRLFNBQVMsT0FBTyxZQUFZO0FBQy9ELGVBQU8sRUFBRSxTQUFTLEtBQUs7QUFBQSxNQUN6QjtBQUFBLE1BRUEsS0FBSyxrQkFBa0I7QUFDckIsY0FBTSxTQUFTLE1BQU0sVUFBVTtBQUMvQixZQUFJLENBQUMsT0FBUSxRQUFPLEVBQUUsU0FBUyxNQUFNLFlBQVksS0FBSztBQUN0RCxjQUFNLFVBQVUsTUFBTSxjQUFjLE9BQU8sWUFBWTtBQUN2RCxlQUFPLEVBQUUsU0FBUyxNQUFNLFlBQVksUUFBUTtBQUFBLE1BQzlDO0FBQUEsTUFFQSxLQUFLLGVBQWU7QUFDbEIsY0FBTSxTQUFTLE1BQU0sVUFBVTtBQUMvQixZQUFJLENBQUMsT0FBUSxPQUFNLElBQUksTUFBTSx1REFBdUQ7QUFFcEYsY0FBTSxFQUFFLFdBQVcsVUFBVSxXQUFXLElBQUksSUFBSTtBQUNoRCxjQUFNLFNBQVMsS0FBSyxTQUFTO0FBQzdCLGNBQU0sUUFBUSxJQUFJLFdBQVcsT0FBTyxNQUFNO0FBQzFDLGlCQUFTLElBQUksR0FBRyxJQUFJLE9BQU8sUUFBUSxJQUFLLE9BQU0sQ0FBQyxJQUFJLE9BQU8sV0FBVyxDQUFDO0FBQ3RFLGNBQU0sT0FBTyxJQUFJLEtBQUssQ0FBQyxLQUFLLEdBQUcsRUFBRSxNQUFNLFNBQVMsQ0FBQztBQUNqRCxjQUFNLFNBQVMsTUFBTSxXQUFXLE1BQU0sWUFBWSxPQUFPLFlBQVk7QUFDckUsZUFBTyxFQUFFLFNBQVMsTUFBTSxPQUFPO0FBQUEsTUFDakM7QUFBQSxNQUVBLEtBQUssa0JBQWtCO0FBQ3JCLGNBQU0sU0FBUyxNQUFNLFVBQVU7QUFDL0IsWUFBSSxDQUFDLE9BQVEsUUFBTyxFQUFFLFNBQVMsTUFBTSxRQUFRLEVBQUUsY0FBYyxnQkFBZ0IsZUFBZSxHQUFHLEVBQUU7QUFDakcsY0FBTSxTQUFTLE1BQU07QUFBQSxVQUNuQixJQUFJLFFBQVEsWUFBWTtBQUFBLFVBQ3hCLElBQUksUUFBUSxvQkFBb0I7QUFBQSxVQUNoQyxJQUFJLFFBQVEsa0JBQWtCO0FBQUEsVUFDOUIsT0FBTztBQUFBLFFBQ1Q7QUFDQSxlQUFPLEVBQUUsU0FBUyxNQUFNLE9BQU87QUFBQSxNQUNqQztBQUFBLE1BRUEsS0FBSyxvQkFBb0I7QUFDdkIsY0FBTSxTQUFTLE1BQU0sVUFBVTtBQUMvQixZQUFJLENBQUMsT0FBUSxRQUFPLEVBQUUsU0FBUyxLQUFLO0FBQ3BDO0FBQUEsVUFDRSxJQUFJLFFBQVE7QUFBQSxVQUNaLElBQUksUUFBUTtBQUFBLFVBQ1osSUFBSSxRQUFRO0FBQUEsVUFDWixJQUFJLFFBQVE7QUFBQSxVQUNaLE9BQU87QUFBQSxRQUNULEVBQUUsTUFBTSxNQUFNO0FBQUEsUUFBQyxDQUFDO0FBQ2hCLGVBQU8sRUFBRSxTQUFTLEtBQUs7QUFBQSxNQUN6QjtBQUFBLE1BRUEsS0FBSyxrQkFBa0I7QUFDckIsY0FBTSxTQUFTLE1BQU0sVUFBVTtBQUMvQixZQUFJLENBQUMsT0FBUSxPQUFNLElBQUksTUFBTSxtQkFBbUI7QUFDaEQsY0FBTTtBQUFBLFVBQ0osSUFBSSxRQUFRO0FBQUEsVUFDWixJQUFJLFFBQVE7QUFBQSxVQUNaLElBQUksUUFBUTtBQUFBLFVBQ1osT0FBTztBQUFBLFFBQ1Q7QUFDQSxlQUFPLEVBQUUsU0FBUyxLQUFLO0FBQUEsTUFDekI7QUFBQSxNQUVBLEtBQUssY0FBYztBQUNqQixjQUFNLFNBQVMsTUFBTSxVQUFVO0FBQy9CLFlBQUksQ0FBQyxPQUFRLE9BQU0sSUFBSSxNQUFNLHVEQUF1RDtBQUNwRixjQUFNLFNBQVMsTUFBTTtBQUFBLFVBQ25CLElBQUksUUFBUTtBQUFBLFVBQ1osSUFBSSxRQUFRO0FBQUEsVUFDWixPQUFPO0FBQUEsVUFDUCxJQUFJLFFBQVE7QUFBQSxRQUNkO0FBQ0EsZUFBTyxFQUFFLFNBQVMsTUFBTSxPQUFPO0FBQUEsTUFDakM7QUFBQSxNQUVBLEtBQUssdUJBQXVCO0FBQzFCLGNBQU0sU0FBUyxNQUFNLFVBQVU7QUFDL0IsWUFBSSxDQUFDLE9BQVEsUUFBTyxFQUFFLFNBQVMsS0FBSztBQUNwQyxnQ0FBd0IsSUFBSSxRQUFRLFNBQVMsSUFBSSxRQUFRLE1BQU0sT0FBTyxZQUFZLEVBQy9FLE1BQU0sTUFBTTtBQUFBLFFBQUMsQ0FBQztBQUNqQixlQUFPLEVBQUUsU0FBUyxLQUFLO0FBQUEsTUFDekI7QUFBQSxNQUVBO0FBQ0UsY0FBTSxJQUFJLE1BQU0sc0JBQXNCO0FBQUEsSUFDMUM7QUFBQSxFQUNGO0FBRUEsV0FBUyxZQUFZLGVBQThCO0FBQ2pELFdBQU8sT0FBTyxhQUFhLEVBQUUsTUFBTSxnQkFBZ0IsS0FBSyxHQUFHLENBQUM7QUFBQSxFQUM5RDtBQUdBLFlBQVUsRUFBRSxLQUFLLENBQUMsTUFBTSxZQUFZLE1BQU0sSUFBSSxDQUFDOyIsCiAgIm5hbWVzIjogW10KfQo=
