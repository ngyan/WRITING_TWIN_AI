"use strict";
(() => {
  // src/lib/compose-detector.ts
  var lastInteraction = /* @__PURE__ */ new WeakMap();
  var RECENT_MS = 3e4;
  function isEditable(el) {
    return el.tagName === "TEXTAREA" || el.getAttribute("contenteditable") === "true" || el.getAttribute("role") === "textbox";
  }
  document.addEventListener("click", (e) => {
    let node = e.target;
    while (node) {
      if (isEditable(node)) {
        lastInteraction.set(node, Date.now());
        break;
      }
      node = node.parentElement;
    }
  }, { capture: true, passive: true });
  document.addEventListener("focusin", (e) => {
    if (e.target instanceof Element && isEditable(e.target)) {
      lastInteraction.set(e.target, Date.now());
    }
  }, { capture: true, passive: true });
  var SEND_LABEL_RE = /\b(send|reply|submit|post|comment|전송|보내기|답장)\b/i;
  function isVisible(el) {
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return false;
    const s = window.getComputedStyle(el);
    return s.display !== "none" && s.visibility !== "hidden" && parseFloat(s.opacity) > 0;
  }
  function hasNearbySendControl(el, extraHints = []) {
    let node = el;
    for (let i = 0; i < 8 && node; i++, node = node.parentElement) {
      const sel = ["button", '[role="button"]', 'input[type="submit"]', ...extraHints].join(", ");
      const found = Array.from(node.querySelectorAll(sel)).some((btn) => {
        const label = [
          btn.textContent?.trim() ?? "",
          btn.getAttribute("aria-label") ?? "",
          btn.getAttribute("title") ?? "",
          btn.getAttribute("data-tooltip") ?? ""
        ].join(" ");
        return SEND_LABEL_RE.test(label);
      });
      if (found) return true;
    }
    return false;
  }
  function scoreElement(el, sendHints, minW, minH) {
    let score = 0;
    const rect = el.getBoundingClientRect();
    score += 2;
    if (document.activeElement === el) score += 3;
    else if (el.contains(document.activeElement)) score += 1;
    const ts = lastInteraction.get(el);
    if (ts !== void 0 && Date.now() - ts < RECENT_MS) score += 3;
    if (rect.width >= minW * 2 && rect.height >= minH * 2) score += 2;
    else if (rect.width >= minW && rect.height >= minH) score += 1;
    if (el.getAttribute("role") === "textbox") score += 1;
    if (el.getAttribute("placeholder") || el.dataset.placeholder) score += 1;
    if (hasNearbySendControl(el, sendHints)) score += 2;
    return score;
  }
  function collectFromIframes(minW, minH, into) {
    Array.from(document.querySelectorAll("iframe")).forEach((iframe) => {
      try {
        const doc = iframe.contentDocument;
        if (!doc) return;
        const body = doc.body;
        if (!body) return;
        if (doc.designMode === "on") {
          into.push(body);
          return;
        }
        Array.from(doc.querySelectorAll(BASE_SEL)).forEach((el) => {
          if (isVisible(el)) into.push(el);
        });
      } catch {
      }
    });
  }
  var BASE_SEL = [
    "textarea",
    'div[contenteditable="true"]',
    'div[role="textbox"]',
    'div[role="textbox"][contenteditable]',
    'div[contenteditable="true"][role="combobox"]'
  ].join(", ");
  function detectAllCompose(adapter) {
    const minW = adapter?.minWidth ?? 200;
    const minH = adapter?.minHeight ?? 50;
    const sendHints = adapter?.sendButtonHints ?? [];
    const platform = adapter?.platform;
    const candidates = /* @__PURE__ */ new Map();
    if (adapter) {
      adapter.composeHints.forEach((sel) => {
        Array.from(document.querySelectorAll(sel)).forEach((el) => {
          if (isVisible(el)) candidates.set(el, el);
        });
      });
    }
    Array.from(document.querySelectorAll(BASE_SEL)).forEach((el) => {
      if (isVisible(el)) candidates.set(el, el);
    });
    const iframeEls = [];
    collectFromIframes(minW, minH, iframeEls);
    iframeEls.forEach((el) => candidates.set(el, el));
    const results = [];
    Array.from(candidates.values()).forEach((el) => {
      const rect = el.getBoundingClientRect();
      if (rect.width < minW || rect.height < minH) return;
      const isHinted = adapter?.composeHints.some((sel) => el.matches(sel)) ?? false;
      const base = scoreElement(el, sendHints, minW, minH);
      const confidence = isHinted ? base + 10 : base;
      results.push({ element: el, confidence, platform });
    });
    return results.sort((a, b) => b.confidence - a.confidence);
  }

  // src/adapters/hiworks-adapter.ts
  var hiworksAdapter = {
    platform: "hiworks",
    composeHints: [
      'div[contenteditable="true"][class*="editor"]',
      'div[contenteditable="true"][class*="body"]',
      'div[contenteditable="true"][class*="compose"]',
      'div[contenteditable="true"][class*="mail"]',
      'div[role="textbox"][contenteditable="true"]',
      'div[contenteditable="true"].editable',
      'textarea[name*="body"]',
      'textarea[class*="body"]',
      'textarea[class*="compose"]'
    ],
    sendButtonHints: [
      // Korean send labels
      'button[aria-label*="\uC804\uC1A1"]',
      'button[aria-label*="\uBCF4\uB0B4\uAE30"]',
      'button[aria-label*="\uB2F5\uC7A5"]',
      // English fallbacks (HiWorks supports English UI)
      'button[aria-label*="send" i]',
      'button[class*="send"]',
      'button[class*="submit"]',
      '[data-action="send"]'
    ],
    minWidth: 300,
    minHeight: 80
  };

  // src/content/hiworks.ts
  var DEBUG = false;
  var HOST_ATTR = "data-wt-hw-injected";
  var FIXED_CONTEXT_OVERRIDE = "professional";
  var PRIMARY = "#0EA5E9";
  var TONES = [
    { key: "professional", label: "Professional", color: PRIMARY },
    { key: "friendly", label: "Friendly", color: "#F59E0B" },
    { key: "direct", label: "Direct", color: "#DC2626" },
    { key: "diplomatic", label: "Diplomatic", color: "#7C3AED" },
    { key: "executive", label: "Executive", color: "#0F172A" },
    { key: "casual", label: "Casual", color: "#06B6D4" }
  ];
  var VOICE_OUTPUT_TYPES = [
    { key: "email", label: "Email" },
    { key: "reply", label: "Reply" },
    { key: "customer_update", label: "Customer Update" },
    { key: "technical_report", label: "Tech Report" }
  ];
  var CSS = `
  :host { display: inline-flex; align-items: center; gap: 4px; }

  #wt-btn {
    display: inline-flex; align-items: center; gap: 5px;
    height: 28px; padding: 0 12px; border-radius: 9999px; border: none;
    background: ${PRIMARY}; color: #fff;
    font: 500 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer; white-space: nowrap;
    transition: background 0.15s, box-shadow 0.15s;
  }
  #wt-btn:hover { background: #0284C7; box-shadow: 0 0 0 3px rgba(14,165,233,0.25); }
  #wt-btn:disabled { opacity: 0.6; cursor: default; box-shadow: none; }

  #wt-mic-btn {
    display: inline-flex; align-items: center; justify-content: center;
    width: 28px; height: 28px; border-radius: 9999px; border: none;
    background: transparent; color: #555; cursor: pointer;
    font-size: 15px; line-height: 1;
    transition: background 0.15s, color 0.15s;
  }
  #wt-mic-btn:hover { background: rgba(0,0,0,0.07); }
  #wt-mic-btn.recording { background: #FEE2E2; color: #DC2626;
    animation: wt-pulse 1.2s ease-in-out infinite; }
  @keyframes wt-pulse {
    0%, 100% { box-shadow: 0 0 0 0 rgba(220,38,38,0.4); }
    50%       { box-shadow: 0 0 0 5px rgba(220,38,38,0); }
  }
  #wt-mic-btn:disabled { opacity: 0.5; cursor: default; }

  .wt-panel {
    position: fixed; z-index: 99999;
    background: #fff; border: 1px solid #E2E8F0; border-radius: 10px;
    box-shadow: 0 12px 32px rgba(0,0,0,0.14);
    padding: 14px 16px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: none;
  }
  .wt-panel.open { display: block; }

  /* \u2500\u2500 Humanize panel \u2500\u2500 */
  #wt-panel { width: 260px; }
  .wt-title { font-size: 12px; font-weight: 600; color: #374151; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase; }
  .wt-tones { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 12px; }
  .wt-tone {
    padding: 4px 10px; border-radius: 9999px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151;
    cursor: pointer; transition: all 0.1s;
  }
  .wt-tone.active { color: #fff; border-color: transparent; }
  .wt-tone:hover:not(.active) { border-color: #7DD3FC; }

  #wt-rewrite {
    width: 100%; height: 32px; border-radius: 8px; border: none;
    background: ${PRIMARY}; color: #fff;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer;
  }
  #wt-rewrite:disabled { opacity: 0.45; cursor: default; }

  #wt-status { margin-top: 8px; font-size: 11px; text-align: center; min-height: 14px; }
  #wt-status.error   { color: #EF4444; }
  #wt-status.success { color: #10B981; }

  #wt-limit { display: none; margin-top: 10px; padding: 10px 12px; border-radius: 8px;
    background: #FFF8F1; border: 1px solid #FED7AA; text-align: center; }
  #wt-limit.visible { display: block; }
  #wt-limit p { font-size: 11px; color: #92400E; margin: 0 0 8px; line-height: 1.4; }
  #wt-limit a {
    display: inline-block; padding: 5px 14px; border-radius: 9999px;
    background: #F59E0B; color: #fff; font-size: 11px; font-weight: 600;
    text-decoration: none;
  }

  #wt-actions { display: none; gap: 6px; margin-top: 8px; }
  #wt-actions.visible { display: flex; }
  .wt-action {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151; cursor: pointer;
  }
  .wt-action.accept { border-color: #10B981; color: #10B981; }
  .wt-action.reject { border-color: #EF4444; color: #EF4444; }

  /* \u2500\u2500 Voice panel \u2500\u2500 */
  #wt-voice-panel { width: 280px; }
  .wt-vt { font-size: 12px; font-weight: 600; color: #374151; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase; }
  .wt-otype-label { font-size: 11px; color: #6B7280; margin-bottom: 4px; }
  .wt-otypes { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 10px; }
  .wt-otype {
    padding: 3px 9px; border-radius: 9999px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 11px; color: #374151; cursor: pointer; transition: all 0.1s;
  }
  .wt-otype.active { background: ${PRIMARY}; color: #fff; border-color: ${PRIMARY}; }
  #wt-record-btn {
    width: 100%; height: 32px; border-radius: 8px; border: none;
    background: #DC2626; color: #fff; cursor: pointer; margin-bottom: 10px;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }
  #wt-record-btn.recording { background: #7F1D1D; }
  #wt-record-btn:disabled { opacity: 0.5; cursor: default; }
  #wt-voice-status { font-size: 11px; text-align: center; min-height: 14px; color: #6B7280; }
  #wt-voice-status.error { color: #EF4444; }
  #wt-voice-actions { display: none; gap: 6px; margin-top: 8px; }
  #wt-voice-actions.visible { display: flex; }
  .wt-va {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151; cursor: pointer;
  }
  .wt-va.accept { border-color: #10B981; color: #10B981; }
  .wt-va.reject { border-color: #EF4444; color: #EF4444; }
`;
  var openPanel = null;
  document.addEventListener("click", (e) => {
    if (openPanel && !openPanel.host.contains(e.target)) {
      openPanel.close();
      openPanel = null;
    }
  }, true);
  function openPanelFor(host, close) {
    if (openPanel && openPanel.host !== host) openPanel.close();
    openPanel = { host, close };
  }
  function clearOpenPanel(host) {
    if (openPanel?.host === host) openPanel = null;
  }
  function sendToBackground(message) {
    return new Promise((resolve) => chrome.runtime.sendMessage(message, resolve));
  }
  function isTextarea(el) {
    return el.tagName === "TEXTAREA";
  }
  function readCompose(el) {
    if (isTextarea(el)) return el.value.trim();
    return el.innerText.trim();
  }
  function writeCompose(el, text) {
    if (isTextarea(el)) {
      const ta = el;
      ta.value = text;
      ta.dispatchEvent(new Event("input", { bubbles: true }));
      ta.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      const div = el;
      div.focus();
      document.execCommand("selectAll", false, void 0);
      document.execCommand("delete", false, void 0);
      const lines = text.split("\n");
      for (let i = 0; i < lines.length; i++) {
        if (lines[i]) document.execCommand("insertText", false, lines[i]);
        if (i < lines.length - 1) document.execCommand("insertParagraph", false, void 0);
      }
    }
  }
  function inject(composeBody) {
    if (composeBody.hasAttribute(HOST_ATTR)) return;
    composeBody.setAttribute(HOST_ATTR, "1");
    const wrapper = document.createElement("div");
    wrapper.style.cssText = "display:flex;align-items:center;gap:4px;margin-top:8px;padding:0 2px;";
    const insertionPoint = composeBody.closest('[class*="editor"], [class*="compose"], [class*="mail"], form') ?? composeBody.parentElement;
    insertionPoint?.insertAdjacentElement("afterend", wrapper);
    if (!wrapper.parentElement) composeBody.parentElement?.appendChild(wrapper);
    const host = document.createElement("span");
    const shadow = host.attachShadow({ mode: "open" });
    let selectedTone = null;
    let lastRewriteId = null;
    let panelOpen = false;
    let voicePanelOpen = false;
    let selectedOutputType = VOICE_OUTPUT_TYPES[0].key;
    let recorder = null;
    let recording = false;
    let audioChunks = [];
    let lastVoiceSessionId = null;
    let originalText = "";
    let originalVoiceText = "";
    shadow.innerHTML = `
    <style>${CSS}</style>
    <button id="wt-btn" title="Humanize with Writing Twin AI">\u2728 Humanize</button>
    <button id="wt-mic-btn" title="Voice Twin \u2014 speak your email">\u{1F399}</button>

    <div id="wt-panel" class="wt-panel">
      <p class="wt-title">Rewrite tone</p>
      <div class="wt-tones">
        ${TONES.map((t) => `<button class="wt-tone" data-tone="${t.key}" data-color="${t.color}">${t.label}</button>`).join("")}
      </div>
      <button id="wt-rewrite" disabled>Rewrite \u2192</button>
      <div id="wt-status"></div>
      <div id="wt-limit">
        <p>You've used all your free rewrites this month.</p>
        <a href="https://writingtwinai.com/pricing" target="_blank" rel="noopener">Upgrade to Pro \u2014 $5/mo</a>
      </div>
      <div id="wt-actions">
        <button class="wt-action accept" id="wt-accept">\u2713 Keep it</button>
        <button class="wt-action reject" id="wt-reject">\u2717 Undo</button>
      </div>
    </div>

    <div id="wt-voice-panel" class="wt-panel">
      <p class="wt-vt">Voice Twin</p>
      <div class="wt-otype-label">Output type</div>
      <div class="wt-otypes">
        ${VOICE_OUTPUT_TYPES.map(
      (o, i) => `<button class="wt-otype${i === 0 ? " active" : ""}" data-type="${o.key}">${o.label}</button>`
    ).join("")}
      </div>
      <button id="wt-record-btn">\u{1F399} Start recording</button>
      <div id="wt-voice-status"></div>
      <div id="wt-voice-actions">
        <button class="wt-va accept" id="wt-va-keep">\u2713 Keep it</button>
        <button class="wt-va reject" id="wt-va-undo">\u2717 Undo</button>
      </div>
    </div>
  `;
    const btn = shadow.getElementById("wt-btn");
    const micBtn = shadow.getElementById("wt-mic-btn");
    const panel = shadow.getElementById("wt-panel");
    const voicePanel = shadow.getElementById("wt-voice-panel");
    const rewriteBtn = shadow.getElementById("wt-rewrite");
    const statusEl = shadow.getElementById("wt-status");
    const limitEl = shadow.getElementById("wt-limit");
    const actionsEl = shadow.getElementById("wt-actions");
    const acceptBtn = shadow.getElementById("wt-accept");
    const rejectBtn = shadow.getElementById("wt-reject");
    const recordBtn = shadow.getElementById("wt-record-btn");
    const vStatusEl = shadow.getElementById("wt-voice-status");
    const vActionsEl = shadow.getElementById("wt-voice-actions");
    const vKeepBtn = shadow.getElementById("wt-va-keep");
    const vUndoBtn = shadow.getElementById("wt-va-undo");
    shadow.querySelectorAll(".wt-tone").forEach((tb) => {
      tb.addEventListener("click", () => {
        shadow.querySelectorAll(".wt-tone").forEach((b) => b.classList.remove("active"));
        tb.classList.add("active");
        tb.style.background = tb.dataset.color ?? PRIMARY;
        tb.style.borderColor = tb.dataset.color ?? PRIMARY;
        selectedTone = tb.dataset.tone;
        rewriteBtn.disabled = false;
        setStatus("");
        limitEl.classList.remove("visible");
        actionsEl.classList.remove("visible");
      });
    });
    shadow.querySelectorAll(".wt-otype").forEach((ob) => {
      ob.addEventListener("click", () => {
        shadow.querySelectorAll(".wt-otype").forEach((b) => b.classList.remove("active"));
        ob.classList.add("active");
        selectedOutputType = ob.dataset.type;
      });
    });
    btn.addEventListener("click", () => {
      if (panelOpen) {
        panelOpen = false;
        panel.classList.remove("open");
        clearOpenPanel(host);
      } else {
        voicePanelOpen = false;
        voicePanel.classList.remove("open");
        panelOpen = true;
        panel.classList.add("open");
        positionPanel(btn, panel);
        openPanelFor(host, () => {
          panelOpen = false;
          panel.classList.remove("open");
          voicePanelOpen = false;
          voicePanel.classList.remove("open");
        });
      }
    });
    micBtn.addEventListener("click", () => {
      if (voicePanelOpen) {
        voicePanelOpen = false;
        voicePanel.classList.remove("open");
        clearOpenPanel(host);
      } else {
        panelOpen = false;
        panel.classList.remove("open");
        voicePanelOpen = true;
        voicePanel.classList.add("open");
        positionPanel(micBtn, voicePanel);
        openPanelFor(host, () => {
          voicePanelOpen = false;
          voicePanel.classList.remove("open");
          panelOpen = false;
          panel.classList.remove("open");
        });
      }
    });
    function positionPanel(anchor, p) {
      const rect = anchor.getBoundingClientRect();
      p.style.bottom = `${window.innerHeight - rect.top + 4}px`;
      p.style.left = `${Math.min(rect.left, window.innerWidth - parseInt(p.style.width || "260") - 20)}px`;
    }
    rewriteBtn.addEventListener("click", async () => {
      if (!selectedTone) return;
      const text = readCompose(composeBody);
      if (!text) {
        setStatus("Write something first.", "error");
        return;
      }
      originalText = text;
      btn.disabled = true;
      rewriteBtn.disabled = true;
      setStatus("Rewriting\u2026");
      actionsEl.classList.remove("visible");
      try {
        const resp = await sendToBackground({
          type: "HUMANIZE",
          payload: {
            text,
            tone: selectedTone,
            ctx: { platform: "hiworks", context_twin_override: FIXED_CONTEXT_OVERRIDE }
          }
        });
        if ("error" in resp) throw new Error(String(resp.error));
        lastRewriteId = resp.result.id;
        writeCompose(composeBody, resp.result.output_text);
        setStatus("Done \u2713", "success");
        actionsEl.classList.add("visible");
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Failed";
        if (msg.startsWith("LIMIT_REACHED:")) {
          limitEl.classList.add("visible");
          setStatus("");
        } else {
          setStatus(msg, "error");
        }
      } finally {
        btn.disabled = false;
        rewriteBtn.disabled = selectedTone === null;
      }
    });
    acceptBtn.addEventListener("click", () => {
      if (lastRewriteId) sendToBackground({ type: "FEEDBACK", payload: { rewriteId: lastRewriteId, action: "accepted" } });
      actionsEl.classList.remove("visible");
      panelOpen = false;
      panel.classList.remove("open");
      clearOpenPanel(host);
      setStatus("");
    });
    rejectBtn.addEventListener("click", () => {
      if (originalText) writeCompose(composeBody, originalText);
      if (lastRewriteId) sendToBackground({ type: "FEEDBACK", payload: { rewriteId: lastRewriteId, action: "rejected" } });
      actionsEl.classList.remove("visible");
      setStatus("Reverted.", "success");
      setTimeout(() => setStatus(""), 2e3);
    });
    function setStatus(msg, cls = "") {
      statusEl.textContent = msg;
      statusEl.className = cls;
    }
    recordBtn.addEventListener("click", async () => {
      if (!recording) await startRecording();
      else stopRecording();
    });
    async function startRecording() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        audioChunks = [];
        recorder = new MediaRecorder(stream, { mimeType: "audio/webm" });
        recorder.ondataavailable = (e) => {
          if (e.data.size > 0) audioChunks.push(e.data);
        };
        recorder.onstop = async () => {
          stream.getTracks().forEach((t) => t.stop());
          await submitVoice(new Blob(audioChunks, { type: "audio/webm" }));
        };
        recorder.start();
        recording = true;
        micBtn.classList.add("recording");
        recordBtn.classList.add("recording");
        recordBtn.textContent = "\u23F9 Stop recording";
        setVStatus("Recording\u2026");
        vActionsEl.classList.remove("visible");
        setTimeout(() => {
          if (recording) stopRecording();
        }, 6e4);
      } catch {
        setVStatus("Microphone access denied.", "error");
      }
    }
    function stopRecording() {
      if (recorder && recording) {
        recorder.stop();
        recording = false;
        micBtn.classList.remove("recording");
        recordBtn.classList.remove("recording");
        recordBtn.textContent = "\u{1F399} Start recording";
        recordBtn.disabled = true;
        setVStatus("Drafting\u2026");
      }
    }
    async function submitVoice(blob) {
      try {
        const buf = await blob.arrayBuffer();
        const audioData = btoa(Array.from(new Uint8Array(buf), (b) => String.fromCharCode(b)).join(""));
        originalVoiceText = readCompose(composeBody);
        const resp = await sendToBackground({
          type: "VOICE_DRAFT",
          payload: { audioData, mimeType: "audio/webm", outputType: selectedOutputType }
        });
        if ("error" in resp) throw new Error(String(resp.error));
        lastVoiceSessionId = resp.result.id;
        writeCompose(composeBody, resp.result.draft);
        setVStatus("Done \u2713");
        vActionsEl.classList.add("visible");
      } catch (err) {
        setVStatus(err instanceof Error ? err.message : "Failed", "error");
      } finally {
        recordBtn.disabled = false;
      }
    }
    vKeepBtn.addEventListener("click", () => {
      if (lastVoiceSessionId) sendToBackground({ type: "VOICE_FEEDBACK", payload: { sessionId: lastVoiceSessionId, accepted: true, editedDraft: null } });
      vActionsEl.classList.remove("visible");
      voicePanelOpen = false;
      voicePanel.classList.remove("open");
      clearOpenPanel(host);
      setVStatus("");
    });
    vUndoBtn.addEventListener("click", () => {
      if (originalVoiceText) writeCompose(composeBody, originalVoiceText);
      if (lastVoiceSessionId) sendToBackground({ type: "VOICE_FEEDBACK", payload: { sessionId: lastVoiceSessionId, accepted: false, editedDraft: null } });
      vActionsEl.classList.remove("visible");
      setVStatus("Reverted.", "success");
      setTimeout(() => setVStatus(""), 2e3);
    });
    function setVStatus(msg, cls = "") {
      vStatusEl.textContent = msg;
      vStatusEl.className = cls;
    }
    wrapper.appendChild(host);
  }
  var seen = /* @__PURE__ */ new WeakSet();
  function tryInject(root = document) {
    const targets = detectAllCompose({ ...hiworksAdapter, minWidth: 300, minHeight: 80 });
    if (DEBUG && targets.length > 0) {
      console.log("[WritingTwin/HiWorks] compose candidates:", targets.map((t) => ({
        tag: t.element.tagName,
        id: t.element.id || "\u2013",
        classes: t.element.className,
        confidence: t.confidence
      })));
    }
    for (const { element } of targets) {
      if (!seen.has(element)) {
        seen.add(element);
        inject(element);
      }
    }
  }
  var observer = new MutationObserver(() => {
    requestIdleCallback(() => tryInject(), { timeout: 500 });
  });
  observer.observe(document.body, { childList: true, subtree: true });
  tryInject();
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vc3JjL2xpYi9jb21wb3NlLWRldGVjdG9yLnRzIiwgIi4uLy4uL3NyYy9hZGFwdGVycy9oaXdvcmtzLWFkYXB0ZXIudHMiLCAiLi4vLi4vc3JjL2NvbnRlbnQvaGl3b3Jrcy50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLy8gR2VuZXJpYyBjb21wb3NlIGFyZWEgZGV0ZWN0aW9uIGVuZ2luZSBmb3IgV3JpdGluZyBUd2luIEFJLlxuLy8gVXNlZCBieSBwbGF0Zm9ybS1zcGVjaWZpYyBjb250ZW50IHNjcmlwdHMgdmlhIFBsYXRmb3JtQWRhcHRlciBoaW50cy5cbi8vIEFkZGluZyBhIG5ldyBwbGF0Zm9ybSA9IG5ldyBhZGFwdGVyICsgdGhpbiBjb250ZW50IHNjcmlwdCwgbm8gZGV0ZWN0b3IgY2hhbmdlcy5cblxuZXhwb3J0IGludGVyZmFjZSBDb21wb3NlVGFyZ2V0IHtcbiAgZWxlbWVudDogSFRNTEVsZW1lbnQ7XG4gIGNvbmZpZGVuY2U6IG51bWJlcjtcbiAgcGxhdGZvcm0/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUGxhdGZvcm1BZGFwdGVyIHtcbiAgcGxhdGZvcm06IHN0cmluZztcbiAgLyoqIENTUyBzZWxlY3RvcnMgdHJpZWQgZmlyc3QgKGhpZ2hlc3Qgc3BlY2lmaWNpdHksIGxlYXN0IGZhbHNlLXBvc2l0aXZlIHJpc2spICovXG4gIGNvbXBvc2VIaW50czogc3RyaW5nW107XG4gIC8qKiBDU1Mgc2VsZWN0b3JzIGZvciBzZW5kL3JlcGx5L3Bvc3Qvc3VibWl0IGNvbnRyb2xzIG5lYXIgdGhlIGNvbXBvc2UgYXJlYSAqL1xuICBzZW5kQnV0dG9uSGludHM6IHN0cmluZ1tdO1xuICAvKiogTWluaW11bSB3aWR0aCBpbiBweCB0byBhY2NlcHQgYSBjYW5kaWRhdGUuIERlZmF1bHQ6IDIwMCAqL1xuICBtaW5XaWR0aD86IG51bWJlcjtcbiAgLyoqIE1pbmltdW0gaGVpZ2h0IGluIHB4IHRvIGFjY2VwdCBhIGNhbmRpZGF0ZS4gRGVmYXVsdDogNTAgKi9cbiAgbWluSGVpZ2h0PzogbnVtYmVyO1xufVxuXG4vLyBcdTI1MDBcdTI1MDAgSW50ZXJhY3Rpb24gdHJhY2tpbmcgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vLyBUcmFja3Mgd2hpY2ggZWRpdGFibGUgZWxlbWVudHMgdGhlIHVzZXIgaGFzIHJlY2VudGx5IGNsaWNrZWQvZm9jdXNlZCBzb1xuLy8gdGhlIGRldGVjdG9yIGNhbiByZXdhcmQgdGhlbSB3aXRoIGEgaGlnaGVyIGNvbmZpZGVuY2Ugc2NvcmUuXG5cbmNvbnN0IGxhc3RJbnRlcmFjdGlvbiA9IG5ldyBXZWFrTWFwPEVsZW1lbnQsIG51bWJlcj4oKTtcbmNvbnN0IFJFQ0VOVF9NUyA9IDMwXzAwMDtcblxuZnVuY3Rpb24gaXNFZGl0YWJsZShlbDogRWxlbWVudCk6IGJvb2xlYW4ge1xuICByZXR1cm4gKFxuICAgIGVsLnRhZ05hbWUgPT09ICdURVhUQVJFQScgfHxcbiAgICBlbC5nZXRBdHRyaWJ1dGUoJ2NvbnRlbnRlZGl0YWJsZScpID09PSAndHJ1ZScgfHxcbiAgICBlbC5nZXRBdHRyaWJ1dGUoJ3JvbGUnKSA9PT0gJ3RleHRib3gnXG4gICk7XG59XG5cbmRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGUpID0+IHtcbiAgbGV0IG5vZGU6IEVsZW1lbnQgfCBudWxsID0gZS50YXJnZXQgYXMgRWxlbWVudDtcbiAgd2hpbGUgKG5vZGUpIHtcbiAgICBpZiAoaXNFZGl0YWJsZShub2RlKSkgeyBsYXN0SW50ZXJhY3Rpb24uc2V0KG5vZGUsIERhdGUubm93KCkpOyBicmVhazsgfVxuICAgIG5vZGUgPSBub2RlLnBhcmVudEVsZW1lbnQ7XG4gIH1cbn0sIHsgY2FwdHVyZTogdHJ1ZSwgcGFzc2l2ZTogdHJ1ZSB9KTtcblxuZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignZm9jdXNpbicsIChlKSA9PiB7XG4gIGlmIChlLnRhcmdldCBpbnN0YW5jZW9mIEVsZW1lbnQgJiYgaXNFZGl0YWJsZShlLnRhcmdldCkpIHtcbiAgICBsYXN0SW50ZXJhY3Rpb24uc2V0KGUudGFyZ2V0LCBEYXRlLm5vdygpKTtcbiAgfVxufSwgeyBjYXB0dXJlOiB0cnVlLCBwYXNzaXZlOiB0cnVlIH0pO1xuXG4vLyBcdTI1MDBcdTI1MDAgU2NvcmluZyBoZWxwZXJzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5jb25zdCBTRU5EX0xBQkVMX1JFID0gL1xcYihzZW5kfHJlcGx5fHN1Ym1pdHxwb3N0fGNvbW1lbnR8XHVDODA0XHVDMUExfFx1QkNGNFx1QjBCNFx1QUUzMHxcdUIyRjVcdUM3QTUpXFxiL2k7XG5cbmZ1bmN0aW9uIGlzVmlzaWJsZShlbDogRWxlbWVudCk6IGJvb2xlYW4ge1xuICBjb25zdCByID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gIGlmIChyLndpZHRoID09PSAwIHx8IHIuaGVpZ2h0ID09PSAwKSByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IHMgPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShlbCk7XG4gIHJldHVybiBzLmRpc3BsYXkgIT09ICdub25lJyAmJiBzLnZpc2liaWxpdHkgIT09ICdoaWRkZW4nICYmIHBhcnNlRmxvYXQocy5vcGFjaXR5KSA+IDA7XG59XG5cbmZ1bmN0aW9uIGhhc05lYXJieVNlbmRDb250cm9sKGVsOiBFbGVtZW50LCBleHRyYUhpbnRzOiBzdHJpbmdbXSA9IFtdKTogYm9vbGVhbiB7XG4gIC8vIFdhbGsgdXAgdXAgdG8gOCBsZXZlbHMgbG9va2luZyBmb3Igc2VuZC9yZXBseS9wb3N0L2NvbW1lbnQgYnV0dG9uc1xuICBsZXQgbm9kZTogRWxlbWVudCB8IG51bGwgPSBlbDtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCA4ICYmIG5vZGU7IGkrKywgbm9kZSA9IG5vZGUucGFyZW50RWxlbWVudCkge1xuICAgIGNvbnN0IHNlbCA9IFsnYnV0dG9uJywgJ1tyb2xlPVwiYnV0dG9uXCJdJywgJ2lucHV0W3R5cGU9XCJzdWJtaXRcIl0nLCAuLi5leHRyYUhpbnRzXS5qb2luKCcsICcpO1xuICAgIGNvbnN0IGZvdW5kID0gQXJyYXkuZnJvbShub2RlLnF1ZXJ5U2VsZWN0b3JBbGw8SFRNTEVsZW1lbnQ+KHNlbCkpLnNvbWUoYnRuID0+IHtcbiAgICAgIGNvbnN0IGxhYmVsID0gW1xuICAgICAgICBidG4udGV4dENvbnRlbnQ/LnRyaW0oKSA/PyAnJyxcbiAgICAgICAgYnRuLmdldEF0dHJpYnV0ZSgnYXJpYS1sYWJlbCcpID8/ICcnLFxuICAgICAgICBidG4uZ2V0QXR0cmlidXRlKCd0aXRsZScpID8/ICcnLFxuICAgICAgICBidG4uZ2V0QXR0cmlidXRlKCdkYXRhLXRvb2x0aXAnKSA/PyAnJyxcbiAgICAgIF0uam9pbignICcpO1xuICAgICAgcmV0dXJuIFNFTkRfTEFCRUxfUkUudGVzdChsYWJlbCk7XG4gICAgfSk7XG4gICAgaWYgKGZvdW5kKSByZXR1cm4gdHJ1ZTtcbiAgfVxuICByZXR1cm4gZmFsc2U7XG59XG5cbmZ1bmN0aW9uIHNjb3JlRWxlbWVudChcbiAgZWw6IEhUTUxFbGVtZW50LFxuICBzZW5kSGludHM6IHN0cmluZ1tdLFxuICBtaW5XOiBudW1iZXIsXG4gIG1pbkg6IG51bWJlcixcbik6IG51bWJlciB7XG4gIGxldCBzY29yZSA9IDA7XG4gIGNvbnN0IHJlY3QgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcblxuICAvLyBWaXNpYmlsaXR5IFx1MjAxNCByZXF1aXJlZCwgc28gYW55dGhpbmcgdGhhdCByZWFjaGVzIGhlcmUgYWxyZWFkeSBwYXNzZWRcbiAgc2NvcmUgKz0gMjtcblxuICAvLyBGb2N1cyBzdGF0ZVxuICBpZiAoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCA9PT0gZWwpIHNjb3JlICs9IDM7XG4gIGVsc2UgaWYgKGVsLmNvbnRhaW5zKGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQpKSBzY29yZSArPSAxO1xuXG4gIC8vIFVzZXIgcmVjZW50bHkgaW50ZXJhY3RlZFxuICBjb25zdCB0cyA9IGxhc3RJbnRlcmFjdGlvbi5nZXQoZWwpO1xuICBpZiAodHMgIT09IHVuZGVmaW5lZCAmJiBEYXRlLm5vdygpIC0gdHMgPCBSRUNFTlRfTVMpIHNjb3JlICs9IDM7XG5cbiAgLy8gU2l6ZSBcdTIwMTQgcmV3YXJkIGxhcmdlIGNvbXBvc2l0aW9uIGFyZWFzXG4gIGlmIChyZWN0LndpZHRoID49IG1pblcgKiAyICYmIHJlY3QuaGVpZ2h0ID49IG1pbkggKiAyKSBzY29yZSArPSAyO1xuICBlbHNlIGlmIChyZWN0LndpZHRoID49IG1pblcgJiYgcmVjdC5oZWlnaHQgPj0gbWluSCkgc2NvcmUgKz0gMTtcblxuICAvLyBFZGl0YWJpbGl0eSBtYXJrZXJzXG4gIGlmIChlbC5nZXRBdHRyaWJ1dGUoJ3JvbGUnKSA9PT0gJ3RleHRib3gnKSBzY29yZSArPSAxO1xuICBpZiAoZWwuZ2V0QXR0cmlidXRlKCdwbGFjZWhvbGRlcicpIHx8IGVsLmRhdGFzZXQucGxhY2Vob2xkZXIpIHNjb3JlICs9IDE7XG5cbiAgLy8gTmVhciBzZW5kL3JlcGx5IGNvbnRyb2xzXG4gIGlmIChoYXNOZWFyYnlTZW5kQ29udHJvbChlbCwgc2VuZEhpbnRzKSkgc2NvcmUgKz0gMjtcblxuICByZXR1cm4gc2NvcmU7XG59XG5cbi8vIFx1MjUwMFx1MjUwMCBJZnJhbWUgc3VwcG9ydCBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuZnVuY3Rpb24gY29sbGVjdEZyb21JZnJhbWVzKG1pblc6IG51bWJlciwgbWluSDogbnVtYmVyLCBpbnRvOiBIVE1MRWxlbWVudFtdKTogdm9pZCB7XG4gIEFycmF5LmZyb20oZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbDxIVE1MSUZyYW1lRWxlbWVudD4oJ2lmcmFtZScpKS5mb3JFYWNoKGlmcmFtZSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGRvYyA9IGlmcmFtZS5jb250ZW50RG9jdW1lbnQ7XG4gICAgICBpZiAoIWRvYykgcmV0dXJuO1xuICAgICAgY29uc3QgYm9keSA9IGRvYy5ib2R5IGFzIEhUTUxFbGVtZW50IHwgbnVsbDtcbiAgICAgIGlmICghYm9keSkgcmV0dXJuO1xuICAgICAgLy8gZGVzaWduTW9kZSA9ICdvbicgbWVhbnMgdGhlIHdob2xlIGJvZHkgaXMgdGhlIGVkaXRvclxuICAgICAgaWYgKChkb2MgYXMgdW5rbm93biBhcyB7IGRlc2lnbk1vZGU6IHN0cmluZyB9KS5kZXNpZ25Nb2RlID09PSAnb24nKSB7XG4gICAgICAgIGludG8ucHVzaChib2R5KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgQXJyYXkuZnJvbShkb2MucXVlcnlTZWxlY3RvckFsbChCQVNFX1NFTCkgYXMgTm9kZUxpc3RPZjxIVE1MRWxlbWVudD4pLmZvckVhY2goZWwgPT4ge1xuICAgICAgICBpZiAoaXNWaXNpYmxlKGVsKSkgaW50by5wdXNoKGVsKTtcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2gge1xuICAgICAgLy8gY3Jvc3Mtb3JpZ2luIFx1MjAxNCBza2lwIHNpbGVudGx5XG4gICAgfVxuICB9KTtcbn1cblxuLy8gXHUyNTAwXHUyNTAwIENvcmUgZGV0ZWN0aW9uIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5jb25zdCBCQVNFX1NFTCA9IFtcbiAgJ3RleHRhcmVhJyxcbiAgJ2Rpdltjb250ZW50ZWRpdGFibGU9XCJ0cnVlXCJdJyxcbiAgJ2Rpdltyb2xlPVwidGV4dGJveFwiXScsXG4gICdkaXZbcm9sZT1cInRleHRib3hcIl1bY29udGVudGVkaXRhYmxlXScsXG4gICdkaXZbY29udGVudGVkaXRhYmxlPVwidHJ1ZVwiXVtyb2xlPVwiY29tYm9ib3hcIl0nLFxuXS5qb2luKCcsICcpO1xuXG4vKipcbiAqIFJldHVybnMgYWxsIGNvbXBvc2UgY2FuZGlkYXRlcywgc29ydGVkIGJ5IGNvbmZpZGVuY2UgKGhpZ2hlc3QgZmlyc3QpLlxuICogUGFzcyBhIFBsYXRmb3JtQWRhcHRlciB0byB3ZWlnaHQgcGxhdGZvcm0tc3BlY2lmaWMgc2VsZWN0b3JzIGZpcnN0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZGV0ZWN0QWxsQ29tcG9zZShhZGFwdGVyPzogUGxhdGZvcm1BZGFwdGVyKTogQ29tcG9zZVRhcmdldFtdIHtcbiAgY29uc3QgbWluVyA9IGFkYXB0ZXI/Lm1pbldpZHRoID8/IDIwMDtcbiAgY29uc3QgbWluSCA9IGFkYXB0ZXI/Lm1pbkhlaWdodCA/PyA1MDtcbiAgY29uc3Qgc2VuZEhpbnRzID0gYWRhcHRlcj8uc2VuZEJ1dHRvbkhpbnRzID8/IFtdO1xuICBjb25zdCBwbGF0Zm9ybSA9IGFkYXB0ZXI/LnBsYXRmb3JtO1xuXG4gIGNvbnN0IGNhbmRpZGF0ZXMgPSBuZXcgTWFwPEVsZW1lbnQsIEhUTUxFbGVtZW50PigpO1xuXG4gIC8vIDEuIFBsYXRmb3JtIGhpbnQgc2VsZWN0b3JzIFx1MjAxNCB0cmllZCBmaXJzdCwgc2NvcmUgZ2V0cyBhIGJvbnVzXG4gIGlmIChhZGFwdGVyKSB7XG4gICAgYWRhcHRlci5jb21wb3NlSGludHMuZm9yRWFjaChzZWwgPT4ge1xuICAgICAgQXJyYXkuZnJvbShkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsPEhUTUxFbGVtZW50PihzZWwpKS5mb3JFYWNoKGVsID0+IHtcbiAgICAgICAgaWYgKGlzVmlzaWJsZShlbCkpIGNhbmRpZGF0ZXMuc2V0KGVsLCBlbCk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuXG4gIC8vIDIuIEdlbmVyaWMgc2VsZWN0b3JzIFx1MjAxNCBmaWxsIGluIGFueXRoaW5nIGhpbnRzIG1pc3NlZFxuICBBcnJheS5mcm9tKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGw8SFRNTEVsZW1lbnQ+KEJBU0VfU0VMKSkuZm9yRWFjaChlbCA9PiB7XG4gICAgaWYgKGlzVmlzaWJsZShlbCkpIGNhbmRpZGF0ZXMuc2V0KGVsLCBlbCk7XG4gIH0pO1xuXG4gIC8vIDMuIElmcmFtZSBlZGl0b3JzXG4gIGNvbnN0IGlmcmFtZUVsczogSFRNTEVsZW1lbnRbXSA9IFtdO1xuICBjb2xsZWN0RnJvbUlmcmFtZXMobWluVywgbWluSCwgaWZyYW1lRWxzKTtcbiAgaWZyYW1lRWxzLmZvckVhY2goZWwgPT4gY2FuZGlkYXRlcy5zZXQoZWwsIGVsKSk7XG5cbiAgY29uc3QgcmVzdWx0czogQ29tcG9zZVRhcmdldFtdID0gW107XG5cbiAgQXJyYXkuZnJvbShjYW5kaWRhdGVzLnZhbHVlcygpKS5mb3JFYWNoKGVsID0+IHtcbiAgICBjb25zdCByZWN0ID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgaWYgKHJlY3Qud2lkdGggPCBtaW5XIHx8IHJlY3QuaGVpZ2h0IDwgbWluSCkgcmV0dXJuO1xuXG4gICAgY29uc3QgaXNIaW50ZWQgPSBhZGFwdGVyPy5jb21wb3NlSGludHMuc29tZShzZWwgPT4gZWwubWF0Y2hlcyhzZWwpKSA/PyBmYWxzZTtcbiAgICBjb25zdCBiYXNlID0gc2NvcmVFbGVtZW50KGVsLCBzZW5kSGludHMsIG1pblcsIG1pbkgpO1xuICAgIGNvbnN0IGNvbmZpZGVuY2UgPSBpc0hpbnRlZCA/IGJhc2UgKyAxMCA6IGJhc2U7XG5cbiAgICByZXN1bHRzLnB1c2goeyBlbGVtZW50OiBlbCwgY29uZmlkZW5jZSwgcGxhdGZvcm0gfSk7XG4gIH0pO1xuXG4gIHJldHVybiByZXN1bHRzLnNvcnQoKGEsIGIpID0+IGIuY29uZmlkZW5jZSAtIGEuY29uZmlkZW5jZSk7XG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgc2luZ2xlIGJlc3QgY29tcG9zZSB0YXJnZXQsIG9yIG51bGwgaWYgbm90aGluZyBmb3VuZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRldGVjdENvbXBvc2UoYWRhcHRlcj86IFBsYXRmb3JtQWRhcHRlcik6IENvbXBvc2VUYXJnZXQgfCBudWxsIHtcbiAgY29uc3QgYWxsID0gZGV0ZWN0QWxsQ29tcG9zZShhZGFwdGVyKTtcbiAgcmV0dXJuIGFsbC5sZW5ndGggPiAwID8gYWxsWzBdIDogbnVsbDtcbn1cbiIsICJpbXBvcnQgdHlwZSB7IFBsYXRmb3JtQWRhcHRlciB9IGZyb20gJy4uL2xpYi9jb21wb3NlLWRldGVjdG9yJztcblxuLy8gSGlXb3JrcyAob2ZmaWNlLmhpd29ya3MuY29tKSBcdTIwMTQgS29yZWFuIGJ1c2luZXNzIHdlYiBvZmZpY2Ugc3VpdGUuXG4vLyBTZWxlY3RvcnMgYXJlIGJlc3QtZWZmb3J0IGJhc2VkIG9uIGNvbW1vbiBSZWFjdCBTUEEgZW1haWwgcGF0dGVybnMuXG4vLyBJZiBIaVdvcmtzIHVwZGF0ZXMgaXRzIFVJLCBydW4gd2l0aCBERUJVRz10cnVlIGluIGhpd29ya3MudHMgdG9cbi8vIGxvZyBkZXRlY3RlZCBjYW5kaWRhdGVzIGFuZCB1cGRhdGUgY29tcG9zZUhpbnRzIGFjY29yZGluZ2x5LlxuZXhwb3J0IGNvbnN0IGhpd29ya3NBZGFwdGVyOiBQbGF0Zm9ybUFkYXB0ZXIgPSB7XG4gIHBsYXRmb3JtOiAnaGl3b3JrcycsXG4gIGNvbXBvc2VIaW50czogW1xuICAgICdkaXZbY29udGVudGVkaXRhYmxlPVwidHJ1ZVwiXVtjbGFzcyo9XCJlZGl0b3JcIl0nLFxuICAgICdkaXZbY29udGVudGVkaXRhYmxlPVwidHJ1ZVwiXVtjbGFzcyo9XCJib2R5XCJdJyxcbiAgICAnZGl2W2NvbnRlbnRlZGl0YWJsZT1cInRydWVcIl1bY2xhc3MqPVwiY29tcG9zZVwiXScsXG4gICAgJ2Rpdltjb250ZW50ZWRpdGFibGU9XCJ0cnVlXCJdW2NsYXNzKj1cIm1haWxcIl0nLFxuICAgICdkaXZbcm9sZT1cInRleHRib3hcIl1bY29udGVudGVkaXRhYmxlPVwidHJ1ZVwiXScsXG4gICAgJ2Rpdltjb250ZW50ZWRpdGFibGU9XCJ0cnVlXCJdLmVkaXRhYmxlJyxcbiAgICAndGV4dGFyZWFbbmFtZSo9XCJib2R5XCJdJyxcbiAgICAndGV4dGFyZWFbY2xhc3MqPVwiYm9keVwiXScsXG4gICAgJ3RleHRhcmVhW2NsYXNzKj1cImNvbXBvc2VcIl0nLFxuICBdLFxuICBzZW5kQnV0dG9uSGludHM6IFtcbiAgICAvLyBLb3JlYW4gc2VuZCBsYWJlbHNcbiAgICAnYnV0dG9uW2FyaWEtbGFiZWwqPVwiXHVDODA0XHVDMUExXCJdJyxcbiAgICAnYnV0dG9uW2FyaWEtbGFiZWwqPVwiXHVCQ0Y0XHVCMEI0XHVBRTMwXCJdJyxcbiAgICAnYnV0dG9uW2FyaWEtbGFiZWwqPVwiXHVCMkY1XHVDN0E1XCJdJyxcbiAgICAvLyBFbmdsaXNoIGZhbGxiYWNrcyAoSGlXb3JrcyBzdXBwb3J0cyBFbmdsaXNoIFVJKVxuICAgICdidXR0b25bYXJpYS1sYWJlbCo9XCJzZW5kXCIgaV0nLFxuICAgICdidXR0b25bY2xhc3MqPVwic2VuZFwiXScsXG4gICAgJ2J1dHRvbltjbGFzcyo9XCJzdWJtaXRcIl0nLFxuICAgICdbZGF0YS1hY3Rpb249XCJzZW5kXCJdJyxcbiAgXSxcbiAgbWluV2lkdGg6IDMwMCxcbiAgbWluSGVpZ2h0OiA4MCxcbn07XG4iLCAiaW1wb3J0IHR5cGUgeyBUb25lLCBSZXdyaXRlUmVzcG9uc2UsIFZvaWNlT3V0cHV0VHlwZSwgVm9pY2VEcmFmdFJlc3BvbnNlIH0gZnJvbSAnLi4vbGliL2FwaSc7XG5pbXBvcnQgeyBkZXRlY3RBbGxDb21wb3NlIH0gZnJvbSAnLi4vbGliL2NvbXBvc2UtZGV0ZWN0b3InO1xuaW1wb3J0IHsgaGl3b3Jrc0FkYXB0ZXIgfSBmcm9tICcuLi9hZGFwdGVycy9oaXdvcmtzLWFkYXB0ZXInO1xuXG4vLyBTZXQgdG8gdHJ1ZSB0ZW1wb3JhcmlseSB0byBsb2cgY2FuZGlkYXRlIGNvbXBvc2UgZWxlbWVudHMgdG8gdGhlIGNvbnNvbGUuXG4vLyBVc2VmdWwgaWYgSGlXb3JrcyBjaGFuZ2VzIGl0cyBVSSBhbmQgdGhlIGJ1dHRvbiBzdG9wcyBhcHBlYXJpbmcuXG5jb25zdCBERUJVRyA9IGZhbHNlO1xuXG5jb25zdCBIT1NUX0FUVFIgPSAnZGF0YS13dC1ody1pbmplY3RlZCc7XG5jb25zdCBGSVhFRF9DT05URVhUX09WRVJSSURFID0gJ3Byb2Zlc3Npb25hbCc7XG4vLyBIaVdvcmtzIHByaW1hcnkgY29sb3IgXHUyMDE0IHNreSBibHVlLCBkaXN0aW5jdCBmcm9tIEdtYWlsL091dGxvb2svTGlua2VkSW4vUmVkZGl0XG5jb25zdCBQUklNQVJZID0gJyMwRUE1RTknO1xuXG5jb25zdCBUT05FUzogeyBrZXk6IFRvbmU7IGxhYmVsOiBzdHJpbmc7IGNvbG9yOiBzdHJpbmcgfVtdID0gW1xuICB7IGtleTogJ3Byb2Zlc3Npb25hbCcsIGxhYmVsOiAnUHJvZmVzc2lvbmFsJywgY29sb3I6IFBSSU1BUlkgfSxcbiAgeyBrZXk6ICdmcmllbmRseScsICAgICBsYWJlbDogJ0ZyaWVuZGx5JywgICAgIGNvbG9yOiAnI0Y1OUUwQicgfSxcbiAgeyBrZXk6ICdkaXJlY3QnLCAgICAgICBsYWJlbDogJ0RpcmVjdCcsICAgICAgIGNvbG9yOiAnI0RDMjYyNicgfSxcbiAgeyBrZXk6ICdkaXBsb21hdGljJywgICBsYWJlbDogJ0RpcGxvbWF0aWMnLCAgIGNvbG9yOiAnIzdDM0FFRCcgfSxcbiAgeyBrZXk6ICdleGVjdXRpdmUnLCAgICBsYWJlbDogJ0V4ZWN1dGl2ZScsICAgIGNvbG9yOiAnIzBGMTcyQScgfSxcbiAgeyBrZXk6ICdjYXN1YWwnLCAgICAgICBsYWJlbDogJ0Nhc3VhbCcsICAgICAgIGNvbG9yOiAnIzA2QjZENCcgfSxcbl07XG5cbmNvbnN0IFZPSUNFX09VVFBVVF9UWVBFUzogeyBrZXk6IFZvaWNlT3V0cHV0VHlwZTsgbGFiZWw6IHN0cmluZyB9W10gPSBbXG4gIHsga2V5OiAnZW1haWwnLCAgICAgICAgICAgIGxhYmVsOiAnRW1haWwnIH0sXG4gIHsga2V5OiAncmVwbHknLCAgICAgICAgICAgIGxhYmVsOiAnUmVwbHknIH0sXG4gIHsga2V5OiAnY3VzdG9tZXJfdXBkYXRlJywgIGxhYmVsOiAnQ3VzdG9tZXIgVXBkYXRlJyB9LFxuICB7IGtleTogJ3RlY2huaWNhbF9yZXBvcnQnLCBsYWJlbDogJ1RlY2ggUmVwb3J0JyB9LFxuXTtcblxuLy8gXHUyNTAwXHUyNTAwIENTUyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuY29uc3QgQ1NTID0gYFxuICA6aG9zdCB7IGRpc3BsYXk6IGlubGluZS1mbGV4OyBhbGlnbi1pdGVtczogY2VudGVyOyBnYXA6IDRweDsgfVxuXG4gICN3dC1idG4ge1xuICAgIGRpc3BsYXk6IGlubGluZS1mbGV4OyBhbGlnbi1pdGVtczogY2VudGVyOyBnYXA6IDVweDtcbiAgICBoZWlnaHQ6IDI4cHg7IHBhZGRpbmc6IDAgMTJweDsgYm9yZGVyLXJhZGl1czogOTk5OXB4OyBib3JkZXI6IG5vbmU7XG4gICAgYmFja2dyb3VuZDogJHtQUklNQVJZfTsgY29sb3I6ICNmZmY7XG4gICAgZm9udDogNTAwIDEycHgvMSAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsIFwiU2Vnb2UgVUlcIiwgUm9ib3RvLCBzYW5zLXNlcmlmO1xuICAgIGN1cnNvcjogcG9pbnRlcjsgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICB0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kIDAuMTVzLCBib3gtc2hhZG93IDAuMTVzO1xuICB9XG4gICN3dC1idG46aG92ZXIgeyBiYWNrZ3JvdW5kOiAjMDI4NEM3OyBib3gtc2hhZG93OiAwIDAgMCAzcHggcmdiYSgxNCwxNjUsMjMzLDAuMjUpOyB9XG4gICN3dC1idG46ZGlzYWJsZWQgeyBvcGFjaXR5OiAwLjY7IGN1cnNvcjogZGVmYXVsdDsgYm94LXNoYWRvdzogbm9uZTsgfVxuXG4gICN3dC1taWMtYnRuIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtZmxleDsgYWxpZ24taXRlbXM6IGNlbnRlcjsganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgd2lkdGg6IDI4cHg7IGhlaWdodDogMjhweDsgYm9yZGVyLXJhZGl1czogOTk5OXB4OyBib3JkZXI6IG5vbmU7XG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7IGNvbG9yOiAjNTU1OyBjdXJzb3I6IHBvaW50ZXI7XG4gICAgZm9udC1zaXplOiAxNXB4OyBsaW5lLWhlaWdodDogMTtcbiAgICB0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kIDAuMTVzLCBjb2xvciAwLjE1cztcbiAgfVxuICAjd3QtbWljLWJ0bjpob3ZlciB7IGJhY2tncm91bmQ6IHJnYmEoMCwwLDAsMC4wNyk7IH1cbiAgI3d0LW1pYy1idG4ucmVjb3JkaW5nIHsgYmFja2dyb3VuZDogI0ZFRTJFMjsgY29sb3I6ICNEQzI2MjY7XG4gICAgYW5pbWF0aW9uOiB3dC1wdWxzZSAxLjJzIGVhc2UtaW4tb3V0IGluZmluaXRlOyB9XG4gIEBrZXlmcmFtZXMgd3QtcHVsc2Uge1xuICAgIDAlLCAxMDAlIHsgYm94LXNoYWRvdzogMCAwIDAgMCByZ2JhKDIyMCwzOCwzOCwwLjQpOyB9XG4gICAgNTAlICAgICAgIHsgYm94LXNoYWRvdzogMCAwIDAgNXB4IHJnYmEoMjIwLDM4LDM4LDApOyB9XG4gIH1cbiAgI3d0LW1pYy1idG46ZGlzYWJsZWQgeyBvcGFjaXR5OiAwLjU7IGN1cnNvcjogZGVmYXVsdDsgfVxuXG4gIC53dC1wYW5lbCB7XG4gICAgcG9zaXRpb246IGZpeGVkOyB6LWluZGV4OiA5OTk5OTtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmOyBib3JkZXI6IDFweCBzb2xpZCAjRTJFOEYwOyBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIGJveC1zaGFkb3c6IDAgMTJweCAzMnB4IHJnYmEoMCwwLDAsMC4xNCk7XG4gICAgcGFkZGluZzogMTRweCAxNnB4O1xuICAgIGZvbnQtZmFtaWx5OiAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsIFwiU2Vnb2UgVUlcIiwgUm9ib3RvLCBzYW5zLXNlcmlmO1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH1cbiAgLnd0LXBhbmVsLm9wZW4geyBkaXNwbGF5OiBibG9jazsgfVxuXG4gIC8qIFx1MjUwMFx1MjUwMCBIdW1hbml6ZSBwYW5lbCBcdTI1MDBcdTI1MDAgKi9cbiAgI3d0LXBhbmVsIHsgd2lkdGg6IDI2MHB4OyB9XG4gIC53dC10aXRsZSB7IGZvbnQtc2l6ZTogMTJweDsgZm9udC13ZWlnaHQ6IDYwMDsgY29sb3I6ICMzNzQxNTE7IG1hcmdpbjogMCAwIDEwcHg7XG4gICAgbGV0dGVyLXNwYWNpbmc6IDAuMDRlbTsgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTsgfVxuICAud3QtdG9uZXMgeyBkaXNwbGF5OiBmbGV4OyBmbGV4LXdyYXA6IHdyYXA7IGdhcDogNnB4OyBtYXJnaW4tYm90dG9tOiAxMnB4OyB9XG4gIC53dC10b25lIHtcbiAgICBwYWRkaW5nOiA0cHggMTBweDsgYm9yZGVyLXJhZGl1czogOTk5OXB4OyBib3JkZXI6IDEuNXB4IHNvbGlkICNFOEVBRUQ7XG4gICAgYmFja2dyb3VuZDogI2ZmZjsgZm9udC1zaXplOiAxMnB4OyBmb250LXdlaWdodDogNTAwOyBjb2xvcjogIzM3NDE1MTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7IHRyYW5zaXRpb246IGFsbCAwLjFzO1xuICB9XG4gIC53dC10b25lLmFjdGl2ZSB7IGNvbG9yOiAjZmZmOyBib3JkZXItY29sb3I6IHRyYW5zcGFyZW50OyB9XG4gIC53dC10b25lOmhvdmVyOm5vdCguYWN0aXZlKSB7IGJvcmRlci1jb2xvcjogIzdERDNGQzsgfVxuXG4gICN3dC1yZXdyaXRlIHtcbiAgICB3aWR0aDogMTAwJTsgaGVpZ2h0OiAzMnB4OyBib3JkZXItcmFkaXVzOiA4cHg7IGJvcmRlcjogbm9uZTtcbiAgICBiYWNrZ3JvdW5kOiAke1BSSU1BUll9OyBjb2xvcjogI2ZmZjtcbiAgICBmb250OiA2MDAgMTNweC8xIC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgXCJTZWdvZSBVSVwiLCBSb2JvdG8sIHNhbnMtc2VyaWY7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gICN3dC1yZXdyaXRlOmRpc2FibGVkIHsgb3BhY2l0eTogMC40NTsgY3Vyc29yOiBkZWZhdWx0OyB9XG5cbiAgI3d0LXN0YXR1cyB7IG1hcmdpbi10b3A6IDhweDsgZm9udC1zaXplOiAxMXB4OyB0ZXh0LWFsaWduOiBjZW50ZXI7IG1pbi1oZWlnaHQ6IDE0cHg7IH1cbiAgI3d0LXN0YXR1cy5lcnJvciAgIHsgY29sb3I6ICNFRjQ0NDQ7IH1cbiAgI3d0LXN0YXR1cy5zdWNjZXNzIHsgY29sb3I6ICMxMEI5ODE7IH1cblxuICAjd3QtbGltaXQgeyBkaXNwbGF5OiBub25lOyBtYXJnaW4tdG9wOiAxMHB4OyBwYWRkaW5nOiAxMHB4IDEycHg7IGJvcmRlci1yYWRpdXM6IDhweDtcbiAgICBiYWNrZ3JvdW5kOiAjRkZGOEYxOyBib3JkZXI6IDFweCBzb2xpZCAjRkVEN0FBOyB0ZXh0LWFsaWduOiBjZW50ZXI7IH1cbiAgI3d0LWxpbWl0LnZpc2libGUgeyBkaXNwbGF5OiBibG9jazsgfVxuICAjd3QtbGltaXQgcCB7IGZvbnQtc2l6ZTogMTFweDsgY29sb3I6ICM5MjQwMEU7IG1hcmdpbjogMCAwIDhweDsgbGluZS1oZWlnaHQ6IDEuNDsgfVxuICAjd3QtbGltaXQgYSB7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrOyBwYWRkaW5nOiA1cHggMTRweDsgYm9yZGVyLXJhZGl1czogOTk5OXB4O1xuICAgIGJhY2tncm91bmQ6ICNGNTlFMEI7IGNvbG9yOiAjZmZmOyBmb250LXNpemU6IDExcHg7IGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xuICB9XG5cbiAgI3d0LWFjdGlvbnMgeyBkaXNwbGF5OiBub25lOyBnYXA6IDZweDsgbWFyZ2luLXRvcDogOHB4OyB9XG4gICN3dC1hY3Rpb25zLnZpc2libGUgeyBkaXNwbGF5OiBmbGV4OyB9XG4gIC53dC1hY3Rpb24ge1xuICAgIGZsZXg6IDE7IGhlaWdodDogMjhweDsgYm9yZGVyLXJhZGl1czogOHB4OyBib3JkZXI6IDEuNXB4IHNvbGlkICNFOEVBRUQ7XG4gICAgYmFja2dyb3VuZDogI2ZmZjsgZm9udC1zaXplOiAxMnB4OyBmb250LXdlaWdodDogNTAwOyBjb2xvcjogIzM3NDE1MTsgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIC53dC1hY3Rpb24uYWNjZXB0IHsgYm9yZGVyLWNvbG9yOiAjMTBCOTgxOyBjb2xvcjogIzEwQjk4MTsgfVxuICAud3QtYWN0aW9uLnJlamVjdCB7IGJvcmRlci1jb2xvcjogI0VGNDQ0NDsgY29sb3I6ICNFRjQ0NDQ7IH1cblxuICAvKiBcdTI1MDBcdTI1MDAgVm9pY2UgcGFuZWwgXHUyNTAwXHUyNTAwICovXG4gICN3dC12b2ljZS1wYW5lbCB7IHdpZHRoOiAyODBweDsgfVxuICAud3QtdnQgeyBmb250LXNpemU6IDEycHg7IGZvbnQtd2VpZ2h0OiA2MDA7IGNvbG9yOiAjMzc0MTUxOyBtYXJnaW46IDAgMCAxMHB4O1xuICAgIGxldHRlci1zcGFjaW5nOiAwLjA0ZW07IHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7IH1cbiAgLnd0LW90eXBlLWxhYmVsIHsgZm9udC1zaXplOiAxMXB4OyBjb2xvcjogIzZCNzI4MDsgbWFyZ2luLWJvdHRvbTogNHB4OyB9XG4gIC53dC1vdHlwZXMgeyBkaXNwbGF5OiBmbGV4OyBmbGV4LXdyYXA6IHdyYXA7IGdhcDogNXB4OyBtYXJnaW4tYm90dG9tOiAxMHB4OyB9XG4gIC53dC1vdHlwZSB7XG4gICAgcGFkZGluZzogM3B4IDlweDsgYm9yZGVyLXJhZGl1czogOTk5OXB4OyBib3JkZXI6IDEuNXB4IHNvbGlkICNFOEVBRUQ7XG4gICAgYmFja2dyb3VuZDogI2ZmZjsgZm9udC1zaXplOiAxMXB4OyBjb2xvcjogIzM3NDE1MTsgY3Vyc29yOiBwb2ludGVyOyB0cmFuc2l0aW9uOiBhbGwgMC4xcztcbiAgfVxuICAud3Qtb3R5cGUuYWN0aXZlIHsgYmFja2dyb3VuZDogJHtQUklNQVJZfTsgY29sb3I6ICNmZmY7IGJvcmRlci1jb2xvcjogJHtQUklNQVJZfTsgfVxuICAjd3QtcmVjb3JkLWJ0biB7XG4gICAgd2lkdGg6IDEwMCU7IGhlaWdodDogMzJweDsgYm9yZGVyLXJhZGl1czogOHB4OyBib3JkZXI6IG5vbmU7XG4gICAgYmFja2dyb3VuZDogI0RDMjYyNjsgY29sb3I6ICNmZmY7IGN1cnNvcjogcG9pbnRlcjsgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICBmb250OiA2MDAgMTNweC8xIC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgXCJTZWdvZSBVSVwiLCBSb2JvdG8sIHNhbnMtc2VyaWY7XG4gIH1cbiAgI3d0LXJlY29yZC1idG4ucmVjb3JkaW5nIHsgYmFja2dyb3VuZDogIzdGMUQxRDsgfVxuICAjd3QtcmVjb3JkLWJ0bjpkaXNhYmxlZCB7IG9wYWNpdHk6IDAuNTsgY3Vyc29yOiBkZWZhdWx0OyB9XG4gICN3dC12b2ljZS1zdGF0dXMgeyBmb250LXNpemU6IDExcHg7IHRleHQtYWxpZ246IGNlbnRlcjsgbWluLWhlaWdodDogMTRweDsgY29sb3I6ICM2QjcyODA7IH1cbiAgI3d0LXZvaWNlLXN0YXR1cy5lcnJvciB7IGNvbG9yOiAjRUY0NDQ0OyB9XG4gICN3dC12b2ljZS1hY3Rpb25zIHsgZGlzcGxheTogbm9uZTsgZ2FwOiA2cHg7IG1hcmdpbi10b3A6IDhweDsgfVxuICAjd3Qtdm9pY2UtYWN0aW9ucy52aXNpYmxlIHsgZGlzcGxheTogZmxleDsgfVxuICAud3QtdmEge1xuICAgIGZsZXg6IDE7IGhlaWdodDogMjhweDsgYm9yZGVyLXJhZGl1czogOHB4OyBib3JkZXI6IDEuNXB4IHNvbGlkICNFOEVBRUQ7XG4gICAgYmFja2dyb3VuZDogI2ZmZjsgZm9udC1zaXplOiAxMnB4OyBmb250LXdlaWdodDogNTAwOyBjb2xvcjogIzM3NDE1MTsgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIC53dC12YS5hY2NlcHQgeyBib3JkZXItY29sb3I6ICMxMEI5ODE7IGNvbG9yOiAjMTBCOTgxOyB9XG4gIC53dC12YS5yZWplY3QgeyBib3JkZXItY29sb3I6ICNFRjQ0NDQ7IGNvbG9yOiAjRUY0NDQ0OyB9XG5gO1xuXG4vLyBcdTI1MDBcdTI1MDAgTW9kdWxlLWxldmVsIHBhbmVsIG1hbmFnZXIgXHUyMDE0IHNpbmdsZSBkZWxlZ2F0ZWQgY2xpY2sgbGlzdGVuZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vLyBHdWFyYW50ZWVzIGV4YWN0bHkgb25lIGRvY3VtZW50IGxpc3RlbmVyIHJlZ2FyZGxlc3Mgb2YgaG93IG1hbnkgY29tcG9zZVxuLy8gd2luZG93cyBhcmUgb3BlbiBzaW11bHRhbmVvdXNseSAoaW1wb3J0YW50IGZvciBTUEEgbmF2aWdhdGlvbnMpLlxuXG5sZXQgb3BlblBhbmVsOiB7IGhvc3Q6IEVsZW1lbnQ7IGNsb3NlOiAoKSA9PiB2b2lkIH0gfCBudWxsID0gbnVsbDtcblxuZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZSkgPT4ge1xuICBpZiAob3BlblBhbmVsICYmICFvcGVuUGFuZWwuaG9zdC5jb250YWlucyhlLnRhcmdldCBhcyBOb2RlKSkge1xuICAgIG9wZW5QYW5lbC5jbG9zZSgpO1xuICAgIG9wZW5QYW5lbCA9IG51bGw7XG4gIH1cbn0sIHRydWUpO1xuXG5mdW5jdGlvbiBvcGVuUGFuZWxGb3IoaG9zdDogRWxlbWVudCwgY2xvc2U6ICgpID0+IHZvaWQpOiB2b2lkIHtcbiAgaWYgKG9wZW5QYW5lbCAmJiBvcGVuUGFuZWwuaG9zdCAhPT0gaG9zdCkgb3BlblBhbmVsLmNsb3NlKCk7XG4gIG9wZW5QYW5lbCA9IHsgaG9zdCwgY2xvc2UgfTtcbn1cblxuZnVuY3Rpb24gY2xlYXJPcGVuUGFuZWwoaG9zdDogRWxlbWVudCk6IHZvaWQge1xuICBpZiAob3BlblBhbmVsPy5ob3N0ID09PSBob3N0KSBvcGVuUGFuZWwgPSBudWxsO1xufVxuXG4vLyBcdTI1MDBcdTI1MDAgSGVscGVycyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuZnVuY3Rpb24gc2VuZFRvQmFja2dyb3VuZDxUPihtZXNzYWdlOiBvYmplY3QpOiBQcm9taXNlPFQ+IHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZShtZXNzYWdlLCByZXNvbHZlKSk7XG59XG5cbmZ1bmN0aW9uIGlzVGV4dGFyZWEoZWw6IEVsZW1lbnQpOiBlbCBpcyBIVE1MVGV4dEFyZWFFbGVtZW50IHtcbiAgcmV0dXJuIGVsLnRhZ05hbWUgPT09ICdURVhUQVJFQSc7XG59XG5cbmZ1bmN0aW9uIHJlYWRDb21wb3NlKGVsOiBFbGVtZW50KTogc3RyaW5nIHtcbiAgaWYgKGlzVGV4dGFyZWEoZWwpKSByZXR1cm4gKGVsIGFzIEhUTUxUZXh0QXJlYUVsZW1lbnQpLnZhbHVlLnRyaW0oKTtcbiAgcmV0dXJuIChlbCBhcyBIVE1MRWxlbWVudCkuaW5uZXJUZXh0LnRyaW0oKTtcbn1cblxuZnVuY3Rpb24gd3JpdGVDb21wb3NlKGVsOiBFbGVtZW50LCB0ZXh0OiBzdHJpbmcpOiB2b2lkIHtcbiAgaWYgKGlzVGV4dGFyZWEoZWwpKSB7XG4gICAgY29uc3QgdGEgPSBlbCBhcyBIVE1MVGV4dEFyZWFFbGVtZW50O1xuICAgIHRhLnZhbHVlID0gdGV4dDtcbiAgICB0YS5kaXNwYXRjaEV2ZW50KG5ldyBFdmVudCgnaW5wdXQnLCB7IGJ1YmJsZXM6IHRydWUgfSkpO1xuICAgIHRhLmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KCdjaGFuZ2UnLCB7IGJ1YmJsZXM6IHRydWUgfSkpO1xuICB9IGVsc2Uge1xuICAgIGNvbnN0IGRpdiA9IGVsIGFzIEhUTUxFbGVtZW50O1xuICAgIGRpdi5mb2N1cygpO1xuICAgIGRvY3VtZW50LmV4ZWNDb21tYW5kKCdzZWxlY3RBbGwnLCBmYWxzZSwgdW5kZWZpbmVkKTtcbiAgICBkb2N1bWVudC5leGVjQ29tbWFuZCgnZGVsZXRlJywgZmFsc2UsIHVuZGVmaW5lZCk7XG4gICAgY29uc3QgbGluZXMgPSB0ZXh0LnNwbGl0KCdcXG4nKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxpbmVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBpZiAobGluZXNbaV0pIGRvY3VtZW50LmV4ZWNDb21tYW5kKCdpbnNlcnRUZXh0JywgZmFsc2UsIGxpbmVzW2ldKTtcbiAgICAgIGlmIChpIDwgbGluZXMubGVuZ3RoIC0gMSkgZG9jdW1lbnQuZXhlY0NvbW1hbmQoJ2luc2VydFBhcmFncmFwaCcsIGZhbHNlLCB1bmRlZmluZWQpO1xuICAgIH1cbiAgfVxufVxuXG4vLyBcdTI1MDBcdTI1MDAgSW5qZWN0aW9uIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5mdW5jdGlvbiBpbmplY3QoY29tcG9zZUJvZHk6IEVsZW1lbnQpOiB2b2lkIHtcbiAgaWYgKGNvbXBvc2VCb2R5Lmhhc0F0dHJpYnV0ZShIT1NUX0FUVFIpKSByZXR1cm47XG4gIGNvbXBvc2VCb2R5LnNldEF0dHJpYnV0ZShIT1NUX0FUVFIsICcxJyk7XG5cbiAgLy8gSW5qZWN0IGEgcm93IG9mIGJ1dHRvbnMgYmVsb3cgdGhlIGNvbXBvc2UgYXJlYS5cbiAgLy8gVXNlIGEgY2xvc2UgYW5jZXN0b3IgYXMgdGhlIGluc2VydGlvbiBwb2ludCBzbyBIaVdvcmtzJyBvd24gbGF5b3V0IGlzXG4gIC8vIGRpc3J1cHRlZCBhcyBsaXR0bGUgYXMgcG9zc2libGUuXG4gIGNvbnN0IHdyYXBwZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgd3JhcHBlci5zdHlsZS5jc3NUZXh0ID0gJ2Rpc3BsYXk6ZmxleDthbGlnbi1pdGVtczpjZW50ZXI7Z2FwOjRweDttYXJnaW4tdG9wOjhweDtwYWRkaW5nOjAgMnB4Oyc7XG5cbiAgY29uc3QgaW5zZXJ0aW9uUG9pbnQgPVxuICAgIGNvbXBvc2VCb2R5LmNsb3Nlc3QoJ1tjbGFzcyo9XCJlZGl0b3JcIl0sIFtjbGFzcyo9XCJjb21wb3NlXCJdLCBbY2xhc3MqPVwibWFpbFwiXSwgZm9ybScpID8/XG4gICAgY29tcG9zZUJvZHkucGFyZW50RWxlbWVudDtcbiAgaW5zZXJ0aW9uUG9pbnQ/Lmluc2VydEFkamFjZW50RWxlbWVudCgnYWZ0ZXJlbmQnLCB3cmFwcGVyKTtcbiAgaWYgKCF3cmFwcGVyLnBhcmVudEVsZW1lbnQpIGNvbXBvc2VCb2R5LnBhcmVudEVsZW1lbnQ/LmFwcGVuZENoaWxkKHdyYXBwZXIpO1xuXG4gIGNvbnN0IGhvc3QgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gIGNvbnN0IHNoYWRvdyA9IGhvc3QuYXR0YWNoU2hhZG93KHsgbW9kZTogJ29wZW4nIH0pO1xuXG4gIGxldCBzZWxlY3RlZFRvbmU6IFRvbmUgfCBudWxsID0gbnVsbDtcbiAgbGV0IGxhc3RSZXdyaXRlSWQ6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuICBsZXQgcGFuZWxPcGVuID0gZmFsc2U7XG4gIGxldCB2b2ljZVBhbmVsT3BlbiA9IGZhbHNlO1xuICBsZXQgc2VsZWN0ZWRPdXRwdXRUeXBlOiBWb2ljZU91dHB1dFR5cGUgPSBWT0lDRV9PVVRQVVRfVFlQRVNbMF0ua2V5O1xuICBsZXQgcmVjb3JkZXI6IE1lZGlhUmVjb3JkZXIgfCBudWxsID0gbnVsbDtcbiAgbGV0IHJlY29yZGluZyA9IGZhbHNlO1xuICBsZXQgYXVkaW9DaHVua3M6IEJsb2JQYXJ0W10gPSBbXTtcbiAgbGV0IGxhc3RWb2ljZVNlc3Npb25JZDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG4gIGxldCBvcmlnaW5hbFRleHQgPSAnJztcbiAgbGV0IG9yaWdpbmFsVm9pY2VUZXh0ID0gJyc7XG5cbiAgc2hhZG93LmlubmVySFRNTCA9IGBcbiAgICA8c3R5bGU+JHtDU1N9PC9zdHlsZT5cbiAgICA8YnV0dG9uIGlkPVwid3QtYnRuXCIgdGl0bGU9XCJIdW1hbml6ZSB3aXRoIFdyaXRpbmcgVHdpbiBBSVwiPlx1MjcyOCBIdW1hbml6ZTwvYnV0dG9uPlxuICAgIDxidXR0b24gaWQ9XCJ3dC1taWMtYnRuXCIgdGl0bGU9XCJWb2ljZSBUd2luIFx1MjAxNCBzcGVhayB5b3VyIGVtYWlsXCI+XHVEODNDXHVERjk5PC9idXR0b24+XG5cbiAgICA8ZGl2IGlkPVwid3QtcGFuZWxcIiBjbGFzcz1cInd0LXBhbmVsXCI+XG4gICAgICA8cCBjbGFzcz1cInd0LXRpdGxlXCI+UmV3cml0ZSB0b25lPC9wPlxuICAgICAgPGRpdiBjbGFzcz1cInd0LXRvbmVzXCI+XG4gICAgICAgICR7VE9ORVMubWFwKHQgPT4gYDxidXR0b24gY2xhc3M9XCJ3dC10b25lXCIgZGF0YS10b25lPVwiJHt0LmtleX1cIiBkYXRhLWNvbG9yPVwiJHt0LmNvbG9yfVwiPiR7dC5sYWJlbH08L2J1dHRvbj5gKS5qb2luKCcnKX1cbiAgICAgIDwvZGl2PlxuICAgICAgPGJ1dHRvbiBpZD1cInd0LXJld3JpdGVcIiBkaXNhYmxlZD5SZXdyaXRlIFx1MjE5MjwvYnV0dG9uPlxuICAgICAgPGRpdiBpZD1cInd0LXN0YXR1c1wiPjwvZGl2PlxuICAgICAgPGRpdiBpZD1cInd0LWxpbWl0XCI+XG4gICAgICAgIDxwPllvdSd2ZSB1c2VkIGFsbCB5b3VyIGZyZWUgcmV3cml0ZXMgdGhpcyBtb250aC48L3A+XG4gICAgICAgIDxhIGhyZWY9XCJodHRwczovL3dyaXRpbmd0d2luYWkuY29tL3ByaWNpbmdcIiB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub29wZW5lclwiPlVwZ3JhZGUgdG8gUHJvIFx1MjAxNCAkNS9tbzwvYT5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBpZD1cInd0LWFjdGlvbnNcIj5cbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cInd0LWFjdGlvbiBhY2NlcHRcIiBpZD1cInd0LWFjY2VwdFwiPlx1MjcxMyBLZWVwIGl0PC9idXR0b24+XG4gICAgICAgIDxidXR0b24gY2xhc3M9XCJ3dC1hY3Rpb24gcmVqZWN0XCIgaWQ9XCJ3dC1yZWplY3RcIj5cdTI3MTcgVW5kbzwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG5cbiAgICA8ZGl2IGlkPVwid3Qtdm9pY2UtcGFuZWxcIiBjbGFzcz1cInd0LXBhbmVsXCI+XG4gICAgICA8cCBjbGFzcz1cInd0LXZ0XCI+Vm9pY2UgVHdpbjwvcD5cbiAgICAgIDxkaXYgY2xhc3M9XCJ3dC1vdHlwZS1sYWJlbFwiPk91dHB1dCB0eXBlPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzPVwid3Qtb3R5cGVzXCI+XG4gICAgICAgICR7Vk9JQ0VfT1VUUFVUX1RZUEVTLm1hcCgobywgaSkgPT5cbiAgICAgICAgICBgPGJ1dHRvbiBjbGFzcz1cInd0LW90eXBlJHtpID09PSAwID8gJyBhY3RpdmUnIDogJyd9XCIgZGF0YS10eXBlPVwiJHtvLmtleX1cIj4ke28ubGFiZWx9PC9idXR0b24+YFxuICAgICAgICApLmpvaW4oJycpfVxuICAgICAgPC9kaXY+XG4gICAgICA8YnV0dG9uIGlkPVwid3QtcmVjb3JkLWJ0blwiPlx1RDgzQ1x1REY5OSBTdGFydCByZWNvcmRpbmc8L2J1dHRvbj5cbiAgICAgIDxkaXYgaWQ9XCJ3dC12b2ljZS1zdGF0dXNcIj48L2Rpdj5cbiAgICAgIDxkaXYgaWQ9XCJ3dC12b2ljZS1hY3Rpb25zXCI+XG4gICAgICAgIDxidXR0b24gY2xhc3M9XCJ3dC12YSBhY2NlcHRcIiBpZD1cInd0LXZhLWtlZXBcIj5cdTI3MTMgS2VlcCBpdDwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uIGNsYXNzPVwid3QtdmEgcmVqZWN0XCIgaWQ9XCJ3dC12YS11bmRvXCI+XHUyNzE3IFVuZG88L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIC8vIFx1MjUwMFx1MjUwMCBFbGVtZW50IHJlZnMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4gIGNvbnN0IGJ0biAgICAgICAgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LWJ0bicpICAgICAgICAgIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICBjb25zdCBtaWNCdG4gICAgID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC1taWMtYnRuJykgICAgICBhcyBIVE1MQnV0dG9uRWxlbWVudDtcbiAgY29uc3QgcGFuZWwgICAgICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtcGFuZWwnKSAgICAgICAgYXMgSFRNTERpdkVsZW1lbnQ7XG4gIGNvbnN0IHZvaWNlUGFuZWwgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LXZvaWNlLXBhbmVsJykgIGFzIEhUTUxEaXZFbGVtZW50O1xuICBjb25zdCByZXdyaXRlQnRuID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC1yZXdyaXRlJykgICAgICBhcyBIVE1MQnV0dG9uRWxlbWVudDtcbiAgY29uc3Qgc3RhdHVzRWwgICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3Qtc3RhdHVzJykgICAgICAgYXMgSFRNTERpdkVsZW1lbnQ7XG4gIGNvbnN0IGxpbWl0RWwgICAgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LWxpbWl0JykgICAgICAgIGFzIEhUTUxEaXZFbGVtZW50O1xuICBjb25zdCBhY3Rpb25zRWwgID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC1hY3Rpb25zJykgICAgICBhcyBIVE1MRGl2RWxlbWVudDtcbiAgY29uc3QgYWNjZXB0QnRuICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtYWNjZXB0JykgICAgICAgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG4gIGNvbnN0IHJlamVjdEJ0biAgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LXJlamVjdCcpICAgICAgIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICBjb25zdCByZWNvcmRCdG4gID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC1yZWNvcmQtYnRuJykgICBhcyBIVE1MQnV0dG9uRWxlbWVudDtcbiAgY29uc3QgdlN0YXR1c0VsICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3Qtdm9pY2Utc3RhdHVzJykgYXMgSFRNTERpdkVsZW1lbnQ7XG4gIGNvbnN0IHZBY3Rpb25zRWwgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LXZvaWNlLWFjdGlvbnMnKSBhcyBIVE1MRGl2RWxlbWVudDtcbiAgY29uc3QgdktlZXBCdG4gICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtdmEta2VlcCcpICAgICAgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG4gIGNvbnN0IHZVbmRvQnRuICAgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LXZhLXVuZG8nKSAgICAgIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuXG4gIC8vIFx1MjUwMFx1MjUwMCBUb25lIHNlbGVjdG9yIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuICBzaGFkb3cucXVlcnlTZWxlY3RvckFsbDxIVE1MQnV0dG9uRWxlbWVudD4oJy53dC10b25lJykuZm9yRWFjaCh0YiA9PiB7XG4gICAgdGIuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgICBzaGFkb3cucXVlcnlTZWxlY3RvckFsbCgnLnd0LXRvbmUnKS5mb3JFYWNoKGIgPT4gYi5jbGFzc0xpc3QucmVtb3ZlKCdhY3RpdmUnKSk7XG4gICAgICB0Yi5jbGFzc0xpc3QuYWRkKCdhY3RpdmUnKTtcbiAgICAgIHRiLnN0eWxlLmJhY2tncm91bmQgID0gdGIuZGF0YXNldC5jb2xvciA/PyBQUklNQVJZO1xuICAgICAgdGIuc3R5bGUuYm9yZGVyQ29sb3IgPSB0Yi5kYXRhc2V0LmNvbG9yID8/IFBSSU1BUlk7XG4gICAgICBzZWxlY3RlZFRvbmUgPSB0Yi5kYXRhc2V0LnRvbmUgYXMgVG9uZTtcbiAgICAgIHJld3JpdGVCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgICAgIHNldFN0YXR1cygnJyk7IGxpbWl0RWwuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xuICAgICAgYWN0aW9uc0VsLmNsYXNzTGlzdC5yZW1vdmUoJ3Zpc2libGUnKTtcbiAgICB9KTtcbiAgfSk7XG5cbiAgLy8gXHUyNTAwXHUyNTAwIFZvaWNlIG91dHB1dCB0eXBlIHNlbGVjdG9yIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuICBzaGFkb3cucXVlcnlTZWxlY3RvckFsbDxIVE1MQnV0dG9uRWxlbWVudD4oJy53dC1vdHlwZScpLmZvckVhY2gob2IgPT4ge1xuICAgIG9iLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgICAgc2hhZG93LnF1ZXJ5U2VsZWN0b3JBbGwoJy53dC1vdHlwZScpLmZvckVhY2goYiA9PiBiLmNsYXNzTGlzdC5yZW1vdmUoJ2FjdGl2ZScpKTtcbiAgICAgIG9iLmNsYXNzTGlzdC5hZGQoJ2FjdGl2ZScpO1xuICAgICAgc2VsZWN0ZWRPdXRwdXRUeXBlID0gb2IuZGF0YXNldC50eXBlIGFzIFZvaWNlT3V0cHV0VHlwZTtcbiAgICB9KTtcbiAgfSk7XG5cbiAgLy8gXHUyNTAwXHUyNTAwIFBhbmVsIHRvZ2dsZXMgKGRlbGVnYXRlZCBjbGljayBsaXN0ZW5lciBoYW5kbGVzIG91dHNpZGUtY2xpY2tzKSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbiAgYnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgIGlmIChwYW5lbE9wZW4pIHtcbiAgICAgIHBhbmVsT3BlbiA9IGZhbHNlOyBwYW5lbC5jbGFzc0xpc3QucmVtb3ZlKCdvcGVuJyk7XG4gICAgICBjbGVhck9wZW5QYW5lbChob3N0KTtcbiAgICB9IGVsc2Uge1xuICAgICAgdm9pY2VQYW5lbE9wZW4gPSBmYWxzZTsgdm9pY2VQYW5lbC5jbGFzc0xpc3QucmVtb3ZlKCdvcGVuJyk7XG4gICAgICBwYW5lbE9wZW4gPSB0cnVlOyBwYW5lbC5jbGFzc0xpc3QuYWRkKCdvcGVuJyk7XG4gICAgICBwb3NpdGlvblBhbmVsKGJ0biwgcGFuZWwpO1xuICAgICAgb3BlblBhbmVsRm9yKGhvc3QsICgpID0+IHtcbiAgICAgICAgcGFuZWxPcGVuID0gZmFsc2U7IHBhbmVsLmNsYXNzTGlzdC5yZW1vdmUoJ29wZW4nKTtcbiAgICAgICAgdm9pY2VQYW5lbE9wZW4gPSBmYWxzZTsgdm9pY2VQYW5lbC5jbGFzc0xpc3QucmVtb3ZlKCdvcGVuJyk7XG4gICAgICB9KTtcbiAgICB9XG4gIH0pO1xuXG4gIG1pY0J0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBpZiAodm9pY2VQYW5lbE9wZW4pIHtcbiAgICAgIHZvaWNlUGFuZWxPcGVuID0gZmFsc2U7IHZvaWNlUGFuZWwuY2xhc3NMaXN0LnJlbW92ZSgnb3BlbicpO1xuICAgICAgY2xlYXJPcGVuUGFuZWwoaG9zdCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHBhbmVsT3BlbiA9IGZhbHNlOyBwYW5lbC5jbGFzc0xpc3QucmVtb3ZlKCdvcGVuJyk7XG4gICAgICB2b2ljZVBhbmVsT3BlbiA9IHRydWU7IHZvaWNlUGFuZWwuY2xhc3NMaXN0LmFkZCgnb3BlbicpO1xuICAgICAgcG9zaXRpb25QYW5lbChtaWNCdG4sIHZvaWNlUGFuZWwpO1xuICAgICAgb3BlblBhbmVsRm9yKGhvc3QsICgpID0+IHtcbiAgICAgICAgdm9pY2VQYW5lbE9wZW4gPSBmYWxzZTsgdm9pY2VQYW5lbC5jbGFzc0xpc3QucmVtb3ZlKCdvcGVuJyk7XG4gICAgICAgIHBhbmVsT3BlbiA9IGZhbHNlOyBwYW5lbC5jbGFzc0xpc3QucmVtb3ZlKCdvcGVuJyk7XG4gICAgICB9KTtcbiAgICB9XG4gIH0pO1xuXG4gIGZ1bmN0aW9uIHBvc2l0aW9uUGFuZWwoYW5jaG9yOiBIVE1MRWxlbWVudCwgcDogSFRNTERpdkVsZW1lbnQpOiB2b2lkIHtcbiAgICBjb25zdCByZWN0ID0gYW5jaG9yLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIHAuc3R5bGUuYm90dG9tID0gYCR7d2luZG93LmlubmVySGVpZ2h0IC0gcmVjdC50b3AgKyA0fXB4YDtcbiAgICBwLnN0eWxlLmxlZnQgICA9IGAke01hdGgubWluKHJlY3QubGVmdCwgd2luZG93LmlubmVyV2lkdGggLSBwYXJzZUludChwLnN0eWxlLndpZHRoIHx8ICcyNjAnKSAtIDIwKX1weGA7XG4gIH1cblxuICAvLyBcdTI1MDBcdTI1MDAgUmV3cml0ZSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbiAgcmV3cml0ZUJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgICBpZiAoIXNlbGVjdGVkVG9uZSkgcmV0dXJuO1xuICAgIGNvbnN0IHRleHQgPSByZWFkQ29tcG9zZShjb21wb3NlQm9keSk7XG4gICAgaWYgKCF0ZXh0KSB7IHNldFN0YXR1cygnV3JpdGUgc29tZXRoaW5nIGZpcnN0LicsICdlcnJvcicpOyByZXR1cm47IH1cblxuICAgIG9yaWdpbmFsVGV4dCA9IHRleHQ7XG4gICAgYnRuLmRpc2FibGVkID0gdHJ1ZTsgcmV3cml0ZUJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gICAgc2V0U3RhdHVzKCdSZXdyaXRpbmdcdTIwMjYnKTsgYWN0aW9uc0VsLmNsYXNzTGlzdC5yZW1vdmUoJ3Zpc2libGUnKTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwID0gYXdhaXQgc2VuZFRvQmFja2dyb3VuZDx7IHJlc3VsdDogUmV3cml0ZVJlc3BvbnNlIH0gfCB7IGVycm9yOiBzdHJpbmcgfT4oe1xuICAgICAgICB0eXBlOiAnSFVNQU5JWkUnLFxuICAgICAgICBwYXlsb2FkOiB7XG4gICAgICAgICAgdGV4dCxcbiAgICAgICAgICB0b25lOiBzZWxlY3RlZFRvbmUsXG4gICAgICAgICAgY3R4OiB7IHBsYXRmb3JtOiAnaGl3b3JrcycsIGNvbnRleHRfdHdpbl9vdmVycmlkZTogRklYRURfQ09OVEVYVF9PVkVSUklERSB9LFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgICBpZiAoJ2Vycm9yJyBpbiByZXNwKSB0aHJvdyBuZXcgRXJyb3IoU3RyaW5nKHJlc3AuZXJyb3IpKTtcbiAgICAgIGxhc3RSZXdyaXRlSWQgPSByZXNwLnJlc3VsdC5pZDtcbiAgICAgIHdyaXRlQ29tcG9zZShjb21wb3NlQm9keSwgcmVzcC5yZXN1bHQub3V0cHV0X3RleHQpO1xuICAgICAgc2V0U3RhdHVzKCdEb25lIFx1MjcxMycsICdzdWNjZXNzJyk7XG4gICAgICBhY3Rpb25zRWwuY2xhc3NMaXN0LmFkZCgndmlzaWJsZScpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc3QgbXNnID0gZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6ICdGYWlsZWQnO1xuICAgICAgaWYgKG1zZy5zdGFydHNXaXRoKCdMSU1JVF9SRUFDSEVEOicpKSB7XG4gICAgICAgIGxpbWl0RWwuY2xhc3NMaXN0LmFkZCgndmlzaWJsZScpOyBzZXRTdGF0dXMoJycpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2V0U3RhdHVzKG1zZywgJ2Vycm9yJyk7XG4gICAgICB9XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIGJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICAgICAgcmV3cml0ZUJ0bi5kaXNhYmxlZCA9IHNlbGVjdGVkVG9uZSA9PT0gbnVsbDtcbiAgICB9XG4gIH0pO1xuXG4gIGFjY2VwdEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBpZiAobGFzdFJld3JpdGVJZCkgc2VuZFRvQmFja2dyb3VuZCh7IHR5cGU6ICdGRUVEQkFDSycsIHBheWxvYWQ6IHsgcmV3cml0ZUlkOiBsYXN0UmV3cml0ZUlkLCBhY3Rpb246ICdhY2NlcHRlZCcgfSB9KTtcbiAgICBhY3Rpb25zRWwuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xuICAgIHBhbmVsT3BlbiA9IGZhbHNlOyBwYW5lbC5jbGFzc0xpc3QucmVtb3ZlKCdvcGVuJyk7XG4gICAgY2xlYXJPcGVuUGFuZWwoaG9zdCk7XG4gICAgc2V0U3RhdHVzKCcnKTtcbiAgfSk7XG5cbiAgcmVqZWN0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgIGlmIChvcmlnaW5hbFRleHQpIHdyaXRlQ29tcG9zZShjb21wb3NlQm9keSwgb3JpZ2luYWxUZXh0KTtcbiAgICBpZiAobGFzdFJld3JpdGVJZCkgc2VuZFRvQmFja2dyb3VuZCh7IHR5cGU6ICdGRUVEQkFDSycsIHBheWxvYWQ6IHsgcmV3cml0ZUlkOiBsYXN0UmV3cml0ZUlkLCBhY3Rpb246ICdyZWplY3RlZCcgfSB9KTtcbiAgICBhY3Rpb25zRWwuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xuICAgIHNldFN0YXR1cygnUmV2ZXJ0ZWQuJywgJ3N1Y2Nlc3MnKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHNldFN0YXR1cygnJyksIDIwMDApO1xuICB9KTtcblxuICBmdW5jdGlvbiBzZXRTdGF0dXMobXNnOiBzdHJpbmcsIGNscyA9ICcnKTogdm9pZCB7XG4gICAgc3RhdHVzRWwudGV4dENvbnRlbnQgPSBtc2c7IHN0YXR1c0VsLmNsYXNzTmFtZSA9IGNscztcbiAgfVxuXG4gIC8vIFx1MjUwMFx1MjUwMCBSZWNvcmRpbmcgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4gIHJlY29yZEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgICBpZiAoIXJlY29yZGluZykgYXdhaXQgc3RhcnRSZWNvcmRpbmcoKTsgZWxzZSBzdG9wUmVjb3JkaW5nKCk7XG4gIH0pO1xuXG4gIGFzeW5jIGZ1bmN0aW9uIHN0YXJ0UmVjb3JkaW5nKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBzdHJlYW0gPSBhd2FpdCBuYXZpZ2F0b3IubWVkaWFEZXZpY2VzLmdldFVzZXJNZWRpYSh7IGF1ZGlvOiB0cnVlIH0pO1xuICAgICAgYXVkaW9DaHVua3MgPSBbXTtcbiAgICAgIHJlY29yZGVyID0gbmV3IE1lZGlhUmVjb3JkZXIoc3RyZWFtLCB7IG1pbWVUeXBlOiAnYXVkaW8vd2VibScgfSk7XG4gICAgICByZWNvcmRlci5vbmRhdGFhdmFpbGFibGUgPSAoZSkgPT4geyBpZiAoZS5kYXRhLnNpemUgPiAwKSBhdWRpb0NodW5rcy5wdXNoKGUuZGF0YSk7IH07XG4gICAgICByZWNvcmRlci5vbnN0b3AgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIHN0cmVhbS5nZXRUcmFja3MoKS5mb3JFYWNoKHQgPT4gdC5zdG9wKCkpO1xuICAgICAgICBhd2FpdCBzdWJtaXRWb2ljZShuZXcgQmxvYihhdWRpb0NodW5rcywgeyB0eXBlOiAnYXVkaW8vd2VibScgfSkpO1xuICAgICAgfTtcbiAgICAgIHJlY29yZGVyLnN0YXJ0KCk7XG4gICAgICByZWNvcmRpbmcgPSB0cnVlO1xuICAgICAgbWljQnRuLmNsYXNzTGlzdC5hZGQoJ3JlY29yZGluZycpO1xuICAgICAgcmVjb3JkQnRuLmNsYXNzTGlzdC5hZGQoJ3JlY29yZGluZycpO1xuICAgICAgcmVjb3JkQnRuLnRleHRDb250ZW50ID0gJ1x1MjNGOSBTdG9wIHJlY29yZGluZyc7XG4gICAgICBzZXRWU3RhdHVzKCdSZWNvcmRpbmdcdTIwMjYnKTtcbiAgICAgIHZBY3Rpb25zRWwuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiB7IGlmIChyZWNvcmRpbmcpIHN0b3BSZWNvcmRpbmcoKTsgfSwgNjBfMDAwKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHNldFZTdGF0dXMoJ01pY3JvcGhvbmUgYWNjZXNzIGRlbmllZC4nLCAnZXJyb3InKTtcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBzdG9wUmVjb3JkaW5nKCk6IHZvaWQge1xuICAgIGlmIChyZWNvcmRlciAmJiByZWNvcmRpbmcpIHtcbiAgICAgIHJlY29yZGVyLnN0b3AoKTsgcmVjb3JkaW5nID0gZmFsc2U7XG4gICAgICBtaWNCdG4uY2xhc3NMaXN0LnJlbW92ZSgncmVjb3JkaW5nJyk7XG4gICAgICByZWNvcmRCdG4uY2xhc3NMaXN0LnJlbW92ZSgncmVjb3JkaW5nJyk7XG4gICAgICByZWNvcmRCdG4udGV4dENvbnRlbnQgPSAnXHVEODNDXHVERjk5IFN0YXJ0IHJlY29yZGluZyc7XG4gICAgICByZWNvcmRCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICAgICAgc2V0VlN0YXR1cygnRHJhZnRpbmdcdTIwMjYnKTtcbiAgICB9XG4gIH1cblxuICBhc3luYyBmdW5jdGlvbiBzdWJtaXRWb2ljZShibG9iOiBCbG9iKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGJ1ZiA9IGF3YWl0IGJsb2IuYXJyYXlCdWZmZXIoKTtcbiAgICAgIGNvbnN0IGF1ZGlvRGF0YSA9IGJ0b2EoQXJyYXkuZnJvbShuZXcgVWludDhBcnJheShidWYpLCBiID0+IFN0cmluZy5mcm9tQ2hhckNvZGUoYikpLmpvaW4oJycpKTtcbiAgICAgIG9yaWdpbmFsVm9pY2VUZXh0ID0gcmVhZENvbXBvc2UoY29tcG9zZUJvZHkpO1xuICAgICAgY29uc3QgcmVzcCA9IGF3YWl0IHNlbmRUb0JhY2tncm91bmQ8eyByZXN1bHQ6IFZvaWNlRHJhZnRSZXNwb25zZSB9IHwgeyBlcnJvcjogc3RyaW5nIH0+KHtcbiAgICAgICAgdHlwZTogJ1ZPSUNFX0RSQUZUJyxcbiAgICAgICAgcGF5bG9hZDogeyBhdWRpb0RhdGEsIG1pbWVUeXBlOiAnYXVkaW8vd2VibScsIG91dHB1dFR5cGU6IHNlbGVjdGVkT3V0cHV0VHlwZSB9LFxuICAgICAgfSk7XG4gICAgICBpZiAoJ2Vycm9yJyBpbiByZXNwKSB0aHJvdyBuZXcgRXJyb3IoU3RyaW5nKHJlc3AuZXJyb3IpKTtcbiAgICAgIGxhc3RWb2ljZVNlc3Npb25JZCA9IHJlc3AucmVzdWx0LmlkO1xuICAgICAgd3JpdGVDb21wb3NlKGNvbXBvc2VCb2R5LCByZXNwLnJlc3VsdC5kcmFmdCk7XG4gICAgICBzZXRWU3RhdHVzKCdEb25lIFx1MjcxMycpO1xuICAgICAgdkFjdGlvbnNFbC5jbGFzc0xpc3QuYWRkKCd2aXNpYmxlJyk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRWU3RhdHVzKGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiAnRmFpbGVkJywgJ2Vycm9yJyk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHJlY29yZEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICAgIH1cbiAgfVxuXG4gIHZLZWVwQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgIGlmIChsYXN0Vm9pY2VTZXNzaW9uSWQpIHNlbmRUb0JhY2tncm91bmQoeyB0eXBlOiAnVk9JQ0VfRkVFREJBQ0snLCBwYXlsb2FkOiB7IHNlc3Npb25JZDogbGFzdFZvaWNlU2Vzc2lvbklkLCBhY2NlcHRlZDogdHJ1ZSwgZWRpdGVkRHJhZnQ6IG51bGwgfSB9KTtcbiAgICB2QWN0aW9uc0VsLmNsYXNzTGlzdC5yZW1vdmUoJ3Zpc2libGUnKTtcbiAgICB2b2ljZVBhbmVsT3BlbiA9IGZhbHNlOyB2b2ljZVBhbmVsLmNsYXNzTGlzdC5yZW1vdmUoJ29wZW4nKTtcbiAgICBjbGVhck9wZW5QYW5lbChob3N0KTtcbiAgICBzZXRWU3RhdHVzKCcnKTtcbiAgfSk7XG5cbiAgdlVuZG9CdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgaWYgKG9yaWdpbmFsVm9pY2VUZXh0KSB3cml0ZUNvbXBvc2UoY29tcG9zZUJvZHksIG9yaWdpbmFsVm9pY2VUZXh0KTtcbiAgICBpZiAobGFzdFZvaWNlU2Vzc2lvbklkKSBzZW5kVG9CYWNrZ3JvdW5kKHsgdHlwZTogJ1ZPSUNFX0ZFRURCQUNLJywgcGF5bG9hZDogeyBzZXNzaW9uSWQ6IGxhc3RWb2ljZVNlc3Npb25JZCwgYWNjZXB0ZWQ6IGZhbHNlLCBlZGl0ZWREcmFmdDogbnVsbCB9IH0pO1xuICAgIHZBY3Rpb25zRWwuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xuICAgIHNldFZTdGF0dXMoJ1JldmVydGVkLicsICdzdWNjZXNzJyk7XG4gICAgc2V0VGltZW91dCgoKSA9PiBzZXRWU3RhdHVzKCcnKSwgMjAwMCk7XG4gIH0pO1xuXG4gIGZ1bmN0aW9uIHNldFZTdGF0dXMobXNnOiBzdHJpbmcsIGNscyA9ICcnKTogdm9pZCB7XG4gICAgdlN0YXR1c0VsLnRleHRDb250ZW50ID0gbXNnOyB2U3RhdHVzRWwuY2xhc3NOYW1lID0gY2xzO1xuICB9XG5cbiAgd3JhcHBlci5hcHBlbmRDaGlsZChob3N0KTtcbn1cblxuLy8gXHUyNTAwXHUyNTAwIE9ic2VydmVyIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5jb25zdCBzZWVuID0gbmV3IFdlYWtTZXQ8RWxlbWVudD4oKTtcblxuZnVuY3Rpb24gdHJ5SW5qZWN0KHJvb3Q6IEVsZW1lbnQgfCBEb2N1bWVudCA9IGRvY3VtZW50KTogdm9pZCB7XG4gIGNvbnN0IHRhcmdldHMgPSBkZXRlY3RBbGxDb21wb3NlKHsgLi4uaGl3b3Jrc0FkYXB0ZXIsIG1pbldpZHRoOiAzMDAsIG1pbkhlaWdodDogODAgfSk7XG5cbiAgaWYgKERFQlVHICYmIHRhcmdldHMubGVuZ3RoID4gMCkge1xuICAgIGNvbnNvbGUubG9nKCdbV3JpdGluZ1R3aW4vSGlXb3Jrc10gY29tcG9zZSBjYW5kaWRhdGVzOicsIHRhcmdldHMubWFwKHQgPT4gKHtcbiAgICAgIHRhZzogdC5lbGVtZW50LnRhZ05hbWUsXG4gICAgICBpZDogdC5lbGVtZW50LmlkIHx8ICdcdTIwMTMnLFxuICAgICAgY2xhc3NlczogdC5lbGVtZW50LmNsYXNzTmFtZSxcbiAgICAgIGNvbmZpZGVuY2U6IHQuY29uZmlkZW5jZSxcbiAgICB9KSkpO1xuICB9XG5cbiAgZm9yIChjb25zdCB7IGVsZW1lbnQgfSBvZiB0YXJnZXRzKSB7XG4gICAgaWYgKCFzZWVuLmhhcyhlbGVtZW50KSkge1xuICAgICAgc2Vlbi5hZGQoZWxlbWVudCk7XG4gICAgICBpbmplY3QoZWxlbWVudCk7XG4gICAgfVxuICB9XG59XG5cbmNvbnN0IG9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoKCkgPT4ge1xuICByZXF1ZXN0SWRsZUNhbGxiYWNrKCgpID0+IHRyeUluamVjdCgpLCB7IHRpbWVvdXQ6IDUwMCB9KTtcbn0pO1xub2JzZXJ2ZXIub2JzZXJ2ZShkb2N1bWVudC5ib2R5LCB7IGNoaWxkTGlzdDogdHJ1ZSwgc3VidHJlZTogdHJ1ZSB9KTtcblxudHJ5SW5qZWN0KCk7XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7QUEwQkEsTUFBTSxrQkFBa0Isb0JBQUksUUFBeUI7QUFDckQsTUFBTSxZQUFZO0FBRWxCLFdBQVMsV0FBVyxJQUFzQjtBQUN4QyxXQUNFLEdBQUcsWUFBWSxjQUNmLEdBQUcsYUFBYSxpQkFBaUIsTUFBTSxVQUN2QyxHQUFHLGFBQWEsTUFBTSxNQUFNO0FBQUEsRUFFaEM7QUFFQSxXQUFTLGlCQUFpQixTQUFTLENBQUMsTUFBTTtBQUN4QyxRQUFJLE9BQXVCLEVBQUU7QUFDN0IsV0FBTyxNQUFNO0FBQ1gsVUFBSSxXQUFXLElBQUksR0FBRztBQUFFLHdCQUFnQixJQUFJLE1BQU0sS0FBSyxJQUFJLENBQUM7QUFBRztBQUFBLE1BQU87QUFDdEUsYUFBTyxLQUFLO0FBQUEsSUFDZDtBQUFBLEVBQ0YsR0FBRyxFQUFFLFNBQVMsTUFBTSxTQUFTLEtBQUssQ0FBQztBQUVuQyxXQUFTLGlCQUFpQixXQUFXLENBQUMsTUFBTTtBQUMxQyxRQUFJLEVBQUUsa0JBQWtCLFdBQVcsV0FBVyxFQUFFLE1BQU0sR0FBRztBQUN2RCxzQkFBZ0IsSUFBSSxFQUFFLFFBQVEsS0FBSyxJQUFJLENBQUM7QUFBQSxJQUMxQztBQUFBLEVBQ0YsR0FBRyxFQUFFLFNBQVMsTUFBTSxTQUFTLEtBQUssQ0FBQztBQUluQyxNQUFNLGdCQUFnQjtBQUV0QixXQUFTLFVBQVUsSUFBc0I7QUFDdkMsVUFBTSxJQUFJLEdBQUcsc0JBQXNCO0FBQ25DLFFBQUksRUFBRSxVQUFVLEtBQUssRUFBRSxXQUFXLEVBQUcsUUFBTztBQUM1QyxVQUFNLElBQUksT0FBTyxpQkFBaUIsRUFBRTtBQUNwQyxXQUFPLEVBQUUsWUFBWSxVQUFVLEVBQUUsZUFBZSxZQUFZLFdBQVcsRUFBRSxPQUFPLElBQUk7QUFBQSxFQUN0RjtBQUVBLFdBQVMscUJBQXFCLElBQWEsYUFBdUIsQ0FBQyxHQUFZO0FBRTdFLFFBQUksT0FBdUI7QUFDM0IsYUFBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLE1BQU0sS0FBSyxPQUFPLEtBQUssZUFBZTtBQUM3RCxZQUFNLE1BQU0sQ0FBQyxVQUFVLG1CQUFtQix3QkFBd0IsR0FBRyxVQUFVLEVBQUUsS0FBSyxJQUFJO0FBQzFGLFlBQU0sUUFBUSxNQUFNLEtBQUssS0FBSyxpQkFBOEIsR0FBRyxDQUFDLEVBQUUsS0FBSyxTQUFPO0FBQzVFLGNBQU0sUUFBUTtBQUFBLFVBQ1osSUFBSSxhQUFhLEtBQUssS0FBSztBQUFBLFVBQzNCLElBQUksYUFBYSxZQUFZLEtBQUs7QUFBQSxVQUNsQyxJQUFJLGFBQWEsT0FBTyxLQUFLO0FBQUEsVUFDN0IsSUFBSSxhQUFhLGNBQWMsS0FBSztBQUFBLFFBQ3RDLEVBQUUsS0FBSyxHQUFHO0FBQ1YsZUFBTyxjQUFjLEtBQUssS0FBSztBQUFBLE1BQ2pDLENBQUM7QUFDRCxVQUFJLE1BQU8sUUFBTztBQUFBLElBQ3BCO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFFQSxXQUFTLGFBQ1AsSUFDQSxXQUNBLE1BQ0EsTUFDUTtBQUNSLFFBQUksUUFBUTtBQUNaLFVBQU0sT0FBTyxHQUFHLHNCQUFzQjtBQUd0QyxhQUFTO0FBR1QsUUFBSSxTQUFTLGtCQUFrQixHQUFJLFVBQVM7QUFBQSxhQUNuQyxHQUFHLFNBQVMsU0FBUyxhQUFhLEVBQUcsVUFBUztBQUd2RCxVQUFNLEtBQUssZ0JBQWdCLElBQUksRUFBRTtBQUNqQyxRQUFJLE9BQU8sVUFBYSxLQUFLLElBQUksSUFBSSxLQUFLLFVBQVcsVUFBUztBQUc5RCxRQUFJLEtBQUssU0FBUyxPQUFPLEtBQUssS0FBSyxVQUFVLE9BQU8sRUFBRyxVQUFTO0FBQUEsYUFDdkQsS0FBSyxTQUFTLFFBQVEsS0FBSyxVQUFVLEtBQU0sVUFBUztBQUc3RCxRQUFJLEdBQUcsYUFBYSxNQUFNLE1BQU0sVUFBVyxVQUFTO0FBQ3BELFFBQUksR0FBRyxhQUFhLGFBQWEsS0FBSyxHQUFHLFFBQVEsWUFBYSxVQUFTO0FBR3ZFLFFBQUkscUJBQXFCLElBQUksU0FBUyxFQUFHLFVBQVM7QUFFbEQsV0FBTztBQUFBLEVBQ1Q7QUFJQSxXQUFTLG1CQUFtQixNQUFjLE1BQWMsTUFBMkI7QUFDakYsVUFBTSxLQUFLLFNBQVMsaUJBQW9DLFFBQVEsQ0FBQyxFQUFFLFFBQVEsWUFBVTtBQUNuRixVQUFJO0FBQ0YsY0FBTSxNQUFNLE9BQU87QUFDbkIsWUFBSSxDQUFDLElBQUs7QUFDVixjQUFNLE9BQU8sSUFBSTtBQUNqQixZQUFJLENBQUMsS0FBTTtBQUVYLFlBQUssSUFBMEMsZUFBZSxNQUFNO0FBQ2xFLGVBQUssS0FBSyxJQUFJO0FBQ2Q7QUFBQSxRQUNGO0FBQ0EsY0FBTSxLQUFLLElBQUksaUJBQWlCLFFBQVEsQ0FBNEIsRUFBRSxRQUFRLFFBQU07QUFDbEYsY0FBSSxVQUFVLEVBQUUsRUFBRyxNQUFLLEtBQUssRUFBRTtBQUFBLFFBQ2pDLENBQUM7QUFBQSxNQUNILFFBQVE7QUFBQSxNQUVSO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUlBLE1BQU0sV0FBVztBQUFBLElBQ2Y7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRixFQUFFLEtBQUssSUFBSTtBQU1KLFdBQVMsaUJBQWlCLFNBQTRDO0FBQzNFLFVBQU0sT0FBTyxTQUFTLFlBQVk7QUFDbEMsVUFBTSxPQUFPLFNBQVMsYUFBYTtBQUNuQyxVQUFNLFlBQVksU0FBUyxtQkFBbUIsQ0FBQztBQUMvQyxVQUFNLFdBQVcsU0FBUztBQUUxQixVQUFNLGFBQWEsb0JBQUksSUFBMEI7QUFHakQsUUFBSSxTQUFTO0FBQ1gsY0FBUSxhQUFhLFFBQVEsU0FBTztBQUNsQyxjQUFNLEtBQUssU0FBUyxpQkFBOEIsR0FBRyxDQUFDLEVBQUUsUUFBUSxRQUFNO0FBQ3BFLGNBQUksVUFBVSxFQUFFLEVBQUcsWUFBVyxJQUFJLElBQUksRUFBRTtBQUFBLFFBQzFDLENBQUM7QUFBQSxNQUNILENBQUM7QUFBQSxJQUNIO0FBR0EsVUFBTSxLQUFLLFNBQVMsaUJBQThCLFFBQVEsQ0FBQyxFQUFFLFFBQVEsUUFBTTtBQUN6RSxVQUFJLFVBQVUsRUFBRSxFQUFHLFlBQVcsSUFBSSxJQUFJLEVBQUU7QUFBQSxJQUMxQyxDQUFDO0FBR0QsVUFBTSxZQUEyQixDQUFDO0FBQ2xDLHVCQUFtQixNQUFNLE1BQU0sU0FBUztBQUN4QyxjQUFVLFFBQVEsUUFBTSxXQUFXLElBQUksSUFBSSxFQUFFLENBQUM7QUFFOUMsVUFBTSxVQUEyQixDQUFDO0FBRWxDLFVBQU0sS0FBSyxXQUFXLE9BQU8sQ0FBQyxFQUFFLFFBQVEsUUFBTTtBQUM1QyxZQUFNLE9BQU8sR0FBRyxzQkFBc0I7QUFDdEMsVUFBSSxLQUFLLFFBQVEsUUFBUSxLQUFLLFNBQVMsS0FBTTtBQUU3QyxZQUFNLFdBQVcsU0FBUyxhQUFhLEtBQUssU0FBTyxHQUFHLFFBQVEsR0FBRyxDQUFDLEtBQUs7QUFDdkUsWUFBTSxPQUFPLGFBQWEsSUFBSSxXQUFXLE1BQU0sSUFBSTtBQUNuRCxZQUFNLGFBQWEsV0FBVyxPQUFPLEtBQUs7QUFFMUMsY0FBUSxLQUFLLEVBQUUsU0FBUyxJQUFJLFlBQVksU0FBUyxDQUFDO0FBQUEsSUFDcEQsQ0FBQztBQUVELFdBQU8sUUFBUSxLQUFLLENBQUMsR0FBRyxNQUFNLEVBQUUsYUFBYSxFQUFFLFVBQVU7QUFBQSxFQUMzRDs7O0FDM0xPLE1BQU0saUJBQWtDO0FBQUEsSUFDN0MsVUFBVTtBQUFBLElBQ1YsY0FBYztBQUFBLE1BQ1o7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQSxJQUNBLGlCQUFpQjtBQUFBO0FBQUEsTUFFZjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUE7QUFBQSxNQUVBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUFBLElBQ0EsVUFBVTtBQUFBLElBQ1YsV0FBVztBQUFBLEVBQ2I7OztBQzFCQSxNQUFNLFFBQVE7QUFFZCxNQUFNLFlBQVk7QUFDbEIsTUFBTSx5QkFBeUI7QUFFL0IsTUFBTSxVQUFVO0FBRWhCLE1BQU0sUUFBdUQ7QUFBQSxJQUMzRCxFQUFFLEtBQUssZ0JBQWdCLE9BQU8sZ0JBQWdCLE9BQU8sUUFBUTtBQUFBLElBQzdELEVBQUUsS0FBSyxZQUFnQixPQUFPLFlBQWdCLE9BQU8sVUFBVTtBQUFBLElBQy9ELEVBQUUsS0FBSyxVQUFnQixPQUFPLFVBQWdCLE9BQU8sVUFBVTtBQUFBLElBQy9ELEVBQUUsS0FBSyxjQUFnQixPQUFPLGNBQWdCLE9BQU8sVUFBVTtBQUFBLElBQy9ELEVBQUUsS0FBSyxhQUFnQixPQUFPLGFBQWdCLE9BQU8sVUFBVTtBQUFBLElBQy9ELEVBQUUsS0FBSyxVQUFnQixPQUFPLFVBQWdCLE9BQU8sVUFBVTtBQUFBLEVBQ2pFO0FBRUEsTUFBTSxxQkFBZ0U7QUFBQSxJQUNwRSxFQUFFLEtBQUssU0FBb0IsT0FBTyxRQUFRO0FBQUEsSUFDMUMsRUFBRSxLQUFLLFNBQW9CLE9BQU8sUUFBUTtBQUFBLElBQzFDLEVBQUUsS0FBSyxtQkFBb0IsT0FBTyxrQkFBa0I7QUFBQSxJQUNwRCxFQUFFLEtBQUssb0JBQW9CLE9BQU8sY0FBYztBQUFBLEVBQ2xEO0FBSUEsTUFBTSxNQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU1NLE9BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFpRFAsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0F1Q1UsT0FBTyxnQ0FBZ0MsT0FBTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQXdCakYsTUFBSSxZQUF5RDtBQUU3RCxXQUFTLGlCQUFpQixTQUFTLENBQUMsTUFBTTtBQUN4QyxRQUFJLGFBQWEsQ0FBQyxVQUFVLEtBQUssU0FBUyxFQUFFLE1BQWMsR0FBRztBQUMzRCxnQkFBVSxNQUFNO0FBQ2hCLGtCQUFZO0FBQUEsSUFDZDtBQUFBLEVBQ0YsR0FBRyxJQUFJO0FBRVAsV0FBUyxhQUFhLE1BQWUsT0FBeUI7QUFDNUQsUUFBSSxhQUFhLFVBQVUsU0FBUyxLQUFNLFdBQVUsTUFBTTtBQUMxRCxnQkFBWSxFQUFFLE1BQU0sTUFBTTtBQUFBLEVBQzVCO0FBRUEsV0FBUyxlQUFlLE1BQXFCO0FBQzNDLFFBQUksV0FBVyxTQUFTLEtBQU0sYUFBWTtBQUFBLEVBQzVDO0FBSUEsV0FBUyxpQkFBb0IsU0FBNkI7QUFDeEQsV0FBTyxJQUFJLFFBQVEsQ0FBQyxZQUFZLE9BQU8sUUFBUSxZQUFZLFNBQVMsT0FBTyxDQUFDO0FBQUEsRUFDOUU7QUFFQSxXQUFTLFdBQVcsSUFBd0M7QUFDMUQsV0FBTyxHQUFHLFlBQVk7QUFBQSxFQUN4QjtBQUVBLFdBQVMsWUFBWSxJQUFxQjtBQUN4QyxRQUFJLFdBQVcsRUFBRSxFQUFHLFFBQVEsR0FBMkIsTUFBTSxLQUFLO0FBQ2xFLFdBQVEsR0FBbUIsVUFBVSxLQUFLO0FBQUEsRUFDNUM7QUFFQSxXQUFTLGFBQWEsSUFBYSxNQUFvQjtBQUNyRCxRQUFJLFdBQVcsRUFBRSxHQUFHO0FBQ2xCLFlBQU0sS0FBSztBQUNYLFNBQUcsUUFBUTtBQUNYLFNBQUcsY0FBYyxJQUFJLE1BQU0sU0FBUyxFQUFFLFNBQVMsS0FBSyxDQUFDLENBQUM7QUFDdEQsU0FBRyxjQUFjLElBQUksTUFBTSxVQUFVLEVBQUUsU0FBUyxLQUFLLENBQUMsQ0FBQztBQUFBLElBQ3pELE9BQU87QUFDTCxZQUFNLE1BQU07QUFDWixVQUFJLE1BQU07QUFDVixlQUFTLFlBQVksYUFBYSxPQUFPLE1BQVM7QUFDbEQsZUFBUyxZQUFZLFVBQVUsT0FBTyxNQUFTO0FBQy9DLFlBQU0sUUFBUSxLQUFLLE1BQU0sSUFBSTtBQUM3QixlQUFTLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLO0FBQ3JDLFlBQUksTUFBTSxDQUFDLEVBQUcsVUFBUyxZQUFZLGNBQWMsT0FBTyxNQUFNLENBQUMsQ0FBQztBQUNoRSxZQUFJLElBQUksTUFBTSxTQUFTLEVBQUcsVUFBUyxZQUFZLG1CQUFtQixPQUFPLE1BQVM7QUFBQSxNQUNwRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBSUEsV0FBUyxPQUFPLGFBQTRCO0FBQzFDLFFBQUksWUFBWSxhQUFhLFNBQVMsRUFBRztBQUN6QyxnQkFBWSxhQUFhLFdBQVcsR0FBRztBQUt2QyxVQUFNLFVBQVUsU0FBUyxjQUFjLEtBQUs7QUFDNUMsWUFBUSxNQUFNLFVBQVU7QUFFeEIsVUFBTSxpQkFDSixZQUFZLFFBQVEsOERBQThELEtBQ2xGLFlBQVk7QUFDZCxvQkFBZ0Isc0JBQXNCLFlBQVksT0FBTztBQUN6RCxRQUFJLENBQUMsUUFBUSxjQUFlLGFBQVksZUFBZSxZQUFZLE9BQU87QUFFMUUsVUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLFVBQU0sU0FBUyxLQUFLLGFBQWEsRUFBRSxNQUFNLE9BQU8sQ0FBQztBQUVqRCxRQUFJLGVBQTRCO0FBQ2hDLFFBQUksZ0JBQStCO0FBQ25DLFFBQUksWUFBWTtBQUNoQixRQUFJLGlCQUFpQjtBQUNyQixRQUFJLHFCQUFzQyxtQkFBbUIsQ0FBQyxFQUFFO0FBQ2hFLFFBQUksV0FBaUM7QUFDckMsUUFBSSxZQUFZO0FBQ2hCLFFBQUksY0FBMEIsQ0FBQztBQUMvQixRQUFJLHFCQUFvQztBQUN4QyxRQUFJLGVBQWU7QUFDbkIsUUFBSSxvQkFBb0I7QUFFeEIsV0FBTyxZQUFZO0FBQUEsYUFDUixHQUFHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFPTixNQUFNLElBQUksT0FBSyxzQ0FBc0MsRUFBRSxHQUFHLGlCQUFpQixFQUFFLEtBQUssS0FBSyxFQUFFLEtBQUssV0FBVyxFQUFFLEtBQUssRUFBRSxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBa0JuSCxtQkFBbUI7QUFBQSxNQUFJLENBQUMsR0FBRyxNQUMzQiwwQkFBMEIsTUFBTSxJQUFJLFlBQVksRUFBRSxnQkFBZ0IsRUFBRSxHQUFHLEtBQUssRUFBRSxLQUFLO0FBQUEsSUFDckYsRUFBRSxLQUFLLEVBQUUsQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVloQixVQUFNLE1BQWEsT0FBTyxlQUFlLFFBQVE7QUFDakQsVUFBTSxTQUFhLE9BQU8sZUFBZSxZQUFZO0FBQ3JELFVBQU0sUUFBYSxPQUFPLGVBQWUsVUFBVTtBQUNuRCxVQUFNLGFBQWEsT0FBTyxlQUFlLGdCQUFnQjtBQUN6RCxVQUFNLGFBQWEsT0FBTyxlQUFlLFlBQVk7QUFDckQsVUFBTSxXQUFhLE9BQU8sZUFBZSxXQUFXO0FBQ3BELFVBQU0sVUFBYSxPQUFPLGVBQWUsVUFBVTtBQUNuRCxVQUFNLFlBQWEsT0FBTyxlQUFlLFlBQVk7QUFDckQsVUFBTSxZQUFhLE9BQU8sZUFBZSxXQUFXO0FBQ3BELFVBQU0sWUFBYSxPQUFPLGVBQWUsV0FBVztBQUNwRCxVQUFNLFlBQWEsT0FBTyxlQUFlLGVBQWU7QUFDeEQsVUFBTSxZQUFhLE9BQU8sZUFBZSxpQkFBaUI7QUFDMUQsVUFBTSxhQUFhLE9BQU8sZUFBZSxrQkFBa0I7QUFDM0QsVUFBTSxXQUFhLE9BQU8sZUFBZSxZQUFZO0FBQ3JELFVBQU0sV0FBYSxPQUFPLGVBQWUsWUFBWTtBQUdyRCxXQUFPLGlCQUFvQyxVQUFVLEVBQUUsUUFBUSxRQUFNO0FBQ25FLFNBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUNqQyxlQUFPLGlCQUFpQixVQUFVLEVBQUUsUUFBUSxPQUFLLEVBQUUsVUFBVSxPQUFPLFFBQVEsQ0FBQztBQUM3RSxXQUFHLFVBQVUsSUFBSSxRQUFRO0FBQ3pCLFdBQUcsTUFBTSxhQUFjLEdBQUcsUUFBUSxTQUFTO0FBQzNDLFdBQUcsTUFBTSxjQUFjLEdBQUcsUUFBUSxTQUFTO0FBQzNDLHVCQUFlLEdBQUcsUUFBUTtBQUMxQixtQkFBVyxXQUFXO0FBQ3RCLGtCQUFVLEVBQUU7QUFBRyxnQkFBUSxVQUFVLE9BQU8sU0FBUztBQUNqRCxrQkFBVSxVQUFVLE9BQU8sU0FBUztBQUFBLE1BQ3RDLENBQUM7QUFBQSxJQUNILENBQUM7QUFHRCxXQUFPLGlCQUFvQyxXQUFXLEVBQUUsUUFBUSxRQUFNO0FBQ3BFLFNBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUNqQyxlQUFPLGlCQUFpQixXQUFXLEVBQUUsUUFBUSxPQUFLLEVBQUUsVUFBVSxPQUFPLFFBQVEsQ0FBQztBQUM5RSxXQUFHLFVBQVUsSUFBSSxRQUFRO0FBQ3pCLDZCQUFxQixHQUFHLFFBQVE7QUFBQSxNQUNsQyxDQUFDO0FBQUEsSUFDSCxDQUFDO0FBR0QsUUFBSSxpQkFBaUIsU0FBUyxNQUFNO0FBQ2xDLFVBQUksV0FBVztBQUNiLG9CQUFZO0FBQU8sY0FBTSxVQUFVLE9BQU8sTUFBTTtBQUNoRCx1QkFBZSxJQUFJO0FBQUEsTUFDckIsT0FBTztBQUNMLHlCQUFpQjtBQUFPLG1CQUFXLFVBQVUsT0FBTyxNQUFNO0FBQzFELG9CQUFZO0FBQU0sY0FBTSxVQUFVLElBQUksTUFBTTtBQUM1QyxzQkFBYyxLQUFLLEtBQUs7QUFDeEIscUJBQWEsTUFBTSxNQUFNO0FBQ3ZCLHNCQUFZO0FBQU8sZ0JBQU0sVUFBVSxPQUFPLE1BQU07QUFDaEQsMkJBQWlCO0FBQU8scUJBQVcsVUFBVSxPQUFPLE1BQU07QUFBQSxRQUM1RCxDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsQ0FBQztBQUVELFdBQU8saUJBQWlCLFNBQVMsTUFBTTtBQUNyQyxVQUFJLGdCQUFnQjtBQUNsQix5QkFBaUI7QUFBTyxtQkFBVyxVQUFVLE9BQU8sTUFBTTtBQUMxRCx1QkFBZSxJQUFJO0FBQUEsTUFDckIsT0FBTztBQUNMLG9CQUFZO0FBQU8sY0FBTSxVQUFVLE9BQU8sTUFBTTtBQUNoRCx5QkFBaUI7QUFBTSxtQkFBVyxVQUFVLElBQUksTUFBTTtBQUN0RCxzQkFBYyxRQUFRLFVBQVU7QUFDaEMscUJBQWEsTUFBTSxNQUFNO0FBQ3ZCLDJCQUFpQjtBQUFPLHFCQUFXLFVBQVUsT0FBTyxNQUFNO0FBQzFELHNCQUFZO0FBQU8sZ0JBQU0sVUFBVSxPQUFPLE1BQU07QUFBQSxRQUNsRCxDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsQ0FBQztBQUVELGFBQVMsY0FBYyxRQUFxQixHQUF5QjtBQUNuRSxZQUFNLE9BQU8sT0FBTyxzQkFBc0I7QUFDMUMsUUFBRSxNQUFNLFNBQVMsR0FBRyxPQUFPLGNBQWMsS0FBSyxNQUFNLENBQUM7QUFDckQsUUFBRSxNQUFNLE9BQVMsR0FBRyxLQUFLLElBQUksS0FBSyxNQUFNLE9BQU8sYUFBYSxTQUFTLEVBQUUsTUFBTSxTQUFTLEtBQUssSUFBSSxFQUFFLENBQUM7QUFBQSxJQUNwRztBQUdBLGVBQVcsaUJBQWlCLFNBQVMsWUFBWTtBQUMvQyxVQUFJLENBQUMsYUFBYztBQUNuQixZQUFNLE9BQU8sWUFBWSxXQUFXO0FBQ3BDLFVBQUksQ0FBQyxNQUFNO0FBQUUsa0JBQVUsMEJBQTBCLE9BQU87QUFBRztBQUFBLE1BQVE7QUFFbkUscUJBQWU7QUFDZixVQUFJLFdBQVc7QUFBTSxpQkFBVyxXQUFXO0FBQzNDLGdCQUFVLGlCQUFZO0FBQUcsZ0JBQVUsVUFBVSxPQUFPLFNBQVM7QUFFN0QsVUFBSTtBQUNGLGNBQU0sT0FBTyxNQUFNLGlCQUFrRTtBQUFBLFVBQ25GLE1BQU07QUFBQSxVQUNOLFNBQVM7QUFBQSxZQUNQO0FBQUEsWUFDQSxNQUFNO0FBQUEsWUFDTixLQUFLLEVBQUUsVUFBVSxXQUFXLHVCQUF1Qix1QkFBdUI7QUFBQSxVQUM1RTtBQUFBLFFBQ0YsQ0FBQztBQUNELFlBQUksV0FBVyxLQUFNLE9BQU0sSUFBSSxNQUFNLE9BQU8sS0FBSyxLQUFLLENBQUM7QUFDdkQsd0JBQWdCLEtBQUssT0FBTztBQUM1QixxQkFBYSxhQUFhLEtBQUssT0FBTyxXQUFXO0FBQ2pELGtCQUFVLGVBQVUsU0FBUztBQUM3QixrQkFBVSxVQUFVLElBQUksU0FBUztBQUFBLE1BQ25DLFNBQVMsS0FBSztBQUNaLGNBQU0sTUFBTSxlQUFlLFFBQVEsSUFBSSxVQUFVO0FBQ2pELFlBQUksSUFBSSxXQUFXLGdCQUFnQixHQUFHO0FBQ3BDLGtCQUFRLFVBQVUsSUFBSSxTQUFTO0FBQUcsb0JBQVUsRUFBRTtBQUFBLFFBQ2hELE9BQU87QUFDTCxvQkFBVSxLQUFLLE9BQU87QUFBQSxRQUN4QjtBQUFBLE1BQ0YsVUFBRTtBQUNBLFlBQUksV0FBVztBQUNmLG1CQUFXLFdBQVcsaUJBQWlCO0FBQUEsTUFDekM7QUFBQSxJQUNGLENBQUM7QUFFRCxjQUFVLGlCQUFpQixTQUFTLE1BQU07QUFDeEMsVUFBSSxjQUFlLGtCQUFpQixFQUFFLE1BQU0sWUFBWSxTQUFTLEVBQUUsV0FBVyxlQUFlLFFBQVEsV0FBVyxFQUFFLENBQUM7QUFDbkgsZ0JBQVUsVUFBVSxPQUFPLFNBQVM7QUFDcEMsa0JBQVk7QUFBTyxZQUFNLFVBQVUsT0FBTyxNQUFNO0FBQ2hELHFCQUFlLElBQUk7QUFDbkIsZ0JBQVUsRUFBRTtBQUFBLElBQ2QsQ0FBQztBQUVELGNBQVUsaUJBQWlCLFNBQVMsTUFBTTtBQUN4QyxVQUFJLGFBQWMsY0FBYSxhQUFhLFlBQVk7QUFDeEQsVUFBSSxjQUFlLGtCQUFpQixFQUFFLE1BQU0sWUFBWSxTQUFTLEVBQUUsV0FBVyxlQUFlLFFBQVEsV0FBVyxFQUFFLENBQUM7QUFDbkgsZ0JBQVUsVUFBVSxPQUFPLFNBQVM7QUFDcEMsZ0JBQVUsYUFBYSxTQUFTO0FBQ2hDLGlCQUFXLE1BQU0sVUFBVSxFQUFFLEdBQUcsR0FBSTtBQUFBLElBQ3RDLENBQUM7QUFFRCxhQUFTLFVBQVUsS0FBYSxNQUFNLElBQVU7QUFDOUMsZUFBUyxjQUFjO0FBQUssZUFBUyxZQUFZO0FBQUEsSUFDbkQ7QUFHQSxjQUFVLGlCQUFpQixTQUFTLFlBQVk7QUFDOUMsVUFBSSxDQUFDLFVBQVcsT0FBTSxlQUFlO0FBQUEsVUFBUSxlQUFjO0FBQUEsSUFDN0QsQ0FBQztBQUVELG1CQUFlLGlCQUFnQztBQUM3QyxVQUFJO0FBQ0YsY0FBTSxTQUFTLE1BQU0sVUFBVSxhQUFhLGFBQWEsRUFBRSxPQUFPLEtBQUssQ0FBQztBQUN4RSxzQkFBYyxDQUFDO0FBQ2YsbUJBQVcsSUFBSSxjQUFjLFFBQVEsRUFBRSxVQUFVLGFBQWEsQ0FBQztBQUMvRCxpQkFBUyxrQkFBa0IsQ0FBQyxNQUFNO0FBQUUsY0FBSSxFQUFFLEtBQUssT0FBTyxFQUFHLGFBQVksS0FBSyxFQUFFLElBQUk7QUFBQSxRQUFHO0FBQ25GLGlCQUFTLFNBQVMsWUFBWTtBQUM1QixpQkFBTyxVQUFVLEVBQUUsUUFBUSxPQUFLLEVBQUUsS0FBSyxDQUFDO0FBQ3hDLGdCQUFNLFlBQVksSUFBSSxLQUFLLGFBQWEsRUFBRSxNQUFNLGFBQWEsQ0FBQyxDQUFDO0FBQUEsUUFDakU7QUFDQSxpQkFBUyxNQUFNO0FBQ2Ysb0JBQVk7QUFDWixlQUFPLFVBQVUsSUFBSSxXQUFXO0FBQ2hDLGtCQUFVLFVBQVUsSUFBSSxXQUFXO0FBQ25DLGtCQUFVLGNBQWM7QUFDeEIsbUJBQVcsaUJBQVk7QUFDdkIsbUJBQVcsVUFBVSxPQUFPLFNBQVM7QUFDckMsbUJBQVcsTUFBTTtBQUFFLGNBQUksVUFBVyxlQUFjO0FBQUEsUUFBRyxHQUFHLEdBQU07QUFBQSxNQUM5RCxRQUFRO0FBQ04sbUJBQVcsNkJBQTZCLE9BQU87QUFBQSxNQUNqRDtBQUFBLElBQ0Y7QUFFQSxhQUFTLGdCQUFzQjtBQUM3QixVQUFJLFlBQVksV0FBVztBQUN6QixpQkFBUyxLQUFLO0FBQUcsb0JBQVk7QUFDN0IsZUFBTyxVQUFVLE9BQU8sV0FBVztBQUNuQyxrQkFBVSxVQUFVLE9BQU8sV0FBVztBQUN0QyxrQkFBVSxjQUFjO0FBQ3hCLGtCQUFVLFdBQVc7QUFDckIsbUJBQVcsZ0JBQVc7QUFBQSxNQUN4QjtBQUFBLElBQ0Y7QUFFQSxtQkFBZSxZQUFZLE1BQTJCO0FBQ3BELFVBQUk7QUFDRixjQUFNLE1BQU0sTUFBTSxLQUFLLFlBQVk7QUFDbkMsY0FBTSxZQUFZLEtBQUssTUFBTSxLQUFLLElBQUksV0FBVyxHQUFHLEdBQUcsT0FBSyxPQUFPLGFBQWEsQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUM7QUFDNUYsNEJBQW9CLFlBQVksV0FBVztBQUMzQyxjQUFNLE9BQU8sTUFBTSxpQkFBcUU7QUFBQSxVQUN0RixNQUFNO0FBQUEsVUFDTixTQUFTLEVBQUUsV0FBVyxVQUFVLGNBQWMsWUFBWSxtQkFBbUI7QUFBQSxRQUMvRSxDQUFDO0FBQ0QsWUFBSSxXQUFXLEtBQU0sT0FBTSxJQUFJLE1BQU0sT0FBTyxLQUFLLEtBQUssQ0FBQztBQUN2RCw2QkFBcUIsS0FBSyxPQUFPO0FBQ2pDLHFCQUFhLGFBQWEsS0FBSyxPQUFPLEtBQUs7QUFDM0MsbUJBQVcsYUFBUTtBQUNuQixtQkFBVyxVQUFVLElBQUksU0FBUztBQUFBLE1BQ3BDLFNBQVMsS0FBSztBQUNaLG1CQUFXLGVBQWUsUUFBUSxJQUFJLFVBQVUsVUFBVSxPQUFPO0FBQUEsTUFDbkUsVUFBRTtBQUNBLGtCQUFVLFdBQVc7QUFBQSxNQUN2QjtBQUFBLElBQ0Y7QUFFQSxhQUFTLGlCQUFpQixTQUFTLE1BQU07QUFDdkMsVUFBSSxtQkFBb0Isa0JBQWlCLEVBQUUsTUFBTSxrQkFBa0IsU0FBUyxFQUFFLFdBQVcsb0JBQW9CLFVBQVUsTUFBTSxhQUFhLEtBQUssRUFBRSxDQUFDO0FBQ2xKLGlCQUFXLFVBQVUsT0FBTyxTQUFTO0FBQ3JDLHVCQUFpQjtBQUFPLGlCQUFXLFVBQVUsT0FBTyxNQUFNO0FBQzFELHFCQUFlLElBQUk7QUFDbkIsaUJBQVcsRUFBRTtBQUFBLElBQ2YsQ0FBQztBQUVELGFBQVMsaUJBQWlCLFNBQVMsTUFBTTtBQUN2QyxVQUFJLGtCQUFtQixjQUFhLGFBQWEsaUJBQWlCO0FBQ2xFLFVBQUksbUJBQW9CLGtCQUFpQixFQUFFLE1BQU0sa0JBQWtCLFNBQVMsRUFBRSxXQUFXLG9CQUFvQixVQUFVLE9BQU8sYUFBYSxLQUFLLEVBQUUsQ0FBQztBQUNuSixpQkFBVyxVQUFVLE9BQU8sU0FBUztBQUNyQyxpQkFBVyxhQUFhLFNBQVM7QUFDakMsaUJBQVcsTUFBTSxXQUFXLEVBQUUsR0FBRyxHQUFJO0FBQUEsSUFDdkMsQ0FBQztBQUVELGFBQVMsV0FBVyxLQUFhLE1BQU0sSUFBVTtBQUMvQyxnQkFBVSxjQUFjO0FBQUssZ0JBQVUsWUFBWTtBQUFBLElBQ3JEO0FBRUEsWUFBUSxZQUFZLElBQUk7QUFBQSxFQUMxQjtBQUlBLE1BQU0sT0FBTyxvQkFBSSxRQUFpQjtBQUVsQyxXQUFTLFVBQVUsT0FBMkIsVUFBZ0I7QUFDNUQsVUFBTSxVQUFVLGlCQUFpQixFQUFFLEdBQUcsZ0JBQWdCLFVBQVUsS0FBSyxXQUFXLEdBQUcsQ0FBQztBQUVwRixRQUFJLFNBQVMsUUFBUSxTQUFTLEdBQUc7QUFDL0IsY0FBUSxJQUFJLDZDQUE2QyxRQUFRLElBQUksUUFBTTtBQUFBLFFBQ3pFLEtBQUssRUFBRSxRQUFRO0FBQUEsUUFDZixJQUFJLEVBQUUsUUFBUSxNQUFNO0FBQUEsUUFDcEIsU0FBUyxFQUFFLFFBQVE7QUFBQSxRQUNuQixZQUFZLEVBQUU7QUFBQSxNQUNoQixFQUFFLENBQUM7QUFBQSxJQUNMO0FBRUEsZUFBVyxFQUFFLFFBQVEsS0FBSyxTQUFTO0FBQ2pDLFVBQUksQ0FBQyxLQUFLLElBQUksT0FBTyxHQUFHO0FBQ3RCLGFBQUssSUFBSSxPQUFPO0FBQ2hCLGVBQU8sT0FBTztBQUFBLE1BQ2hCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFFQSxNQUFNLFdBQVcsSUFBSSxpQkFBaUIsTUFBTTtBQUMxQyx3QkFBb0IsTUFBTSxVQUFVLEdBQUcsRUFBRSxTQUFTLElBQUksQ0FBQztBQUFBLEVBQ3pELENBQUM7QUFDRCxXQUFTLFFBQVEsU0FBUyxNQUFNLEVBQUUsV0FBVyxNQUFNLFNBQVMsS0FBSyxDQUFDO0FBRWxFLFlBQVU7IiwKICAibmFtZXMiOiBbXQp9Cg==
