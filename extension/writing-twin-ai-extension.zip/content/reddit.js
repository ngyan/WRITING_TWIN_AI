"use strict";
(() => {
  // src/content/reddit.ts
  var OLD_REDDIT_SEL = 'textarea[name="text"], textarea.usertext-edit textarea';
  var NEW_REDDIT_SEL = 'div[contenteditable="true"][data-testid], div.DraftEditor-editorContainer [contenteditable="true"], .editor-container [contenteditable="true"]';
  var COMPOSE_SEL = `${OLD_REDDIT_SEL}, ${NEW_REDDIT_SEL}`;
  var HOST_ATTR = "data-wt-rd-injected";
  var FIXED_CONTEXT_OVERRIDE = "community";
  var TONES = [
    { key: "casual", label: "Casual", color: "#FF4500" },
    { key: "professional", label: "Professional", color: "#0A66C2" },
    { key: "friendly", label: "Friendly", color: "#F59E0B" },
    { key: "direct", label: "Direct", color: "#DC2626" },
    { key: "executive", label: "Executive", color: "#0F172A" }
  ];
  var VOICE_OUTPUT_TYPES = [
    { key: "reply", label: "Reply" },
    { key: "email", label: "Message" }
  ];
  var BUTTON_CSS = `
  :host { display: inline-flex; align-items: center; }

  #wt-btn {
    display: inline-flex; align-items: center; gap: 5px;
    height: 28px; padding: 0 12px; border-radius: 9999px; border: none;
    background: #FF4500; color: #fff;
    font: 500 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer; white-space: nowrap;
    transition: background 0.15s, box-shadow 0.15s;
  }
  #wt-btn:hover { background: #cc3700; box-shadow: 0 0 0 3px rgba(255,69,0,0.25); }
  #wt-btn:disabled { opacity: 0.6; cursor: default; box-shadow: none; }

  #wt-panel {
    position: fixed; z-index: 99999;
    background: #fff; border: 1px solid #E2E8F0; border-radius: 10px;
    box-shadow: 0 12px 32px rgba(0,0,0,0.14);
    padding: 14px 16px; width: 260px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: none;
  }
  #wt-panel.open { display: block; }

  .wt-title { font-size: 12px; font-weight: 600; color: #374151; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase; }
  .wt-tones { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 12px; }
  .wt-tone {
    padding: 4px 10px; border-radius: 9999px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151;
    cursor: pointer; transition: all 0.1s;
  }
  .wt-tone.active { color: #fff; border-color: transparent; }
  .wt-tone:hover:not(.active) { border-color: #FCA5A5; }

  #wt-rewrite {
    width: 100%; height: 32px; border-radius: 8px; border: none;
    background: #FF4500; color: #fff;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer;
  }
  #wt-rewrite:disabled { opacity: 0.45; cursor: default; }

  #wt-status { margin-top: 8px; font-size: 11px; text-align: center; min-height: 14px; }
  #wt-status.error { color: #EF4444; }
  #wt-status.success { color: #10B981; }

  #wt-actions { display: none; gap: 6px; margin-top: 8px; }
  #wt-actions.visible { display: flex; }
  .wt-action {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151;
    cursor: pointer;
  }
  .wt-action.accept { border-color: #10B981; color: #10B981; }
  .wt-action.reject { border-color: #EF4444; color: #EF4444; }

  #wt-limit { display: none; margin-top: 10px; padding: 10px 12px; border-radius: 8px;
    background: #FFF8F1; border: 1px solid #FED7AA; text-align: center; }
  #wt-limit.visible { display: block; }
  #wt-limit p { font-size: 11px; color: #92400E; margin: 0 0 8px; line-height: 1.4; }
  #wt-limit a {
    display: inline-block; padding: 5px 14px; border-radius: 9999px;
    background: #F59E0B; color: #fff; font-size: 11px; font-weight: 600;
    text-decoration: none;
  }
`;
  var MIC_CSS = `
  :host { display: inline-flex; align-items: center; margin-left: 4px; }

  #wt-mic-btn {
    display: inline-flex; align-items: center; justify-content: center;
    width: 28px; height: 28px; border-radius: 9999px; border: none;
    background: transparent; color: #666; cursor: pointer;
    transition: background 0.15s, color 0.15s; font-size: 15px; line-height: 1;
  }
  #wt-mic-btn:hover { background: rgba(0,0,0,0.07); }
  #wt-mic-btn.recording { background: #FEE2E2; color: #DC2626;
    animation: wt-pulse 1.2s ease-in-out infinite; }
  @keyframes wt-pulse {
    0%, 100% { box-shadow: 0 0 0 0 rgba(220,38,38,0.4); }
    50%       { box-shadow: 0 0 0 5px rgba(220,38,38,0); }
  }
  #wt-mic-btn:disabled { opacity: 0.5; cursor: default; }

  #wt-voice-panel {
    position: fixed; z-index: 99999;
    background: #fff; border: 1px solid #E2E8F0; border-radius: 10px;
    box-shadow: 0 12px 32px rgba(0,0,0,0.14);
    padding: 14px 16px; width: 280px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: none;
  }
  #wt-voice-panel.open { display: block; }

  .wt-vt { font-size: 12px; font-weight: 600; color: #374151; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase; }
  #wt-record-btn {
    width: 100%; height: 34px; border-radius: 8px; border: none;
    background: #DC2626; color: #fff; cursor: pointer;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    margin-bottom: 10px;
  }
  #wt-record-btn.recording { background: #7F1D1D; }
  #wt-record-btn:disabled { opacity: 0.5; cursor: default; }
  .wt-otype-label { font-size: 11px; color: #6B7280; margin-bottom: 4px; }
  .wt-otypes { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 10px; }
  .wt-otype {
    padding: 3px 9px; border-radius: 9999px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 11px; color: #374151; cursor: pointer;
    transition: all 0.1s;
  }
  .wt-otype.active { background: #FF4500; color: #fff; border-color: #FF4500; }
  #wt-voice-status { font-size: 11px; text-align: center; min-height: 14px; color: #6B7280; }
  #wt-voice-status.error { color: #EF4444; }
  #wt-voice-actions { display: none; gap: 6px; margin-top: 8px; }
  #wt-voice-actions.visible { display: flex; }
  .wt-va {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151; cursor: pointer;
  }
  .wt-va.accept { border-color: #10B981; color: #10B981; }
  .wt-va.reject { border-color: #EF4444; color: #EF4444; }
`;
  var openPanel = null;
  document.addEventListener("click", (e) => {
    if (openPanel && !openPanel.host.contains(e.target)) {
      openPanel.close();
      openPanel = null;
    }
  }, true);
  function openPanelFor(host, close) {
    if (openPanel && openPanel.host !== host) openPanel.close();
    openPanel = { host, close };
  }
  function clearOpenPanel(host) {
    if (openPanel?.host === host) openPanel = null;
  }
  function sendToBackground(message) {
    return new Promise((resolve) => chrome.runtime.sendMessage(message, resolve));
  }
  function isTextarea(el) {
    return el.tagName === "TEXTAREA";
  }
  function getComposeText(el) {
    if (isTextarea(el)) return el.value.trim();
    return el.innerText.trim();
  }
  function setComposeText(el, text) {
    if (isTextarea(el)) {
      const ta = el;
      ta.value = text;
      ta.dispatchEvent(new Event("input", { bubbles: true }));
      ta.dispatchEvent(new Event("change", { bubbles: true }));
    } else {
      el.focus();
      document.execCommand("selectAll", false, void 0);
      document.execCommand("delete", false, void 0);
      const lines = text.split("\n");
      for (let i = 0; i < lines.length; i++) {
        if (lines[i]) document.execCommand("insertText", false, lines[i]);
        if (i < lines.length - 1) document.execCommand("insertParagraph", false, void 0);
      }
    }
  }
  function injectMicButton(container, composeBody) {
    const micHost = document.createElement("span");
    micHost.style.cssText = "display:inline-flex;align-items:center;margin-left:4px;";
    const shadow = micHost.attachShadow({ mode: "open" });
    shadow.innerHTML = `
    <style>${MIC_CSS}</style>
    <button id="wt-mic-btn" title="Voice Twin">\u{1F399}</button>
    <div id="wt-voice-panel">
      <p class="wt-vt">Voice Twin</p>
      <div class="wt-otype-label">Output type</div>
      <div class="wt-otypes">
        ${VOICE_OUTPUT_TYPES.map(
      (o, i) => `<button class="wt-otype${i === 0 ? " active" : ""}" data-type="${o.key}">${o.label}</button>`
    ).join("")}
      </div>
      <button id="wt-record-btn">\u{1F399} Start recording</button>
      <div id="wt-voice-status"></div>
      <div id="wt-voice-actions">
        <button class="wt-va accept" id="wt-va-keep">\u2713 Keep it</button>
        <button class="wt-va reject" id="wt-va-undo">\u2717 Undo</button>
      </div>
    </div>
  `;
    const micBtn = shadow.getElementById("wt-mic-btn");
    const panel = shadow.getElementById("wt-voice-panel");
    const recordBtn = shadow.getElementById("wt-record-btn");
    const statusEl = shadow.getElementById("wt-voice-status");
    const actionsEl = shadow.getElementById("wt-voice-actions");
    const keepBtn = shadow.getElementById("wt-va-keep");
    const undoBtn = shadow.getElementById("wt-va-undo");
    let panelOpen = false;
    let selectedType = VOICE_OUTPUT_TYPES[0].key;
    let recorder = null;
    let recording = false;
    let chunks = [];
    let lastSessionId = null;
    let originalText = "";
    shadow.querySelectorAll(".wt-otype").forEach((btn) => {
      btn.addEventListener("click", () => {
        shadow.querySelectorAll(".wt-otype").forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        selectedType = btn.dataset.type;
      });
    });
    micBtn.addEventListener("click", () => {
      if (panelOpen) {
        panelOpen = false;
        panel.classList.remove("open");
        clearOpenPanel(micHost);
      } else {
        panelOpen = true;
        panel.classList.add("open");
        positionPanel();
        openPanelFor(micHost, () => {
          panelOpen = false;
          panel.classList.remove("open");
        });
      }
    });
    function positionPanel() {
      const rect = micBtn.getBoundingClientRect();
      panel.style.bottom = `${window.innerHeight - rect.top + 4}px`;
      panel.style.left = `${Math.min(rect.left, window.innerWidth - 296)}px`;
    }
    recordBtn.addEventListener("click", async () => {
      if (!recording) await startRecording();
      else stopRecording();
    });
    async function startRecording() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        chunks = [];
        recorder = new MediaRecorder(stream, { mimeType: "audio/webm" });
        recorder.ondataavailable = (e) => {
          if (e.data.size > 0) chunks.push(e.data);
        };
        recorder.onstop = async () => {
          stream.getTracks().forEach((t) => t.stop());
          await submitVoice(new Blob(chunks, { type: "audio/webm" }));
        };
        recorder.start();
        recording = true;
        micBtn.classList.add("recording");
        recordBtn.classList.add("recording");
        recordBtn.textContent = "\u23F9 Stop recording";
        setVStatus("Recording\u2026");
        actionsEl.classList.remove("visible");
        setTimeout(() => {
          if (recording) stopRecording();
        }, 6e4);
      } catch {
        setVStatus("Microphone access denied.", "error");
      }
    }
    function stopRecording() {
      if (recorder && recording) {
        recorder.stop();
        recording = false;
        micBtn.classList.remove("recording");
        recordBtn.classList.remove("recording");
        recordBtn.textContent = "\u{1F399} Start recording";
        recordBtn.disabled = true;
        setVStatus("Drafting\u2026");
      }
    }
    async function submitVoice(blob) {
      try {
        const buf = await blob.arrayBuffer();
        const audioData = btoa(Array.from(new Uint8Array(buf), (b) => String.fromCharCode(b)).join(""));
        originalText = getComposeText(composeBody);
        const resp = await sendToBackground({
          type: "VOICE_DRAFT",
          payload: { audioData, mimeType: "audio/webm", outputType: selectedType }
        });
        if ("error" in resp) throw new Error(String(resp.error));
        lastSessionId = resp.result.id;
        setComposeText(composeBody, resp.result.draft);
        setVStatus("Done \u2713");
        actionsEl.classList.add("visible");
      } catch (err) {
        setVStatus(err instanceof Error ? err.message : "Failed", "error");
      } finally {
        recordBtn.disabled = false;
      }
    }
    keepBtn.addEventListener("click", () => {
      if (lastSessionId) sendToBackground({ type: "VOICE_FEEDBACK", payload: { sessionId: lastSessionId, accepted: true, editedDraft: null } });
      actionsEl.classList.remove("visible");
      panelOpen = false;
      panel.classList.remove("open");
      clearOpenPanel(micHost);
      setVStatus("");
    });
    undoBtn.addEventListener("click", () => {
      if (originalText) setComposeText(composeBody, originalText);
      if (lastSessionId) sendToBackground({ type: "VOICE_FEEDBACK", payload: { sessionId: lastSessionId, accepted: false, editedDraft: null } });
      actionsEl.classList.remove("visible");
      setVStatus("Reverted.", "success");
      setTimeout(() => setVStatus(""), 2e3);
    });
    function setVStatus(msg, cls = "") {
      statusEl.textContent = msg;
      statusEl.className = cls;
    }
    container.appendChild(micHost);
  }
  function inject(composeBody) {
    if (composeBody.hasAttribute(HOST_ATTR)) return;
    composeBody.setAttribute(HOST_ATTR, "1");
    const wrapper = document.createElement("div");
    wrapper.style.cssText = "display:flex;align-items:center;gap:4px;margin-top:6px;padding:0 2px;";
    const insertionPoint = isTextarea(composeBody) ? composeBody.closest("form, .usertext-edit, .md-container") ?? composeBody.parentElement : composeBody.closest('.DraftEditor-root, .editor-container, [class*="Editor"]') ?? composeBody.parentElement;
    insertionPoint?.insertAdjacentElement("afterend", wrapper);
    if (!wrapper.parentElement) {
      composeBody.parentElement?.appendChild(wrapper);
    }
    const host = document.createElement("span");
    const shadow = host.attachShadow({ mode: "open" });
    let selectedTone = null;
    let lastRewriteId = null;
    let panelOpen = false;
    shadow.innerHTML = `
    <style>${BUTTON_CSS}</style>
    <button id="wt-btn" title="Humanize with Writing Twin AI">\u2728 Humanize</button>
    <div id="wt-panel">
      <p class="wt-title">Rewrite tone</p>
      <div class="wt-tones">
        ${TONES.map((t) => `<button class="wt-tone" data-tone="${t.key}" data-color="${t.color}">${t.label}</button>`).join("")}
      </div>
      <button id="wt-rewrite" disabled>Rewrite \u2192</button>
      <div id="wt-status"></div>
      <div id="wt-limit">
        <p>You've used all your free rewrites this month.</p>
        <a href="https://writingtwinai.com/pricing" target="_blank" rel="noopener">Upgrade to Pro \u2014 $5/mo</a>
      </div>
      <div id="wt-actions">
        <button class="wt-action accept" id="wt-accept">\u2713 Keep it</button>
        <button class="wt-action reject" id="wt-reject">\u2717 Undo</button>
      </div>
    </div>
  `;
    const btn = shadow.getElementById("wt-btn");
    const panel = shadow.getElementById("wt-panel");
    const rewriteBtn = shadow.getElementById("wt-rewrite");
    const statusEl = shadow.getElementById("wt-status");
    const limitEl = shadow.getElementById("wt-limit");
    const actionsEl = shadow.getElementById("wt-actions");
    const acceptBtn = shadow.getElementById("wt-accept");
    const rejectBtn = shadow.getElementById("wt-reject");
    shadow.querySelectorAll(".wt-tone").forEach((tb) => {
      tb.addEventListener("click", () => {
        shadow.querySelectorAll(".wt-tone").forEach((b) => b.classList.remove("active"));
        tb.classList.add("active");
        tb.style.background = tb.dataset.color ?? "#FF4500";
        tb.style.borderColor = tb.dataset.color ?? "#FF4500";
        selectedTone = tb.dataset.tone;
        rewriteBtn.disabled = false;
        statusEl.textContent = "";
        statusEl.className = "";
        limitEl.classList.remove("visible");
        actionsEl.classList.remove("visible");
      });
    });
    btn.addEventListener("click", () => {
      if (panelOpen) {
        panelOpen = false;
        panel.classList.remove("open");
        clearOpenPanel(host);
      } else {
        panelOpen = true;
        panel.classList.add("open");
        positionPanel();
        openPanelFor(host, () => {
          panelOpen = false;
          panel.classList.remove("open");
        });
      }
    });
    function positionPanel() {
      const rect = btn.getBoundingClientRect();
      panel.style.bottom = `${window.innerHeight - rect.top + 4}px`;
      panel.style.left = `${Math.min(rect.left, window.innerWidth - 276)}px`;
    }
    let originalText = "";
    rewriteBtn.addEventListener("click", async () => {
      if (!selectedTone) return;
      const text = getComposeText(composeBody);
      if (!text) {
        setStatus("Write something first.", "error");
        return;
      }
      originalText = text;
      btn.disabled = true;
      rewriteBtn.disabled = true;
      setStatus("Rewriting\u2026");
      actionsEl.classList.remove("visible");
      try {
        const resp = await sendToBackground({
          type: "HUMANIZE",
          payload: {
            text,
            tone: selectedTone,
            ctx: { platform: "reddit", context_twin_override: FIXED_CONTEXT_OVERRIDE }
          }
        });
        if ("error" in resp) throw new Error(String(resp.error));
        lastRewriteId = resp.result.id;
        setComposeText(composeBody, resp.result.output_text);
        setStatus("Done \u2713", "success");
        actionsEl.classList.add("visible");
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Failed";
        if (msg.startsWith("LIMIT_REACHED:")) {
          limitEl.classList.add("visible");
          setStatus("");
        } else {
          setStatus(msg, "error");
        }
      } finally {
        btn.disabled = false;
        rewriteBtn.disabled = selectedTone === null;
      }
    });
    acceptBtn.addEventListener("click", () => {
      if (lastRewriteId) sendToBackground({ type: "FEEDBACK", payload: { rewriteId: lastRewriteId, action: "accepted" } });
      actionsEl.classList.remove("visible");
      panelOpen = false;
      panel.classList.remove("open");
      clearOpenPanel(host);
      setStatus("");
    });
    rejectBtn.addEventListener("click", () => {
      if (originalText) setComposeText(composeBody, originalText);
      if (lastRewriteId) sendToBackground({ type: "FEEDBACK", payload: { rewriteId: lastRewriteId, action: "rejected" } });
      actionsEl.classList.remove("visible");
      setStatus("Reverted.", "success");
      setTimeout(() => setStatus(""), 2e3);
    });
    function setStatus(msg, cls = "") {
      statusEl.textContent = msg;
      statusEl.className = cls;
    }
    wrapper.appendChild(host);
    injectMicButton(wrapper, composeBody);
  }
  var seen = /* @__PURE__ */ new WeakSet();
  function tryInject(root) {
    root.querySelectorAll(COMPOSE_SEL).forEach((body) => {
      if (!seen.has(body)) {
        seen.add(body);
        inject(body);
      }
    });
  }
  var observer = new MutationObserver(() => {
    requestIdleCallback(() => tryInject(document), { timeout: 500 });
  });
  observer.observe(document.body, { childList: true, subtree: true });
  tryInject(document);
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vc3JjL2NvbnRlbnQvcmVkZGl0LnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJpbXBvcnQgdHlwZSB7IFRvbmUsIFJld3JpdGVSZXNwb25zZSwgVm9pY2VPdXRwdXRUeXBlLCBWb2ljZURyYWZ0UmVzcG9uc2UgfSBmcm9tICcuLi9saWIvYXBpJztcblxuLy8gT2xkIFJlZGRpdDogcGxhaW4gdGV4dGFyZWE7IE5ldyBSZWRkaXQ6IFNsYXRlLWJhc2VkIGNvbnRlbnRlZGl0YWJsZVxuY29uc3QgT0xEX1JFRERJVF9TRUwgPSAndGV4dGFyZWFbbmFtZT1cInRleHRcIl0sIHRleHRhcmVhLnVzZXJ0ZXh0LWVkaXQgdGV4dGFyZWEnO1xuY29uc3QgTkVXX1JFRERJVF9TRUwgPSAnZGl2W2NvbnRlbnRlZGl0YWJsZT1cInRydWVcIl1bZGF0YS10ZXN0aWRdLCBkaXYuRHJhZnRFZGl0b3ItZWRpdG9yQ29udGFpbmVyIFtjb250ZW50ZWRpdGFibGU9XCJ0cnVlXCJdLCAuZWRpdG9yLWNvbnRhaW5lciBbY29udGVudGVkaXRhYmxlPVwidHJ1ZVwiXSc7XG5jb25zdCBDT01QT1NFX1NFTCA9IGAke09MRF9SRURESVRfU0VMfSwgJHtORVdfUkVERElUX1NFTH1gO1xuY29uc3QgSE9TVF9BVFRSID0gJ2RhdGEtd3QtcmQtaW5qZWN0ZWQnO1xuXG4vLyBSZWRkaXQgaXMgQ29tbXVuaXR5IGNvbnRleHQgYnkgZGVmYXVsdFxuY29uc3QgRklYRURfQ09OVEVYVF9PVkVSUklERSA9ICdjb21tdW5pdHknO1xuXG5jb25zdCBUT05FUzogeyBrZXk6IFRvbmU7IGxhYmVsOiBzdHJpbmc7IGNvbG9yOiBzdHJpbmcgfVtdID0gW1xuICB7IGtleTogJ2Nhc3VhbCcsICAgICAgIGxhYmVsOiAnQ2FzdWFsJywgICAgICAgY29sb3I6ICcjRkY0NTAwJyB9LFxuICB7IGtleTogJ3Byb2Zlc3Npb25hbCcsIGxhYmVsOiAnUHJvZmVzc2lvbmFsJywgY29sb3I6ICcjMEE2NkMyJyB9LFxuICB7IGtleTogJ2ZyaWVuZGx5JywgICAgIGxhYmVsOiAnRnJpZW5kbHknLCAgICAgY29sb3I6ICcjRjU5RTBCJyB9LFxuICB7IGtleTogJ2RpcmVjdCcsICAgICAgIGxhYmVsOiAnRGlyZWN0JywgICAgICAgY29sb3I6ICcjREMyNjI2JyB9LFxuICB7IGtleTogJ2V4ZWN1dGl2ZScsICAgIGxhYmVsOiAnRXhlY3V0aXZlJywgICAgY29sb3I6ICcjMEYxNzJBJyB9LFxuXTtcblxuY29uc3QgVk9JQ0VfT1VUUFVUX1RZUEVTOiB7IGtleTogVm9pY2VPdXRwdXRUeXBlOyBsYWJlbDogc3RyaW5nIH1bXSA9IFtcbiAgeyBrZXk6ICdyZXBseScsICBsYWJlbDogJ1JlcGx5JyB9LFxuICB7IGtleTogJ2VtYWlsJywgIGxhYmVsOiAnTWVzc2FnZScgfSxcbl07XG5cbi8vIFx1MjUwMFx1MjUwMCBTaGFkb3cgRE9NIHN0eWxlcyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuY29uc3QgQlVUVE9OX0NTUyA9IGBcbiAgOmhvc3QgeyBkaXNwbGF5OiBpbmxpbmUtZmxleDsgYWxpZ24taXRlbXM6IGNlbnRlcjsgfVxuXG4gICN3dC1idG4ge1xuICAgIGRpc3BsYXk6IGlubGluZS1mbGV4OyBhbGlnbi1pdGVtczogY2VudGVyOyBnYXA6IDVweDtcbiAgICBoZWlnaHQ6IDI4cHg7IHBhZGRpbmc6IDAgMTJweDsgYm9yZGVyLXJhZGl1czogOTk5OXB4OyBib3JkZXI6IG5vbmU7XG4gICAgYmFja2dyb3VuZDogI0ZGNDUwMDsgY29sb3I6ICNmZmY7XG4gICAgZm9udDogNTAwIDEycHgvMSAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsIFwiU2Vnb2UgVUlcIiwgUm9ib3RvLCBzYW5zLXNlcmlmO1xuICAgIGN1cnNvcjogcG9pbnRlcjsgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICB0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kIDAuMTVzLCBib3gtc2hhZG93IDAuMTVzO1xuICB9XG4gICN3dC1idG46aG92ZXIgeyBiYWNrZ3JvdW5kOiAjY2MzNzAwOyBib3gtc2hhZG93OiAwIDAgMCAzcHggcmdiYSgyNTUsNjksMCwwLjI1KTsgfVxuICAjd3QtYnRuOmRpc2FibGVkIHsgb3BhY2l0eTogMC42OyBjdXJzb3I6IGRlZmF1bHQ7IGJveC1zaGFkb3c6IG5vbmU7IH1cblxuICAjd3QtcGFuZWwge1xuICAgIHBvc2l0aW9uOiBmaXhlZDsgei1pbmRleDogOTk5OTk7XG4gICAgYmFja2dyb3VuZDogI2ZmZjsgYm9yZGVyOiAxcHggc29saWQgI0UyRThGMDsgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICBib3gtc2hhZG93OiAwIDEycHggMzJweCByZ2JhKDAsMCwwLDAuMTQpO1xuICAgIHBhZGRpbmc6IDE0cHggMTZweDsgd2lkdGg6IDI2MHB4O1xuICAgIGZvbnQtZmFtaWx5OiAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsIFwiU2Vnb2UgVUlcIiwgUm9ib3RvLCBzYW5zLXNlcmlmO1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH1cbiAgI3d0LXBhbmVsLm9wZW4geyBkaXNwbGF5OiBibG9jazsgfVxuXG4gIC53dC10aXRsZSB7IGZvbnQtc2l6ZTogMTJweDsgZm9udC13ZWlnaHQ6IDYwMDsgY29sb3I6ICMzNzQxNTE7IG1hcmdpbjogMCAwIDEwcHg7XG4gICAgbGV0dGVyLXNwYWNpbmc6IDAuMDRlbTsgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTsgfVxuICAud3QtdG9uZXMgeyBkaXNwbGF5OiBmbGV4OyBmbGV4LXdyYXA6IHdyYXA7IGdhcDogNnB4OyBtYXJnaW4tYm90dG9tOiAxMnB4OyB9XG4gIC53dC10b25lIHtcbiAgICBwYWRkaW5nOiA0cHggMTBweDsgYm9yZGVyLXJhZGl1czogOTk5OXB4OyBib3JkZXI6IDEuNXB4IHNvbGlkICNFOEVBRUQ7XG4gICAgYmFja2dyb3VuZDogI2ZmZjsgZm9udC1zaXplOiAxMnB4OyBmb250LXdlaWdodDogNTAwOyBjb2xvcjogIzM3NDE1MTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7IHRyYW5zaXRpb246IGFsbCAwLjFzO1xuICB9XG4gIC53dC10b25lLmFjdGl2ZSB7IGNvbG9yOiAjZmZmOyBib3JkZXItY29sb3I6IHRyYW5zcGFyZW50OyB9XG4gIC53dC10b25lOmhvdmVyOm5vdCguYWN0aXZlKSB7IGJvcmRlci1jb2xvcjogI0ZDQTVBNTsgfVxuXG4gICN3dC1yZXdyaXRlIHtcbiAgICB3aWR0aDogMTAwJTsgaGVpZ2h0OiAzMnB4OyBib3JkZXItcmFkaXVzOiA4cHg7IGJvcmRlcjogbm9uZTtcbiAgICBiYWNrZ3JvdW5kOiAjRkY0NTAwOyBjb2xvcjogI2ZmZjtcbiAgICBmb250OiA2MDAgMTNweC8xIC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgXCJTZWdvZSBVSVwiLCBSb2JvdG8sIHNhbnMtc2VyaWY7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gICN3dC1yZXdyaXRlOmRpc2FibGVkIHsgb3BhY2l0eTogMC40NTsgY3Vyc29yOiBkZWZhdWx0OyB9XG5cbiAgI3d0LXN0YXR1cyB7IG1hcmdpbi10b3A6IDhweDsgZm9udC1zaXplOiAxMXB4OyB0ZXh0LWFsaWduOiBjZW50ZXI7IG1pbi1oZWlnaHQ6IDE0cHg7IH1cbiAgI3d0LXN0YXR1cy5lcnJvciB7IGNvbG9yOiAjRUY0NDQ0OyB9XG4gICN3dC1zdGF0dXMuc3VjY2VzcyB7IGNvbG9yOiAjMTBCOTgxOyB9XG5cbiAgI3d0LWFjdGlvbnMgeyBkaXNwbGF5OiBub25lOyBnYXA6IDZweDsgbWFyZ2luLXRvcDogOHB4OyB9XG4gICN3dC1hY3Rpb25zLnZpc2libGUgeyBkaXNwbGF5OiBmbGV4OyB9XG4gIC53dC1hY3Rpb24ge1xuICAgIGZsZXg6IDE7IGhlaWdodDogMjhweDsgYm9yZGVyLXJhZGl1czogOHB4OyBib3JkZXI6IDEuNXB4IHNvbGlkICNFOEVBRUQ7XG4gICAgYmFja2dyb3VuZDogI2ZmZjsgZm9udC1zaXplOiAxMnB4OyBmb250LXdlaWdodDogNTAwOyBjb2xvcjogIzM3NDE1MTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cbiAgLnd0LWFjdGlvbi5hY2NlcHQgeyBib3JkZXItY29sb3I6ICMxMEI5ODE7IGNvbG9yOiAjMTBCOTgxOyB9XG4gIC53dC1hY3Rpb24ucmVqZWN0IHsgYm9yZGVyLWNvbG9yOiAjRUY0NDQ0OyBjb2xvcjogI0VGNDQ0NDsgfVxuXG4gICN3dC1saW1pdCB7IGRpc3BsYXk6IG5vbmU7IG1hcmdpbi10b3A6IDEwcHg7IHBhZGRpbmc6IDEwcHggMTJweDsgYm9yZGVyLXJhZGl1czogOHB4O1xuICAgIGJhY2tncm91bmQ6ICNGRkY4RjE7IGJvcmRlcjogMXB4IHNvbGlkICNGRUQ3QUE7IHRleHQtYWxpZ246IGNlbnRlcjsgfVxuICAjd3QtbGltaXQudmlzaWJsZSB7IGRpc3BsYXk6IGJsb2NrOyB9XG4gICN3dC1saW1pdCBwIHsgZm9udC1zaXplOiAxMXB4OyBjb2xvcjogIzkyNDAwRTsgbWFyZ2luOiAwIDAgOHB4OyBsaW5lLWhlaWdodDogMS40OyB9XG4gICN3dC1saW1pdCBhIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7IHBhZGRpbmc6IDVweCAxNHB4OyBib3JkZXItcmFkaXVzOiA5OTk5cHg7XG4gICAgYmFja2dyb3VuZDogI0Y1OUUwQjsgY29sb3I6ICNmZmY7IGZvbnQtc2l6ZTogMTFweDsgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gIH1cbmA7XG5cbmNvbnN0IE1JQ19DU1MgPSBgXG4gIDpob3N0IHsgZGlzcGxheTogaW5saW5lLWZsZXg7IGFsaWduLWl0ZW1zOiBjZW50ZXI7IG1hcmdpbi1sZWZ0OiA0cHg7IH1cblxuICAjd3QtbWljLWJ0biB7XG4gICAgZGlzcGxheTogaW5saW5lLWZsZXg7IGFsaWduLWl0ZW1zOiBjZW50ZXI7IGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIHdpZHRoOiAyOHB4OyBoZWlnaHQ6IDI4cHg7IGJvcmRlci1yYWRpdXM6IDk5OTlweDsgYm9yZGVyOiBub25lO1xuICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50OyBjb2xvcjogIzY2NjsgY3Vyc29yOiBwb2ludGVyO1xuICAgIHRyYW5zaXRpb246IGJhY2tncm91bmQgMC4xNXMsIGNvbG9yIDAuMTVzOyBmb250LXNpemU6IDE1cHg7IGxpbmUtaGVpZ2h0OiAxO1xuICB9XG4gICN3dC1taWMtYnRuOmhvdmVyIHsgYmFja2dyb3VuZDogcmdiYSgwLDAsMCwwLjA3KTsgfVxuICAjd3QtbWljLWJ0bi5yZWNvcmRpbmcgeyBiYWNrZ3JvdW5kOiAjRkVFMkUyOyBjb2xvcjogI0RDMjYyNjtcbiAgICBhbmltYXRpb246IHd0LXB1bHNlIDEuMnMgZWFzZS1pbi1vdXQgaW5maW5pdGU7IH1cbiAgQGtleWZyYW1lcyB3dC1wdWxzZSB7XG4gICAgMCUsIDEwMCUgeyBib3gtc2hhZG93OiAwIDAgMCAwIHJnYmEoMjIwLDM4LDM4LDAuNCk7IH1cbiAgICA1MCUgICAgICAgeyBib3gtc2hhZG93OiAwIDAgMCA1cHggcmdiYSgyMjAsMzgsMzgsMCk7IH1cbiAgfVxuICAjd3QtbWljLWJ0bjpkaXNhYmxlZCB7IG9wYWNpdHk6IDAuNTsgY3Vyc29yOiBkZWZhdWx0OyB9XG5cbiAgI3d0LXZvaWNlLXBhbmVsIHtcbiAgICBwb3NpdGlvbjogZml4ZWQ7IHotaW5kZXg6IDk5OTk5O1xuICAgIGJhY2tncm91bmQ6ICNmZmY7IGJvcmRlcjogMXB4IHNvbGlkICNFMkU4RjA7IGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgYm94LXNoYWRvdzogMCAxMnB4IDMycHggcmdiYSgwLDAsMCwwLjE0KTtcbiAgICBwYWRkaW5nOiAxNHB4IDE2cHg7IHdpZHRoOiAyODBweDtcbiAgICBmb250LWZhbWlseTogLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCBcIlNlZ29lIFVJXCIsIFJvYm90bywgc2Fucy1zZXJpZjtcbiAgICBkaXNwbGF5OiBub25lO1xuICB9XG4gICN3dC12b2ljZS1wYW5lbC5vcGVuIHsgZGlzcGxheTogYmxvY2s7IH1cblxuICAud3QtdnQgeyBmb250LXNpemU6IDEycHg7IGZvbnQtd2VpZ2h0OiA2MDA7IGNvbG9yOiAjMzc0MTUxOyBtYXJnaW46IDAgMCAxMHB4O1xuICAgIGxldHRlci1zcGFjaW5nOiAwLjA0ZW07IHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7IH1cbiAgI3d0LXJlY29yZC1idG4ge1xuICAgIHdpZHRoOiAxMDAlOyBoZWlnaHQ6IDM0cHg7IGJvcmRlci1yYWRpdXM6IDhweDsgYm9yZGVyOiBub25lO1xuICAgIGJhY2tncm91bmQ6ICNEQzI2MjY7IGNvbG9yOiAjZmZmOyBjdXJzb3I6IHBvaW50ZXI7XG4gICAgZm9udDogNjAwIDEzcHgvMSAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsIFwiU2Vnb2UgVUlcIiwgUm9ib3RvLCBzYW5zLXNlcmlmO1xuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIH1cbiAgI3d0LXJlY29yZC1idG4ucmVjb3JkaW5nIHsgYmFja2dyb3VuZDogIzdGMUQxRDsgfVxuICAjd3QtcmVjb3JkLWJ0bjpkaXNhYmxlZCB7IG9wYWNpdHk6IDAuNTsgY3Vyc29yOiBkZWZhdWx0OyB9XG4gIC53dC1vdHlwZS1sYWJlbCB7IGZvbnQtc2l6ZTogMTFweDsgY29sb3I6ICM2QjcyODA7IG1hcmdpbi1ib3R0b206IDRweDsgfVxuICAud3Qtb3R5cGVzIHsgZGlzcGxheTogZmxleDsgZmxleC13cmFwOiB3cmFwOyBnYXA6IDVweDsgbWFyZ2luLWJvdHRvbTogMTBweDsgfVxuICAud3Qtb3R5cGUge1xuICAgIHBhZGRpbmc6IDNweCA5cHg7IGJvcmRlci1yYWRpdXM6IDk5OTlweDsgYm9yZGVyOiAxLjVweCBzb2xpZCAjRThFQUVEO1xuICAgIGJhY2tncm91bmQ6ICNmZmY7IGZvbnQtc2l6ZTogMTFweDsgY29sb3I6ICMzNzQxNTE7IGN1cnNvcjogcG9pbnRlcjtcbiAgICB0cmFuc2l0aW9uOiBhbGwgMC4xcztcbiAgfVxuICAud3Qtb3R5cGUuYWN0aXZlIHsgYmFja2dyb3VuZDogI0ZGNDUwMDsgY29sb3I6ICNmZmY7IGJvcmRlci1jb2xvcjogI0ZGNDUwMDsgfVxuICAjd3Qtdm9pY2Utc3RhdHVzIHsgZm9udC1zaXplOiAxMXB4OyB0ZXh0LWFsaWduOiBjZW50ZXI7IG1pbi1oZWlnaHQ6IDE0cHg7IGNvbG9yOiAjNkI3MjgwOyB9XG4gICN3dC12b2ljZS1zdGF0dXMuZXJyb3IgeyBjb2xvcjogI0VGNDQ0NDsgfVxuICAjd3Qtdm9pY2UtYWN0aW9ucyB7IGRpc3BsYXk6IG5vbmU7IGdhcDogNnB4OyBtYXJnaW4tdG9wOiA4cHg7IH1cbiAgI3d0LXZvaWNlLWFjdGlvbnMudmlzaWJsZSB7IGRpc3BsYXk6IGZsZXg7IH1cbiAgLnd0LXZhIHtcbiAgICBmbGV4OiAxOyBoZWlnaHQ6IDI4cHg7IGJvcmRlci1yYWRpdXM6IDhweDsgYm9yZGVyOiAxLjVweCBzb2xpZCAjRThFQUVEO1xuICAgIGJhY2tncm91bmQ6ICNmZmY7IGZvbnQtc2l6ZTogMTJweDsgZm9udC13ZWlnaHQ6IDUwMDsgY29sb3I6ICMzNzQxNTE7IGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAud3QtdmEuYWNjZXB0IHsgYm9yZGVyLWNvbG9yOiAjMTBCOTgxOyBjb2xvcjogIzEwQjk4MTsgfVxuICAud3QtdmEucmVqZWN0IHsgYm9yZGVyLWNvbG9yOiAjRUY0NDQ0OyBjb2xvcjogI0VGNDQ0NDsgfVxuYDtcblxuLy8gXHUyNTAwXHUyNTAwIE1vZHVsZS1sZXZlbCBwYW5lbCBtYW5hZ2VyIChzaW5nbGUgZGVsZWdhdGVkIGNsaWNrIGxpc3RlbmVyKSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxubGV0IG9wZW5QYW5lbDogeyBob3N0OiBFbGVtZW50OyBjbG9zZTogKCkgPT4gdm9pZCB9IHwgbnVsbCA9IG51bGw7XG5cbmRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGUpID0+IHtcbiAgaWYgKG9wZW5QYW5lbCAmJiAhb3BlblBhbmVsLmhvc3QuY29udGFpbnMoZS50YXJnZXQgYXMgTm9kZSkpIHtcbiAgICBvcGVuUGFuZWwuY2xvc2UoKTtcbiAgICBvcGVuUGFuZWwgPSBudWxsO1xuICB9XG59LCB0cnVlKTtcblxuZnVuY3Rpb24gb3BlblBhbmVsRm9yKGhvc3Q6IEVsZW1lbnQsIGNsb3NlOiAoKSA9PiB2b2lkKTogdm9pZCB7XG4gIGlmIChvcGVuUGFuZWwgJiYgb3BlblBhbmVsLmhvc3QgIT09IGhvc3QpIG9wZW5QYW5lbC5jbG9zZSgpO1xuICBvcGVuUGFuZWwgPSB7IGhvc3QsIGNsb3NlIH07XG59XG5cbmZ1bmN0aW9uIGNsZWFyT3BlblBhbmVsKGhvc3Q6IEVsZW1lbnQpOiB2b2lkIHtcbiAgaWYgKG9wZW5QYW5lbD8uaG9zdCA9PT0gaG9zdCkgb3BlblBhbmVsID0gbnVsbDtcbn1cblxuLy8gXHUyNTAwXHUyNTAwIEhlbHBlcnMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmZ1bmN0aW9uIHNlbmRUb0JhY2tncm91bmQ8VD4obWVzc2FnZTogb2JqZWN0KTogUHJvbWlzZTxUPiB7XG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4gY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UobWVzc2FnZSwgcmVzb2x2ZSkpO1xufVxuXG5mdW5jdGlvbiBpc1RleHRhcmVhKGVsOiBFbGVtZW50KTogZWwgaXMgSFRNTFRleHRBcmVhRWxlbWVudCB7XG4gIHJldHVybiBlbC50YWdOYW1lID09PSAnVEVYVEFSRUEnO1xufVxuXG5mdW5jdGlvbiBnZXRDb21wb3NlVGV4dChlbDogRWxlbWVudCk6IHN0cmluZyB7XG4gIGlmIChpc1RleHRhcmVhKGVsKSkgcmV0dXJuIChlbCBhcyBIVE1MVGV4dEFyZWFFbGVtZW50KS52YWx1ZS50cmltKCk7XG4gIHJldHVybiAoZWwgYXMgSFRNTEVsZW1lbnQpLmlubmVyVGV4dC50cmltKCk7XG59XG5cbmZ1bmN0aW9uIHNldENvbXBvc2VUZXh0KGVsOiBFbGVtZW50LCB0ZXh0OiBzdHJpbmcpOiB2b2lkIHtcbiAgaWYgKGlzVGV4dGFyZWEoZWwpKSB7XG4gICAgY29uc3QgdGEgPSBlbCBhcyBIVE1MVGV4dEFyZWFFbGVtZW50O1xuICAgIHRhLnZhbHVlID0gdGV4dDtcbiAgICB0YS5kaXNwYXRjaEV2ZW50KG5ldyBFdmVudCgnaW5wdXQnLCB7IGJ1YmJsZXM6IHRydWUgfSkpO1xuICAgIHRhLmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KCdjaGFuZ2UnLCB7IGJ1YmJsZXM6IHRydWUgfSkpO1xuICB9IGVsc2Uge1xuICAgIC8vIE5ldyBSZWRkaXQgdXNlcyBTbGF0ZS9EcmFmdC5qcyBcdTIwMTQgZXhlY0NvbW1hbmQgd29ya3MgYmVzdFxuICAgIChlbCBhcyBIVE1MRWxlbWVudCkuZm9jdXMoKTtcbiAgICBkb2N1bWVudC5leGVjQ29tbWFuZCgnc2VsZWN0QWxsJywgZmFsc2UsIHVuZGVmaW5lZCk7XG4gICAgZG9jdW1lbnQuZXhlY0NvbW1hbmQoJ2RlbGV0ZScsIGZhbHNlLCB1bmRlZmluZWQpO1xuICAgIGNvbnN0IGxpbmVzID0gdGV4dC5zcGxpdCgnXFxuJyk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsaW5lcy5sZW5ndGg7IGkrKykge1xuICAgICAgaWYgKGxpbmVzW2ldKSBkb2N1bWVudC5leGVjQ29tbWFuZCgnaW5zZXJ0VGV4dCcsIGZhbHNlLCBsaW5lc1tpXSk7XG4gICAgICBpZiAoaSA8IGxpbmVzLmxlbmd0aCAtIDEpIGRvY3VtZW50LmV4ZWNDb21tYW5kKCdpbnNlcnRQYXJhZ3JhcGgnLCBmYWxzZSwgdW5kZWZpbmVkKTtcbiAgICB9XG4gIH1cbn1cblxuLy8gXHUyNTAwXHUyNTAwIE1pYyBidXR0b24gKFZvaWNlIFR3aW4pIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5mdW5jdGlvbiBpbmplY3RNaWNCdXR0b24oY29udGFpbmVyOiBFbGVtZW50LCBjb21wb3NlQm9keTogRWxlbWVudCk6IHZvaWQge1xuICBjb25zdCBtaWNIb3N0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICBtaWNIb3N0LnN0eWxlLmNzc1RleHQgPSAnZGlzcGxheTppbmxpbmUtZmxleDthbGlnbi1pdGVtczpjZW50ZXI7bWFyZ2luLWxlZnQ6NHB4Oyc7XG4gIGNvbnN0IHNoYWRvdyA9IG1pY0hvc3QuYXR0YWNoU2hhZG93KHsgbW9kZTogJ29wZW4nIH0pO1xuXG4gIHNoYWRvdy5pbm5lckhUTUwgPSBgXG4gICAgPHN0eWxlPiR7TUlDX0NTU308L3N0eWxlPlxuICAgIDxidXR0b24gaWQ9XCJ3dC1taWMtYnRuXCIgdGl0bGU9XCJWb2ljZSBUd2luXCI+XHVEODNDXHVERjk5PC9idXR0b24+XG4gICAgPGRpdiBpZD1cInd0LXZvaWNlLXBhbmVsXCI+XG4gICAgICA8cCBjbGFzcz1cInd0LXZ0XCI+Vm9pY2UgVHdpbjwvcD5cbiAgICAgIDxkaXYgY2xhc3M9XCJ3dC1vdHlwZS1sYWJlbFwiPk91dHB1dCB0eXBlPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzPVwid3Qtb3R5cGVzXCI+XG4gICAgICAgICR7Vk9JQ0VfT1VUUFVUX1RZUEVTLm1hcCgobywgaSkgPT5cbiAgICAgICAgICBgPGJ1dHRvbiBjbGFzcz1cInd0LW90eXBlJHtpID09PSAwID8gJyBhY3RpdmUnIDogJyd9XCIgZGF0YS10eXBlPVwiJHtvLmtleX1cIj4ke28ubGFiZWx9PC9idXR0b24+YFxuICAgICAgICApLmpvaW4oJycpfVxuICAgICAgPC9kaXY+XG4gICAgICA8YnV0dG9uIGlkPVwid3QtcmVjb3JkLWJ0blwiPlx1RDgzQ1x1REY5OSBTdGFydCByZWNvcmRpbmc8L2J1dHRvbj5cbiAgICAgIDxkaXYgaWQ9XCJ3dC12b2ljZS1zdGF0dXNcIj48L2Rpdj5cbiAgICAgIDxkaXYgaWQ9XCJ3dC12b2ljZS1hY3Rpb25zXCI+XG4gICAgICAgIDxidXR0b24gY2xhc3M9XCJ3dC12YSBhY2NlcHRcIiBpZD1cInd0LXZhLWtlZXBcIj5cdTI3MTMgS2VlcCBpdDwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uIGNsYXNzPVwid3QtdmEgcmVqZWN0XCIgaWQ9XCJ3dC12YS11bmRvXCI+XHUyNzE3IFVuZG88L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIGNvbnN0IG1pY0J0biAgICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtbWljLWJ0bicpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICBjb25zdCBwYW5lbCAgICAgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LXZvaWNlLXBhbmVsJykgYXMgSFRNTERpdkVsZW1lbnQ7XG4gIGNvbnN0IHJlY29yZEJ0biA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtcmVjb3JkLWJ0bicpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICBjb25zdCBzdGF0dXNFbCAgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LXZvaWNlLXN0YXR1cycpIGFzIEhUTUxEaXZFbGVtZW50O1xuICBjb25zdCBhY3Rpb25zRWwgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LXZvaWNlLWFjdGlvbnMnKSBhcyBIVE1MRGl2RWxlbWVudDtcbiAgY29uc3Qga2VlcEJ0biAgID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC12YS1rZWVwJykgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG4gIGNvbnN0IHVuZG9CdG4gICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtdmEtdW5kbycpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuXG4gIGxldCBwYW5lbE9wZW4gPSBmYWxzZTtcbiAgbGV0IHNlbGVjdGVkVHlwZTogVm9pY2VPdXRwdXRUeXBlID0gVk9JQ0VfT1VUUFVUX1RZUEVTWzBdLmtleTtcbiAgbGV0IHJlY29yZGVyOiBNZWRpYVJlY29yZGVyIHwgbnVsbCA9IG51bGw7XG4gIGxldCByZWNvcmRpbmcgPSBmYWxzZTtcbiAgbGV0IGNodW5rczogQmxvYlBhcnRbXSA9IFtdO1xuICBsZXQgbGFzdFNlc3Npb25JZDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG4gIGxldCBvcmlnaW5hbFRleHQgPSAnJztcblxuICBzaGFkb3cucXVlcnlTZWxlY3RvckFsbDxIVE1MQnV0dG9uRWxlbWVudD4oJy53dC1vdHlwZScpLmZvckVhY2goYnRuID0+IHtcbiAgICBidG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgICBzaGFkb3cucXVlcnlTZWxlY3RvckFsbCgnLnd0LW90eXBlJykuZm9yRWFjaChiID0+IGIuY2xhc3NMaXN0LnJlbW92ZSgnYWN0aXZlJykpO1xuICAgICAgYnRuLmNsYXNzTGlzdC5hZGQoJ2FjdGl2ZScpO1xuICAgICAgc2VsZWN0ZWRUeXBlID0gYnRuLmRhdGFzZXQudHlwZSBhcyBWb2ljZU91dHB1dFR5cGU7XG4gICAgfSk7XG4gIH0pO1xuXG4gIG1pY0J0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBpZiAocGFuZWxPcGVuKSB7XG4gICAgICBwYW5lbE9wZW4gPSBmYWxzZTtcbiAgICAgIHBhbmVsLmNsYXNzTGlzdC5yZW1vdmUoJ29wZW4nKTtcbiAgICAgIGNsZWFyT3BlblBhbmVsKG1pY0hvc3QpO1xuICAgIH0gZWxzZSB7XG4gICAgICBwYW5lbE9wZW4gPSB0cnVlO1xuICAgICAgcGFuZWwuY2xhc3NMaXN0LmFkZCgnb3BlbicpO1xuICAgICAgcG9zaXRpb25QYW5lbCgpO1xuICAgICAgb3BlblBhbmVsRm9yKG1pY0hvc3QsICgpID0+IHsgcGFuZWxPcGVuID0gZmFsc2U7IHBhbmVsLmNsYXNzTGlzdC5yZW1vdmUoJ29wZW4nKTsgfSk7XG4gICAgfVxuICB9KTtcblxuICBmdW5jdGlvbiBwb3NpdGlvblBhbmVsKCk6IHZvaWQge1xuICAgIGNvbnN0IHJlY3QgPSBtaWNCdG4uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgcGFuZWwuc3R5bGUuYm90dG9tID0gYCR7d2luZG93LmlubmVySGVpZ2h0IC0gcmVjdC50b3AgKyA0fXB4YDtcbiAgICBwYW5lbC5zdHlsZS5sZWZ0ID0gYCR7TWF0aC5taW4ocmVjdC5sZWZ0LCB3aW5kb3cuaW5uZXJXaWR0aCAtIDI5Nil9cHhgO1xuICB9XG5cbiAgcmVjb3JkQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICAgIGlmICghcmVjb3JkaW5nKSBhd2FpdCBzdGFydFJlY29yZGluZygpOyBlbHNlIHN0b3BSZWNvcmRpbmcoKTtcbiAgfSk7XG5cbiAgYXN5bmMgZnVuY3Rpb24gc3RhcnRSZWNvcmRpbmcoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHN0cmVhbSA9IGF3YWl0IG5hdmlnYXRvci5tZWRpYURldmljZXMuZ2V0VXNlck1lZGlhKHsgYXVkaW86IHRydWUgfSk7XG4gICAgICBjaHVua3MgPSBbXTtcbiAgICAgIHJlY29yZGVyID0gbmV3IE1lZGlhUmVjb3JkZXIoc3RyZWFtLCB7IG1pbWVUeXBlOiAnYXVkaW8vd2VibScgfSk7XG4gICAgICByZWNvcmRlci5vbmRhdGFhdmFpbGFibGUgPSAoZSkgPT4geyBpZiAoZS5kYXRhLnNpemUgPiAwKSBjaHVua3MucHVzaChlLmRhdGEpOyB9O1xuICAgICAgcmVjb3JkZXIub25zdG9wID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBzdHJlYW0uZ2V0VHJhY2tzKCkuZm9yRWFjaCh0ID0+IHQuc3RvcCgpKTtcbiAgICAgICAgYXdhaXQgc3VibWl0Vm9pY2UobmV3IEJsb2IoY2h1bmtzLCB7IHR5cGU6ICdhdWRpby93ZWJtJyB9KSk7XG4gICAgICB9O1xuICAgICAgcmVjb3JkZXIuc3RhcnQoKTtcbiAgICAgIHJlY29yZGluZyA9IHRydWU7XG4gICAgICBtaWNCdG4uY2xhc3NMaXN0LmFkZCgncmVjb3JkaW5nJyk7XG4gICAgICByZWNvcmRCdG4uY2xhc3NMaXN0LmFkZCgncmVjb3JkaW5nJyk7XG4gICAgICByZWNvcmRCdG4udGV4dENvbnRlbnQgPSAnXHUyM0Y5IFN0b3AgcmVjb3JkaW5nJztcbiAgICAgIHNldFZTdGF0dXMoJ1JlY29yZGluZ1x1MjAyNicpO1xuICAgICAgYWN0aW9uc0VsLmNsYXNzTGlzdC5yZW1vdmUoJ3Zpc2libGUnKTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4geyBpZiAocmVjb3JkaW5nKSBzdG9wUmVjb3JkaW5nKCk7IH0sIDYwXzAwMCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICBzZXRWU3RhdHVzKCdNaWNyb3Bob25lIGFjY2VzcyBkZW5pZWQuJywgJ2Vycm9yJyk7XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gc3RvcFJlY29yZGluZygpOiB2b2lkIHtcbiAgICBpZiAocmVjb3JkZXIgJiYgcmVjb3JkaW5nKSB7XG4gICAgICByZWNvcmRlci5zdG9wKCk7IHJlY29yZGluZyA9IGZhbHNlO1xuICAgICAgbWljQnRuLmNsYXNzTGlzdC5yZW1vdmUoJ3JlY29yZGluZycpO1xuICAgICAgcmVjb3JkQnRuLmNsYXNzTGlzdC5yZW1vdmUoJ3JlY29yZGluZycpO1xuICAgICAgcmVjb3JkQnRuLnRleHRDb250ZW50ID0gJ1x1RDgzQ1x1REY5OSBTdGFydCByZWNvcmRpbmcnO1xuICAgICAgcmVjb3JkQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgICAgIHNldFZTdGF0dXMoJ0RyYWZ0aW5nXHUyMDI2Jyk7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgZnVuY3Rpb24gc3VibWl0Vm9pY2UoYmxvYjogQmxvYik6IFByb21pc2U8dm9pZD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBidWYgPSBhd2FpdCBibG9iLmFycmF5QnVmZmVyKCk7XG4gICAgICBjb25zdCBhdWRpb0RhdGEgPSBidG9hKEFycmF5LmZyb20obmV3IFVpbnQ4QXJyYXkoYnVmKSwgYiA9PiBTdHJpbmcuZnJvbUNoYXJDb2RlKGIpKS5qb2luKCcnKSk7XG4gICAgICBvcmlnaW5hbFRleHQgPSBnZXRDb21wb3NlVGV4dChjb21wb3NlQm9keSk7XG4gICAgICBjb25zdCByZXNwID0gYXdhaXQgc2VuZFRvQmFja2dyb3VuZDx7IHJlc3VsdDogVm9pY2VEcmFmdFJlc3BvbnNlIH0gfCB7IGVycm9yOiBzdHJpbmcgfT4oe1xuICAgICAgICB0eXBlOiAnVk9JQ0VfRFJBRlQnLFxuICAgICAgICBwYXlsb2FkOiB7IGF1ZGlvRGF0YSwgbWltZVR5cGU6ICdhdWRpby93ZWJtJywgb3V0cHV0VHlwZTogc2VsZWN0ZWRUeXBlIH0sXG4gICAgICB9KTtcbiAgICAgIGlmICgnZXJyb3InIGluIHJlc3ApIHRocm93IG5ldyBFcnJvcihTdHJpbmcocmVzcC5lcnJvcikpO1xuICAgICAgbGFzdFNlc3Npb25JZCA9IHJlc3AucmVzdWx0LmlkO1xuICAgICAgc2V0Q29tcG9zZVRleHQoY29tcG9zZUJvZHksIHJlc3AucmVzdWx0LmRyYWZ0KTtcbiAgICAgIHNldFZTdGF0dXMoJ0RvbmUgXHUyNzEzJyk7XG4gICAgICBhY3Rpb25zRWwuY2xhc3NMaXN0LmFkZCgndmlzaWJsZScpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0VlN0YXR1cyhlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogJ0ZhaWxlZCcsICdlcnJvcicpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICByZWNvcmRCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgICB9XG4gIH1cblxuICBrZWVwQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgIGlmIChsYXN0U2Vzc2lvbklkKSBzZW5kVG9CYWNrZ3JvdW5kKHsgdHlwZTogJ1ZPSUNFX0ZFRURCQUNLJywgcGF5bG9hZDogeyBzZXNzaW9uSWQ6IGxhc3RTZXNzaW9uSWQsIGFjY2VwdGVkOiB0cnVlLCBlZGl0ZWREcmFmdDogbnVsbCB9IH0pO1xuICAgIGFjdGlvbnNFbC5jbGFzc0xpc3QucmVtb3ZlKCd2aXNpYmxlJyk7XG4gICAgcGFuZWxPcGVuID0gZmFsc2U7IHBhbmVsLmNsYXNzTGlzdC5yZW1vdmUoJ29wZW4nKTtcbiAgICBjbGVhck9wZW5QYW5lbChtaWNIb3N0KTtcbiAgICBzZXRWU3RhdHVzKCcnKTtcbiAgfSk7XG5cbiAgdW5kb0J0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBpZiAob3JpZ2luYWxUZXh0KSBzZXRDb21wb3NlVGV4dChjb21wb3NlQm9keSwgb3JpZ2luYWxUZXh0KTtcbiAgICBpZiAobGFzdFNlc3Npb25JZCkgc2VuZFRvQmFja2dyb3VuZCh7IHR5cGU6ICdWT0lDRV9GRUVEQkFDSycsIHBheWxvYWQ6IHsgc2Vzc2lvbklkOiBsYXN0U2Vzc2lvbklkLCBhY2NlcHRlZDogZmFsc2UsIGVkaXRlZERyYWZ0OiBudWxsIH0gfSk7XG4gICAgYWN0aW9uc0VsLmNsYXNzTGlzdC5yZW1vdmUoJ3Zpc2libGUnKTtcbiAgICBzZXRWU3RhdHVzKCdSZXZlcnRlZC4nLCAnc3VjY2VzcycpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0VlN0YXR1cygnJyksIDIwMDApO1xuICB9KTtcblxuICBmdW5jdGlvbiBzZXRWU3RhdHVzKG1zZzogc3RyaW5nLCBjbHMgPSAnJyk6IHZvaWQge1xuICAgIHN0YXR1c0VsLnRleHRDb250ZW50ID0gbXNnOyBzdGF0dXNFbC5jbGFzc05hbWUgPSBjbHM7XG4gIH1cblxuICBjb250YWluZXIuYXBwZW5kQ2hpbGQobWljSG9zdCk7XG59XG5cbi8vIFx1MjUwMFx1MjUwMCBIdW1hbml6ZSBidXR0b24gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmZ1bmN0aW9uIGluamVjdChjb21wb3NlQm9keTogRWxlbWVudCk6IHZvaWQge1xuICBpZiAoY29tcG9zZUJvZHkuaGFzQXR0cmlidXRlKEhPU1RfQVRUUikpIHJldHVybjtcbiAgY29tcG9zZUJvZHkuc2V0QXR0cmlidXRlKEhPU1RfQVRUUiwgJzEnKTtcblxuICAvLyBCdWlsZCB3cmFwcGVyIHJvdyBhZnRlciB0aGUgY29tcG9zZSBlbGVtZW50IChvciBuZWFyZXN0IGJsb2NrIHBhcmVudClcbiAgY29uc3Qgd3JhcHBlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICB3cmFwcGVyLnN0eWxlLmNzc1RleHQgPSAnZGlzcGxheTpmbGV4O2FsaWduLWl0ZW1zOmNlbnRlcjtnYXA6NHB4O21hcmdpbi10b3A6NnB4O3BhZGRpbmc6MCAycHg7JztcblxuICBjb25zdCBpbnNlcnRpb25Qb2ludCA9IGlzVGV4dGFyZWEoY29tcG9zZUJvZHkpXG4gICAgPyAoY29tcG9zZUJvZHkuY2xvc2VzdCgnZm9ybSwgLnVzZXJ0ZXh0LWVkaXQsIC5tZC1jb250YWluZXInKSA/PyBjb21wb3NlQm9keS5wYXJlbnRFbGVtZW50KVxuICAgIDogKGNvbXBvc2VCb2R5LmNsb3Nlc3QoJy5EcmFmdEVkaXRvci1yb290LCAuZWRpdG9yLWNvbnRhaW5lciwgW2NsYXNzKj1cIkVkaXRvclwiXScpID8/IGNvbXBvc2VCb2R5LnBhcmVudEVsZW1lbnQpO1xuICBpbnNlcnRpb25Qb2ludD8uaW5zZXJ0QWRqYWNlbnRFbGVtZW50KCdhZnRlcmVuZCcsIHdyYXBwZXIpO1xuICBpZiAoIXdyYXBwZXIucGFyZW50RWxlbWVudCkge1xuICAgIGNvbXBvc2VCb2R5LnBhcmVudEVsZW1lbnQ/LmFwcGVuZENoaWxkKHdyYXBwZXIpO1xuICB9XG5cbiAgY29uc3QgaG9zdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgY29uc3Qgc2hhZG93ID0gaG9zdC5hdHRhY2hTaGFkb3coeyBtb2RlOiAnb3BlbicgfSk7XG5cbiAgbGV0IHNlbGVjdGVkVG9uZTogVG9uZSB8IG51bGwgPSBudWxsO1xuICBsZXQgbGFzdFJld3JpdGVJZDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG4gIGxldCBwYW5lbE9wZW4gPSBmYWxzZTtcblxuICBzaGFkb3cuaW5uZXJIVE1MID0gYFxuICAgIDxzdHlsZT4ke0JVVFRPTl9DU1N9PC9zdHlsZT5cbiAgICA8YnV0dG9uIGlkPVwid3QtYnRuXCIgdGl0bGU9XCJIdW1hbml6ZSB3aXRoIFdyaXRpbmcgVHdpbiBBSVwiPlx1MjcyOCBIdW1hbml6ZTwvYnV0dG9uPlxuICAgIDxkaXYgaWQ9XCJ3dC1wYW5lbFwiPlxuICAgICAgPHAgY2xhc3M9XCJ3dC10aXRsZVwiPlJld3JpdGUgdG9uZTwvcD5cbiAgICAgIDxkaXYgY2xhc3M9XCJ3dC10b25lc1wiPlxuICAgICAgICAke1RPTkVTLm1hcCh0ID0+IGA8YnV0dG9uIGNsYXNzPVwid3QtdG9uZVwiIGRhdGEtdG9uZT1cIiR7dC5rZXl9XCIgZGF0YS1jb2xvcj1cIiR7dC5jb2xvcn1cIj4ke3QubGFiZWx9PC9idXR0b24+YCkuam9pbignJyl9XG4gICAgICA8L2Rpdj5cbiAgICAgIDxidXR0b24gaWQ9XCJ3dC1yZXdyaXRlXCIgZGlzYWJsZWQ+UmV3cml0ZSBcdTIxOTI8L2J1dHRvbj5cbiAgICAgIDxkaXYgaWQ9XCJ3dC1zdGF0dXNcIj48L2Rpdj5cbiAgICAgIDxkaXYgaWQ9XCJ3dC1saW1pdFwiPlxuICAgICAgICA8cD5Zb3UndmUgdXNlZCBhbGwgeW91ciBmcmVlIHJld3JpdGVzIHRoaXMgbW9udGguPC9wPlxuICAgICAgICA8YSBocmVmPVwiaHR0cHM6Ly93cml0aW5ndHdpbmFpLmNvbS9wcmljaW5nXCIgdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9vcGVuZXJcIj5VcGdyYWRlIHRvIFBybyBcdTIwMTQgJDUvbW88L2E+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgaWQ9XCJ3dC1hY3Rpb25zXCI+XG4gICAgICAgIDxidXR0b24gY2xhc3M9XCJ3dC1hY3Rpb24gYWNjZXB0XCIgaWQ9XCJ3dC1hY2NlcHRcIj5cdTI3MTMgS2VlcCBpdDwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uIGNsYXNzPVwid3QtYWN0aW9uIHJlamVjdFwiIGlkPVwid3QtcmVqZWN0XCI+XHUyNzE3IFVuZG88L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIGNvbnN0IGJ0biAgICAgICAgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LWJ0bicpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICBjb25zdCBwYW5lbCAgICAgID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC1wYW5lbCcpIGFzIEhUTUxEaXZFbGVtZW50O1xuICBjb25zdCByZXdyaXRlQnRuID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC1yZXdyaXRlJykgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG4gIGNvbnN0IHN0YXR1c0VsICAgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LXN0YXR1cycpIGFzIEhUTUxEaXZFbGVtZW50O1xuICBjb25zdCBsaW1pdEVsICAgID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC1saW1pdCcpIGFzIEhUTUxEaXZFbGVtZW50O1xuICBjb25zdCBhY3Rpb25zRWwgID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC1hY3Rpb25zJykgYXMgSFRNTERpdkVsZW1lbnQ7XG4gIGNvbnN0IGFjY2VwdEJ0biAgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LWFjY2VwdCcpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICBjb25zdCByZWplY3RCdG4gID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC1yZWplY3QnKSBhcyBIVE1MQnV0dG9uRWxlbWVudDtcblxuICBzaGFkb3cucXVlcnlTZWxlY3RvckFsbDxIVE1MQnV0dG9uRWxlbWVudD4oJy53dC10b25lJykuZm9yRWFjaCh0YiA9PiB7XG4gICAgdGIuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgICBzaGFkb3cucXVlcnlTZWxlY3RvckFsbCgnLnd0LXRvbmUnKS5mb3JFYWNoKGIgPT4gYi5jbGFzc0xpc3QucmVtb3ZlKCdhY3RpdmUnKSk7XG4gICAgICB0Yi5jbGFzc0xpc3QuYWRkKCdhY3RpdmUnKTtcbiAgICAgIHRiLnN0eWxlLmJhY2tncm91bmQgPSB0Yi5kYXRhc2V0LmNvbG9yID8/ICcjRkY0NTAwJztcbiAgICAgIHRiLnN0eWxlLmJvcmRlckNvbG9yID0gdGIuZGF0YXNldC5jb2xvciA/PyAnI0ZGNDUwMCc7XG4gICAgICBzZWxlY3RlZFRvbmUgPSB0Yi5kYXRhc2V0LnRvbmUgYXMgVG9uZTtcbiAgICAgIHJld3JpdGVCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgICAgIHN0YXR1c0VsLnRleHRDb250ZW50ID0gJyc7IHN0YXR1c0VsLmNsYXNzTmFtZSA9ICcnO1xuICAgICAgbGltaXRFbC5jbGFzc0xpc3QucmVtb3ZlKCd2aXNpYmxlJyk7XG4gICAgICBhY3Rpb25zRWwuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xuICAgIH0pO1xuICB9KTtcblxuICBidG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgaWYgKHBhbmVsT3Blbikge1xuICAgICAgcGFuZWxPcGVuID0gZmFsc2U7XG4gICAgICBwYW5lbC5jbGFzc0xpc3QucmVtb3ZlKCdvcGVuJyk7XG4gICAgICBjbGVhck9wZW5QYW5lbChob3N0KTtcbiAgICB9IGVsc2Uge1xuICAgICAgcGFuZWxPcGVuID0gdHJ1ZTtcbiAgICAgIHBhbmVsLmNsYXNzTGlzdC5hZGQoJ29wZW4nKTtcbiAgICAgIHBvc2l0aW9uUGFuZWwoKTtcbiAgICAgIG9wZW5QYW5lbEZvcihob3N0LCAoKSA9PiB7IHBhbmVsT3BlbiA9IGZhbHNlOyBwYW5lbC5jbGFzc0xpc3QucmVtb3ZlKCdvcGVuJyk7IH0pO1xuICAgIH1cbiAgfSk7XG5cbiAgZnVuY3Rpb24gcG9zaXRpb25QYW5lbCgpOiB2b2lkIHtcbiAgICBjb25zdCByZWN0ID0gYnRuLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIHBhbmVsLnN0eWxlLmJvdHRvbSA9IGAke3dpbmRvdy5pbm5lckhlaWdodCAtIHJlY3QudG9wICsgNH1weGA7XG4gICAgcGFuZWwuc3R5bGUubGVmdCA9IGAke01hdGgubWluKHJlY3QubGVmdCwgd2luZG93LmlubmVyV2lkdGggLSAyNzYpfXB4YDtcbiAgfVxuXG4gIGxldCBvcmlnaW5hbFRleHQgPSAnJztcblxuICByZXdyaXRlQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICAgIGlmICghc2VsZWN0ZWRUb25lKSByZXR1cm47XG4gICAgY29uc3QgdGV4dCA9IGdldENvbXBvc2VUZXh0KGNvbXBvc2VCb2R5KTtcbiAgICBpZiAoIXRleHQpIHsgc2V0U3RhdHVzKCdXcml0ZSBzb21ldGhpbmcgZmlyc3QuJywgJ2Vycm9yJyk7IHJldHVybjsgfVxuICAgIG9yaWdpbmFsVGV4dCA9IHRleHQ7XG4gICAgYnRuLmRpc2FibGVkID0gdHJ1ZTsgcmV3cml0ZUJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gICAgc2V0U3RhdHVzKCdSZXdyaXRpbmdcdTIwMjYnKTtcbiAgICBhY3Rpb25zRWwuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3AgPSBhd2FpdCBzZW5kVG9CYWNrZ3JvdW5kPHsgcmVzdWx0OiBSZXdyaXRlUmVzcG9uc2UgfSB8IHsgZXJyb3I6IHN0cmluZyB9Pih7XG4gICAgICAgIHR5cGU6ICdIVU1BTklaRScsXG4gICAgICAgIHBheWxvYWQ6IHtcbiAgICAgICAgICB0ZXh0LFxuICAgICAgICAgIHRvbmU6IHNlbGVjdGVkVG9uZSxcbiAgICAgICAgICBjdHg6IHsgcGxhdGZvcm06ICdyZWRkaXQnLCBjb250ZXh0X3R3aW5fb3ZlcnJpZGU6IEZJWEVEX0NPTlRFWFRfT1ZFUlJJREUgfSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgICAgaWYgKCdlcnJvcicgaW4gcmVzcCkgdGhyb3cgbmV3IEVycm9yKFN0cmluZyhyZXNwLmVycm9yKSk7XG4gICAgICBsYXN0UmV3cml0ZUlkID0gcmVzcC5yZXN1bHQuaWQ7XG4gICAgICBzZXRDb21wb3NlVGV4dChjb21wb3NlQm9keSwgcmVzcC5yZXN1bHQub3V0cHV0X3RleHQpO1xuICAgICAgc2V0U3RhdHVzKCdEb25lIFx1MjcxMycsICdzdWNjZXNzJyk7XG4gICAgICBhY3Rpb25zRWwuY2xhc3NMaXN0LmFkZCgndmlzaWJsZScpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc3QgbXNnID0gZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6ICdGYWlsZWQnO1xuICAgICAgaWYgKG1zZy5zdGFydHNXaXRoKCdMSU1JVF9SRUFDSEVEOicpKSB7XG4gICAgICAgIGxpbWl0RWwuY2xhc3NMaXN0LmFkZCgndmlzaWJsZScpOyBzZXRTdGF0dXMoJycpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2V0U3RhdHVzKG1zZywgJ2Vycm9yJyk7XG4gICAgICB9XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIGJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICAgICAgcmV3cml0ZUJ0bi5kaXNhYmxlZCA9IHNlbGVjdGVkVG9uZSA9PT0gbnVsbDtcbiAgICB9XG4gIH0pO1xuXG4gIGFjY2VwdEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBpZiAobGFzdFJld3JpdGVJZCkgc2VuZFRvQmFja2dyb3VuZCh7IHR5cGU6ICdGRUVEQkFDSycsIHBheWxvYWQ6IHsgcmV3cml0ZUlkOiBsYXN0UmV3cml0ZUlkLCBhY3Rpb246ICdhY2NlcHRlZCcgfSB9KTtcbiAgICBhY3Rpb25zRWwuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xuICAgIHBhbmVsT3BlbiA9IGZhbHNlOyBwYW5lbC5jbGFzc0xpc3QucmVtb3ZlKCdvcGVuJyk7XG4gICAgY2xlYXJPcGVuUGFuZWwoaG9zdCk7XG4gICAgc2V0U3RhdHVzKCcnKTtcbiAgfSk7XG5cbiAgcmVqZWN0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgIGlmIChvcmlnaW5hbFRleHQpIHNldENvbXBvc2VUZXh0KGNvbXBvc2VCb2R5LCBvcmlnaW5hbFRleHQpO1xuICAgIGlmIChsYXN0UmV3cml0ZUlkKSBzZW5kVG9CYWNrZ3JvdW5kKHsgdHlwZTogJ0ZFRURCQUNLJywgcGF5bG9hZDogeyByZXdyaXRlSWQ6IGxhc3RSZXdyaXRlSWQsIGFjdGlvbjogJ3JlamVjdGVkJyB9IH0pO1xuICAgIGFjdGlvbnNFbC5jbGFzc0xpc3QucmVtb3ZlKCd2aXNpYmxlJyk7XG4gICAgc2V0U3RhdHVzKCdSZXZlcnRlZC4nLCAnc3VjY2VzcycpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0U3RhdHVzKCcnKSwgMjAwMCk7XG4gIH0pO1xuXG4gIGZ1bmN0aW9uIHNldFN0YXR1cyhtc2c6IHN0cmluZywgY2xzID0gJycpOiB2b2lkIHtcbiAgICBzdGF0dXNFbC50ZXh0Q29udGVudCA9IG1zZzsgc3RhdHVzRWwuY2xhc3NOYW1lID0gY2xzO1xuICB9XG5cbiAgd3JhcHBlci5hcHBlbmRDaGlsZChob3N0KTtcbiAgaW5qZWN0TWljQnV0dG9uKHdyYXBwZXIsIGNvbXBvc2VCb2R5KTtcbn1cblxuLy8gXHUyNTAwXHUyNTAwIE11dGF0aW9uT2JzZXJ2ZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmNvbnN0IHNlZW4gPSBuZXcgV2Vha1NldDxFbGVtZW50PigpO1xuXG5mdW5jdGlvbiB0cnlJbmplY3Qocm9vdDogRWxlbWVudCB8IERvY3VtZW50KTogdm9pZCB7XG4gIHJvb3QucXVlcnlTZWxlY3RvckFsbDxFbGVtZW50PihDT01QT1NFX1NFTCkuZm9yRWFjaCgoYm9keSkgPT4ge1xuICAgIGlmICghc2Vlbi5oYXMoYm9keSkpIHtcbiAgICAgIHNlZW4uYWRkKGJvZHkpO1xuICAgICAgaW5qZWN0KGJvZHkpO1xuICAgIH1cbiAgfSk7XG59XG5cbmNvbnN0IG9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoKCkgPT4ge1xuICByZXF1ZXN0SWRsZUNhbGxiYWNrKCgpID0+IHRyeUluamVjdChkb2N1bWVudCksIHsgdGltZW91dDogNTAwIH0pO1xufSk7XG5vYnNlcnZlci5vYnNlcnZlKGRvY3VtZW50LmJvZHksIHsgY2hpbGRMaXN0OiB0cnVlLCBzdWJ0cmVlOiB0cnVlIH0pO1xudHJ5SW5qZWN0KGRvY3VtZW50KTtcblxuIl0sCiAgIm1hcHBpbmdzIjogIjs7O0FBR0EsTUFBTSxpQkFBaUI7QUFDdkIsTUFBTSxpQkFBaUI7QUFDdkIsTUFBTSxjQUFjLEdBQUcsY0FBYyxLQUFLLGNBQWM7QUFDeEQsTUFBTSxZQUFZO0FBR2xCLE1BQU0seUJBQXlCO0FBRS9CLE1BQU0sUUFBdUQ7QUFBQSxJQUMzRCxFQUFFLEtBQUssVUFBZ0IsT0FBTyxVQUFnQixPQUFPLFVBQVU7QUFBQSxJQUMvRCxFQUFFLEtBQUssZ0JBQWdCLE9BQU8sZ0JBQWdCLE9BQU8sVUFBVTtBQUFBLElBQy9ELEVBQUUsS0FBSyxZQUFnQixPQUFPLFlBQWdCLE9BQU8sVUFBVTtBQUFBLElBQy9ELEVBQUUsS0FBSyxVQUFnQixPQUFPLFVBQWdCLE9BQU8sVUFBVTtBQUFBLElBQy9ELEVBQUUsS0FBSyxhQUFnQixPQUFPLGFBQWdCLE9BQU8sVUFBVTtBQUFBLEVBQ2pFO0FBRUEsTUFBTSxxQkFBZ0U7QUFBQSxJQUNwRSxFQUFFLEtBQUssU0FBVSxPQUFPLFFBQVE7QUFBQSxJQUNoQyxFQUFFLEtBQUssU0FBVSxPQUFPLFVBQVU7QUFBQSxFQUNwQztBQUlBLE1BQU0sYUFBYTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQW9FbkIsTUFBTSxVQUFVO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQTREaEIsTUFBSSxZQUF5RDtBQUU3RCxXQUFTLGlCQUFpQixTQUFTLENBQUMsTUFBTTtBQUN4QyxRQUFJLGFBQWEsQ0FBQyxVQUFVLEtBQUssU0FBUyxFQUFFLE1BQWMsR0FBRztBQUMzRCxnQkFBVSxNQUFNO0FBQ2hCLGtCQUFZO0FBQUEsSUFDZDtBQUFBLEVBQ0YsR0FBRyxJQUFJO0FBRVAsV0FBUyxhQUFhLE1BQWUsT0FBeUI7QUFDNUQsUUFBSSxhQUFhLFVBQVUsU0FBUyxLQUFNLFdBQVUsTUFBTTtBQUMxRCxnQkFBWSxFQUFFLE1BQU0sTUFBTTtBQUFBLEVBQzVCO0FBRUEsV0FBUyxlQUFlLE1BQXFCO0FBQzNDLFFBQUksV0FBVyxTQUFTLEtBQU0sYUFBWTtBQUFBLEVBQzVDO0FBSUEsV0FBUyxpQkFBb0IsU0FBNkI7QUFDeEQsV0FBTyxJQUFJLFFBQVEsQ0FBQyxZQUFZLE9BQU8sUUFBUSxZQUFZLFNBQVMsT0FBTyxDQUFDO0FBQUEsRUFDOUU7QUFFQSxXQUFTLFdBQVcsSUFBd0M7QUFDMUQsV0FBTyxHQUFHLFlBQVk7QUFBQSxFQUN4QjtBQUVBLFdBQVMsZUFBZSxJQUFxQjtBQUMzQyxRQUFJLFdBQVcsRUFBRSxFQUFHLFFBQVEsR0FBMkIsTUFBTSxLQUFLO0FBQ2xFLFdBQVEsR0FBbUIsVUFBVSxLQUFLO0FBQUEsRUFDNUM7QUFFQSxXQUFTLGVBQWUsSUFBYSxNQUFvQjtBQUN2RCxRQUFJLFdBQVcsRUFBRSxHQUFHO0FBQ2xCLFlBQU0sS0FBSztBQUNYLFNBQUcsUUFBUTtBQUNYLFNBQUcsY0FBYyxJQUFJLE1BQU0sU0FBUyxFQUFFLFNBQVMsS0FBSyxDQUFDLENBQUM7QUFDdEQsU0FBRyxjQUFjLElBQUksTUFBTSxVQUFVLEVBQUUsU0FBUyxLQUFLLENBQUMsQ0FBQztBQUFBLElBQ3pELE9BQU87QUFFTCxNQUFDLEdBQW1CLE1BQU07QUFDMUIsZUFBUyxZQUFZLGFBQWEsT0FBTyxNQUFTO0FBQ2xELGVBQVMsWUFBWSxVQUFVLE9BQU8sTUFBUztBQUMvQyxZQUFNLFFBQVEsS0FBSyxNQUFNLElBQUk7QUFDN0IsZUFBUyxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSztBQUNyQyxZQUFJLE1BQU0sQ0FBQyxFQUFHLFVBQVMsWUFBWSxjQUFjLE9BQU8sTUFBTSxDQUFDLENBQUM7QUFDaEUsWUFBSSxJQUFJLE1BQU0sU0FBUyxFQUFHLFVBQVMsWUFBWSxtQkFBbUIsT0FBTyxNQUFTO0FBQUEsTUFDcEY7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUlBLFdBQVMsZ0JBQWdCLFdBQW9CLGFBQTRCO0FBQ3ZFLFVBQU0sVUFBVSxTQUFTLGNBQWMsTUFBTTtBQUM3QyxZQUFRLE1BQU0sVUFBVTtBQUN4QixVQUFNLFNBQVMsUUFBUSxhQUFhLEVBQUUsTUFBTSxPQUFPLENBQUM7QUFFcEQsV0FBTyxZQUFZO0FBQUEsYUFDUixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTVYsbUJBQW1CO0FBQUEsTUFBSSxDQUFDLEdBQUcsTUFDM0IsMEJBQTBCLE1BQU0sSUFBSSxZQUFZLEVBQUUsZ0JBQWdCLEVBQUUsR0FBRyxLQUFLLEVBQUUsS0FBSztBQUFBLElBQ3JGLEVBQUUsS0FBSyxFQUFFLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFXaEIsVUFBTSxTQUFZLE9BQU8sZUFBZSxZQUFZO0FBQ3BELFVBQU0sUUFBWSxPQUFPLGVBQWUsZ0JBQWdCO0FBQ3hELFVBQU0sWUFBWSxPQUFPLGVBQWUsZUFBZTtBQUN2RCxVQUFNLFdBQVksT0FBTyxlQUFlLGlCQUFpQjtBQUN6RCxVQUFNLFlBQVksT0FBTyxlQUFlLGtCQUFrQjtBQUMxRCxVQUFNLFVBQVksT0FBTyxlQUFlLFlBQVk7QUFDcEQsVUFBTSxVQUFZLE9BQU8sZUFBZSxZQUFZO0FBRXBELFFBQUksWUFBWTtBQUNoQixRQUFJLGVBQWdDLG1CQUFtQixDQUFDLEVBQUU7QUFDMUQsUUFBSSxXQUFpQztBQUNyQyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxTQUFxQixDQUFDO0FBQzFCLFFBQUksZ0JBQStCO0FBQ25DLFFBQUksZUFBZTtBQUVuQixXQUFPLGlCQUFvQyxXQUFXLEVBQUUsUUFBUSxTQUFPO0FBQ3JFLFVBQUksaUJBQWlCLFNBQVMsTUFBTTtBQUNsQyxlQUFPLGlCQUFpQixXQUFXLEVBQUUsUUFBUSxPQUFLLEVBQUUsVUFBVSxPQUFPLFFBQVEsQ0FBQztBQUM5RSxZQUFJLFVBQVUsSUFBSSxRQUFRO0FBQzFCLHVCQUFlLElBQUksUUFBUTtBQUFBLE1BQzdCLENBQUM7QUFBQSxJQUNILENBQUM7QUFFRCxXQUFPLGlCQUFpQixTQUFTLE1BQU07QUFDckMsVUFBSSxXQUFXO0FBQ2Isb0JBQVk7QUFDWixjQUFNLFVBQVUsT0FBTyxNQUFNO0FBQzdCLHVCQUFlLE9BQU87QUFBQSxNQUN4QixPQUFPO0FBQ0wsb0JBQVk7QUFDWixjQUFNLFVBQVUsSUFBSSxNQUFNO0FBQzFCLHNCQUFjO0FBQ2QscUJBQWEsU0FBUyxNQUFNO0FBQUUsc0JBQVk7QUFBTyxnQkFBTSxVQUFVLE9BQU8sTUFBTTtBQUFBLFFBQUcsQ0FBQztBQUFBLE1BQ3BGO0FBQUEsSUFDRixDQUFDO0FBRUQsYUFBUyxnQkFBc0I7QUFDN0IsWUFBTSxPQUFPLE9BQU8sc0JBQXNCO0FBQzFDLFlBQU0sTUFBTSxTQUFTLEdBQUcsT0FBTyxjQUFjLEtBQUssTUFBTSxDQUFDO0FBQ3pELFlBQU0sTUFBTSxPQUFPLEdBQUcsS0FBSyxJQUFJLEtBQUssTUFBTSxPQUFPLGFBQWEsR0FBRyxDQUFDO0FBQUEsSUFDcEU7QUFFQSxjQUFVLGlCQUFpQixTQUFTLFlBQVk7QUFDOUMsVUFBSSxDQUFDLFVBQVcsT0FBTSxlQUFlO0FBQUEsVUFBUSxlQUFjO0FBQUEsSUFDN0QsQ0FBQztBQUVELG1CQUFlLGlCQUFnQztBQUM3QyxVQUFJO0FBQ0YsY0FBTSxTQUFTLE1BQU0sVUFBVSxhQUFhLGFBQWEsRUFBRSxPQUFPLEtBQUssQ0FBQztBQUN4RSxpQkFBUyxDQUFDO0FBQ1YsbUJBQVcsSUFBSSxjQUFjLFFBQVEsRUFBRSxVQUFVLGFBQWEsQ0FBQztBQUMvRCxpQkFBUyxrQkFBa0IsQ0FBQyxNQUFNO0FBQUUsY0FBSSxFQUFFLEtBQUssT0FBTyxFQUFHLFFBQU8sS0FBSyxFQUFFLElBQUk7QUFBQSxRQUFHO0FBQzlFLGlCQUFTLFNBQVMsWUFBWTtBQUM1QixpQkFBTyxVQUFVLEVBQUUsUUFBUSxPQUFLLEVBQUUsS0FBSyxDQUFDO0FBQ3hDLGdCQUFNLFlBQVksSUFBSSxLQUFLLFFBQVEsRUFBRSxNQUFNLGFBQWEsQ0FBQyxDQUFDO0FBQUEsUUFDNUQ7QUFDQSxpQkFBUyxNQUFNO0FBQ2Ysb0JBQVk7QUFDWixlQUFPLFVBQVUsSUFBSSxXQUFXO0FBQ2hDLGtCQUFVLFVBQVUsSUFBSSxXQUFXO0FBQ25DLGtCQUFVLGNBQWM7QUFDeEIsbUJBQVcsaUJBQVk7QUFDdkIsa0JBQVUsVUFBVSxPQUFPLFNBQVM7QUFDcEMsbUJBQVcsTUFBTTtBQUFFLGNBQUksVUFBVyxlQUFjO0FBQUEsUUFBRyxHQUFHLEdBQU07QUFBQSxNQUM5RCxRQUFRO0FBQ04sbUJBQVcsNkJBQTZCLE9BQU87QUFBQSxNQUNqRDtBQUFBLElBQ0Y7QUFFQSxhQUFTLGdCQUFzQjtBQUM3QixVQUFJLFlBQVksV0FBVztBQUN6QixpQkFBUyxLQUFLO0FBQUcsb0JBQVk7QUFDN0IsZUFBTyxVQUFVLE9BQU8sV0FBVztBQUNuQyxrQkFBVSxVQUFVLE9BQU8sV0FBVztBQUN0QyxrQkFBVSxjQUFjO0FBQ3hCLGtCQUFVLFdBQVc7QUFDckIsbUJBQVcsZ0JBQVc7QUFBQSxNQUN4QjtBQUFBLElBQ0Y7QUFFQSxtQkFBZSxZQUFZLE1BQTJCO0FBQ3BELFVBQUk7QUFDRixjQUFNLE1BQU0sTUFBTSxLQUFLLFlBQVk7QUFDbkMsY0FBTSxZQUFZLEtBQUssTUFBTSxLQUFLLElBQUksV0FBVyxHQUFHLEdBQUcsT0FBSyxPQUFPLGFBQWEsQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUM7QUFDNUYsdUJBQWUsZUFBZSxXQUFXO0FBQ3pDLGNBQU0sT0FBTyxNQUFNLGlCQUFxRTtBQUFBLFVBQ3RGLE1BQU07QUFBQSxVQUNOLFNBQVMsRUFBRSxXQUFXLFVBQVUsY0FBYyxZQUFZLGFBQWE7QUFBQSxRQUN6RSxDQUFDO0FBQ0QsWUFBSSxXQUFXLEtBQU0sT0FBTSxJQUFJLE1BQU0sT0FBTyxLQUFLLEtBQUssQ0FBQztBQUN2RCx3QkFBZ0IsS0FBSyxPQUFPO0FBQzVCLHVCQUFlLGFBQWEsS0FBSyxPQUFPLEtBQUs7QUFDN0MsbUJBQVcsYUFBUTtBQUNuQixrQkFBVSxVQUFVLElBQUksU0FBUztBQUFBLE1BQ25DLFNBQVMsS0FBSztBQUNaLG1CQUFXLGVBQWUsUUFBUSxJQUFJLFVBQVUsVUFBVSxPQUFPO0FBQUEsTUFDbkUsVUFBRTtBQUNBLGtCQUFVLFdBQVc7QUFBQSxNQUN2QjtBQUFBLElBQ0Y7QUFFQSxZQUFRLGlCQUFpQixTQUFTLE1BQU07QUFDdEMsVUFBSSxjQUFlLGtCQUFpQixFQUFFLE1BQU0sa0JBQWtCLFNBQVMsRUFBRSxXQUFXLGVBQWUsVUFBVSxNQUFNLGFBQWEsS0FBSyxFQUFFLENBQUM7QUFDeEksZ0JBQVUsVUFBVSxPQUFPLFNBQVM7QUFDcEMsa0JBQVk7QUFBTyxZQUFNLFVBQVUsT0FBTyxNQUFNO0FBQ2hELHFCQUFlLE9BQU87QUFDdEIsaUJBQVcsRUFBRTtBQUFBLElBQ2YsQ0FBQztBQUVELFlBQVEsaUJBQWlCLFNBQVMsTUFBTTtBQUN0QyxVQUFJLGFBQWMsZ0JBQWUsYUFBYSxZQUFZO0FBQzFELFVBQUksY0FBZSxrQkFBaUIsRUFBRSxNQUFNLGtCQUFrQixTQUFTLEVBQUUsV0FBVyxlQUFlLFVBQVUsT0FBTyxhQUFhLEtBQUssRUFBRSxDQUFDO0FBQ3pJLGdCQUFVLFVBQVUsT0FBTyxTQUFTO0FBQ3BDLGlCQUFXLGFBQWEsU0FBUztBQUNqQyxpQkFBVyxNQUFNLFdBQVcsRUFBRSxHQUFHLEdBQUk7QUFBQSxJQUN2QyxDQUFDO0FBRUQsYUFBUyxXQUFXLEtBQWEsTUFBTSxJQUFVO0FBQy9DLGVBQVMsY0FBYztBQUFLLGVBQVMsWUFBWTtBQUFBLElBQ25EO0FBRUEsY0FBVSxZQUFZLE9BQU87QUFBQSxFQUMvQjtBQUlBLFdBQVMsT0FBTyxhQUE0QjtBQUMxQyxRQUFJLFlBQVksYUFBYSxTQUFTLEVBQUc7QUFDekMsZ0JBQVksYUFBYSxXQUFXLEdBQUc7QUFHdkMsVUFBTSxVQUFVLFNBQVMsY0FBYyxLQUFLO0FBQzVDLFlBQVEsTUFBTSxVQUFVO0FBRXhCLFVBQU0saUJBQWlCLFdBQVcsV0FBVyxJQUN4QyxZQUFZLFFBQVEscUNBQXFDLEtBQUssWUFBWSxnQkFDMUUsWUFBWSxRQUFRLHlEQUF5RCxLQUFLLFlBQVk7QUFDbkcsb0JBQWdCLHNCQUFzQixZQUFZLE9BQU87QUFDekQsUUFBSSxDQUFDLFFBQVEsZUFBZTtBQUMxQixrQkFBWSxlQUFlLFlBQVksT0FBTztBQUFBLElBQ2hEO0FBRUEsVUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLFVBQU0sU0FBUyxLQUFLLGFBQWEsRUFBRSxNQUFNLE9BQU8sQ0FBQztBQUVqRCxRQUFJLGVBQTRCO0FBQ2hDLFFBQUksZ0JBQStCO0FBQ25DLFFBQUksWUFBWTtBQUVoQixXQUFPLFlBQVk7QUFBQSxhQUNSLFVBQVU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS2IsTUFBTSxJQUFJLE9BQUssc0NBQXNDLEVBQUUsR0FBRyxpQkFBaUIsRUFBRSxLQUFLLEtBQUssRUFBRSxLQUFLLFdBQVcsRUFBRSxLQUFLLEVBQUUsQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBZTNILFVBQU0sTUFBYSxPQUFPLGVBQWUsUUFBUTtBQUNqRCxVQUFNLFFBQWEsT0FBTyxlQUFlLFVBQVU7QUFDbkQsVUFBTSxhQUFhLE9BQU8sZUFBZSxZQUFZO0FBQ3JELFVBQU0sV0FBYSxPQUFPLGVBQWUsV0FBVztBQUNwRCxVQUFNLFVBQWEsT0FBTyxlQUFlLFVBQVU7QUFDbkQsVUFBTSxZQUFhLE9BQU8sZUFBZSxZQUFZO0FBQ3JELFVBQU0sWUFBYSxPQUFPLGVBQWUsV0FBVztBQUNwRCxVQUFNLFlBQWEsT0FBTyxlQUFlLFdBQVc7QUFFcEQsV0FBTyxpQkFBb0MsVUFBVSxFQUFFLFFBQVEsUUFBTTtBQUNuRSxTQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDakMsZUFBTyxpQkFBaUIsVUFBVSxFQUFFLFFBQVEsT0FBSyxFQUFFLFVBQVUsT0FBTyxRQUFRLENBQUM7QUFDN0UsV0FBRyxVQUFVLElBQUksUUFBUTtBQUN6QixXQUFHLE1BQU0sYUFBYSxHQUFHLFFBQVEsU0FBUztBQUMxQyxXQUFHLE1BQU0sY0FBYyxHQUFHLFFBQVEsU0FBUztBQUMzQyx1QkFBZSxHQUFHLFFBQVE7QUFDMUIsbUJBQVcsV0FBVztBQUN0QixpQkFBUyxjQUFjO0FBQUksaUJBQVMsWUFBWTtBQUNoRCxnQkFBUSxVQUFVLE9BQU8sU0FBUztBQUNsQyxrQkFBVSxVQUFVLE9BQU8sU0FBUztBQUFBLE1BQ3RDLENBQUM7QUFBQSxJQUNILENBQUM7QUFFRCxRQUFJLGlCQUFpQixTQUFTLE1BQU07QUFDbEMsVUFBSSxXQUFXO0FBQ2Isb0JBQVk7QUFDWixjQUFNLFVBQVUsT0FBTyxNQUFNO0FBQzdCLHVCQUFlLElBQUk7QUFBQSxNQUNyQixPQUFPO0FBQ0wsb0JBQVk7QUFDWixjQUFNLFVBQVUsSUFBSSxNQUFNO0FBQzFCLHNCQUFjO0FBQ2QscUJBQWEsTUFBTSxNQUFNO0FBQUUsc0JBQVk7QUFBTyxnQkFBTSxVQUFVLE9BQU8sTUFBTTtBQUFBLFFBQUcsQ0FBQztBQUFBLE1BQ2pGO0FBQUEsSUFDRixDQUFDO0FBRUQsYUFBUyxnQkFBc0I7QUFDN0IsWUFBTSxPQUFPLElBQUksc0JBQXNCO0FBQ3ZDLFlBQU0sTUFBTSxTQUFTLEdBQUcsT0FBTyxjQUFjLEtBQUssTUFBTSxDQUFDO0FBQ3pELFlBQU0sTUFBTSxPQUFPLEdBQUcsS0FBSyxJQUFJLEtBQUssTUFBTSxPQUFPLGFBQWEsR0FBRyxDQUFDO0FBQUEsSUFDcEU7QUFFQSxRQUFJLGVBQWU7QUFFbkIsZUFBVyxpQkFBaUIsU0FBUyxZQUFZO0FBQy9DLFVBQUksQ0FBQyxhQUFjO0FBQ25CLFlBQU0sT0FBTyxlQUFlLFdBQVc7QUFDdkMsVUFBSSxDQUFDLE1BQU07QUFBRSxrQkFBVSwwQkFBMEIsT0FBTztBQUFHO0FBQUEsTUFBUTtBQUNuRSxxQkFBZTtBQUNmLFVBQUksV0FBVztBQUFNLGlCQUFXLFdBQVc7QUFDM0MsZ0JBQVUsaUJBQVk7QUFDdEIsZ0JBQVUsVUFBVSxPQUFPLFNBQVM7QUFFcEMsVUFBSTtBQUNGLGNBQU0sT0FBTyxNQUFNLGlCQUFrRTtBQUFBLFVBQ25GLE1BQU07QUFBQSxVQUNOLFNBQVM7QUFBQSxZQUNQO0FBQUEsWUFDQSxNQUFNO0FBQUEsWUFDTixLQUFLLEVBQUUsVUFBVSxVQUFVLHVCQUF1Qix1QkFBdUI7QUFBQSxVQUMzRTtBQUFBLFFBQ0YsQ0FBQztBQUNELFlBQUksV0FBVyxLQUFNLE9BQU0sSUFBSSxNQUFNLE9BQU8sS0FBSyxLQUFLLENBQUM7QUFDdkQsd0JBQWdCLEtBQUssT0FBTztBQUM1Qix1QkFBZSxhQUFhLEtBQUssT0FBTyxXQUFXO0FBQ25ELGtCQUFVLGVBQVUsU0FBUztBQUM3QixrQkFBVSxVQUFVLElBQUksU0FBUztBQUFBLE1BQ25DLFNBQVMsS0FBSztBQUNaLGNBQU0sTUFBTSxlQUFlLFFBQVEsSUFBSSxVQUFVO0FBQ2pELFlBQUksSUFBSSxXQUFXLGdCQUFnQixHQUFHO0FBQ3BDLGtCQUFRLFVBQVUsSUFBSSxTQUFTO0FBQUcsb0JBQVUsRUFBRTtBQUFBLFFBQ2hELE9BQU87QUFDTCxvQkFBVSxLQUFLLE9BQU87QUFBQSxRQUN4QjtBQUFBLE1BQ0YsVUFBRTtBQUNBLFlBQUksV0FBVztBQUNmLG1CQUFXLFdBQVcsaUJBQWlCO0FBQUEsTUFDekM7QUFBQSxJQUNGLENBQUM7QUFFRCxjQUFVLGlCQUFpQixTQUFTLE1BQU07QUFDeEMsVUFBSSxjQUFlLGtCQUFpQixFQUFFLE1BQU0sWUFBWSxTQUFTLEVBQUUsV0FBVyxlQUFlLFFBQVEsV0FBVyxFQUFFLENBQUM7QUFDbkgsZ0JBQVUsVUFBVSxPQUFPLFNBQVM7QUFDcEMsa0JBQVk7QUFBTyxZQUFNLFVBQVUsT0FBTyxNQUFNO0FBQ2hELHFCQUFlLElBQUk7QUFDbkIsZ0JBQVUsRUFBRTtBQUFBLElBQ2QsQ0FBQztBQUVELGNBQVUsaUJBQWlCLFNBQVMsTUFBTTtBQUN4QyxVQUFJLGFBQWMsZ0JBQWUsYUFBYSxZQUFZO0FBQzFELFVBQUksY0FBZSxrQkFBaUIsRUFBRSxNQUFNLFlBQVksU0FBUyxFQUFFLFdBQVcsZUFBZSxRQUFRLFdBQVcsRUFBRSxDQUFDO0FBQ25ILGdCQUFVLFVBQVUsT0FBTyxTQUFTO0FBQ3BDLGdCQUFVLGFBQWEsU0FBUztBQUNoQyxpQkFBVyxNQUFNLFVBQVUsRUFBRSxHQUFHLEdBQUk7QUFBQSxJQUN0QyxDQUFDO0FBRUQsYUFBUyxVQUFVLEtBQWEsTUFBTSxJQUFVO0FBQzlDLGVBQVMsY0FBYztBQUFLLGVBQVMsWUFBWTtBQUFBLElBQ25EO0FBRUEsWUFBUSxZQUFZLElBQUk7QUFDeEIsb0JBQWdCLFNBQVMsV0FBVztBQUFBLEVBQ3RDO0FBSUEsTUFBTSxPQUFPLG9CQUFJLFFBQWlCO0FBRWxDLFdBQVMsVUFBVSxNQUFnQztBQUNqRCxTQUFLLGlCQUEwQixXQUFXLEVBQUUsUUFBUSxDQUFDLFNBQVM7QUFDNUQsVUFBSSxDQUFDLEtBQUssSUFBSSxJQUFJLEdBQUc7QUFDbkIsYUFBSyxJQUFJLElBQUk7QUFDYixlQUFPLElBQUk7QUFBQSxNQUNiO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUVBLE1BQU0sV0FBVyxJQUFJLGlCQUFpQixNQUFNO0FBQzFDLHdCQUFvQixNQUFNLFVBQVUsUUFBUSxHQUFHLEVBQUUsU0FBUyxJQUFJLENBQUM7QUFBQSxFQUNqRSxDQUFDO0FBQ0QsV0FBUyxRQUFRLFNBQVMsTUFBTSxFQUFFLFdBQVcsTUFBTSxTQUFTLEtBQUssQ0FBQztBQUNsRSxZQUFVLFFBQVE7IiwKICAibmFtZXMiOiBbXQp9Cg==
