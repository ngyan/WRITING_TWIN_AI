"use strict";(()=>{var j='textarea[name="text"], textarea.usertext-edit textarea',z='div[contenteditable="true"][data-testid], div.DraftEditor-editorContainer [contenteditable="true"], .editor-container [contenteditable="true"]',S="data-wt-rd-injected",$="community";var U=[{key:"casual",label:"Casual",color:"#FF4500"},{key:"professional",label:"Professional",color:"#0A66C2"},{key:"friendly",label:"Friendly",color:"#F59E0B"},{key:"direct",label:"Direct",color:"#DC2626"},{key:"executive",label:"Executive",color:"#0F172A"}],A=[{key:"reply",label:"Reply"},{key:"email",label:"Message"}],V=`
  :host { display: inline-flex; align-items: center; }

  #wt-btn {
    display: inline-flex; align-items: center; gap: 5px;
    height: 28px; padding: 0 12px; border-radius: 9999px; border: none;
    background: #FF4500; color: #fff;
    font: 500 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer; white-space: nowrap;
    transition: background 0.15s, box-shadow 0.15s;
  }
  #wt-btn:hover { background: #cc3700; box-shadow: 0 0 0 3px rgba(255,69,0,0.25); }
  #wt-btn:disabled { opacity: 0.6; cursor: default; box-shadow: none; }

  #wt-panel {
    position: fixed; z-index: 99999;
    background: #fff; border: 1px solid #E2E8F0; border-radius: 10px;
    box-shadow: 0 12px 32px rgba(0,0,0,0.14);
    padding: 14px 16px; width: 260px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: none;
  }
  #wt-panel.open { display: block; }

  .wt-title { font-size: 12px; font-weight: 600; color: #374151; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase; }
  .wt-tones { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 12px; }
  .wt-tone {
    padding: 4px 10px; border-radius: 9999px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151;
    cursor: pointer; transition: all 0.1s;
  }
  .wt-tone.active { color: #fff; border-color: transparent; }
  .wt-tone:hover:not(.active) { border-color: #FCA5A5; }

  #wt-rewrite {
    width: 100%; height: 32px; border-radius: 8px; border: none;
    background: #FF4500; color: #fff;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer;
  }
  #wt-rewrite:disabled { opacity: 0.45; cursor: default; }

  #wt-status { margin-top: 8px; font-size: 11px; text-align: center; min-height: 14px; }
  #wt-status.error { color: #EF4444; }
  #wt-status.success { color: #10B981; }

  #wt-actions { display: none; gap: 6px; margin-top: 8px; }
  #wt-actions.visible { display: flex; }
  .wt-action {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151;
    cursor: pointer;
  }
  .wt-action.accept { border-color: #10B981; color: #10B981; }
  .wt-action.reject { border-color: #EF4444; color: #EF4444; }

  #wt-limit { display: none; margin-top: 10px; padding: 10px 12px; border-radius: 8px;
    background: #FFF8F1; border: 1px solid #FED7AA; text-align: center; }
  #wt-limit.visible { display: block; }
  #wt-limit p { font-size: 11px; color: #92400E; margin: 0 0 8px; line-height: 1.4; }
  #wt-limit a {
    display: inline-block; padding: 5px 14px; border-radius: 9999px;
    background: #F59E0B; color: #fff; font-size: 11px; font-weight: 600;
    text-decoration: none;
  }
`,P=`
  :host { display: inline-flex; align-items: center; margin-left: 4px; }

  #wt-mic-btn {
    display: inline-flex; align-items: center; justify-content: center;
    width: 28px; height: 28px; border-radius: 9999px; border: none;
    background: transparent; color: #666; cursor: pointer;
    transition: background 0.15s, color 0.15s; font-size: 15px; line-height: 1;
  }
  #wt-mic-btn:hover { background: rgba(0,0,0,0.07); }
  #wt-mic-btn.recording { background: #FEE2E2; color: #DC2626;
    animation: wt-pulse 1.2s ease-in-out infinite; }
  @keyframes wt-pulse {
    0%, 100% { box-shadow: 0 0 0 0 rgba(220,38,38,0.4); }
    50%       { box-shadow: 0 0 0 5px rgba(220,38,38,0); }
  }
  #wt-mic-btn:disabled { opacity: 0.5; cursor: default; }

  #wt-voice-panel {
    position: fixed; z-index: 99999;
    background: #fff; border: 1px solid #E2E8F0; border-radius: 10px;
    box-shadow: 0 12px 32px rgba(0,0,0,0.14);
    padding: 14px 16px; width: 280px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: none;
  }
  #wt-voice-panel.open { display: block; }

  .wt-vt { font-size: 12px; font-weight: 600; color: #374151; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase; }
  #wt-record-btn {
    width: 100%; height: 34px; border-radius: 8px; border: none;
    background: #DC2626; color: #fff; cursor: pointer;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    margin-bottom: 10px;
  }
  #wt-record-btn.recording { background: #7F1D1D; }
  #wt-record-btn:disabled { opacity: 0.5; cursor: default; }
  .wt-otype-label { font-size: 11px; color: #6B7280; margin-bottom: 4px; }
  .wt-otypes { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 10px; }
  .wt-otype {
    padding: 3px 9px; border-radius: 9999px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 11px; color: #374151; cursor: pointer;
    transition: all 0.1s;
  }
  .wt-otype.active { background: #FF4500; color: #fff; border-color: #FF4500; }
  #wt-voice-status { font-size: 11px; text-align: center; min-height: 14px; color: #6B7280; }
  #wt-voice-status.error { color: #EF4444; }
  #wt-voice-actions { display: none; gap: 6px; margin-top: 8px; }
  #wt-voice-actions.visible { display: flex; }
  .wt-va {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151; cursor: pointer;
  }
  .wt-va.accept { border-color: #10B981; color: #10B981; }
  .wt-va.reject { border-color: #EF4444; color: #EF4444; }
`;function h(e){return new Promise(r=>chrome.runtime.sendMessage(e,r))}function M(e){return e.tagName==="TEXTAREA"}function H(e){return M(e)?e.value.trim():e.innerText.trim()}function B(e,r){if(M(e)){let o=e;o.value=r,o.dispatchEvent(new Event("input",{bubbles:!0})),o.dispatchEvent(new Event("change",{bubbles:!0}))}else{e.focus(),document.execCommand("selectAll",!1,void 0),document.execCommand("delete",!1,void 0);let o=r.split(`
`);for(let n=0;n<o.length;n++)o[n]&&document.execCommand("insertText",!1,o[n]),n<o.length-1&&document.execCommand("insertParagraph",!1,void 0)}}function N(e,r){let o=document.createElement("span");o.style.cssText="display:inline-flex;align-items:center;margin-left:4px;";let n=o.attachShadow({mode:"open"});n.innerHTML=`
    <style>${P}</style>
    <button id="wt-mic-btn" title="Voice Twin">\u{1F399}</button>
    <div id="wt-voice-panel">
      <p class="wt-vt">Voice Twin</p>
      <div class="wt-otype-label">Output type</div>
      <div class="wt-otypes">
        ${A.map((i,a)=>`<button class="wt-otype${a===0?" active":""}" data-type="${i.key}">${i.label}</button>`).join("")}
      </div>
      <button id="wt-record-btn">\u{1F399} Start recording</button>
      <div id="wt-voice-status"></div>
      <div id="wt-voice-actions">
        <button class="wt-va accept" id="wt-va-keep">\u2713 Keep it</button>
        <button class="wt-va reject" id="wt-va-undo">\u2717 Undo</button>
      </div>
    </div>
  `;let s=n.getElementById("wt-mic-btn"),u=n.getElementById("wt-voice-panel"),c=n.getElementById("wt-record-btn"),m=n.getElementById("wt-voice-status"),b=n.getElementById("wt-voice-actions"),g=n.getElementById("wt-va-keep"),y=n.getElementById("wt-va-undo"),d=!1,T=A[0].key,p=null,x=!1,L=[],E=null,v="";n.querySelectorAll(".wt-otype").forEach(i=>{i.addEventListener("click",()=>{n.querySelectorAll(".wt-otype").forEach(a=>a.classList.remove("active")),i.classList.add("active"),T=i.dataset.type})}),s.addEventListener("click",()=>{d=!d,u.classList.toggle("open",d),d&&f()}),document.addEventListener("click",i=>{!o.contains(i.target)&&d&&(d=!1,u.classList.remove("open"))},!0);function f(){let i=s.getBoundingClientRect();u.style.bottom=`${window.innerHeight-i.top+4}px`,u.style.left=`${Math.min(i.left,window.innerWidth-296)}px`}c.addEventListener("click",async()=>{x?l():await t()});async function t(){try{let i=await navigator.mediaDevices.getUserMedia({audio:!0});L=[],p=new MediaRecorder(i,{mimeType:"audio/webm"}),p.ondataavailable=a=>{a.data.size>0&&L.push(a.data)},p.onstop=async()=>{i.getTracks().forEach(a=>a.stop()),await k(new Blob(L,{type:"audio/webm"}))},p.start(),x=!0,s.classList.add("recording"),c.classList.add("recording"),c.textContent="\u23F9 Stop recording",w("Recording\u2026"),b.classList.remove("visible"),setTimeout(()=>{x&&l()},6e4)}catch{w("Microphone access denied.","error")}}function l(){p&&x&&(p.stop(),x=!1,s.classList.remove("recording"),c.classList.remove("recording"),c.textContent="\u{1F399} Start recording",c.disabled=!0,w("Drafting\u2026"))}async function k(i){try{let a=await i.arrayBuffer(),I=new Uint8Array(a),C="";for(let D=0;D<I.length;D++)C+=String.fromCharCode(I[D]);let O=btoa(C);v=H(r);let F=await h({type:"VOICE_DRAFT",payload:{audioData:O,mimeType:"audio/webm",outputType:T}});if("error"in F)throw new Error(String(F.error));E=F.result.id,B(r,F.result.draft),w("Done \u2713"),b.classList.add("visible")}catch(a){w(a instanceof Error?a.message:"Failed","error")}finally{c.disabled=!1}}g.addEventListener("click",()=>{E&&h({type:"VOICE_FEEDBACK",payload:{sessionId:E,accepted:!0,editedDraft:null}}),b.classList.remove("visible"),d=!1,u.classList.remove("open"),w("")}),y.addEventListener("click",()=>{v&&B(r,v),E&&h({type:"VOICE_FEEDBACK",payload:{sessionId:E,accepted:!1,editedDraft:null}}),b.classList.remove("visible"),w("Reverted.","success"),setTimeout(()=>w(""),2e3)});function w(i,a=""){m.textContent=i,m.className=a}e.appendChild(o)}function W(e){if(e.hasAttribute(S))return;e.setAttribute(S,"1");let r=document.createElement("div");r.style.cssText="display:flex;align-items:center;gap:4px;margin-top:6px;padding:0 2px;",(M(e)?e.closest("form, .usertext-edit, .md-container")??e.parentElement:e.closest('.DraftEditor-root, .editor-container, [class*="Editor"]')??e.parentElement)?.insertAdjacentElement("afterend",r),r.parentElement||e.parentElement?.appendChild(r);let n=document.createElement("span"),s=n.attachShadow({mode:"open"}),u=null,c=null,m=!1;s.innerHTML=`
    <style>${V}</style>
    <button id="wt-btn" title="Humanize with Writing Twin AI">\u2728 Humanize</button>
    <div id="wt-panel">
      <p class="wt-title">Rewrite tone</p>
      <div class="wt-tones">
        ${U.map(t=>`<button class="wt-tone" data-tone="${t.key}" data-color="${t.color}">${t.label}</button>`).join("")}
      </div>
      <button id="wt-rewrite" disabled>Rewrite \u2192</button>
      <div id="wt-status"></div>
      <div id="wt-limit">
        <p>You've used all your free rewrites this month.</p>
        <a href="https://writingtwinai.com/pricing" target="_blank" rel="noopener">Upgrade to Pro \u2014 $5/mo</a>
      </div>
      <div id="wt-actions">
        <button class="wt-action accept" id="wt-accept">\u2713 Keep it</button>
        <button class="wt-action reject" id="wt-reject">\u2717 Undo</button>
      </div>
    </div>
  `;let b=s.getElementById("wt-btn"),g=s.getElementById("wt-panel"),y=s.getElementById("wt-rewrite"),d=s.getElementById("wt-status"),T=s.getElementById("wt-limit"),p=s.getElementById("wt-actions"),x=s.getElementById("wt-accept"),L=s.getElementById("wt-reject");s.querySelectorAll(".wt-tone").forEach(t=>{t.addEventListener("click",()=>{s.querySelectorAll(".wt-tone").forEach(l=>l.classList.remove("active")),t.classList.add("active"),t.style.background=t.dataset.color??"#FF4500",t.style.borderColor=t.dataset.color??"#FF4500",u=t.dataset.tone,y.disabled=!1,d.textContent="",d.className="",T.classList.remove("visible"),p.classList.remove("visible")})}),b.addEventListener("click",()=>{m=!m,g.classList.toggle("open",m),m&&E()}),document.addEventListener("click",t=>{!n.contains(t.target)&&m&&(m=!1,g.classList.remove("open"))},!0);function E(){let t=b.getBoundingClientRect();g.style.bottom=`${window.innerHeight-t.top+4}px`,g.style.left=`${Math.min(t.left,window.innerWidth-276)}px`}let v="";y.addEventListener("click",async()=>{if(!u)return;let t=H(e);if(!t){f("Write something first.","error");return}v=t,b.disabled=!0,y.disabled=!0,f("Rewriting\u2026"),p.classList.remove("visible");try{let l=await h({type:"HUMANIZE",payload:{text:t,tone:u,ctx:{platform:"reddit",context_twin_override:$}}});if("error"in l)throw new Error(String(l.error));c=l.result.id,B(e,l.result.output_text),f("Done \u2713","success"),p.classList.add("visible")}catch(l){let k=l instanceof Error?l.message:"Failed";k.startsWith("LIMIT_REACHED:")?(T.classList.add("visible"),f("")):f(k,"error")}finally{b.disabled=!1,y.disabled=u===null}}),x.addEventListener("click",()=>{c&&h({type:"FEEDBACK",payload:{rewriteId:c,action:"accepted"}}),p.classList.remove("visible"),m=!1,g.classList.remove("open"),f("")}),L.addEventListener("click",()=>{v&&B(e,v),c&&h({type:"FEEDBACK",payload:{rewriteId:c,action:"rejected"}}),p.classList.remove("visible"),f("Reverted.","success"),setTimeout(()=>f(""),2e3)});function f(t,l=""){d.textContent=t,d.className=l}r.appendChild(n),N(r,e)}var R=new WeakSet;function _(e){let r=`${j}, ${z}`;e.querySelectorAll(r).forEach(o=>{R.has(o)||(R.add(o),W(o))})}var K=new MutationObserver(()=>_(document));K.observe(document.body,{childList:!0,subtree:!0});_(document);})();
