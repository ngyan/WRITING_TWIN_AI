"use strict";(()=>{var z='[g_editable="true"], div[contenteditable="true"][aria-multiline="true"]',H='[data-tooltip^="Send"], [aria-label^="Send"]',S="data-wt-injected";var j="professional",$=[{key:"professional",label:"Professional",color:"#4F46E5"},{key:"casual",label:"Casual",color:"#06B6D4"},{key:"friendly",label:"Friendly",color:"#F59E0B"},{key:"direct",label:"Direct",color:"#DC2626"},{key:"diplomatic",label:"Diplomatic",color:"#7C3AED"},{key:"executive",label:"Executive",color:"#0F172A"}],V=`
  :host { display: inline-flex; align-items: center; margin-left: 8px; }

  #wt-btn {
    display: inline-flex; align-items: center; gap: 5px;
    height: 28px; padding: 0 12px; border-radius: 9999px; border: none;
    background: #4F46E5; color: #fff;
    font: 500 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer; white-space: nowrap;
    transition: background 0.15s, box-shadow 0.15s;
  }
  #wt-btn:hover { background: #3F37C9; box-shadow: 0 0 0 3px rgba(79,70,229,0.25); }
  #wt-btn:disabled { opacity: 0.6; cursor: default; box-shadow: none; }

  #wt-panel {
    position: fixed; z-index: 9999;
    background: #fff; border: 1px solid #E8EAED; border-radius: 10px;
    box-shadow: 0 12px 32px rgba(15,23,42,0.14);
    padding: 14px 16px; width: 260px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: none;
  }
  #wt-panel.open { display: block; }

  .wt-title {
    font-size: 12px; font-weight: 600; color: #374151; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase;
  }
  .wt-tones {
    display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 12px;
  }
  .wt-tone {
    padding: 4px 10px; border-radius: 9999px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151;
    cursor: pointer; transition: all 0.1s;
  }
  .wt-tone.active {
    color: #fff; border-color: transparent;
  }
  .wt-tone:hover:not(.active) { border-color: #9BA0FF; }

  #wt-rewrite {
    width: 100%; height: 32px; border-radius: 8px; border: none;
    background: #4F46E5; color: #fff;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer;
  }
  #wt-rewrite:disabled { opacity: 0.45; cursor: default; }

  #wt-status {
    margin-top: 8px; font-size: 11px; text-align: center; min-height: 14px;
  }
  #wt-status.error { color: #EF4444; }
  #wt-status.success { color: #10B981; }

  #wt-limit {
    display: none; margin-top: 10px; padding: 10px 12px; border-radius: 8px;
    background: #FFF8F1; border: 1px solid #FED7AA; text-align: center;
  }
  #wt-limit.visible { display: block; }
  #wt-limit p { font-size: 11px; color: #92400E; margin: 0 0 8px; line-height: 1.4; }
  #wt-limit a {
    display: inline-block; padding: 5px 14px; border-radius: 9999px;
    background: #F59E0B; color: #fff; font-size: 11px; font-weight: 600;
    text-decoration: none;
  }
  #wt-limit a:hover { background: #D97706; }

  #wt-actions {
    display: none; gap: 6px; margin-top: 8px;
  }
  #wt-actions.visible { display: flex; }
  .wt-action {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151;
    cursor: pointer;
  }
  .wt-action.accept { border-color: #10B981; color: #10B981; }
  .wt-action.reject { border-color: #EF4444; color: #EF4444; }
`,q=[{key:"reply",label:"Reply"},{key:"email",label:"Email"},{key:"customer_update",label:"Customer Update"},{key:"jira_ticket",label:"Jira Ticket"},{key:"technical_report",label:"Tech Report"}],P=`
  :host { display: inline-flex; align-items: center; margin-left: 4px; }

  #wt-mic-btn {
    display: inline-flex; align-items: center; justify-content: center;
    width: 28px; height: 28px; border-radius: 9999px; border: none;
    background: transparent; color: #5F6368; cursor: pointer;
    transition: background 0.15s, color 0.15s;
    font-size: 15px; line-height: 1;
  }
  #wt-mic-btn:hover { background: rgba(0,0,0,0.07); }
  #wt-mic-btn.recording {
    background: #FEE2E2; color: #DC2626;
    animation: wt-pulse 1.2s ease-in-out infinite;
  }
  @keyframes wt-pulse {
    0%, 100% { box-shadow: 0 0 0 0 rgba(220,38,38,0.4); }
    50%       { box-shadow: 0 0 0 5px rgba(220,38,38,0); }
  }
  #wt-mic-btn:disabled { opacity: 0.5; cursor: default; }

  #wt-voice-panel {
    position: fixed; z-index: 9999;
    background: #fff; border: 1px solid #E8EAED; border-radius: 10px;
    box-shadow: 0 12px 32px rgba(15,23,42,0.14);
    padding: 14px 16px; width: 280px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: none;
  }
  #wt-voice-panel.open { display: block; }

  .wt-vt { font-size: 12px; font-weight: 600; color: #374151; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase; }

  #wt-record-btn {
    width: 100%; height: 34px; border-radius: 8px; border: none;
    background: #DC2626; color: #fff; cursor: pointer;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    margin-bottom: 10px;
  }
  #wt-record-btn.recording { background: #7F1D1D; }
  #wt-record-btn:disabled { opacity: 0.5; cursor: default; }

  .wt-otype-label { font-size: 11px; color: #6B7280; margin-bottom: 4px; }
  .wt-otypes { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 10px; }
  .wt-otype {
    padding: 3px 9px; border-radius: 9999px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 11px; color: #374151; cursor: pointer;
    transition: all 0.1s;
  }
  .wt-otype.active { background: #4F46E5; color: #fff; border-color: #4F46E5; }

  #wt-voice-status { font-size: 11px; text-align: center; min-height: 14px; color: #6B7280; }
  #wt-voice-status.error { color: #EF4444; }

  #wt-voice-actions { display: none; gap: 6px; margin-top: 8px; }
  #wt-voice-actions.visible { display: flex; }
  .wt-va {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151; cursor: pointer;
  }
  .wt-va.accept { border-color: #10B981; color: #10B981; }
  .wt-va.reject { border-color: #EF4444; color: #EF4444; }
`;function K(e,t){let n=document.createElement("span"),o=n.attachShadow({mode:"open"});o.innerHTML=`
    <style>${P}</style>
    <button id="wt-mic-btn" title="Voice Twin \u2014 speak your email (Cmd+Shift+V)">\u{1F399}</button>
    <div id="wt-voice-panel">
      <p class="wt-vt">Voice Twin</p>
      <div class="wt-otype-label">Output type</div>
      <div class="wt-otypes">
        ${q.map((a,i)=>`<button class="wt-otype${i===0?" active":""}" data-type="${a.key}">${a.label}</button>`).join("")}
      </div>
      <button id="wt-record-btn">\u{1F399} Start recording</button>
      <div id="wt-voice-status"></div>
      <div id="wt-voice-actions">
        <button class="wt-va accept" id="wt-va-keep">\u2713 Keep it</button>
        <button class="wt-va reject" id="wt-va-undo">\u2717 Undo</button>
      </div>
    </div>
  `;let r=o.getElementById("wt-mic-btn"),s=o.getElementById("wt-voice-panel"),l=o.getElementById("wt-record-btn"),d=o.getElementById("wt-voice-status"),u=o.getElementById("wt-voice-actions"),w=o.getElementById("wt-va-keep"),v=o.getElementById("wt-va-undo"),m=!1,y="reply",b=null,x=!1,h=[],g=null,k="";o.querySelectorAll(".wt-otype").forEach(a=>{a.addEventListener("click",()=>{o.querySelectorAll(".wt-otype").forEach(i=>i.classList.remove("active")),a.classList.add("active"),y=a.dataset.type})}),r.addEventListener("click",()=>{m=!m,s.classList.toggle("open",m),m&&C()}),document.addEventListener("click",a=>{!n.contains(a.target)&&m&&(m=!1,s.classList.remove("open"))},!0);function C(){let a=r.getBoundingClientRect();s.style.bottom=`${window.innerHeight-a.top+4}px`,s.style.left=`${Math.min(a.left,window.innerWidth-296)}px`}l.addEventListener("click",async()=>{x?L():await F()});async function F(){try{let a=await navigator.mediaDevices.getUserMedia({audio:!0});h=[],b=new MediaRecorder(a,{mimeType:"audio/webm"}),b.ondataavailable=i=>{i.data.size>0&&h.push(i.data)},b.onstop=async()=>{a.getTracks().forEach(c=>c.stop());let i=new Blob(h,{type:"audio/webm"});await A(i)},b.start(),x=!0,r.classList.add("recording"),l.classList.add("recording"),l.textContent="\u23F9 Stop recording",E("Recording\u2026"),u.classList.remove("visible"),setTimeout(()=>{x&&L()},6e4)}catch{E("Microphone access denied.","error")}}function L(){b&&x&&(b.stop(),x=!1,r.classList.remove("recording"),l.classList.remove("recording"),l.textContent="\u{1F399} Start recording",l.disabled=!0,E("Drafting\u2026"))}async function A(a){try{let i=await a.arrayBuffer(),c=new Uint8Array(i),p="";for(let M=0;M<c.length;M++)p+=String.fromCharCode(c[M]);let U=btoa(p);k=t.innerText.trim();let B=await f({type:"VOICE_DRAFT",payload:{audioData:U,mimeType:"audio/webm",outputType:y}});if("error"in B)throw new Error(String(B.error));g=B.result.id,D(t,B.result.draft),E("Done \u2713"),u.classList.add("visible")}catch(i){let c=i instanceof Error?i.message:"Failed";E(c,"error")}finally{l.disabled=!1}}w.addEventListener("click",()=>{g&&f({type:"VOICE_FEEDBACK",payload:{sessionId:g,accepted:!0,editedDraft:null}}),u.classList.remove("visible"),m=!1,s.classList.remove("open"),E("")}),v.addEventListener("click",()=>{k&&D(t,k),g&&f({type:"VOICE_FEEDBACK",payload:{sessionId:g,accepted:!1,editedDraft:null}}),u.classList.remove("visible"),E("Reverted.","success"),setTimeout(()=>E(""),2e3)});function E(a,i=""){d.textContent=a,d.className=i}let T=Array.from(e.children).find(a=>a.shadowRoot);if(T)e.insertBefore(n,T.nextSibling);else{let a=e.querySelector(H);a?e.insertBefore(n,a):e.appendChild(n)}}function _(e){let t=e,n=null;for(let s=0;s<20&&t;s++){if(t.querySelector("[data-hovercard-id], [email]")){n=t;break}t=t.parentElement}let o,r;if(n){let s=n.querySelector("[email], [data-hovercard-id]"),l=s?.getAttribute("email")??s?.getAttribute("data-hovercard-id")??"";l.includes("@")&&(o=l.split("@")[1].toLowerCase());let d=n.querySelector('input[name="subjectbox"]');d?.value&&(r=d.value)}return{platform:"gmail",recipient_domain:o,thread_subject:r}}function N(e){let t=W(e);if(!t)return;let n=t.parentElement;if(!n||n.hasAttribute(S))return;n.setAttribute(S,"1");let o=document.createElement("span"),r=o.attachShadow({mode:"open"}),s=null,l=null,d=!1,u="professional",w;r.innerHTML=`
    <style>${V}
    #wt-ctx-badge {
      display: inline-flex; align-items: center;
      height: 18px; padding: 0 7px; border-radius: 9999px;
      background: #EEF2FF; color: #4338CA; font-size: 10px; font-weight: 600;
      margin-left: 5px; cursor: pointer; white-space: nowrap;
      transition: background 0.1s;
    }
    #wt-ctx-badge:hover { background: #E0E7FF; }
    #wt-ctx-badge.hidden { display: none; }
    </style>
    <button id="wt-btn" title="Humanize with Writing Twin AI (Cmd+Shift+H)">\u2728 Humanize</button>
    <span id="wt-ctx-badge" class="hidden" title="Detected context \u2014 click to override"></span>
    <div id="wt-panel">
      <p class="wt-title">Rewrite tone</p>
      <div class="wt-tones">
        ${$.map(i=>`<button class="wt-tone" data-tone="${i.key}" data-color="${i.color}">${i.label}</button>`).join("")}
      </div>
      <button id="wt-rewrite" disabled>Rewrite \u2192</button>
      <div id="wt-status"></div>
      <div id="wt-limit">
        <p>You've used all your free rewrites this month.</p>
        <a href="https://writingtwinai.com/pricing" target="_blank" rel="noopener">Upgrade to Pro \u2014 $5/mo</a>
      </div>
      <div id="wt-actions">
        <button class="wt-action accept" id="wt-accept">\u2713 Keep it</button>
        <button class="wt-action reject" id="wt-reject">\u2717 Undo</button>
      </div>
    </div>
  `;let v=r.getElementById("wt-btn"),m=r.getElementById("wt-ctx-badge"),y=r.getElementById("wt-panel"),b=r.getElementById("wt-rewrite"),x=r.getElementById("wt-status"),h=r.getElementById("wt-limit"),g=r.getElementById("wt-actions"),k=r.getElementById("wt-accept"),C=r.getElementById("wt-reject");r.querySelectorAll(".wt-tone").forEach(i=>{i.addEventListener("click",()=>{r.querySelectorAll(".wt-tone").forEach(c=>c.classList.remove("active")),i.classList.add("active"),i.style.background=i.dataset.color??"#4F46E5",i.style.borderColor=i.dataset.color??"#4F46E5",s=i.dataset.tone,b.disabled=!1,x.textContent="",x.className="",h.classList.remove("visible"),g.classList.remove("visible")})}),setTimeout(()=>F(),800);function F(){let i=_(e);f({type:"DETECT_CONTEXT",payload:i}).then(c=>{"result"in c&&c.result?.context_twin&&(u=c.result.context_twin,L(u))}).catch(()=>{})}function L(i){let c=i.charAt(0).toUpperCase()+i.slice(1);m.textContent=c,m.classList.remove("hidden")}let A=["professional","customer","technical","escalation","casual"];m.addEventListener("click",()=>{let i=w??u,c=A.indexOf(i),p=A[(c+1)%A.length];w=p,L(p),f({type:"CONTEXT_OVERRIDE",payload:{detected_context:u,selected_context:p,platform:"gmail"}})}),v.addEventListener("click",()=>{d=!d,y.classList.toggle("open",d),d&&E()}),document.addEventListener("click",i=>{!o.contains(i.target)&&d&&(d=!1,y.classList.remove("open"))},!0);function E(){let i=v.getBoundingClientRect();y.style.bottom=`${window.innerHeight-i.top+4}px`,y.style.left=`${Math.min(i.left,window.innerWidth-276)}px`}let T="";b.addEventListener("click",async()=>{if(!s)return;let i=e.innerText.trim();if(!i){a("Write something first.","error");return}T=i,v.disabled=!0,b.disabled=!0,a("Rewriting\u2026"),g.classList.remove("visible");try{let c=_(e),p=await f({type:"HUMANIZE",payload:{text:i,tone:s,ctx:{...c,context_twin_override:w}}});if("error"in p)throw new Error(String(p.error));l=p.result.id,D(e,p.result.output_text),a("Done \u2713","success"),g.classList.add("visible")}catch(c){let p=c instanceof Error?c.message:"Failed";p.startsWith("LIMIT_REACHED:")?(h.classList.add("visible"),a("")):a(p,"error")}finally{v.disabled=!1,b.disabled=s===null}}),k.addEventListener("click",async()=>{l&&f({type:"FEEDBACK",payload:{rewriteId:l,action:"accepted"}}),g.classList.remove("visible"),d=!1,y.classList.remove("open"),a("")}),C.addEventListener("click",async()=>{T&&D(e,T),l&&f({type:"FEEDBACK",payload:{rewriteId:l,action:"rejected"}}),g.classList.remove("visible"),a("Reverted.","success"),setTimeout(()=>a(""),2e3)});function a(i,c=""){x.textContent=i,x.className=c}n.insertBefore(o,t),K(n,e),setTimeout(()=>G(e),500)}function W(e){let t=e;for(let n=0;n<25&&t;n++){let o=t.querySelector(H);if(o)return o;t=t.parentElement}return null}function D(e,t){e.focus(),document.execCommand("selectAll",!1,void 0),document.execCommand("delete",!1,void 0);let n=t.split(`
`);for(let o=0;o<n.length;o++)n[o]&&document.execCommand("insertText",!1,n[o]),o<n.length-1&&document.execCommand("insertParagraph",!1,void 0)}function f(e){return new Promise(t=>{chrome.runtime.sendMessage(e,t)})}function Y(e){let t=e,n=null;for(let r=0;r<20&&t;r++){if(t.querySelectorAll(".gs").length>0){n=t;break}t=t.parentElement}if(!n)return null;let o=Array.from(n.querySelectorAll(".gs"));for(let r=o.length-1;r>=0;r--)if(!o[r].contains(e))return o[r];return null}function X(e){let t=e.querySelector(".a3s.aiL")??e.querySelector(".ii.gt")??e.querySelector(".adn");if(!t)return null;let n=t.innerText.trim();return n.length<20?null:n.split(/\s+/).slice(0,500).join(" ")}var I="data-wt-autodraft";async function G(e){if(e.hasAttribute(I)||(e.setAttribute(I,"1"),e.innerText.trim()!==""))return;let t=Y(e);if(!t)return;let n=X(t);if(!n)return;let o=_(e),r=new AbortController,s=setTimeout(()=>r.abort(),2e3),l;try{let d=await Promise.race([f({type:"AUTO_DRAFT",payload:{incomingText:n,tone:j,ctx:o}}),new Promise((u,w)=>setTimeout(()=>w(new Error("timeout")),2e3))]);if(clearTimeout(s),"error"in d)return;l=d.result}catch{clearTimeout(s);return}e.innerText.trim()===""&&J(e,l)}function J(e,t){document.getElementById("wt-auto-draft-banner")?.remove();let n=document.createElement("div");n.id="wt-auto-draft-banner",n.style.cssText=`
    position: fixed; z-index: 9998;
    background: #EEF2FF; border: 1px solid #C7D2FE; border-radius: 10px;
    padding: 10px 14px; display: flex; align-items: center; gap: 10px;
    font: 13px/1.4 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #312E81; box-shadow: 0 4px 16px rgba(79,70,229,0.12);
    max-width: 420px;
  `;let o=document.createElement("span");o.style.cssText="font-weight: 600; white-space: nowrap;",o.textContent="\u2726 Draft ready";let r=document.createElement("button");r.style.cssText=`
    height: 28px; padding: 0 12px; border-radius: 9999px; border: none;
    background: #4F46E5; color: #fff; font: 600 12px/1 inherit;
    cursor: pointer; white-space: nowrap;
  `,r.textContent="Use draft";let s=document.createElement("button");s.style.cssText=`
    height: 24px; width: 24px; border-radius: 9999px; border: none;
    background: transparent; color: #6366F1; font-size: 16px; line-height: 1;
    cursor: pointer; margin-left: auto; display: flex; align-items: center; justify-content: center;
  `,s.title="Dismiss",s.textContent="\u2715",n.append(o,r,s),document.body.appendChild(n);function l(){let w=e.getBoundingClientRect();n.style.top=`${Math.max(w.top-52,60)}px`,n.style.left=`${Math.min(w.left,window.innerWidth-440)}px`}l(),window.addEventListener("resize",l,{passive:!0});function d(){n.remove(),window.removeEventListener("resize",l)}r.addEventListener("click",()=>{D(e,t.draft),f({type:"AUTO_DRAFT_FEEDBACK",payload:{draftId:t.id,kept:!0}}),d()}),s.addEventListener("click",()=>{f({type:"AUTO_DRAFT_FEEDBACK",payload:{draftId:t.id,kept:!1}}),d()});let u=()=>{e.innerText.trim()!==""&&(f({type:"AUTO_DRAFT_FEEDBACK",payload:{draftId:t.id,kept:!1}}),d(),e.removeEventListener("input",u))};e.addEventListener("input",u),setTimeout(d,3e4)}var R=new WeakSet;function O(e){e.querySelectorAll(z).forEach(t=>{R.has(t)||(R.add(t),N(t))})}var Z=new MutationObserver(()=>O(document));Z.observe(document.body,{childList:!0,subtree:!0});O(document);document.addEventListener("keydown",e=>{let t=document.querySelector(`[${S}]`);if(!t)return;let n=Array.from(t.children).filter(o=>o.shadowRoot);(e.metaKey||e.ctrlKey)&&e.shiftKey&&e.key==="H"&&(e.preventDefault(),n[0]?.shadowRoot?.getElementById("wt-btn")?.click()),(e.metaKey||e.ctrlKey)&&e.shiftKey&&e.key==="V"&&(e.preventDefault(),n[1]?.shadowRoot?.getElementById("wt-mic-btn")?.click())});})();
