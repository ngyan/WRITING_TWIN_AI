"use strict";(()=>{var C='[g_editable="true"], div[contenteditable="true"][aria-multiline="true"]',I='[data-tooltip^="Send"], [aria-label^="Send"]',M="data-wt-injected",A=[{key:"professional",label:"Professional",color:"#4F46E5"},{key:"casual",label:"Casual",color:"#06B6D4"},{key:"friendly",label:"Friendly",color:"#F59E0B"},{key:"direct",label:"Direct",color:"#DC2626"},{key:"diplomatic",label:"Diplomatic",color:"#7C3AED"},{key:"executive",label:"Executive",color:"#0F172A"}],O=`
  :host { display: inline-flex; align-items: center; margin-left: 8px; }

  #wt-btn {
    display: inline-flex; align-items: center; gap: 5px;
    height: 28px; padding: 0 12px; border-radius: 9999px; border: none;
    background: #4F46E5; color: #fff;
    font: 500 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer; white-space: nowrap;
    transition: background 0.15s, box-shadow 0.15s;
  }
  #wt-btn:hover { background: #3F37C9; box-shadow: 0 0 0 3px rgba(79,70,229,0.25); }
  #wt-btn:disabled { opacity: 0.6; cursor: default; box-shadow: none; }

  #wt-panel {
    position: fixed; z-index: 9999;
    background: #fff; border: 1px solid #E8EAED; border-radius: 10px;
    box-shadow: 0 12px 32px rgba(15,23,42,0.14);
    padding: 14px 16px; width: 260px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: none;
  }
  #wt-panel.open { display: block; }

  .wt-title {
    font-size: 12px; font-weight: 600; color: #374151; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase;
  }
  .wt-tones {
    display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 12px;
  }
  .wt-tone {
    padding: 4px 10px; border-radius: 9999px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151;
    cursor: pointer; transition: all 0.1s;
  }
  .wt-tone.active {
    color: #fff; border-color: transparent;
  }
  .wt-tone:hover:not(.active) { border-color: #9BA0FF; }

  #wt-rewrite {
    width: 100%; height: 32px; border-radius: 8px; border: none;
    background: #4F46E5; color: #fff;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer;
  }
  #wt-rewrite:disabled { opacity: 0.45; cursor: default; }

  #wt-status {
    margin-top: 8px; font-size: 11px; text-align: center; min-height: 14px;
  }
  #wt-status.error { color: #EF4444; }
  #wt-status.success { color: #10B981; }

  #wt-limit {
    display: none; margin-top: 10px; padding: 10px 12px; border-radius: 8px;
    background: #FFF8F1; border: 1px solid #FED7AA; text-align: center;
  }
  #wt-limit.visible { display: block; }
  #wt-limit p { font-size: 11px; color: #92400E; margin: 0 0 8px; line-height: 1.4; }
  #wt-limit a {
    display: inline-block; padding: 5px 14px; border-radius: 9999px;
    background: #F59E0B; color: #fff; font-size: 11px; font-weight: 600;
    text-decoration: none;
  }
  #wt-limit a:hover { background: #D97706; }

  #wt-actions {
    display: none; gap: 6px; margin-top: 8px;
  }
  #wt-actions.visible { display: flex; }
  .wt-action {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151;
    cursor: pointer;
  }
  .wt-action.accept { border-color: #10B981; color: #10B981; }
  .wt-action.reject { border-color: #EF4444; color: #EF4444; }
`,_=[{key:"reply",label:"Reply"},{key:"email",label:"Email"},{key:"customer_update",label:"Customer Update"},{key:"jira_ticket",label:"Jira Ticket"},{key:"technical_report",label:"Tech Report"}],$=`
  :host { display: inline-flex; align-items: center; margin-left: 4px; }

  #wt-mic-btn {
    display: inline-flex; align-items: center; justify-content: center;
    width: 28px; height: 28px; border-radius: 9999px; border: none;
    background: transparent; color: #5F6368; cursor: pointer;
    transition: background 0.15s, color 0.15s;
    font-size: 15px; line-height: 1;
  }
  #wt-mic-btn:hover { background: rgba(0,0,0,0.07); }
  #wt-mic-btn.recording {
    background: #FEE2E2; color: #DC2626;
    animation: wt-pulse 1.2s ease-in-out infinite;
  }
  @keyframes wt-pulse {
    0%, 100% { box-shadow: 0 0 0 0 rgba(220,38,38,0.4); }
    50%       { box-shadow: 0 0 0 5px rgba(220,38,38,0); }
  }
  #wt-mic-btn:disabled { opacity: 0.5; cursor: default; }

  #wt-voice-panel {
    position: fixed; z-index: 9999;
    background: #fff; border: 1px solid #E8EAED; border-radius: 10px;
    box-shadow: 0 12px 32px rgba(15,23,42,0.14);
    padding: 14px 16px; width: 280px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: none;
  }
  #wt-voice-panel.open { display: block; }

  .wt-vt { font-size: 12px; font-weight: 600; color: #374151; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase; }

  #wt-record-btn {
    width: 100%; height: 34px; border-radius: 8px; border: none;
    background: #DC2626; color: #fff; cursor: pointer;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    margin-bottom: 10px;
  }
  #wt-record-btn.recording { background: #7F1D1D; }
  #wt-record-btn:disabled { opacity: 0.5; cursor: default; }

  .wt-otype-label { font-size: 11px; color: #6B7280; margin-bottom: 4px; }
  .wt-otypes { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 10px; }
  .wt-otype {
    padding: 3px 9px; border-radius: 9999px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 11px; color: #374151; cursor: pointer;
    transition: all 0.1s;
  }
  .wt-otype.active { background: #4F46E5; color: #fff; border-color: #4F46E5; }

  #wt-voice-status { font-size: 11px; text-align: center; min-height: 14px; color: #6B7280; }
  #wt-voice-status.error { color: #EF4444; }

  #wt-voice-actions { display: none; gap: 6px; margin-top: 8px; }
  #wt-voice-actions.visible { display: flex; }
  .wt-va {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151; cursor: pointer;
  }
  .wt-va.accept { border-color: #10B981; color: #10B981; }
  .wt-va.reject { border-color: #EF4444; color: #EF4444; }
`;function z(e,r){let o=document.createElement("span"),t=o.attachShadow({mode:"open"});t.innerHTML=`
    <style>${$}</style>
    <button id="wt-mic-btn" title="Voice Twin \u2014 speak your email (Cmd+Shift+V)">\u{1F399}</button>
    <div id="wt-voice-panel">
      <p class="wt-vt">Voice Twin</p>
      <div class="wt-otype-label">Output type</div>
      <div class="wt-otypes">
        ${_.map((n,s)=>`<button class="wt-otype${s===0?" active":""}" data-type="${n.key}">${n.label}</button>`).join("")}
      </div>
      <button id="wt-record-btn">\u{1F399} Start recording</button>
      <div id="wt-voice-status"></div>
      <div id="wt-voice-actions">
        <button class="wt-va accept" id="wt-va-keep">\u2713 Keep it</button>
        <button class="wt-va reject" id="wt-va-undo">\u2717 Undo</button>
      </div>
    </div>
  `;let a=t.getElementById("wt-mic-btn"),p=t.getElementById("wt-voice-panel"),c=t.getElementById("wt-record-btn"),m=t.getElementById("wt-voice-status"),w=t.getElementById("wt-voice-actions"),E=t.getElementById("wt-va-keep"),h=t.getElementById("wt-va-undo"),u=!1,T="reply",l=null,g=!1,k="",y=null,x="";t.querySelectorAll(".wt-otype").forEach(n=>{n.addEventListener("click",()=>{t.querySelectorAll(".wt-otype").forEach(s=>s.classList.remove("active")),n.classList.add("active"),T=n.dataset.type})}),a.addEventListener("click",()=>{u=!u,p.classList.toggle("open",u),u&&b()}),document.addEventListener("click",n=>{!o.contains(n.target)&&u&&(u=!1,p.classList.remove("open"))},!0);function b(){let n=a.getBoundingClientRect();p.style.bottom=`${window.innerHeight-n.top+4}px`,p.style.left=`${Math.min(n.left,window.innerWidth-296)}px`}c.addEventListener("click",async()=>{g?d():await i()});async function i(){let n=window.webkitSpeechRecognition;if(!n){f("Speech recognition not supported in this browser.","error");return}k="",l=new n,l.continuous=!0,l.interimResults=!0,l.lang="en-US",l.onresult=s=>{let F="";for(let L=s.resultIndex;L<s.results.length;L++)s.results[L].isFinal?k+=s.results[L][0].transcript+" ":F+=s.results[L][0].transcript;f(`\u{1F399} ${(k+F).trim()||"Listening\u2026"}`)},l.onerror=s=>{s.error!=="aborted"&&f(`Mic error: ${s.error}`,"error")},l.onend=()=>{g&&l?.start()};try{l.start(),g=!0,a.classList.add("recording"),c.classList.add("recording"),c.textContent="\u23F9 Stop recording",w.classList.remove("visible"),setTimeout(()=>{g&&d()},6e4)}catch{f("Microphone access denied.","error")}}function d(){l&&g&&(g=!1,l.onend=null,l.stop(),l=null,a.classList.remove("recording"),c.classList.remove("recording"),c.textContent="\u{1F399} Start recording",c.disabled=!0,f("Drafting\u2026"),B())}async function B(){try{let n=k.trim();if(!n){f("Nothing recorded \u2014 try again.","error"),c.disabled=!1;return}x=r.innerText.trim();let s=await v({type:"VOICE_DRAFT",payload:{transcript:n,outputType:T}});if("error"in s)throw new Error(String(s.error));y=s.result.id,S(r,s.result.draft),f("Done \u2713"),w.classList.add("visible")}catch(n){let s=n instanceof Error?n.message:"Failed";f(s,"error")}finally{c.disabled=!1}}E.addEventListener("click",()=>{y&&v({type:"VOICE_FEEDBACK",payload:{sessionId:y,accepted:!0,editedDraft:null}}),w.classList.remove("visible"),u=!1,p.classList.remove("open"),f("")}),h.addEventListener("click",()=>{x&&S(r,x),y&&v({type:"VOICE_FEEDBACK",payload:{sessionId:y,accepted:!1,editedDraft:null}}),w.classList.remove("visible"),f("Reverted.","success"),setTimeout(()=>f(""),2e3)});function f(n,s=""){m.textContent=n,m.className=s}let D=Array.from(e.children).find(n=>n.shadowRoot);if(D)e.insertBefore(o,D.nextSibling);else{let n=e.querySelector(I);n?e.insertBefore(o,n):e.appendChild(o)}}function j(e){let r=U(e);if(!r)return;let o=r.parentElement;if(!o||o.hasAttribute(M))return;o.setAttribute(M,"1");let t=document.createElement("span"),a=t.attachShadow({mode:"open"}),p=null,c=null,m=!1;a.innerHTML=`
    <style>${O}</style>
    <button id="wt-btn" title="Humanize with Writing Twin AI (Cmd+Shift+H)">\u2728 Humanize</button>
    <div id="wt-panel">
      <p class="wt-title">Rewrite tone</p>
      <div class="wt-tones">
        ${A.map(i=>`<button class="wt-tone" data-tone="${i.key}" data-color="${i.color}">${i.label}</button>`).join("")}
      </div>
      <button id="wt-rewrite" disabled>Rewrite \u2192</button>
      <div id="wt-status"></div>
      <div id="wt-limit">
        <p>You've used all your free rewrites this month.</p>
        <a href="https://writingtwinai.com/pricing" target="_blank" rel="noopener">Upgrade to Pro \u2014 $5/mo</a>
      </div>
      <div id="wt-actions">
        <button class="wt-action accept" id="wt-accept">\u2713 Keep it</button>
        <button class="wt-action reject" id="wt-reject">\u2717 Undo</button>
      </div>
    </div>
  `;let w=a.getElementById("wt-btn"),E=a.getElementById("wt-panel"),h=a.getElementById("wt-rewrite"),u=a.getElementById("wt-status"),T=a.getElementById("wt-limit"),l=a.getElementById("wt-actions"),g=a.getElementById("wt-accept"),k=a.getElementById("wt-reject");a.querySelectorAll(".wt-tone").forEach(i=>{i.addEventListener("click",()=>{a.querySelectorAll(".wt-tone").forEach(d=>d.classList.remove("active")),i.classList.add("active"),i.style.background=i.dataset.color??"#4F46E5",i.style.borderColor=i.dataset.color??"#4F46E5",p=i.dataset.tone,h.disabled=!1,u.textContent="",u.className="",T.classList.remove("visible"),l.classList.remove("visible")})}),w.addEventListener("click",()=>{m=!m,E.classList.toggle("open",m),m&&y()}),document.addEventListener("click",i=>{!t.contains(i.target)&&m&&(m=!1,E.classList.remove("open"))},!0);function y(){let i=w.getBoundingClientRect();E.style.bottom=`${window.innerHeight-i.top+4}px`,E.style.left=`${Math.min(i.left,window.innerWidth-276)}px`}let x="";h.addEventListener("click",async()=>{if(!p)return;let i=e.innerText.trim();if(!i){b("Write something first.","error");return}x=i,w.disabled=!0,h.disabled=!0,b("Rewriting\u2026"),l.classList.remove("visible");try{let d=await v({type:"HUMANIZE",payload:{text:i,tone:p}});if("error"in d)throw new Error(String(d.error));c=d.result.id,S(e,d.result.output_text),b("Done \u2713","success"),l.classList.add("visible")}catch(d){let B=d instanceof Error?d.message:"Failed";B.startsWith("LIMIT_REACHED:")?(T.classList.add("visible"),b("")):b(B,"error")}finally{w.disabled=!1,h.disabled=p===null}}),g.addEventListener("click",async()=>{c&&v({type:"FEEDBACK",payload:{rewriteId:c,action:"accepted"}}),l.classList.remove("visible"),m=!1,E.classList.remove("open"),b("")}),k.addEventListener("click",async()=>{x&&S(e,x),c&&v({type:"FEEDBACK",payload:{rewriteId:c,action:"rejected"}}),l.classList.remove("visible"),b("Reverted.","success"),setTimeout(()=>b(""),2e3)});function b(i,d=""){u.textContent=i,u.className=d}o.insertBefore(t,r),z(o,e)}function U(e){let r=e;for(let o=0;o<25&&r;o++){let t=r.querySelector(I);if(t)return t;r=r.parentElement}return null}function S(e,r){e.focus(),document.execCommand("selectAll",!1,void 0),document.execCommand("delete",!1,void 0);let o=r.split(`
`);for(let t=0;t<o.length;t++)o[t]&&document.execCommand("insertText",!1,o[t]),t<o.length-1&&document.execCommand("insertParagraph",!1,void 0)}function v(e,r=0){return new Promise((o,t)=>{let a=()=>{r===0?setTimeout(()=>v(e,1).then(o).catch(t),900):t(new Error("Extension restarted \u2014 please reload Gmail and try again."))};if(!chrome?.runtime?.sendMessage){a();return}try{chrome.runtime.sendMessage(e,p=>{chrome.runtime?.lastError?a():o(p)})}catch{a()}})}var H=new WeakSet;function R(e){e.querySelectorAll(C).forEach(r=>{H.has(r)||(H.add(r),j(r))})}var V=new MutationObserver(()=>R(document));V.observe(document.body,{childList:!0,subtree:!0});R(document);document.addEventListener("keydown",e=>{let r=document.querySelector(`[${M}]`);if(!r)return;let o=Array.from(r.children).filter(t=>t.shadowRoot);(e.metaKey||e.ctrlKey)&&e.shiftKey&&e.key==="H"&&(e.preventDefault(),o[0]?.shadowRoot?.getElementById("wt-btn")?.click()),(e.metaKey||e.ctrlKey)&&e.shiftKey&&e.key==="V"&&(e.preventDefault(),o[1]?.shadowRoot?.getElementById("wt-mic-btn")?.click())});})();
