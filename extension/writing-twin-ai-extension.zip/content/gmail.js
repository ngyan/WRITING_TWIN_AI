"use strict";
(() => {
  // src/content/gmail.ts
  var COMPOSE_BODY_SEL = '[g_editable="true"], div[contenteditable="true"][aria-multiline="true"]';
  var SEND_BUTTON_SEL = '[data-tooltip^="Send"], [aria-label^="Send"]';
  var HOST_ATTR = "data-wt-injected";
  var AUTO_DRAFT_TIMEOUT_MS = 2e3;
  var AUTO_DRAFT_DEFAULT_TONE = "professional";
  var TONES = [
    { key: "professional", label: "Professional", color: "#4F46E5" },
    { key: "casual", label: "Casual", color: "#06B6D4" },
    { key: "friendly", label: "Friendly", color: "#F59E0B" },
    { key: "direct", label: "Direct", color: "#DC2626" },
    { key: "diplomatic", label: "Diplomatic", color: "#7C3AED" },
    { key: "executive", label: "Executive", color: "#0F172A" }
  ];
  var BUTTON_CSS = `
  :host { display: inline-flex; align-items: center; margin-left: 8px; }

  #wt-btn {
    display: inline-flex; align-items: center; gap: 5px;
    height: 28px; padding: 0 12px; border-radius: 9999px; border: none;
    background: #4F46E5; color: #fff;
    font: 500 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer; white-space: nowrap;
    transition: background 0.15s, box-shadow 0.15s;
  }
  #wt-btn:hover { background: #3F37C9; box-shadow: 0 0 0 3px rgba(79,70,229,0.25); }
  #wt-btn:disabled { opacity: 0.6; cursor: default; box-shadow: none; }

  #wt-panel {
    position: fixed; z-index: 9999;
    background: #fff; border: 1px solid #E8EAED; border-radius: 10px;
    box-shadow: 0 12px 32px rgba(15,23,42,0.14);
    padding: 14px 16px; width: 260px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: none;
  }
  #wt-panel.open { display: block; }

  .wt-title {
    font-size: 12px; font-weight: 600; color: #374151; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase;
  }
  .wt-tones {
    display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 12px;
  }
  .wt-tone {
    padding: 4px 10px; border-radius: 9999px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151;
    cursor: pointer; transition: all 0.1s;
  }
  .wt-tone.active {
    color: #fff; border-color: transparent;
  }
  .wt-tone:hover:not(.active) { border-color: #9BA0FF; }

  #wt-rewrite {
    width: 100%; height: 32px; border-radius: 8px; border: none;
    background: #4F46E5; color: #fff;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer;
  }
  #wt-rewrite:disabled { opacity: 0.45; cursor: default; }

  #wt-status {
    margin-top: 8px; font-size: 11px; text-align: center; min-height: 14px;
  }
  #wt-status.error { color: #EF4444; }
  #wt-status.success { color: #10B981; }

  #wt-limit {
    display: none; margin-top: 10px; padding: 10px 12px; border-radius: 8px;
    background: #FFF8F1; border: 1px solid #FED7AA; text-align: center;
  }
  #wt-limit.visible { display: block; }
  #wt-limit p { font-size: 11px; color: #92400E; margin: 0 0 8px; line-height: 1.4; }
  #wt-limit a {
    display: inline-block; padding: 5px 14px; border-radius: 9999px;
    background: #F59E0B; color: #fff; font-size: 11px; font-weight: 600;
    text-decoration: none;
  }
  #wt-limit a:hover { background: #D97706; }

  #wt-actions {
    display: none; gap: 6px; margin-top: 8px;
  }
  #wt-actions.visible { display: flex; }
  .wt-action {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151;
    cursor: pointer;
  }
  .wt-action.accept { border-color: #10B981; color: #10B981; }
  .wt-action.reject { border-color: #EF4444; color: #EF4444; }
`;
  var VOICE_OUTPUT_TYPES = [
    { key: "reply", label: "Reply" },
    { key: "email", label: "Email" },
    { key: "customer_update", label: "Customer Update" },
    { key: "jira_ticket", label: "Jira Ticket" },
    { key: "technical_report", label: "Tech Report" }
  ];
  var MIC_CSS = `
  :host { display: inline-flex; align-items: center; margin-left: 4px; }

  #wt-mic-btn {
    display: inline-flex; align-items: center; justify-content: center;
    width: 28px; height: 28px; border-radius: 9999px; border: none;
    background: transparent; color: #5F6368; cursor: pointer;
    transition: background 0.15s, color 0.15s;
    font-size: 15px; line-height: 1;
  }
  #wt-mic-btn:hover { background: rgba(0,0,0,0.07); }
  #wt-mic-btn.recording {
    background: #FEE2E2; color: #DC2626;
    animation: wt-pulse 1.2s ease-in-out infinite;
  }
  @keyframes wt-pulse {
    0%, 100% { box-shadow: 0 0 0 0 rgba(220,38,38,0.4); }
    50%       { box-shadow: 0 0 0 5px rgba(220,38,38,0); }
  }
  #wt-mic-btn:disabled { opacity: 0.5; cursor: default; }

  #wt-voice-panel {
    position: fixed; z-index: 9999;
    background: #fff; border: 1px solid #E8EAED; border-radius: 10px;
    box-shadow: 0 12px 32px rgba(15,23,42,0.14);
    padding: 14px 16px; width: 280px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: none;
  }
  #wt-voice-panel.open { display: block; }

  .wt-vt { font-size: 12px; font-weight: 600; color: #374151; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase; }

  #wt-record-btn {
    width: 100%; height: 34px; border-radius: 8px; border: none;
    background: #DC2626; color: #fff; cursor: pointer;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    margin-bottom: 10px;
  }
  #wt-record-btn.recording { background: #7F1D1D; }
  #wt-record-btn:disabled { opacity: 0.5; cursor: default; }

  .wt-otype-label { font-size: 11px; color: #6B7280; margin-bottom: 4px; }
  .wt-otypes { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 10px; }
  .wt-otype {
    padding: 3px 9px; border-radius: 9999px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 11px; color: #374151; cursor: pointer;
    transition: all 0.1s;
  }
  .wt-otype.active { background: #4F46E5; color: #fff; border-color: #4F46E5; }

  #wt-voice-status { font-size: 11px; text-align: center; min-height: 14px; color: #6B7280; }
  #wt-voice-status.error { color: #EF4444; }

  #wt-voice-actions { display: none; gap: 6px; margin-top: 8px; }
  #wt-voice-actions.visible { display: flex; }
  .wt-va {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151; cursor: pointer;
  }
  .wt-va.accept { border-color: #10B981; color: #10B981; }
  .wt-va.reject { border-color: #EF4444; color: #EF4444; }
`;
  function injectMicButton(toolbar, composeBody) {
    const micHost = document.createElement("span");
    const shadow = micHost.attachShadow({ mode: "open" });
    shadow.innerHTML = `
    <style>${MIC_CSS}</style>
    <button id="wt-mic-btn" title="Voice Twin \u2014 speak your email (Cmd+Shift+V)">\u{1F399}</button>
    <div id="wt-voice-panel">
      <p class="wt-vt">Voice Twin</p>
      <div class="wt-otype-label">Output type</div>
      <div class="wt-otypes">
        ${VOICE_OUTPUT_TYPES.map(
      (o, i) => `<button class="wt-otype${i === 0 ? " active" : ""}" data-type="${o.key}">${o.label}</button>`
    ).join("")}
      </div>
      <button id="wt-record-btn">\u{1F399} Start recording</button>
      <div id="wt-voice-status"></div>
      <div id="wt-voice-actions">
        <button class="wt-va accept" id="wt-va-keep">\u2713 Keep it</button>
        <button class="wt-va reject" id="wt-va-undo">\u2717 Undo</button>
      </div>
    </div>
  `;
    const micBtn = shadow.getElementById("wt-mic-btn");
    const panel = shadow.getElementById("wt-voice-panel");
    const recordBtn = shadow.getElementById("wt-record-btn");
    const statusEl = shadow.getElementById("wt-voice-status");
    const actionsEl = shadow.getElementById("wt-voice-actions");
    const keepBtn = shadow.getElementById("wt-va-keep");
    const undoBtn = shadow.getElementById("wt-va-undo");
    let panelOpen = false;
    let selectedType = "reply";
    let recorder = null;
    let recording = false;
    let chunks = [];
    let lastSessionId = null;
    let originalText = "";
    shadow.querySelectorAll(".wt-otype").forEach((btn) => {
      btn.addEventListener("click", () => {
        shadow.querySelectorAll(".wt-otype").forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        selectedType = btn.dataset.type;
      });
    });
    micBtn.addEventListener("click", () => {
      panelOpen = !panelOpen;
      panel.classList.toggle("open", panelOpen);
      if (panelOpen) positionPanel();
    });
    document.addEventListener("click", (e) => {
      if (!micHost.contains(e.target) && panelOpen) {
        panelOpen = false;
        panel.classList.remove("open");
      }
    }, true);
    function positionPanel() {
      const rect = micBtn.getBoundingClientRect();
      panel.style.bottom = `${window.innerHeight - rect.top + 4}px`;
      panel.style.left = `${Math.min(rect.left, window.innerWidth - 296)}px`;
    }
    recordBtn.addEventListener("click", async () => {
      if (!recording) {
        await startRecording();
      } else {
        stopRecording();
      }
    });
    async function startRecording() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        chunks = [];
        recorder = new MediaRecorder(stream, { mimeType: "audio/webm" });
        recorder.ondataavailable = (e) => {
          if (e.data.size > 0) chunks.push(e.data);
        };
        recorder.onstop = async () => {
          stream.getTracks().forEach((t) => t.stop());
          const blob = new Blob(chunks, { type: "audio/webm" });
          await submitVoice(blob);
        };
        recorder.start();
        recording = true;
        micBtn.classList.add("recording");
        recordBtn.classList.add("recording");
        recordBtn.textContent = "\u23F9 Stop recording";
        setVoiceStatus("Recording\u2026");
        actionsEl.classList.remove("visible");
        setTimeout(() => {
          if (recording) stopRecording();
        }, 6e4);
      } catch {
        setVoiceStatus("Microphone access denied.", "error");
      }
    }
    function stopRecording() {
      if (recorder && recording) {
        recorder.stop();
        recording = false;
        micBtn.classList.remove("recording");
        recordBtn.classList.remove("recording");
        recordBtn.textContent = "\u{1F399} Start recording";
        recordBtn.disabled = true;
        setVoiceStatus("Drafting\u2026");
      }
    }
    async function submitVoice(blob) {
      try {
        const arrayBuf = await blob.arrayBuffer();
        const uint8 = new Uint8Array(arrayBuf);
        let binary = "";
        for (let i = 0; i < uint8.length; i++) binary += String.fromCharCode(uint8[i]);
        const audioData = btoa(binary);
        originalText = composeBody.innerText.trim();
        const resp = await sendToBackground({
          type: "VOICE_DRAFT",
          payload: { audioData, mimeType: "audio/webm", outputType: selectedType }
        });
        if ("error" in resp) throw new Error(String(resp.error));
        lastSessionId = resp.result.id;
        setComposeText(composeBody, resp.result.draft);
        setVoiceStatus("Done \u2713");
        actionsEl.classList.add("visible");
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Failed";
        setVoiceStatus(msg, "error");
      } finally {
        recordBtn.disabled = false;
      }
    }
    keepBtn.addEventListener("click", () => {
      if (lastSessionId) {
        sendToBackground({
          type: "VOICE_FEEDBACK",
          payload: { sessionId: lastSessionId, accepted: true, editedDraft: null }
        });
      }
      actionsEl.classList.remove("visible");
      panelOpen = false;
      panel.classList.remove("open");
      setVoiceStatus("");
    });
    undoBtn.addEventListener("click", () => {
      if (originalText) setComposeText(composeBody, originalText);
      if (lastSessionId) {
        sendToBackground({
          type: "VOICE_FEEDBACK",
          payload: { sessionId: lastSessionId, accepted: false, editedDraft: null }
        });
      }
      actionsEl.classList.remove("visible");
      setVoiceStatus("Reverted.", "success");
      setTimeout(() => setVoiceStatus(""), 2e3);
    });
    function setVoiceStatus(msg, cls = "") {
      statusEl.textContent = msg;
      statusEl.className = cls;
    }
    const humanizeHost = Array.from(toolbar.children).find((c) => c.shadowRoot);
    if (humanizeHost) {
      toolbar.insertBefore(micHost, humanizeHost.nextSibling);
    } else {
      const sendBtn = toolbar.querySelector(SEND_BUTTON_SEL);
      if (sendBtn) toolbar.insertBefore(micHost, sendBtn);
      else toolbar.appendChild(micHost);
    }
  }
  function buildGmailContext(composeBody) {
    let el = composeBody;
    let container = null;
    for (let i = 0; i < 20; i++) {
      if (!el) break;
      if (el.querySelector("[data-hovercard-id], [email]")) {
        container = el;
        break;
      }
      el = el.parentElement;
    }
    let recipientDomain;
    let threadSubject;
    if (container) {
      const chip = container.querySelector("[email], [data-hovercard-id]");
      const email = chip?.getAttribute("email") ?? chip?.getAttribute("data-hovercard-id") ?? "";
      if (email.includes("@")) recipientDomain = email.split("@")[1].toLowerCase();
      const subjectEl = container.querySelector('input[name="subjectbox"]');
      if (subjectEl?.value) threadSubject = subjectEl.value;
    }
    return {
      platform: "gmail",
      recipient_domain: recipientDomain,
      thread_subject: threadSubject
    };
  }
  function inject(composeBody) {
    const sendBtn = findSendButton(composeBody);
    if (!sendBtn) return;
    const toolbar = sendBtn.parentElement;
    if (!toolbar || toolbar.hasAttribute(HOST_ATTR)) return;
    toolbar.setAttribute(HOST_ATTR, "1");
    const host = document.createElement("span");
    const shadow = host.attachShadow({ mode: "open" });
    let selectedTone = null;
    let lastRewriteId = null;
    let panelOpen = false;
    let detectedContextTwin = "professional";
    let contextOverride;
    shadow.innerHTML = `
    <style>${BUTTON_CSS}
    #wt-ctx-badge {
      display: inline-flex; align-items: center;
      height: 18px; padding: 0 7px; border-radius: 9999px;
      background: #EEF2FF; color: #4338CA; font-size: 10px; font-weight: 600;
      margin-left: 5px; cursor: pointer; white-space: nowrap;
      transition: background 0.1s;
    }
    #wt-ctx-badge:hover { background: #E0E7FF; }
    #wt-ctx-badge.hidden { display: none; }
    </style>
    <button id="wt-btn" title="Humanize with Writing Twin AI (Cmd+Shift+H)">\u2728 Humanize</button>
    <span id="wt-ctx-badge" class="hidden" title="Detected context \u2014 click to override"></span>
    <div id="wt-panel">
      <p class="wt-title">Rewrite tone</p>
      <div class="wt-tones">
        ${TONES.map((t) => `<button class="wt-tone" data-tone="${t.key}" data-color="${t.color}">${t.label}</button>`).join("")}
      </div>
      <button id="wt-rewrite" disabled>Rewrite \u2192</button>
      <div id="wt-status"></div>
      <div id="wt-limit">
        <p>You've used all your free rewrites this month.</p>
        <a href="https://writingtwinai.com/pricing" target="_blank" rel="noopener">Upgrade to Pro \u2014 $5/mo</a>
      </div>
      <div id="wt-actions">
        <button class="wt-action accept" id="wt-accept">\u2713 Keep it</button>
        <button class="wt-action reject" id="wt-reject">\u2717 Undo</button>
      </div>
    </div>
  `;
    const btn = shadow.getElementById("wt-btn");
    const ctxBadge = shadow.getElementById("wt-ctx-badge");
    const panel = shadow.getElementById("wt-panel");
    const rewriteBtn = shadow.getElementById("wt-rewrite");
    const statusEl = shadow.getElementById("wt-status");
    const limitEl = shadow.getElementById("wt-limit");
    const actionsEl = shadow.getElementById("wt-actions");
    const acceptBtn = shadow.getElementById("wt-accept");
    const rejectBtn = shadow.getElementById("wt-reject");
    shadow.querySelectorAll(".wt-tone").forEach((tonebtn) => {
      tonebtn.addEventListener("click", () => {
        shadow.querySelectorAll(".wt-tone").forEach((b) => b.classList.remove("active"));
        tonebtn.classList.add("active");
        tonebtn.style.background = tonebtn.dataset.color ?? "#4F46E5";
        tonebtn.style.borderColor = tonebtn.dataset.color ?? "#4F46E5";
        selectedTone = tonebtn.dataset.tone;
        rewriteBtn.disabled = false;
        statusEl.textContent = "";
        statusEl.className = "";
        limitEl.classList.remove("visible");
        actionsEl.classList.remove("visible");
      });
    });
    setTimeout(() => refreshContextBadge(), 800);
    function refreshContextBadge() {
      const ctx = buildGmailContext(composeBody);
      sendToBackground({
        type: "DETECT_CONTEXT",
        payload: ctx
      }).then((resp) => {
        if ("result" in resp && resp.result?.context_twin) {
          detectedContextTwin = resp.result.context_twin;
          showContextBadge(detectedContextTwin);
        }
      }).catch(() => {
      });
    }
    function showContextBadge(twin) {
      const label = twin.charAt(0).toUpperCase() + twin.slice(1);
      ctxBadge.textContent = label;
      ctxBadge.classList.remove("hidden");
    }
    const CONTEXT_CYCLE = ["professional", "customer", "technical", "escalation", "casual"];
    ctxBadge.addEventListener("click", () => {
      const current = contextOverride ?? detectedContextTwin;
      const idx = CONTEXT_CYCLE.indexOf(current);
      const next = CONTEXT_CYCLE[(idx + 1) % CONTEXT_CYCLE.length];
      contextOverride = next;
      showContextBadge(next);
      sendToBackground({
        type: "CONTEXT_OVERRIDE",
        payload: {
          detected_context: detectedContextTwin,
          selected_context: next,
          platform: "gmail"
        }
      });
    });
    btn.addEventListener("click", () => {
      panelOpen = !panelOpen;
      panel.classList.toggle("open", panelOpen);
      if (panelOpen) positionPanel();
    });
    document.addEventListener("click", (e) => {
      if (!host.contains(e.target) && panelOpen) {
        panelOpen = false;
        panel.classList.remove("open");
      }
    }, true);
    function positionPanel() {
      const rect = btn.getBoundingClientRect();
      panel.style.bottom = `${window.innerHeight - rect.top + 4}px`;
      panel.style.left = `${Math.min(rect.left, window.innerWidth - 276)}px`;
    }
    let originalText = "";
    rewriteBtn.addEventListener("click", async () => {
      if (!selectedTone) return;
      const text = composeBody.innerText.trim();
      if (!text) {
        setStatus("Write something first.", "error");
        return;
      }
      originalText = text;
      btn.disabled = true;
      rewriteBtn.disabled = true;
      setStatus("Rewriting\u2026");
      actionsEl.classList.remove("visible");
      try {
        const baseCtx = buildGmailContext(composeBody);
        const resp = await sendToBackground({
          type: "HUMANIZE",
          payload: {
            text,
            tone: selectedTone,
            ctx: { ...baseCtx, context_twin_override: contextOverride }
          }
        });
        if ("error" in resp) throw new Error(String(resp.error));
        lastRewriteId = resp.result.id;
        setComposeText(composeBody, resp.result.output_text);
        setStatus("Done \u2713", "success");
        actionsEl.classList.add("visible");
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Failed";
        if (msg.startsWith("LIMIT_REACHED:")) {
          limitEl.classList.add("visible");
          setStatus("");
        } else {
          setStatus(msg, "error");
        }
      } finally {
        btn.disabled = false;
        rewriteBtn.disabled = selectedTone === null;
      }
    });
    acceptBtn.addEventListener("click", async () => {
      if (lastRewriteId) {
        sendToBackground({ type: "FEEDBACK", payload: { rewriteId: lastRewriteId, action: "accepted" } });
      }
      actionsEl.classList.remove("visible");
      panelOpen = false;
      panel.classList.remove("open");
      setStatus("");
    });
    rejectBtn.addEventListener("click", async () => {
      if (originalText) setComposeText(composeBody, originalText);
      if (lastRewriteId) {
        sendToBackground({ type: "FEEDBACK", payload: { rewriteId: lastRewriteId, action: "rejected" } });
      }
      actionsEl.classList.remove("visible");
      setStatus("Reverted.", "success");
      setTimeout(() => setStatus(""), 2e3);
    });
    function setStatus(msg, cls = "") {
      statusEl.textContent = msg;
      statusEl.className = cls;
    }
    toolbar.insertBefore(host, sendBtn);
    injectMicButton(toolbar, composeBody);
    setTimeout(() => tryAutoDraft(composeBody), 500);
  }
  function findSendButton(composeBody) {
    let el = composeBody;
    for (let i = 0; i < 25; i++) {
      if (!el) break;
      const send = el.querySelector(SEND_BUTTON_SEL);
      if (send) return send;
      el = el.parentElement;
    }
    return null;
  }
  function setComposeText(el, text) {
    el.focus();
    document.execCommand("selectAll", false, void 0);
    document.execCommand("delete", false, void 0);
    const lines = text.split("\n");
    for (let i = 0; i < lines.length; i++) {
      if (lines[i]) document.execCommand("insertText", false, lines[i]);
      if (i < lines.length - 1) document.execCommand("insertParagraph", false, void 0);
    }
  }
  function sendToBackground(message) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(message, resolve);
    });
  }
  function findIncomingMessageEl(composeBody) {
    let el = composeBody;
    let threadContainer = null;
    for (let i = 0; i < 20; i++) {
      if (!el) break;
      if (el.querySelectorAll(".gs").length > 0) {
        threadContainer = el;
        break;
      }
      el = el.parentElement;
    }
    if (!threadContainer) return null;
    const rows = Array.from(threadContainer.querySelectorAll(".gs"));
    for (let i = rows.length - 1; i >= 0; i--) {
      if (!rows[i].contains(composeBody)) return rows[i];
    }
    return null;
  }
  function extractIncomingText(msgEl) {
    const bodyEl = msgEl.querySelector(".a3s.aiL") ?? msgEl.querySelector(".ii.gt") ?? msgEl.querySelector(".adn");
    if (!bodyEl) return null;
    const text = bodyEl.innerText.trim();
    if (text.length < 20) return null;
    return text.split(/\s+/).slice(0, 500).join(" ");
  }
  var AUTO_DRAFT_ATTR = "data-wt-autodraft";
  async function tryAutoDraft(composeBody) {
    if (composeBody.hasAttribute(AUTO_DRAFT_ATTR)) return;
    composeBody.setAttribute(AUTO_DRAFT_ATTR, "1");
    if (composeBody.innerText.trim() !== "") return;
    const incomingEl = findIncomingMessageEl(composeBody);
    if (!incomingEl) return;
    const incomingText = extractIncomingText(incomingEl);
    if (!incomingText) return;
    const ctx = buildGmailContext(composeBody);
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), AUTO_DRAFT_TIMEOUT_MS);
    let result;
    try {
      const resp = await Promise.race([
        sendToBackground({
          type: "AUTO_DRAFT",
          payload: {
            incomingText,
            tone: AUTO_DRAFT_DEFAULT_TONE,
            ctx
          }
        }),
        new Promise(
          (_, reject) => setTimeout(() => reject(new Error("timeout")), AUTO_DRAFT_TIMEOUT_MS)
        )
      ]);
      clearTimeout(timeoutId);
      if ("error" in resp) return;
      result = resp.result;
    } catch {
      clearTimeout(timeoutId);
      return;
    }
    if (composeBody.innerText.trim() !== "") return;
    showAutoDraftBanner(composeBody, result);
  }
  function showAutoDraftBanner(composeBody, result) {
    document.getElementById("wt-auto-draft-banner")?.remove();
    const banner = document.createElement("div");
    banner.id = "wt-auto-draft-banner";
    banner.style.cssText = `
    position: fixed; z-index: 9998;
    background: #EEF2FF; border: 1px solid #C7D2FE; border-radius: 10px;
    padding: 10px 14px; display: flex; align-items: center; gap: 10px;
    font: 13px/1.4 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    color: #312E81; box-shadow: 0 4px 16px rgba(79,70,229,0.12);
    max-width: 420px;
  `;
    const label = document.createElement("span");
    label.style.cssText = "font-weight: 600; white-space: nowrap;";
    label.textContent = "\u2726 Draft ready";
    const useBtn = document.createElement("button");
    useBtn.style.cssText = `
    height: 28px; padding: 0 12px; border-radius: 9999px; border: none;
    background: #4F46E5; color: #fff; font: 600 12px/1 inherit;
    cursor: pointer; white-space: nowrap;
  `;
    useBtn.textContent = "Use draft";
    const dismissBtn = document.createElement("button");
    dismissBtn.style.cssText = `
    height: 24px; width: 24px; border-radius: 9999px; border: none;
    background: transparent; color: #6366F1; font-size: 16px; line-height: 1;
    cursor: pointer; margin-left: auto; display: flex; align-items: center; justify-content: center;
  `;
    dismissBtn.title = "Dismiss";
    dismissBtn.textContent = "\u2715";
    banner.append(label, useBtn, dismissBtn);
    document.body.appendChild(banner);
    function positionBanner() {
      const rect = composeBody.getBoundingClientRect();
      banner.style.top = `${Math.max(rect.top - 52, 60)}px`;
      banner.style.left = `${Math.min(rect.left, window.innerWidth - 440)}px`;
    }
    positionBanner();
    window.addEventListener("resize", positionBanner, { passive: true });
    function removeBanner() {
      banner.remove();
      window.removeEventListener("resize", positionBanner);
    }
    useBtn.addEventListener("click", () => {
      setComposeText(composeBody, result.draft);
      sendToBackground({
        type: "AUTO_DRAFT_FEEDBACK",
        payload: { draftId: result.id, kept: true }
      });
      removeBanner();
    });
    dismissBtn.addEventListener("click", () => {
      sendToBackground({
        type: "AUTO_DRAFT_FEEDBACK",
        payload: { draftId: result.id, kept: false }
      });
      removeBanner();
    });
    const typingListener = () => {
      if (composeBody.innerText.trim() !== "") {
        sendToBackground({
          type: "AUTO_DRAFT_FEEDBACK",
          payload: { draftId: result.id, kept: false }
        });
        removeBanner();
        composeBody.removeEventListener("input", typingListener);
      }
    };
    composeBody.addEventListener("input", typingListener);
    setTimeout(removeBanner, 3e4);
  }
  var seen = /* @__PURE__ */ new WeakSet();
  function tryInject(root) {
    root.querySelectorAll(COMPOSE_BODY_SEL).forEach((body) => {
      if (!seen.has(body)) {
        seen.add(body);
        inject(body);
      }
    });
  }
  var observer = new MutationObserver(() => tryInject(document));
  observer.observe(document.body, { childList: true, subtree: true });
  tryInject(document);
  document.addEventListener("keydown", (e) => {
    const toolbar = document.querySelector(`[${HOST_ATTR}]`);
    if (!toolbar) return;
    const hosts = Array.from(toolbar.children).filter((c) => c.shadowRoot);
    if ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key === "H") {
      e.preventDefault();
      const btn = hosts[0]?.shadowRoot?.getElementById("wt-btn");
      btn?.click();
    }
    if ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key === "V") {
      e.preventDefault();
      const btn = hosts[1]?.shadowRoot?.getElementById("wt-mic-btn");
      btn?.click();
    }
  });
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vc3JjL2NvbnRlbnQvZ21haWwudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB0eXBlIHsgVG9uZSwgUmV3cml0ZVJlc3BvbnNlLCBWb2ljZU91dHB1dFR5cGUsIFZvaWNlRHJhZnRSZXNwb25zZSwgSHVtYW5pemVDb250ZXh0LCBBdXRvRHJhZnRSZXNwb25zZSB9IGZyb20gJy4uL2xpYi9hcGknO1xuXG4vLyBHbWFpbCBzZWxlY3RvcnMgXHUyMDE0IHVzZSBwcmVmaXgvc3Vic3RyaW5nIG1hdGNoZXMgc28gbG9jYWxlIHZhcmlhbnRzIHN0aWxsIG1hdGNoXG4vLyBlLmcuIHRvb2x0aXAgY2FuIGJlIFwiU2VuZFwiLCBcIlNlbmQgXHUyMzE4RW50ZXJcIiwgXCJTZW5kIChDdHJsK0VudGVyKVwiXG5jb25zdCBDT01QT1NFX0JPRFlfU0VMID0gJ1tnX2VkaXRhYmxlPVwidHJ1ZVwiXSwgZGl2W2NvbnRlbnRlZGl0YWJsZT1cInRydWVcIl1bYXJpYS1tdWx0aWxpbmU9XCJ0cnVlXCJdJztcbmNvbnN0IFNFTkRfQlVUVE9OX1NFTCA9ICdbZGF0YS10b29sdGlwXj1cIlNlbmRcIl0sIFthcmlhLWxhYmVsXj1cIlNlbmRcIl0nO1xuY29uc3QgSE9TVF9BVFRSID0gJ2RhdGEtd3QtaW5qZWN0ZWQnO1xuY29uc3QgQVVUT19EUkFGVF9USU1FT1VUX01TID0gMjAwMDtcbmNvbnN0IEFVVE9fRFJBRlRfREVGQVVMVF9UT05FOiBUb25lID0gJ3Byb2Zlc3Npb25hbCc7XG5cbi8vIFx1MjUwMFx1MjUwMCBUb25lIGNvbmZpZyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuY29uc3QgVE9ORVM6IHsga2V5OiBUb25lOyBsYWJlbDogc3RyaW5nOyBjb2xvcjogc3RyaW5nIH1bXSA9IFtcbiAgeyBrZXk6ICdwcm9mZXNzaW9uYWwnLCBsYWJlbDogJ1Byb2Zlc3Npb25hbCcsIGNvbG9yOiAnIzRGNDZFNScgfSxcbiAgeyBrZXk6ICdjYXN1YWwnLCAgICAgICBsYWJlbDogJ0Nhc3VhbCcsICAgICAgIGNvbG9yOiAnIzA2QjZENCcgfSxcbiAgeyBrZXk6ICdmcmllbmRseScsICAgICBsYWJlbDogJ0ZyaWVuZGx5JywgICAgIGNvbG9yOiAnI0Y1OUUwQicgfSxcbiAgeyBrZXk6ICdkaXJlY3QnLCAgICAgICBsYWJlbDogJ0RpcmVjdCcsICAgICAgIGNvbG9yOiAnI0RDMjYyNicgfSxcbiAgeyBrZXk6ICdkaXBsb21hdGljJywgICBsYWJlbDogJ0RpcGxvbWF0aWMnLCAgIGNvbG9yOiAnIzdDM0FFRCcgfSxcbiAgeyBrZXk6ICdleGVjdXRpdmUnLCAgICBsYWJlbDogJ0V4ZWN1dGl2ZScsICAgIGNvbG9yOiAnIzBGMTcyQScgfSxcbl07XG5cbi8vIFx1MjUwMFx1MjUwMCBTaGFkb3cgRE9NIHN0eWxlcyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuY29uc3QgQlVUVE9OX0NTUyA9IGBcbiAgOmhvc3QgeyBkaXNwbGF5OiBpbmxpbmUtZmxleDsgYWxpZ24taXRlbXM6IGNlbnRlcjsgbWFyZ2luLWxlZnQ6IDhweDsgfVxuXG4gICN3dC1idG4ge1xuICAgIGRpc3BsYXk6IGlubGluZS1mbGV4OyBhbGlnbi1pdGVtczogY2VudGVyOyBnYXA6IDVweDtcbiAgICBoZWlnaHQ6IDI4cHg7IHBhZGRpbmc6IDAgMTJweDsgYm9yZGVyLXJhZGl1czogOTk5OXB4OyBib3JkZXI6IG5vbmU7XG4gICAgYmFja2dyb3VuZDogIzRGNDZFNTsgY29sb3I6ICNmZmY7XG4gICAgZm9udDogNTAwIDEycHgvMSAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsIFwiU2Vnb2UgVUlcIiwgUm9ib3RvLCBzYW5zLXNlcmlmO1xuICAgIGN1cnNvcjogcG9pbnRlcjsgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICB0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kIDAuMTVzLCBib3gtc2hhZG93IDAuMTVzO1xuICB9XG4gICN3dC1idG46aG92ZXIgeyBiYWNrZ3JvdW5kOiAjM0YzN0M5OyBib3gtc2hhZG93OiAwIDAgMCAzcHggcmdiYSg3OSw3MCwyMjksMC4yNSk7IH1cbiAgI3d0LWJ0bjpkaXNhYmxlZCB7IG9wYWNpdHk6IDAuNjsgY3Vyc29yOiBkZWZhdWx0OyBib3gtc2hhZG93OiBub25lOyB9XG5cbiAgI3d0LXBhbmVsIHtcbiAgICBwb3NpdGlvbjogZml4ZWQ7IHotaW5kZXg6IDk5OTk7XG4gICAgYmFja2dyb3VuZDogI2ZmZjsgYm9yZGVyOiAxcHggc29saWQgI0U4RUFFRDsgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICBib3gtc2hhZG93OiAwIDEycHggMzJweCByZ2JhKDE1LDIzLDQyLDAuMTQpO1xuICAgIHBhZGRpbmc6IDE0cHggMTZweDsgd2lkdGg6IDI2MHB4O1xuICAgIGZvbnQtZmFtaWx5OiAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsIFwiU2Vnb2UgVUlcIiwgUm9ib3RvLCBzYW5zLXNlcmlmO1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH1cbiAgI3d0LXBhbmVsLm9wZW4geyBkaXNwbGF5OiBibG9jazsgfVxuXG4gIC53dC10aXRsZSB7XG4gICAgZm9udC1zaXplOiAxMnB4OyBmb250LXdlaWdodDogNjAwOyBjb2xvcjogIzM3NDE1MTsgbWFyZ2luOiAwIDAgMTBweDtcbiAgICBsZXR0ZXItc3BhY2luZzogMC4wNGVtOyB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICB9XG4gIC53dC10b25lcyB7XG4gICAgZGlzcGxheTogZmxleDsgZmxleC13cmFwOiB3cmFwOyBnYXA6IDZweDsgbWFyZ2luLWJvdHRvbTogMTJweDtcbiAgfVxuICAud3QtdG9uZSB7XG4gICAgcGFkZGluZzogNHB4IDEwcHg7IGJvcmRlci1yYWRpdXM6IDk5OTlweDsgYm9yZGVyOiAxLjVweCBzb2xpZCAjRThFQUVEO1xuICAgIGJhY2tncm91bmQ6ICNmZmY7IGZvbnQtc2l6ZTogMTJweDsgZm9udC13ZWlnaHQ6IDUwMDsgY29sb3I6ICMzNzQxNTE7XG4gICAgY3Vyc29yOiBwb2ludGVyOyB0cmFuc2l0aW9uOiBhbGwgMC4xcztcbiAgfVxuICAud3QtdG9uZS5hY3RpdmUge1xuICAgIGNvbG9yOiAjZmZmOyBib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICB9XG4gIC53dC10b25lOmhvdmVyOm5vdCguYWN0aXZlKSB7IGJvcmRlci1jb2xvcjogIzlCQTBGRjsgfVxuXG4gICN3dC1yZXdyaXRlIHtcbiAgICB3aWR0aDogMTAwJTsgaGVpZ2h0OiAzMnB4OyBib3JkZXItcmFkaXVzOiA4cHg7IGJvcmRlcjogbm9uZTtcbiAgICBiYWNrZ3JvdW5kOiAjNEY0NkU1OyBjb2xvcjogI2ZmZjtcbiAgICBmb250OiA2MDAgMTNweC8xIC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgXCJTZWdvZSBVSVwiLCBSb2JvdG8sIHNhbnMtc2VyaWY7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gICN3dC1yZXdyaXRlOmRpc2FibGVkIHsgb3BhY2l0eTogMC40NTsgY3Vyc29yOiBkZWZhdWx0OyB9XG5cbiAgI3d0LXN0YXR1cyB7XG4gICAgbWFyZ2luLXRvcDogOHB4OyBmb250LXNpemU6IDExcHg7IHRleHQtYWxpZ246IGNlbnRlcjsgbWluLWhlaWdodDogMTRweDtcbiAgfVxuICAjd3Qtc3RhdHVzLmVycm9yIHsgY29sb3I6ICNFRjQ0NDQ7IH1cbiAgI3d0LXN0YXR1cy5zdWNjZXNzIHsgY29sb3I6ICMxMEI5ODE7IH1cblxuICAjd3QtbGltaXQge1xuICAgIGRpc3BsYXk6IG5vbmU7IG1hcmdpbi10b3A6IDEwcHg7IHBhZGRpbmc6IDEwcHggMTJweDsgYm9yZGVyLXJhZGl1czogOHB4O1xuICAgIGJhY2tncm91bmQ6ICNGRkY4RjE7IGJvcmRlcjogMXB4IHNvbGlkICNGRUQ3QUE7IHRleHQtYWxpZ246IGNlbnRlcjtcbiAgfVxuICAjd3QtbGltaXQudmlzaWJsZSB7IGRpc3BsYXk6IGJsb2NrOyB9XG4gICN3dC1saW1pdCBwIHsgZm9udC1zaXplOiAxMXB4OyBjb2xvcjogIzkyNDAwRTsgbWFyZ2luOiAwIDAgOHB4OyBsaW5lLWhlaWdodDogMS40OyB9XG4gICN3dC1saW1pdCBhIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7IHBhZGRpbmc6IDVweCAxNHB4OyBib3JkZXItcmFkaXVzOiA5OTk5cHg7XG4gICAgYmFja2dyb3VuZDogI0Y1OUUwQjsgY29sb3I6ICNmZmY7IGZvbnQtc2l6ZTogMTFweDsgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gIH1cbiAgI3d0LWxpbWl0IGE6aG92ZXIgeyBiYWNrZ3JvdW5kOiAjRDk3NzA2OyB9XG5cbiAgI3d0LWFjdGlvbnMge1xuICAgIGRpc3BsYXk6IG5vbmU7IGdhcDogNnB4OyBtYXJnaW4tdG9wOiA4cHg7XG4gIH1cbiAgI3d0LWFjdGlvbnMudmlzaWJsZSB7IGRpc3BsYXk6IGZsZXg7IH1cbiAgLnd0LWFjdGlvbiB7XG4gICAgZmxleDogMTsgaGVpZ2h0OiAyOHB4OyBib3JkZXItcmFkaXVzOiA4cHg7IGJvcmRlcjogMS41cHggc29saWQgI0U4RUFFRDtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmOyBmb250LXNpemU6IDEycHg7IGZvbnQtd2VpZ2h0OiA1MDA7IGNvbG9yOiAjMzc0MTUxO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAud3QtYWN0aW9uLmFjY2VwdCB7IGJvcmRlci1jb2xvcjogIzEwQjk4MTsgY29sb3I6ICMxMEI5ODE7IH1cbiAgLnd0LWFjdGlvbi5yZWplY3QgeyBib3JkZXItY29sb3I6ICNFRjQ0NDQ7IGNvbG9yOiAjRUY0NDQ0OyB9XG5gO1xuXG4vLyBcdTI1MDBcdTI1MDAgVm9pY2Ugb3V0cHV0IHR5cGVzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5jb25zdCBWT0lDRV9PVVRQVVRfVFlQRVM6IHsga2V5OiBWb2ljZU91dHB1dFR5cGU7IGxhYmVsOiBzdHJpbmcgfVtdID0gW1xuICB7IGtleTogJ3JlcGx5JywgICAgICAgICAgIGxhYmVsOiAnUmVwbHknIH0sXG4gIHsga2V5OiAnZW1haWwnLCAgICAgICAgICAgbGFiZWw6ICdFbWFpbCcgfSxcbiAgeyBrZXk6ICdjdXN0b21lcl91cGRhdGUnLCBsYWJlbDogJ0N1c3RvbWVyIFVwZGF0ZScgfSxcbiAgeyBrZXk6ICdqaXJhX3RpY2tldCcsICAgICBsYWJlbDogJ0ppcmEgVGlja2V0JyB9LFxuICB7IGtleTogJ3RlY2huaWNhbF9yZXBvcnQnLGxhYmVsOiAnVGVjaCBSZXBvcnQnIH0sXG5dO1xuXG5jb25zdCBNSUNfQ1NTID0gYFxuICA6aG9zdCB7IGRpc3BsYXk6IGlubGluZS1mbGV4OyBhbGlnbi1pdGVtczogY2VudGVyOyBtYXJnaW4tbGVmdDogNHB4OyB9XG5cbiAgI3d0LW1pYy1idG4ge1xuICAgIGRpc3BsYXk6IGlubGluZS1mbGV4OyBhbGlnbi1pdGVtczogY2VudGVyOyBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICB3aWR0aDogMjhweDsgaGVpZ2h0OiAyOHB4OyBib3JkZXItcmFkaXVzOiA5OTk5cHg7IGJvcmRlcjogbm9uZTtcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDsgY29sb3I6ICM1RjYzNjg7IGN1cnNvcjogcG9pbnRlcjtcbiAgICB0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kIDAuMTVzLCBjb2xvciAwLjE1cztcbiAgICBmb250LXNpemU6IDE1cHg7IGxpbmUtaGVpZ2h0OiAxO1xuICB9XG4gICN3dC1taWMtYnRuOmhvdmVyIHsgYmFja2dyb3VuZDogcmdiYSgwLDAsMCwwLjA3KTsgfVxuICAjd3QtbWljLWJ0bi5yZWNvcmRpbmcge1xuICAgIGJhY2tncm91bmQ6ICNGRUUyRTI7IGNvbG9yOiAjREMyNjI2O1xuICAgIGFuaW1hdGlvbjogd3QtcHVsc2UgMS4ycyBlYXNlLWluLW91dCBpbmZpbml0ZTtcbiAgfVxuICBAa2V5ZnJhbWVzIHd0LXB1bHNlIHtcbiAgICAwJSwgMTAwJSB7IGJveC1zaGFkb3c6IDAgMCAwIDAgcmdiYSgyMjAsMzgsMzgsMC40KTsgfVxuICAgIDUwJSAgICAgICB7IGJveC1zaGFkb3c6IDAgMCAwIDVweCByZ2JhKDIyMCwzOCwzOCwwKTsgfVxuICB9XG4gICN3dC1taWMtYnRuOmRpc2FibGVkIHsgb3BhY2l0eTogMC41OyBjdXJzb3I6IGRlZmF1bHQ7IH1cblxuICAjd3Qtdm9pY2UtcGFuZWwge1xuICAgIHBvc2l0aW9uOiBmaXhlZDsgei1pbmRleDogOTk5OTtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmOyBib3JkZXI6IDFweCBzb2xpZCAjRThFQUVEOyBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIGJveC1zaGFkb3c6IDAgMTJweCAzMnB4IHJnYmEoMTUsMjMsNDIsMC4xNCk7XG4gICAgcGFkZGluZzogMTRweCAxNnB4OyB3aWR0aDogMjgwcHg7XG4gICAgZm9udC1mYW1pbHk6IC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgXCJTZWdvZSBVSVwiLCBSb2JvdG8sIHNhbnMtc2VyaWY7XG4gICAgZGlzcGxheTogbm9uZTtcbiAgfVxuICAjd3Qtdm9pY2UtcGFuZWwub3BlbiB7IGRpc3BsYXk6IGJsb2NrOyB9XG5cbiAgLnd0LXZ0IHsgZm9udC1zaXplOiAxMnB4OyBmb250LXdlaWdodDogNjAwOyBjb2xvcjogIzM3NDE1MTsgbWFyZ2luOiAwIDAgMTBweDtcbiAgICBsZXR0ZXItc3BhY2luZzogMC4wNGVtOyB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlOyB9XG5cbiAgI3d0LXJlY29yZC1idG4ge1xuICAgIHdpZHRoOiAxMDAlOyBoZWlnaHQ6IDM0cHg7IGJvcmRlci1yYWRpdXM6IDhweDsgYm9yZGVyOiBub25lO1xuICAgIGJhY2tncm91bmQ6ICNEQzI2MjY7IGNvbG9yOiAjZmZmOyBjdXJzb3I6IHBvaW50ZXI7XG4gICAgZm9udDogNjAwIDEzcHgvMSAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsIFwiU2Vnb2UgVUlcIiwgUm9ib3RvLCBzYW5zLXNlcmlmO1xuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIH1cbiAgI3d0LXJlY29yZC1idG4ucmVjb3JkaW5nIHsgYmFja2dyb3VuZDogIzdGMUQxRDsgfVxuICAjd3QtcmVjb3JkLWJ0bjpkaXNhYmxlZCB7IG9wYWNpdHk6IDAuNTsgY3Vyc29yOiBkZWZhdWx0OyB9XG5cbiAgLnd0LW90eXBlLWxhYmVsIHsgZm9udC1zaXplOiAxMXB4OyBjb2xvcjogIzZCNzI4MDsgbWFyZ2luLWJvdHRvbTogNHB4OyB9XG4gIC53dC1vdHlwZXMgeyBkaXNwbGF5OiBmbGV4OyBmbGV4LXdyYXA6IHdyYXA7IGdhcDogNXB4OyBtYXJnaW4tYm90dG9tOiAxMHB4OyB9XG4gIC53dC1vdHlwZSB7XG4gICAgcGFkZGluZzogM3B4IDlweDsgYm9yZGVyLXJhZGl1czogOTk5OXB4OyBib3JkZXI6IDEuNXB4IHNvbGlkICNFOEVBRUQ7XG4gICAgYmFja2dyb3VuZDogI2ZmZjsgZm9udC1zaXplOiAxMXB4OyBjb2xvcjogIzM3NDE1MTsgY3Vyc29yOiBwb2ludGVyO1xuICAgIHRyYW5zaXRpb246IGFsbCAwLjFzO1xuICB9XG4gIC53dC1vdHlwZS5hY3RpdmUgeyBiYWNrZ3JvdW5kOiAjNEY0NkU1OyBjb2xvcjogI2ZmZjsgYm9yZGVyLWNvbG9yOiAjNEY0NkU1OyB9XG5cbiAgI3d0LXZvaWNlLXN0YXR1cyB7IGZvbnQtc2l6ZTogMTFweDsgdGV4dC1hbGlnbjogY2VudGVyOyBtaW4taGVpZ2h0OiAxNHB4OyBjb2xvcjogIzZCNzI4MDsgfVxuICAjd3Qtdm9pY2Utc3RhdHVzLmVycm9yIHsgY29sb3I6ICNFRjQ0NDQ7IH1cblxuICAjd3Qtdm9pY2UtYWN0aW9ucyB7IGRpc3BsYXk6IG5vbmU7IGdhcDogNnB4OyBtYXJnaW4tdG9wOiA4cHg7IH1cbiAgI3d0LXZvaWNlLWFjdGlvbnMudmlzaWJsZSB7IGRpc3BsYXk6IGZsZXg7IH1cbiAgLnd0LXZhIHtcbiAgICBmbGV4OiAxOyBoZWlnaHQ6IDI4cHg7IGJvcmRlci1yYWRpdXM6IDhweDsgYm9yZGVyOiAxLjVweCBzb2xpZCAjRThFQUVEO1xuICAgIGJhY2tncm91bmQ6ICNmZmY7IGZvbnQtc2l6ZTogMTJweDsgZm9udC13ZWlnaHQ6IDUwMDsgY29sb3I6ICMzNzQxNTE7IGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAud3QtdmEuYWNjZXB0IHsgYm9yZGVyLWNvbG9yOiAjMTBCOTgxOyBjb2xvcjogIzEwQjk4MTsgfVxuICAud3QtdmEucmVqZWN0IHsgYm9yZGVyLWNvbG9yOiAjRUY0NDQ0OyBjb2xvcjogI0VGNDQ0NDsgfVxuYDtcblxuLy8gXHUyNTAwXHUyNTAwIEluamVjdCBWb2ljZSBUd2luIG1pYyBidXR0b24gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmZ1bmN0aW9uIGluamVjdE1pY0J1dHRvbih0b29sYmFyOiBFbGVtZW50LCBjb21wb3NlQm9keTogRWxlbWVudCk6IHZvaWQge1xuICBjb25zdCBtaWNIb3N0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICBjb25zdCBzaGFkb3cgPSBtaWNIb3N0LmF0dGFjaFNoYWRvdyh7IG1vZGU6ICdvcGVuJyB9KTtcblxuICBzaGFkb3cuaW5uZXJIVE1MID0gYFxuICAgIDxzdHlsZT4ke01JQ19DU1N9PC9zdHlsZT5cbiAgICA8YnV0dG9uIGlkPVwid3QtbWljLWJ0blwiIHRpdGxlPVwiVm9pY2UgVHdpbiBcdTIwMTQgc3BlYWsgeW91ciBlbWFpbCAoQ21kK1NoaWZ0K1YpXCI+XHVEODNDXHVERjk5PC9idXR0b24+XG4gICAgPGRpdiBpZD1cInd0LXZvaWNlLXBhbmVsXCI+XG4gICAgICA8cCBjbGFzcz1cInd0LXZ0XCI+Vm9pY2UgVHdpbjwvcD5cbiAgICAgIDxkaXYgY2xhc3M9XCJ3dC1vdHlwZS1sYWJlbFwiPk91dHB1dCB0eXBlPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzPVwid3Qtb3R5cGVzXCI+XG4gICAgICAgICR7Vk9JQ0VfT1VUUFVUX1RZUEVTLm1hcCgobywgaSkgPT5cbiAgICAgICAgICBgPGJ1dHRvbiBjbGFzcz1cInd0LW90eXBlJHtpID09PSAwID8gJyBhY3RpdmUnIDogJyd9XCIgZGF0YS10eXBlPVwiJHtvLmtleX1cIj4ke28ubGFiZWx9PC9idXR0b24+YFxuICAgICAgICApLmpvaW4oJycpfVxuICAgICAgPC9kaXY+XG4gICAgICA8YnV0dG9uIGlkPVwid3QtcmVjb3JkLWJ0blwiPlx1RDgzQ1x1REY5OSBTdGFydCByZWNvcmRpbmc8L2J1dHRvbj5cbiAgICAgIDxkaXYgaWQ9XCJ3dC12b2ljZS1zdGF0dXNcIj48L2Rpdj5cbiAgICAgIDxkaXYgaWQ9XCJ3dC12b2ljZS1hY3Rpb25zXCI+XG4gICAgICAgIDxidXR0b24gY2xhc3M9XCJ3dC12YSBhY2NlcHRcIiBpZD1cInd0LXZhLWtlZXBcIj5cdTI3MTMgS2VlcCBpdDwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uIGNsYXNzPVwid3QtdmEgcmVqZWN0XCIgaWQ9XCJ3dC12YS11bmRvXCI+XHUyNzE3IFVuZG88L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIGNvbnN0IG1pY0J0biAgICAgID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC1taWMtYnRuJykgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG4gIGNvbnN0IHBhbmVsICAgICAgID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC12b2ljZS1wYW5lbCcpIGFzIEhUTUxEaXZFbGVtZW50O1xuICBjb25zdCByZWNvcmRCdG4gICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtcmVjb3JkLWJ0bicpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICBjb25zdCBzdGF0dXNFbCAgICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3Qtdm9pY2Utc3RhdHVzJykgYXMgSFRNTERpdkVsZW1lbnQ7XG4gIGNvbnN0IGFjdGlvbnNFbCAgID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC12b2ljZS1hY3Rpb25zJykgYXMgSFRNTERpdkVsZW1lbnQ7XG4gIGNvbnN0IGtlZXBCdG4gICAgID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC12YS1rZWVwJykgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG4gIGNvbnN0IHVuZG9CdG4gICAgID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC12YS11bmRvJykgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG5cbiAgbGV0IHBhbmVsT3BlbiA9IGZhbHNlO1xuICBsZXQgc2VsZWN0ZWRUeXBlOiBWb2ljZU91dHB1dFR5cGUgPSAncmVwbHknO1xuICBsZXQgcmVjb3JkZXI6IE1lZGlhUmVjb3JkZXIgfCBudWxsID0gbnVsbDtcbiAgbGV0IHJlY29yZGluZyA9IGZhbHNlO1xuICBsZXQgY2h1bmtzOiBCbG9iUGFydFtdID0gW107XG4gIGxldCBsYXN0U2Vzc2lvbklkOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcbiAgbGV0IG9yaWdpbmFsVGV4dCA9ICcnO1xuXG4gIC8vIE91dHB1dCB0eXBlIHNlbGVjdGlvblxuICBzaGFkb3cucXVlcnlTZWxlY3RvckFsbDxIVE1MQnV0dG9uRWxlbWVudD4oJy53dC1vdHlwZScpLmZvckVhY2goYnRuID0+IHtcbiAgICBidG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgICBzaGFkb3cucXVlcnlTZWxlY3RvckFsbCgnLnd0LW90eXBlJykuZm9yRWFjaChiID0+IGIuY2xhc3NMaXN0LnJlbW92ZSgnYWN0aXZlJykpO1xuICAgICAgYnRuLmNsYXNzTGlzdC5hZGQoJ2FjdGl2ZScpO1xuICAgICAgc2VsZWN0ZWRUeXBlID0gYnRuLmRhdGFzZXQudHlwZSBhcyBWb2ljZU91dHB1dFR5cGU7XG4gICAgfSk7XG4gIH0pO1xuXG4gIG1pY0J0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBwYW5lbE9wZW4gPSAhcGFuZWxPcGVuO1xuICAgIHBhbmVsLmNsYXNzTGlzdC50b2dnbGUoJ29wZW4nLCBwYW5lbE9wZW4pO1xuICAgIGlmIChwYW5lbE9wZW4pIHBvc2l0aW9uUGFuZWwoKTtcbiAgfSk7XG5cbiAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZSkgPT4ge1xuICAgIGlmICghbWljSG9zdC5jb250YWlucyhlLnRhcmdldCBhcyBOb2RlKSAmJiBwYW5lbE9wZW4pIHtcbiAgICAgIHBhbmVsT3BlbiA9IGZhbHNlO1xuICAgICAgcGFuZWwuY2xhc3NMaXN0LnJlbW92ZSgnb3BlbicpO1xuICAgIH1cbiAgfSwgdHJ1ZSk7XG5cbiAgZnVuY3Rpb24gcG9zaXRpb25QYW5lbCgpOiB2b2lkIHtcbiAgICBjb25zdCByZWN0ID0gbWljQnRuLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIHBhbmVsLnN0eWxlLmJvdHRvbSA9IGAke3dpbmRvdy5pbm5lckhlaWdodCAtIHJlY3QudG9wICsgNH1weGA7XG4gICAgcGFuZWwuc3R5bGUubGVmdCA9IGAke01hdGgubWluKHJlY3QubGVmdCwgd2luZG93LmlubmVyV2lkdGggLSAyOTYpfXB4YDtcbiAgfVxuXG4gIHJlY29yZEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgICBpZiAoIXJlY29yZGluZykge1xuICAgICAgYXdhaXQgc3RhcnRSZWNvcmRpbmcoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgc3RvcFJlY29yZGluZygpO1xuICAgIH1cbiAgfSk7XG5cbiAgYXN5bmMgZnVuY3Rpb24gc3RhcnRSZWNvcmRpbmcoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHN0cmVhbSA9IGF3YWl0IG5hdmlnYXRvci5tZWRpYURldmljZXMuZ2V0VXNlck1lZGlhKHsgYXVkaW86IHRydWUgfSk7XG4gICAgICBjaHVua3MgPSBbXTtcbiAgICAgIHJlY29yZGVyID0gbmV3IE1lZGlhUmVjb3JkZXIoc3RyZWFtLCB7IG1pbWVUeXBlOiAnYXVkaW8vd2VibScgfSk7XG5cbiAgICAgIHJlY29yZGVyLm9uZGF0YWF2YWlsYWJsZSA9IChlKSA9PiB7XG4gICAgICAgIGlmIChlLmRhdGEuc2l6ZSA+IDApIGNodW5rcy5wdXNoKGUuZGF0YSk7XG4gICAgICB9O1xuXG4gICAgICByZWNvcmRlci5vbnN0b3AgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIHN0cmVhbS5nZXRUcmFja3MoKS5mb3JFYWNoKHQgPT4gdC5zdG9wKCkpO1xuICAgICAgICBjb25zdCBibG9iID0gbmV3IEJsb2IoY2h1bmtzLCB7IHR5cGU6ICdhdWRpby93ZWJtJyB9KTtcbiAgICAgICAgYXdhaXQgc3VibWl0Vm9pY2UoYmxvYik7XG4gICAgICB9O1xuXG4gICAgICByZWNvcmRlci5zdGFydCgpO1xuICAgICAgcmVjb3JkaW5nID0gdHJ1ZTtcbiAgICAgIG1pY0J0bi5jbGFzc0xpc3QuYWRkKCdyZWNvcmRpbmcnKTtcbiAgICAgIHJlY29yZEJ0bi5jbGFzc0xpc3QuYWRkKCdyZWNvcmRpbmcnKTtcbiAgICAgIHJlY29yZEJ0bi50ZXh0Q29udGVudCA9ICdcdTIzRjkgU3RvcCByZWNvcmRpbmcnO1xuICAgICAgc2V0Vm9pY2VTdGF0dXMoJ1JlY29yZGluZ1x1MjAyNicpO1xuICAgICAgYWN0aW9uc0VsLmNsYXNzTGlzdC5yZW1vdmUoJ3Zpc2libGUnKTtcblxuICAgICAgLy8gQXV0by1zdG9wIGF0IDYwIHNlY29uZHNcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBpZiAocmVjb3JkaW5nKSBzdG9wUmVjb3JkaW5nKCk7XG4gICAgICB9LCA2MF8wMDApO1xuICAgIH0gY2F0Y2gge1xuICAgICAgc2V0Vm9pY2VTdGF0dXMoJ01pY3JvcGhvbmUgYWNjZXNzIGRlbmllZC4nLCAnZXJyb3InKTtcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBzdG9wUmVjb3JkaW5nKCk6IHZvaWQge1xuICAgIGlmIChyZWNvcmRlciAmJiByZWNvcmRpbmcpIHtcbiAgICAgIHJlY29yZGVyLnN0b3AoKTtcbiAgICAgIHJlY29yZGluZyA9IGZhbHNlO1xuICAgICAgbWljQnRuLmNsYXNzTGlzdC5yZW1vdmUoJ3JlY29yZGluZycpO1xuICAgICAgcmVjb3JkQnRuLmNsYXNzTGlzdC5yZW1vdmUoJ3JlY29yZGluZycpO1xuICAgICAgcmVjb3JkQnRuLnRleHRDb250ZW50ID0gJ1x1RDgzQ1x1REY5OSBTdGFydCByZWNvcmRpbmcnO1xuICAgICAgcmVjb3JkQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgICAgIHNldFZvaWNlU3RhdHVzKCdEcmFmdGluZ1x1MjAyNicpO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIHN1Ym1pdFZvaWNlKGJsb2I6IEJsb2IpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgYXJyYXlCdWYgPSBhd2FpdCBibG9iLmFycmF5QnVmZmVyKCk7XG4gICAgICBjb25zdCB1aW50OCA9IG5ldyBVaW50OEFycmF5KGFycmF5QnVmKTtcbiAgICAgIGxldCBiaW5hcnkgPSAnJztcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdWludDgubGVuZ3RoOyBpKyspIGJpbmFyeSArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKHVpbnQ4W2ldKTtcbiAgICAgIGNvbnN0IGF1ZGlvRGF0YSA9IGJ0b2EoYmluYXJ5KTtcblxuICAgICAgb3JpZ2luYWxUZXh0ID0gKGNvbXBvc2VCb2R5IGFzIEhUTUxFbGVtZW50KS5pbm5lclRleHQudHJpbSgpO1xuXG4gICAgICBjb25zdCByZXNwID0gYXdhaXQgc2VuZFRvQmFja2dyb3VuZDx7IHJlc3VsdDogVm9pY2VEcmFmdFJlc3BvbnNlIH0gfCB7IGVycm9yOiBzdHJpbmcgfT4oe1xuICAgICAgICB0eXBlOiAnVk9JQ0VfRFJBRlQnLFxuICAgICAgICBwYXlsb2FkOiB7IGF1ZGlvRGF0YSwgbWltZVR5cGU6ICdhdWRpby93ZWJtJywgb3V0cHV0VHlwZTogc2VsZWN0ZWRUeXBlIH0sXG4gICAgICB9KTtcblxuICAgICAgaWYgKCdlcnJvcicgaW4gcmVzcCkgdGhyb3cgbmV3IEVycm9yKFN0cmluZyhyZXNwLmVycm9yKSk7XG5cbiAgICAgIGxhc3RTZXNzaW9uSWQgPSByZXNwLnJlc3VsdC5pZDtcbiAgICAgIHNldENvbXBvc2VUZXh0KGNvbXBvc2VCb2R5IGFzIEhUTUxFbGVtZW50LCByZXNwLnJlc3VsdC5kcmFmdCk7XG4gICAgICBzZXRWb2ljZVN0YXR1cygnRG9uZSBcdTI3MTMnKTtcbiAgICAgIGFjdGlvbnNFbC5jbGFzc0xpc3QuYWRkKCd2aXNpYmxlJyk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zdCBtc2cgPSBlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogJ0ZhaWxlZCc7XG4gICAgICBzZXRWb2ljZVN0YXR1cyhtc2csICdlcnJvcicpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICByZWNvcmRCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgICB9XG4gIH1cblxuICBrZWVwQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgIGlmIChsYXN0U2Vzc2lvbklkKSB7XG4gICAgICBzZW5kVG9CYWNrZ3JvdW5kKHtcbiAgICAgICAgdHlwZTogJ1ZPSUNFX0ZFRURCQUNLJyxcbiAgICAgICAgcGF5bG9hZDogeyBzZXNzaW9uSWQ6IGxhc3RTZXNzaW9uSWQsIGFjY2VwdGVkOiB0cnVlLCBlZGl0ZWREcmFmdDogbnVsbCB9LFxuICAgICAgfSk7XG4gICAgfVxuICAgIGFjdGlvbnNFbC5jbGFzc0xpc3QucmVtb3ZlKCd2aXNpYmxlJyk7XG4gICAgcGFuZWxPcGVuID0gZmFsc2U7XG4gICAgcGFuZWwuY2xhc3NMaXN0LnJlbW92ZSgnb3BlbicpO1xuICAgIHNldFZvaWNlU3RhdHVzKCcnKTtcbiAgfSk7XG5cbiAgdW5kb0J0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBpZiAob3JpZ2luYWxUZXh0KSBzZXRDb21wb3NlVGV4dChjb21wb3NlQm9keSBhcyBIVE1MRWxlbWVudCwgb3JpZ2luYWxUZXh0KTtcbiAgICBpZiAobGFzdFNlc3Npb25JZCkge1xuICAgICAgc2VuZFRvQmFja2dyb3VuZCh7XG4gICAgICAgIHR5cGU6ICdWT0lDRV9GRUVEQkFDSycsXG4gICAgICAgIHBheWxvYWQ6IHsgc2Vzc2lvbklkOiBsYXN0U2Vzc2lvbklkLCBhY2NlcHRlZDogZmFsc2UsIGVkaXRlZERyYWZ0OiBudWxsIH0sXG4gICAgICB9KTtcbiAgICB9XG4gICAgYWN0aW9uc0VsLmNsYXNzTGlzdC5yZW1vdmUoJ3Zpc2libGUnKTtcbiAgICBzZXRWb2ljZVN0YXR1cygnUmV2ZXJ0ZWQuJywgJ3N1Y2Nlc3MnKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHNldFZvaWNlU3RhdHVzKCcnKSwgMjAwMCk7XG4gIH0pO1xuXG4gIGZ1bmN0aW9uIHNldFZvaWNlU3RhdHVzKG1zZzogc3RyaW5nLCBjbHMgPSAnJyk6IHZvaWQge1xuICAgIHN0YXR1c0VsLnRleHRDb250ZW50ID0gbXNnO1xuICAgIHN0YXR1c0VsLmNsYXNzTmFtZSA9IGNscztcbiAgfVxuXG4gIC8vIEluc2VydCBtaWMgaG9zdCBhZnRlciB0aGUgaHVtYW5pemUgaG9zdCAod2hpY2ggaXMgcmlnaHQgYmVmb3JlIHRoZSBTZW5kIGJ1dHRvbilcbiAgY29uc3QgaHVtYW5pemVIb3N0ID0gQXJyYXkuZnJvbSh0b29sYmFyLmNoaWxkcmVuKS5maW5kKGMgPT4gYy5zaGFkb3dSb290KTtcbiAgaWYgKGh1bWFuaXplSG9zdCkge1xuICAgIHRvb2xiYXIuaW5zZXJ0QmVmb3JlKG1pY0hvc3QsIGh1bWFuaXplSG9zdC5uZXh0U2libGluZyk7XG4gIH0gZWxzZSB7XG4gICAgY29uc3Qgc2VuZEJ0biA9IHRvb2xiYXIucXVlcnlTZWxlY3RvcihTRU5EX0JVVFRPTl9TRUwpO1xuICAgIGlmIChzZW5kQnRuKSB0b29sYmFyLmluc2VydEJlZm9yZShtaWNIb3N0LCBzZW5kQnRuKTtcbiAgICBlbHNlIHRvb2xiYXIuYXBwZW5kQ2hpbGQobWljSG9zdCk7XG4gIH1cbn1cblxuLy8gXHUyNTAwXHUyNTAwIENvbnRleHQgaGVscGVycyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuZnVuY3Rpb24gYnVpbGRHbWFpbENvbnRleHQoY29tcG9zZUJvZHk6IEVsZW1lbnQpOiBIdW1hbml6ZUNvbnRleHQge1xuICAvLyBXYWxrIHVwIHRvIGNvbXBvc2UgY29udGFpbmVyIGFuZCByZWFkIFRvIGZpZWxkICsgU3ViamVjdFxuICBsZXQgZWw6IEVsZW1lbnQgfCBudWxsID0gY29tcG9zZUJvZHk7XG4gIGxldCBjb250YWluZXI6IEVsZW1lbnQgfCBudWxsID0gbnVsbDtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCAyMDsgaSsrKSB7XG4gICAgaWYgKCFlbCkgYnJlYWs7XG4gICAgaWYgKGVsLnF1ZXJ5U2VsZWN0b3IoJ1tkYXRhLWhvdmVyY2FyZC1pZF0sIFtlbWFpbF0nKSkgeyBjb250YWluZXIgPSBlbDsgYnJlYWs7IH1cbiAgICBlbCA9IGVsLnBhcmVudEVsZW1lbnQ7XG4gIH1cblxuICBsZXQgcmVjaXBpZW50RG9tYWluOiBzdHJpbmcgfCB1bmRlZmluZWQ7XG4gIGxldCB0aHJlYWRTdWJqZWN0OiBzdHJpbmcgfCB1bmRlZmluZWQ7XG5cbiAgaWYgKGNvbnRhaW5lcikge1xuICAgIC8vIFJlY2lwaWVudCBlbWFpbCBjaGlwOiBbZW1haWw9XCJ1c2VyQGRvbWFpbi5jb21cIl0gb3IgZGF0YS1ob3ZlcmNhcmQtaWRcbiAgICBjb25zdCBjaGlwID0gY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3I8SFRNTEVsZW1lbnQ+KCdbZW1haWxdLCBbZGF0YS1ob3ZlcmNhcmQtaWRdJyk7XG4gICAgY29uc3QgZW1haWwgPSBjaGlwPy5nZXRBdHRyaWJ1dGUoJ2VtYWlsJykgPz8gY2hpcD8uZ2V0QXR0cmlidXRlKCdkYXRhLWhvdmVyY2FyZC1pZCcpID8/ICcnO1xuICAgIGlmIChlbWFpbC5pbmNsdWRlcygnQCcpKSByZWNpcGllbnREb21haW4gPSBlbWFpbC5zcGxpdCgnQCcpWzFdLnRvTG93ZXJDYXNlKCk7XG5cbiAgICAvLyBTdWJqZWN0IGlucHV0XG4gICAgY29uc3Qgc3ViamVjdEVsID0gY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3I8SFRNTElucHV0RWxlbWVudD4oJ2lucHV0W25hbWU9XCJzdWJqZWN0Ym94XCJdJyk7XG4gICAgaWYgKHN1YmplY3RFbD8udmFsdWUpIHRocmVhZFN1YmplY3QgPSBzdWJqZWN0RWwudmFsdWU7XG4gIH1cblxuICByZXR1cm4ge1xuICAgIHBsYXRmb3JtOiAnZ21haWwnLFxuICAgIHJlY2lwaWVudF9kb21haW46IHJlY2lwaWVudERvbWFpbixcbiAgICB0aHJlYWRfc3ViamVjdDogdGhyZWFkU3ViamVjdCxcbiAgfTtcbn1cblxuLy8gXHUyNTAwXHUyNTAwIEluamVjdCBIdW1hbml6ZSBidXR0b24gaW50byBhIGNvbXBvc2Ugd2luZG93IFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5mdW5jdGlvbiBpbmplY3QoY29tcG9zZUJvZHk6IEVsZW1lbnQpOiB2b2lkIHtcbiAgLy8gRmluZCB0aGUgcGFyZW50IGNvbXBvc2UgY29udGFpbmVyICh3YWxrIHVwIHRvIGZpbmQgZWxlbWVudCB3aXRoIFNlbmQgYnV0dG9uKVxuICBjb25zdCBzZW5kQnRuID0gZmluZFNlbmRCdXR0b24oY29tcG9zZUJvZHkpO1xuICBpZiAoIXNlbmRCdG4pIHJldHVybjtcblxuICBjb25zdCB0b29sYmFyID0gc2VuZEJ0bi5wYXJlbnRFbGVtZW50O1xuICBpZiAoIXRvb2xiYXIgfHwgdG9vbGJhci5oYXNBdHRyaWJ1dGUoSE9TVF9BVFRSKSkgcmV0dXJuO1xuXG4gIHRvb2xiYXIuc2V0QXR0cmlidXRlKEhPU1RfQVRUUiwgJzEnKTtcblxuICAvLyBDcmVhdGUgc2hhZG93IGhvc3RcbiAgY29uc3QgaG9zdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgY29uc3Qgc2hhZG93ID0gaG9zdC5hdHRhY2hTaGFkb3coeyBtb2RlOiAnb3BlbicgfSk7XG5cbiAgLy8gU3RhdGVcbiAgbGV0IHNlbGVjdGVkVG9uZTogVG9uZSB8IG51bGwgPSBudWxsO1xuICBsZXQgbGFzdFJld3JpdGVJZDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG4gIGxldCBwYW5lbE9wZW4gPSBmYWxzZTtcbiAgbGV0IGRldGVjdGVkQ29udGV4dFR3aW4gPSAncHJvZmVzc2lvbmFsJztcbiAgbGV0IGNvbnRleHRPdmVycmlkZTogc3RyaW5nIHwgdW5kZWZpbmVkO1xuXG4gIHNoYWRvdy5pbm5lckhUTUwgPSBgXG4gICAgPHN0eWxlPiR7QlVUVE9OX0NTU31cbiAgICAjd3QtY3R4LWJhZGdlIHtcbiAgICAgIGRpc3BsYXk6IGlubGluZS1mbGV4OyBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgaGVpZ2h0OiAxOHB4OyBwYWRkaW5nOiAwIDdweDsgYm9yZGVyLXJhZGl1czogOTk5OXB4O1xuICAgICAgYmFja2dyb3VuZDogI0VFRjJGRjsgY29sb3I6ICM0MzM4Q0E7IGZvbnQtc2l6ZTogMTBweDsgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICAgIG1hcmdpbi1sZWZ0OiA1cHg7IGN1cnNvcjogcG9pbnRlcjsgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICAgIHRyYW5zaXRpb246IGJhY2tncm91bmQgMC4xcztcbiAgICB9XG4gICAgI3d0LWN0eC1iYWRnZTpob3ZlciB7IGJhY2tncm91bmQ6ICNFMEU3RkY7IH1cbiAgICAjd3QtY3R4LWJhZGdlLmhpZGRlbiB7IGRpc3BsYXk6IG5vbmU7IH1cbiAgICA8L3N0eWxlPlxuICAgIDxidXR0b24gaWQ9XCJ3dC1idG5cIiB0aXRsZT1cIkh1bWFuaXplIHdpdGggV3JpdGluZyBUd2luIEFJIChDbWQrU2hpZnQrSClcIj5cdTI3MjggSHVtYW5pemU8L2J1dHRvbj5cbiAgICA8c3BhbiBpZD1cInd0LWN0eC1iYWRnZVwiIGNsYXNzPVwiaGlkZGVuXCIgdGl0bGU9XCJEZXRlY3RlZCBjb250ZXh0IFx1MjAxNCBjbGljayB0byBvdmVycmlkZVwiPjwvc3Bhbj5cbiAgICA8ZGl2IGlkPVwid3QtcGFuZWxcIj5cbiAgICAgIDxwIGNsYXNzPVwid3QtdGl0bGVcIj5SZXdyaXRlIHRvbmU8L3A+XG4gICAgICA8ZGl2IGNsYXNzPVwid3QtdG9uZXNcIj5cbiAgICAgICAgJHtUT05FUy5tYXAodCA9PiBgPGJ1dHRvbiBjbGFzcz1cInd0LXRvbmVcIiBkYXRhLXRvbmU9XCIke3Qua2V5fVwiIGRhdGEtY29sb3I9XCIke3QuY29sb3J9XCI+JHt0LmxhYmVsfTwvYnV0dG9uPmApLmpvaW4oJycpfVxuICAgICAgPC9kaXY+XG4gICAgICA8YnV0dG9uIGlkPVwid3QtcmV3cml0ZVwiIGRpc2FibGVkPlJld3JpdGUgXHUyMTkyPC9idXR0b24+XG4gICAgICA8ZGl2IGlkPVwid3Qtc3RhdHVzXCI+PC9kaXY+XG4gICAgICA8ZGl2IGlkPVwid3QtbGltaXRcIj5cbiAgICAgICAgPHA+WW91J3ZlIHVzZWQgYWxsIHlvdXIgZnJlZSByZXdyaXRlcyB0aGlzIG1vbnRoLjwvcD5cbiAgICAgICAgPGEgaHJlZj1cImh0dHBzOi8vd3JpdGluZ3R3aW5haS5jb20vcHJpY2luZ1wiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyXCI+VXBncmFkZSB0byBQcm8gXHUyMDE0ICQ1L21vPC9hPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGlkPVwid3QtYWN0aW9uc1wiPlxuICAgICAgICA8YnV0dG9uIGNsYXNzPVwid3QtYWN0aW9uIGFjY2VwdFwiIGlkPVwid3QtYWNjZXB0XCI+XHUyNzEzIEtlZXAgaXQ8L2J1dHRvbj5cbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cInd0LWFjdGlvbiByZWplY3RcIiBpZD1cInd0LXJlamVjdFwiPlx1MjcxNyBVbmRvPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgYDtcblxuICBjb25zdCBidG4gICAgICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtYnRuJykgICAgICAgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG4gIGNvbnN0IGN0eEJhZGdlID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC1jdHgtYmFkZ2UnKSBhcyBIVE1MU3BhbkVsZW1lbnQ7XG4gIGNvbnN0IHBhbmVsICAgID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC1wYW5lbCcpICAgICBhcyBIVE1MRGl2RWxlbWVudDtcbiAgY29uc3QgcmV3cml0ZUJ0biA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtcmV3cml0ZScpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICBjb25zdCBzdGF0dXNFbCA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3Qtc3RhdHVzJykgYXMgSFRNTERpdkVsZW1lbnQ7XG4gIGNvbnN0IGxpbWl0RWwgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LWxpbWl0JykgYXMgSFRNTERpdkVsZW1lbnQ7XG4gIGNvbnN0IGFjdGlvbnNFbCA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtYWN0aW9ucycpIGFzIEhUTUxEaXZFbGVtZW50O1xuICBjb25zdCBhY2NlcHRCdG4gPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LWFjY2VwdCcpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICBjb25zdCByZWplY3RCdG4gPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LXJlamVjdCcpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuXG4gIC8vIFRvbmUgc2VsZWN0aW9uXG4gIHNoYWRvdy5xdWVyeVNlbGVjdG9yQWxsPEhUTUxCdXR0b25FbGVtZW50PignLnd0LXRvbmUnKS5mb3JFYWNoKHRvbmVidG4gPT4ge1xuICAgIHRvbmVidG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgICBzaGFkb3cucXVlcnlTZWxlY3RvckFsbCgnLnd0LXRvbmUnKS5mb3JFYWNoKGIgPT4gYi5jbGFzc0xpc3QucmVtb3ZlKCdhY3RpdmUnKSk7XG4gICAgICB0b25lYnRuLmNsYXNzTGlzdC5hZGQoJ2FjdGl2ZScpO1xuICAgICAgdG9uZWJ0bi5zdHlsZS5iYWNrZ3JvdW5kID0gdG9uZWJ0bi5kYXRhc2V0LmNvbG9yID8/ICcjNEY0NkU1JztcbiAgICAgIHRvbmVidG4uc3R5bGUuYm9yZGVyQ29sb3IgPSB0b25lYnRuLmRhdGFzZXQuY29sb3IgPz8gJyM0RjQ2RTUnO1xuICAgICAgc2VsZWN0ZWRUb25lID0gdG9uZWJ0bi5kYXRhc2V0LnRvbmUgYXMgVG9uZTtcbiAgICAgIHJld3JpdGVCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgICAgIHN0YXR1c0VsLnRleHRDb250ZW50ID0gJyc7XG4gICAgICBzdGF0dXNFbC5jbGFzc05hbWUgPSAnJztcbiAgICAgIGxpbWl0RWwuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xuICAgICAgYWN0aW9uc0VsLmNsYXNzTGlzdC5yZW1vdmUoJ3Zpc2libGUnKTtcbiAgICB9KTtcbiAgfSk7XG5cbiAgLy8gRGV0ZWN0IGNvbnRleHQgb24gZmlyc3Qgb3BlbiAoZmlyZS1hbmQtZm9yZ2V0KVxuICBzZXRUaW1lb3V0KCgpID0+IHJlZnJlc2hDb250ZXh0QmFkZ2UoKSwgODAwKTtcblxuICBmdW5jdGlvbiByZWZyZXNoQ29udGV4dEJhZGdlKCk6IHZvaWQge1xuICAgIGNvbnN0IGN0eCA9IGJ1aWxkR21haWxDb250ZXh0KGNvbXBvc2VCb2R5KTtcbiAgICBzZW5kVG9CYWNrZ3JvdW5kPHsgcmVzdWx0PzogeyBjb250ZXh0X3R3aW46IHN0cmluZyB9IH0gfCB7IGVycm9yOiBzdHJpbmcgfT4oe1xuICAgICAgdHlwZTogJ0RFVEVDVF9DT05URVhUJyxcbiAgICAgIHBheWxvYWQ6IGN0eCxcbiAgICB9KS50aGVuKChyZXNwKSA9PiB7XG4gICAgICBpZiAoJ3Jlc3VsdCcgaW4gcmVzcCAmJiByZXNwLnJlc3VsdD8uY29udGV4dF90d2luKSB7XG4gICAgICAgIGRldGVjdGVkQ29udGV4dFR3aW4gPSByZXNwLnJlc3VsdC5jb250ZXh0X3R3aW47XG4gICAgICAgIHNob3dDb250ZXh0QmFkZ2UoZGV0ZWN0ZWRDb250ZXh0VHdpbik7XG4gICAgICB9XG4gICAgfSkuY2F0Y2goKCkgPT4geyAvKiBiZXN0LWVmZm9ydCAqLyB9KTtcbiAgfVxuXG4gIGZ1bmN0aW9uIHNob3dDb250ZXh0QmFkZ2UodHdpbjogc3RyaW5nKTogdm9pZCB7XG4gICAgY29uc3QgbGFiZWwgPSB0d2luLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgdHdpbi5zbGljZSgxKTtcbiAgICBjdHhCYWRnZS50ZXh0Q29udGVudCA9IGxhYmVsO1xuICAgIGN0eEJhZGdlLmNsYXNzTGlzdC5yZW1vdmUoJ2hpZGRlbicpO1xuICB9XG5cbiAgLy8gQmFkZ2UgY2xpY2s6IGN5Y2xlIHRocm91Z2ggY29udGV4dCBvdmVycmlkZXNcbiAgY29uc3QgQ09OVEVYVF9DWUNMRSA9IFsncHJvZmVzc2lvbmFsJywgJ2N1c3RvbWVyJywgJ3RlY2huaWNhbCcsICdlc2NhbGF0aW9uJywgJ2Nhc3VhbCddO1xuICBjdHhCYWRnZS5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBjb25zdCBjdXJyZW50ID0gY29udGV4dE92ZXJyaWRlID8/IGRldGVjdGVkQ29udGV4dFR3aW47XG4gICAgY29uc3QgaWR4ID0gQ09OVEVYVF9DWUNMRS5pbmRleE9mKGN1cnJlbnQpO1xuICAgIGNvbnN0IG5leHQgPSBDT05URVhUX0NZQ0xFWyhpZHggKyAxKSAlIENPTlRFWFRfQ1lDTEUubGVuZ3RoXTtcbiAgICBjb250ZXh0T3ZlcnJpZGUgPSBuZXh0O1xuICAgIHNob3dDb250ZXh0QmFkZ2UobmV4dCk7XG4gICAgLy8gUmVjb3JkIG92ZXJyaWRlIHNpZ25hbFxuICAgIHNlbmRUb0JhY2tncm91bmQoe1xuICAgICAgdHlwZTogJ0NPTlRFWFRfT1ZFUlJJREUnLFxuICAgICAgcGF5bG9hZDoge1xuICAgICAgICBkZXRlY3RlZF9jb250ZXh0OiBkZXRlY3RlZENvbnRleHRUd2luLFxuICAgICAgICBzZWxlY3RlZF9jb250ZXh0OiBuZXh0LFxuICAgICAgICBwbGF0Zm9ybTogJ2dtYWlsJyxcbiAgICAgIH0sXG4gICAgfSk7XG4gIH0pO1xuXG4gIC8vIFRvZ2dsZSBwYW5lbFxuICBidG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgcGFuZWxPcGVuID0gIXBhbmVsT3BlbjtcbiAgICBwYW5lbC5jbGFzc0xpc3QudG9nZ2xlKCdvcGVuJywgcGFuZWxPcGVuKTtcbiAgICBpZiAocGFuZWxPcGVuKSBwb3NpdGlvblBhbmVsKCk7XG4gIH0pO1xuXG4gIC8vIENsb3NlIHBhbmVsIG9uIG91dHNpZGUgY2xpY2tcbiAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZSkgPT4ge1xuICAgIGlmICghaG9zdC5jb250YWlucyhlLnRhcmdldCBhcyBOb2RlKSAmJiBwYW5lbE9wZW4pIHtcbiAgICAgIHBhbmVsT3BlbiA9IGZhbHNlO1xuICAgICAgcGFuZWwuY2xhc3NMaXN0LnJlbW92ZSgnb3BlbicpO1xuICAgIH1cbiAgfSwgdHJ1ZSk7XG5cbiAgZnVuY3Rpb24gcG9zaXRpb25QYW5lbCgpOiB2b2lkIHtcbiAgICBjb25zdCByZWN0ID0gYnRuLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIHBhbmVsLnN0eWxlLmJvdHRvbSA9IGAke3dpbmRvdy5pbm5lckhlaWdodCAtIHJlY3QudG9wICsgNH1weGA7XG4gICAgcGFuZWwuc3R5bGUubGVmdCA9IGAke01hdGgubWluKHJlY3QubGVmdCwgd2luZG93LmlubmVyV2lkdGggLSAyNzYpfXB4YDtcbiAgfVxuXG4gIGxldCBvcmlnaW5hbFRleHQgPSAnJztcblxuICAvLyBSZXdyaXRlXG4gIHJld3JpdGVCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFzZWxlY3RlZFRvbmUpIHJldHVybjtcblxuICAgIGNvbnN0IHRleHQgPSAoY29tcG9zZUJvZHkgYXMgSFRNTEVsZW1lbnQpLmlubmVyVGV4dC50cmltKCk7XG4gICAgaWYgKCF0ZXh0KSB7XG4gICAgICBzZXRTdGF0dXMoJ1dyaXRlIHNvbWV0aGluZyBmaXJzdC4nLCAnZXJyb3InKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBvcmlnaW5hbFRleHQgPSB0ZXh0O1xuICAgIGJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gICAgcmV3cml0ZUJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gICAgc2V0U3RhdHVzKCdSZXdyaXRpbmdcdTIwMjYnKTtcbiAgICBhY3Rpb25zRWwuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGJhc2VDdHggPSBidWlsZEdtYWlsQ29udGV4dChjb21wb3NlQm9keSk7XG4gICAgICBjb25zdCByZXNwID0gYXdhaXQgc2VuZFRvQmFja2dyb3VuZDx7IHJlc3VsdDogUmV3cml0ZVJlc3BvbnNlIH0+KHtcbiAgICAgICAgdHlwZTogJ0hVTUFOSVpFJyxcbiAgICAgICAgcGF5bG9hZDoge1xuICAgICAgICAgIHRleHQsXG4gICAgICAgICAgdG9uZTogc2VsZWN0ZWRUb25lLFxuICAgICAgICAgIGN0eDogeyAuLi5iYXNlQ3R4LCBjb250ZXh0X3R3aW5fb3ZlcnJpZGU6IGNvbnRleHRPdmVycmlkZSB9LFxuICAgICAgICB9LFxuICAgICAgfSk7XG5cbiAgICAgIGlmICgnZXJyb3InIGluIHJlc3ApIHRocm93IG5ldyBFcnJvcihTdHJpbmcocmVzcC5lcnJvcikpO1xuXG4gICAgICBsYXN0UmV3cml0ZUlkID0gcmVzcC5yZXN1bHQuaWQ7XG4gICAgICBzZXRDb21wb3NlVGV4dChjb21wb3NlQm9keSBhcyBIVE1MRWxlbWVudCwgcmVzcC5yZXN1bHQub3V0cHV0X3RleHQpO1xuICAgICAgc2V0U3RhdHVzKCdEb25lIFx1MjcxMycsICdzdWNjZXNzJyk7XG4gICAgICBhY3Rpb25zRWwuY2xhc3NMaXN0LmFkZCgndmlzaWJsZScpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc3QgbXNnID0gZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6ICdGYWlsZWQnO1xuICAgICAgaWYgKG1zZy5zdGFydHNXaXRoKCdMSU1JVF9SRUFDSEVEOicpKSB7XG4gICAgICAgIGxpbWl0RWwuY2xhc3NMaXN0LmFkZCgndmlzaWJsZScpO1xuICAgICAgICBzZXRTdGF0dXMoJycpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2V0U3RhdHVzKG1zZywgJ2Vycm9yJyk7XG4gICAgICB9XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIGJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICAgICAgcmV3cml0ZUJ0bi5kaXNhYmxlZCA9IHNlbGVjdGVkVG9uZSA9PT0gbnVsbDtcbiAgICB9XG4gIH0pO1xuXG4gIC8vIEFjY2VwdCBmZWVkYmFja1xuICBhY2NlcHRCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XG4gICAgaWYgKGxhc3RSZXdyaXRlSWQpIHtcbiAgICAgIHNlbmRUb0JhY2tncm91bmQoeyB0eXBlOiAnRkVFREJBQ0snLCBwYXlsb2FkOiB7IHJld3JpdGVJZDogbGFzdFJld3JpdGVJZCwgYWN0aW9uOiAnYWNjZXB0ZWQnIH0gfSk7XG4gICAgfVxuICAgIGFjdGlvbnNFbC5jbGFzc0xpc3QucmVtb3ZlKCd2aXNpYmxlJyk7XG4gICAgcGFuZWxPcGVuID0gZmFsc2U7XG4gICAgcGFuZWwuY2xhc3NMaXN0LnJlbW92ZSgnb3BlbicpO1xuICAgIHNldFN0YXR1cygnJyk7XG4gIH0pO1xuXG4gIC8vIFJlamVjdCAvIHVuZG9cbiAgcmVqZWN0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICAgIGlmIChvcmlnaW5hbFRleHQpIHNldENvbXBvc2VUZXh0KGNvbXBvc2VCb2R5IGFzIEhUTUxFbGVtZW50LCBvcmlnaW5hbFRleHQpO1xuICAgIGlmIChsYXN0UmV3cml0ZUlkKSB7XG4gICAgICBzZW5kVG9CYWNrZ3JvdW5kKHsgdHlwZTogJ0ZFRURCQUNLJywgcGF5bG9hZDogeyByZXdyaXRlSWQ6IGxhc3RSZXdyaXRlSWQsIGFjdGlvbjogJ3JlamVjdGVkJyB9IH0pO1xuICAgIH1cbiAgICBhY3Rpb25zRWwuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xuICAgIHNldFN0YXR1cygnUmV2ZXJ0ZWQuJywgJ3N1Y2Nlc3MnKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHNldFN0YXR1cygnJyksIDIwMDApO1xuICB9KTtcblxuICBmdW5jdGlvbiBzZXRTdGF0dXMobXNnOiBzdHJpbmcsIGNscyA9ICcnKTogdm9pZCB7XG4gICAgc3RhdHVzRWwudGV4dENvbnRlbnQgPSBtc2c7XG4gICAgc3RhdHVzRWwuY2xhc3NOYW1lID0gY2xzO1xuICB9XG5cbiAgLy8gSW5zZXJ0IGh1bWFuaXplIGhvc3QgYmVmb3JlIFNlbmQgYnV0dG9uIGluIHRoZSB0b29sYmFyXG4gIHRvb2xiYXIuaW5zZXJ0QmVmb3JlKGhvc3QsIHNlbmRCdG4pO1xuXG4gIC8vIEluamVjdCBtaWMgYnV0dG9uIGltbWVkaWF0ZWx5IGFmdGVyXG4gIGluamVjdE1pY0J1dHRvbih0b29sYmFyLCBjb21wb3NlQm9keSk7XG5cbiAgLy8gQXV0by1kcmFmdDogZmlyZSBhZnRlciA1MDBtcyB0byBsZXQgY29tcG9zZSBmdWxseSBtb3VudFxuICBzZXRUaW1lb3V0KCgpID0+IHRyeUF1dG9EcmFmdChjb21wb3NlQm9keSksIDUwMCk7XG59XG5cbi8vIFx1MjUwMFx1MjUwMCBIZWxwZXJzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5mdW5jdGlvbiBmaW5kU2VuZEJ1dHRvbihjb21wb3NlQm9keTogRWxlbWVudCk6IEVsZW1lbnQgfCBudWxsIHtcbiAgLy8gV2FsayB1cCB0aGUgdHJlZSB0byBmaW5kIHRoZSBjb21wb3NlIGNvbnRhaW5lciB0aGF0IGhvbGRzIHRoZSBTZW5kIGJ1dHRvbi5cbiAgLy8gR21haWwgbmVzdHMgdGhlIHRvb2xiYXIgZGVlcCBcdTIwMTQgMjUgbGV2ZWxzIGlzIHNhZmUgaGVhZHJvb20uXG4gIGxldCBlbDogRWxlbWVudCB8IG51bGwgPSBjb21wb3NlQm9keTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCAyNTsgaSsrKSB7XG4gICAgaWYgKCFlbCkgYnJlYWs7XG4gICAgY29uc3Qgc2VuZCA9IGVsLnF1ZXJ5U2VsZWN0b3IoU0VORF9CVVRUT05fU0VMKTtcbiAgICBpZiAoc2VuZCkgcmV0dXJuIHNlbmQ7XG4gICAgZWwgPSBlbC5wYXJlbnRFbGVtZW50O1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG5mdW5jdGlvbiBzZXRDb21wb3NlVGV4dChlbDogSFRNTEVsZW1lbnQsIHRleHQ6IHN0cmluZyk6IHZvaWQge1xuICBlbC5mb2N1cygpO1xuICBkb2N1bWVudC5leGVjQ29tbWFuZCgnc2VsZWN0QWxsJywgZmFsc2UsIHVuZGVmaW5lZCk7XG4gIGRvY3VtZW50LmV4ZWNDb21tYW5kKCdkZWxldGUnLCBmYWxzZSwgdW5kZWZpbmVkKTtcbiAgLy8gSW5zZXJ0IGxpbmUgYnkgbGluZSB0byBwcmVzZXJ2ZSBwYXJhZ3JhcGggc3RydWN0dXJlXG4gIGNvbnN0IGxpbmVzID0gdGV4dC5zcGxpdCgnXFxuJyk7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbGluZXMubGVuZ3RoOyBpKyspIHtcbiAgICBpZiAobGluZXNbaV0pIGRvY3VtZW50LmV4ZWNDb21tYW5kKCdpbnNlcnRUZXh0JywgZmFsc2UsIGxpbmVzW2ldKTtcbiAgICBpZiAoaSA8IGxpbmVzLmxlbmd0aCAtIDEpIGRvY3VtZW50LmV4ZWNDb21tYW5kKCdpbnNlcnRQYXJhZ3JhcGgnLCBmYWxzZSwgdW5kZWZpbmVkKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBzZW5kVG9CYWNrZ3JvdW5kPFQ+KG1lc3NhZ2U6IG9iamVjdCk6IFByb21pc2U8VD4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZShtZXNzYWdlLCByZXNvbHZlKTtcbiAgfSk7XG59XG5cbi8vIFx1MjUwMFx1MjUwMCBBdXRvIERyYWZ0IFx1MjAxNCBkZXRlY3QgcmVwbHksIHJlYWQgaW5jb21pbmcgZW1haWwsIGluamVjdCBiYW5uZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbi8qKlxuICogV2FsayB1cCBmcm9tIGNvbXBvc2VCb2R5IHRvIGZpbmQgYSB0aHJlYWQgY29udGFpbmVyIHRoYXQgaG9sZHMgbWVzc2FnZSByb3dzXG4gKiAoLmdzIGVsZW1lbnRzKS4gUmV0dXJucyB0aGUgbGFzdCAuZ3MgYmVmb3JlIHRoZSBjb21wb3NlIGFyZWEsIG9yIG51bGwgaWZcbiAqIHRoaXMgbG9va3MgbGlrZSBhIG5ldy1jb21wb3NlIChub3QgYSByZXBseSkuXG4gKi9cbmZ1bmN0aW9uIGZpbmRJbmNvbWluZ01lc3NhZ2VFbChjb21wb3NlQm9keTogRWxlbWVudCk6IEVsZW1lbnQgfCBudWxsIHtcbiAgbGV0IGVsOiBFbGVtZW50IHwgbnVsbCA9IGNvbXBvc2VCb2R5O1xuICBsZXQgdGhyZWFkQ29udGFpbmVyOiBFbGVtZW50IHwgbnVsbCA9IG51bGw7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgMjA7IGkrKykge1xuICAgIGlmICghZWwpIGJyZWFrO1xuICAgIGlmIChlbC5xdWVyeVNlbGVjdG9yQWxsKCcuZ3MnKS5sZW5ndGggPiAwKSB7IHRocmVhZENvbnRhaW5lciA9IGVsOyBicmVhazsgfVxuICAgIGVsID0gZWwucGFyZW50RWxlbWVudDtcbiAgfVxuICBpZiAoIXRocmVhZENvbnRhaW5lcikgcmV0dXJuIG51bGw7XG5cbiAgLy8gV2FsayBtZXNzYWdlIHJvd3MgXHUyMDE0IGZpbmQgdGhlIGxhc3QgLmdzIHRoYXQgZG9lc24ndCBjb250YWluIHRoZSBjb21wb3NlIGJvZHlcbiAgY29uc3Qgcm93cyA9IEFycmF5LmZyb20odGhyZWFkQ29udGFpbmVyLnF1ZXJ5U2VsZWN0b3JBbGwoJy5ncycpKTtcbiAgZm9yIChsZXQgaSA9IHJvd3MubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcbiAgICBpZiAoIXJvd3NbaV0uY29udGFpbnMoY29tcG9zZUJvZHkpKSByZXR1cm4gcm93c1tpXTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuZnVuY3Rpb24gZXh0cmFjdEluY29taW5nVGV4dChtc2dFbDogRWxlbWVudCk6IHN0cmluZyB8IG51bGwge1xuICAvLyBUcnkgc3RhbmRhcmQgR21haWwgbWVzc2FnZSBib2R5IHNlbGVjdG9ycyBpbiBwcmlvcml0eSBvcmRlclxuICBjb25zdCBib2R5RWwgPSAoXG4gICAgbXNnRWwucXVlcnlTZWxlY3RvcignLmEzcy5haUwnKSA/P1xuICAgIG1zZ0VsLnF1ZXJ5U2VsZWN0b3IoJy5paS5ndCcpID8/XG4gICAgbXNnRWwucXVlcnlTZWxlY3RvcignLmFkbicpXG4gICkgYXMgSFRNTEVsZW1lbnQgfCBudWxsO1xuICBpZiAoIWJvZHlFbCkgcmV0dXJuIG51bGw7XG4gIGNvbnN0IHRleHQgPSBib2R5RWwuaW5uZXJUZXh0LnRyaW0oKTtcbiAgaWYgKHRleHQubGVuZ3RoIDwgMjApIHJldHVybiBudWxsO1xuICAvLyBGaXJzdCA1MDAgd29yZHMgb25seVxuICByZXR1cm4gdGV4dC5zcGxpdCgvXFxzKy8pLnNsaWNlKDAsIDUwMCkuam9pbignICcpO1xufVxuXG5jb25zdCBBVVRPX0RSQUZUX0FUVFIgPSAnZGF0YS13dC1hdXRvZHJhZnQnO1xuXG5hc3luYyBmdW5jdGlvbiB0cnlBdXRvRHJhZnQoY29tcG9zZUJvZHk6IEVsZW1lbnQpOiBQcm9taXNlPHZvaWQ+IHtcbiAgLy8gR3VhcmQ6IG9ubHkgZmlyZSBvbmNlIHBlciBjb21wb3NlIHdpbmRvd1xuICBpZiAoY29tcG9zZUJvZHkuaGFzQXR0cmlidXRlKEFVVE9fRFJBRlRfQVRUUikpIHJldHVybjtcbiAgY29tcG9zZUJvZHkuc2V0QXR0cmlidXRlKEFVVE9fRFJBRlRfQVRUUiwgJzEnKTtcblxuICAvLyBPbmx5IGZpcmUgaWYgY29tcG9zZSBib2R5IGlzIGVtcHR5ICh1c2VyIGhhc24ndCBzdGFydGVkIHR5cGluZylcbiAgaWYgKChjb21wb3NlQm9keSBhcyBIVE1MRWxlbWVudCkuaW5uZXJUZXh0LnRyaW0oKSAhPT0gJycpIHJldHVybjtcblxuICBjb25zdCBpbmNvbWluZ0VsID0gZmluZEluY29taW5nTWVzc2FnZUVsKGNvbXBvc2VCb2R5KTtcbiAgaWYgKCFpbmNvbWluZ0VsKSByZXR1cm47IC8vIG5ldyBjb21wb3NlIFx1MjAxNCBza2lwXG5cbiAgY29uc3QgaW5jb21pbmdUZXh0ID0gZXh0cmFjdEluY29taW5nVGV4dChpbmNvbWluZ0VsKTtcbiAgaWYgKCFpbmNvbWluZ1RleHQpIHJldHVybjtcblxuICBjb25zdCBjdHggPSBidWlsZEdtYWlsQ29udGV4dChjb21wb3NlQm9keSk7XG5cbiAgLy8gMnMgQWJvcnRDb250cm9sbGVyIHRpbWVvdXQgXHUyMDE0IG5ldmVyIGJsb2NrIHRoZSB1c2VyXG4gIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gIGNvbnN0IHRpbWVvdXRJZCA9IHNldFRpbWVvdXQoKCkgPT4gY29udHJvbGxlci5hYm9ydCgpLCBBVVRPX0RSQUZUX1RJTUVPVVRfTVMpO1xuXG4gIGxldCByZXN1bHQ6IEF1dG9EcmFmdFJlc3BvbnNlO1xuICB0cnkge1xuICAgIGNvbnN0IHJlc3AgPSBhd2FpdCBQcm9taXNlLnJhY2UoW1xuICAgICAgc2VuZFRvQmFja2dyb3VuZDx7IHJlc3VsdDogQXV0b0RyYWZ0UmVzcG9uc2UgfSB8IHsgZXJyb3I6IHN0cmluZyB9Pih7XG4gICAgICAgIHR5cGU6ICdBVVRPX0RSQUZUJyxcbiAgICAgICAgcGF5bG9hZDoge1xuICAgICAgICAgIGluY29taW5nVGV4dCxcbiAgICAgICAgICB0b25lOiBBVVRPX0RSQUZUX0RFRkFVTFRfVE9ORSxcbiAgICAgICAgICBjdHgsXG4gICAgICAgIH0sXG4gICAgICB9KSxcbiAgICAgIG5ldyBQcm9taXNlPG5ldmVyPigoXywgcmVqZWN0KSA9PlxuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHJlamVjdChuZXcgRXJyb3IoJ3RpbWVvdXQnKSksIEFVVE9fRFJBRlRfVElNRU9VVF9NUylcbiAgICAgICksXG4gICAgXSk7XG4gICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCk7XG4gICAgaWYgKCdlcnJvcicgaW4gcmVzcCkgcmV0dXJuO1xuICAgIHJlc3VsdCA9IHJlc3AucmVzdWx0O1xuICB9IGNhdGNoIHtcbiAgICBjbGVhclRpbWVvdXQodGltZW91dElkKTtcbiAgICByZXR1cm47XG4gIH1cblxuICAvLyBPbmx5IGluamVjdCBpZiBjb21wb3NlIGlzIHN0aWxsIGVtcHR5ICh1c2VyIG1heSBoYXZlIHN0YXJ0ZWQgdHlwaW5nIGR1cmluZyB0aGUgd2FpdClcbiAgaWYgKChjb21wb3NlQm9keSBhcyBIVE1MRWxlbWVudCkuaW5uZXJUZXh0LnRyaW0oKSAhPT0gJycpIHJldHVybjtcblxuICBzaG93QXV0b0RyYWZ0QmFubmVyKGNvbXBvc2VCb2R5LCByZXN1bHQpO1xufVxuXG5mdW5jdGlvbiBzaG93QXV0b0RyYWZ0QmFubmVyKGNvbXBvc2VCb2R5OiBFbGVtZW50LCByZXN1bHQ6IEF1dG9EcmFmdFJlc3BvbnNlKTogdm9pZCB7XG4gIC8vIFJlbW92ZSBhbnkgZXhpc3RpbmcgYmFubmVyXG4gIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd3dC1hdXRvLWRyYWZ0LWJhbm5lcicpPy5yZW1vdmUoKTtcblxuICBjb25zdCBiYW5uZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgYmFubmVyLmlkID0gJ3d0LWF1dG8tZHJhZnQtYmFubmVyJztcbiAgYmFubmVyLnN0eWxlLmNzc1RleHQgPSBgXG4gICAgcG9zaXRpb246IGZpeGVkOyB6LWluZGV4OiA5OTk4O1xuICAgIGJhY2tncm91bmQ6ICNFRUYyRkY7IGJvcmRlcjogMXB4IHNvbGlkICNDN0QyRkU7IGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgcGFkZGluZzogMTBweCAxNHB4OyBkaXNwbGF5OiBmbGV4OyBhbGlnbi1pdGVtczogY2VudGVyOyBnYXA6IDEwcHg7XG4gICAgZm9udDogMTNweC8xLjQgLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCBcIlNlZ29lIFVJXCIsIFJvYm90bywgc2Fucy1zZXJpZjtcbiAgICBjb2xvcjogIzMxMkU4MTsgYm94LXNoYWRvdzogMCA0cHggMTZweCByZ2JhKDc5LDcwLDIyOSwwLjEyKTtcbiAgICBtYXgtd2lkdGg6IDQyMHB4O1xuICBgO1xuXG4gIGNvbnN0IGxhYmVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICBsYWJlbC5zdHlsZS5jc3NUZXh0ID0gJ2ZvbnQtd2VpZ2h0OiA2MDA7IHdoaXRlLXNwYWNlOiBub3dyYXA7JztcbiAgbGFiZWwudGV4dENvbnRlbnQgPSAnXHUyNzI2IERyYWZ0IHJlYWR5JztcblxuICBjb25zdCB1c2VCdG4gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdidXR0b24nKTtcbiAgdXNlQnRuLnN0eWxlLmNzc1RleHQgPSBgXG4gICAgaGVpZ2h0OiAyOHB4OyBwYWRkaW5nOiAwIDEycHg7IGJvcmRlci1yYWRpdXM6IDk5OTlweDsgYm9yZGVyOiBub25lO1xuICAgIGJhY2tncm91bmQ6ICM0RjQ2RTU7IGNvbG9yOiAjZmZmOyBmb250OiA2MDAgMTJweC8xIGluaGVyaXQ7XG4gICAgY3Vyc29yOiBwb2ludGVyOyB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICBgO1xuICB1c2VCdG4udGV4dENvbnRlbnQgPSAnVXNlIGRyYWZ0JztcblxuICBjb25zdCBkaXNtaXNzQnRuID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYnV0dG9uJyk7XG4gIGRpc21pc3NCdG4uc3R5bGUuY3NzVGV4dCA9IGBcbiAgICBoZWlnaHQ6IDI0cHg7IHdpZHRoOiAyNHB4OyBib3JkZXItcmFkaXVzOiA5OTk5cHg7IGJvcmRlcjogbm9uZTtcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDsgY29sb3I6ICM2MzY2RjE7IGZvbnQtc2l6ZTogMTZweDsgbGluZS1oZWlnaHQ6IDE7XG4gICAgY3Vyc29yOiBwb2ludGVyOyBtYXJnaW4tbGVmdDogYXV0bzsgZGlzcGxheTogZmxleDsgYWxpZ24taXRlbXM6IGNlbnRlcjsganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGA7XG4gIGRpc21pc3NCdG4udGl0bGUgPSAnRGlzbWlzcyc7XG4gIGRpc21pc3NCdG4udGV4dENvbnRlbnQgPSAnXHUyNzE1JztcblxuICBiYW5uZXIuYXBwZW5kKGxhYmVsLCB1c2VCdG4sIGRpc21pc3NCdG4pO1xuICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGJhbm5lcik7XG5cbiAgLy8gUG9zaXRpb24gYmFubmVyIGFib3ZlIHRoZSBjb21wb3NlIGJvZHlcbiAgZnVuY3Rpb24gcG9zaXRpb25CYW5uZXIoKTogdm9pZCB7XG4gICAgY29uc3QgcmVjdCA9IGNvbXBvc2VCb2R5LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIGJhbm5lci5zdHlsZS50b3AgPSBgJHtNYXRoLm1heChyZWN0LnRvcCAtIDUyLCA2MCl9cHhgO1xuICAgIGJhbm5lci5zdHlsZS5sZWZ0ID0gYCR7TWF0aC5taW4ocmVjdC5sZWZ0LCB3aW5kb3cuaW5uZXJXaWR0aCAtIDQ0MCl9cHhgO1xuICB9XG4gIHBvc2l0aW9uQmFubmVyKCk7XG4gIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdyZXNpemUnLCBwb3NpdGlvbkJhbm5lciwgeyBwYXNzaXZlOiB0cnVlIH0pO1xuXG4gIGZ1bmN0aW9uIHJlbW92ZUJhbm5lcigpOiB2b2lkIHtcbiAgICBiYW5uZXIucmVtb3ZlKCk7XG4gICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIHBvc2l0aW9uQmFubmVyKTtcbiAgfVxuXG4gIC8vIFwiVXNlIGRyYWZ0XCIgXHUyMDE0IGZpbGwgY29tcG9zZSBhbmQgcmVjb3JkIGtlcHQ9dHJ1ZVxuICB1c2VCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgc2V0Q29tcG9zZVRleHQoY29tcG9zZUJvZHkgYXMgSFRNTEVsZW1lbnQsIHJlc3VsdC5kcmFmdCk7XG4gICAgc2VuZFRvQmFja2dyb3VuZCh7XG4gICAgICB0eXBlOiAnQVVUT19EUkFGVF9GRUVEQkFDSycsXG4gICAgICBwYXlsb2FkOiB7IGRyYWZ0SWQ6IHJlc3VsdC5pZCwga2VwdDogdHJ1ZSB9LFxuICAgIH0pO1xuICAgIHJlbW92ZUJhbm5lcigpO1xuICB9KTtcblxuICAvLyBcIlx1MjcxNSBEaXNtaXNzXCIgXHUyMDE0IHJlY29yZCBrZXB0PWZhbHNlXG4gIGRpc21pc3NCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgc2VuZFRvQmFja2dyb3VuZCh7XG4gICAgICB0eXBlOiAnQVVUT19EUkFGVF9GRUVEQkFDSycsXG4gICAgICBwYXlsb2FkOiB7IGRyYWZ0SWQ6IHJlc3VsdC5pZCwga2VwdDogZmFsc2UgfSxcbiAgICB9KTtcbiAgICByZW1vdmVCYW5uZXIoKTtcbiAgfSk7XG5cbiAgLy8gQXV0by1kaXNtaXNzIGlmIHVzZXIgc3RhcnRzIHR5cGluZ1xuICBjb25zdCB0eXBpbmdMaXN0ZW5lciA9ICgpOiB2b2lkID0+IHtcbiAgICBpZiAoKGNvbXBvc2VCb2R5IGFzIEhUTUxFbGVtZW50KS5pbm5lclRleHQudHJpbSgpICE9PSAnJykge1xuICAgICAgc2VuZFRvQmFja2dyb3VuZCh7XG4gICAgICAgIHR5cGU6ICdBVVRPX0RSQUZUX0ZFRURCQUNLJyxcbiAgICAgICAgcGF5bG9hZDogeyBkcmFmdElkOiByZXN1bHQuaWQsIGtlcHQ6IGZhbHNlIH0sXG4gICAgICB9KTtcbiAgICAgIHJlbW92ZUJhbm5lcigpO1xuICAgICAgY29tcG9zZUJvZHkucmVtb3ZlRXZlbnRMaXN0ZW5lcignaW5wdXQnLCB0eXBpbmdMaXN0ZW5lcik7XG4gICAgfVxuICB9O1xuICBjb21wb3NlQm9keS5hZGRFdmVudExpc3RlbmVyKCdpbnB1dCcsIHR5cGluZ0xpc3RlbmVyKTtcblxuICAvLyBBdXRvLWRpc21pc3MgYWZ0ZXIgMzBzIGlmIG5vIGludGVyYWN0aW9uXG4gIHNldFRpbWVvdXQocmVtb3ZlQmFubmVyLCAzMF8wMDApO1xufVxuXG4vLyBcdTI1MDBcdTI1MDAgTXV0YXRpb25PYnNlcnZlciBcdTIwMTQgd2F0Y2ggZm9yIG5ldyBjb21wb3NlIHdpbmRvd3MgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmNvbnN0IHNlZW4gPSBuZXcgV2Vha1NldDxFbGVtZW50PigpO1xuXG5mdW5jdGlvbiB0cnlJbmplY3Qocm9vdDogRWxlbWVudCB8IERvY3VtZW50KTogdm9pZCB7XG4gIHJvb3QucXVlcnlTZWxlY3RvckFsbDxFbGVtZW50PihDT01QT1NFX0JPRFlfU0VMKS5mb3JFYWNoKChib2R5KSA9PiB7XG4gICAgaWYgKCFzZWVuLmhhcyhib2R5KSkge1xuICAgICAgc2Vlbi5hZGQoYm9keSk7XG4gICAgICBpbmplY3QoYm9keSk7XG4gICAgfVxuICB9KTtcbn1cblxuY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgTXV0YXRpb25PYnNlcnZlcigoKSA9PiB0cnlJbmplY3QoZG9jdW1lbnQpKTtcblxub2JzZXJ2ZXIub2JzZXJ2ZShkb2N1bWVudC5ib2R5LCB7IGNoaWxkTGlzdDogdHJ1ZSwgc3VidHJlZTogdHJ1ZSB9KTtcblxuLy8gSGFuZGxlIGNvbXBvc2Ugd2luZG93cyBhbHJlYWR5IG9wZW4gb24gbG9hZFxudHJ5SW5qZWN0KGRvY3VtZW50KTtcblxuLy8gS2V5Ym9hcmQgc2hvcnRjdXRzXG5kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgKGUpID0+IHtcbiAgY29uc3QgdG9vbGJhciA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoYFske0hPU1RfQVRUUn1dYCk7XG4gIGlmICghdG9vbGJhcikgcmV0dXJuO1xuICBjb25zdCBob3N0cyA9IEFycmF5LmZyb20odG9vbGJhci5jaGlsZHJlbikuZmlsdGVyKGMgPT4gYy5zaGFkb3dSb290KSBhcyBIVE1MRWxlbWVudFtdO1xuXG4gIGlmICgoZS5tZXRhS2V5IHx8IGUuY3RybEtleSkgJiYgZS5zaGlmdEtleSAmJiBlLmtleSA9PT0gJ0gnKSB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIC8vIEZpcnN0IHNoYWRvdyBob3N0ID0gaHVtYW5pemUgYnV0dG9uXG4gICAgY29uc3QgYnRuID0gaG9zdHNbMF0/LnNoYWRvd1Jvb3Q/LmdldEVsZW1lbnRCeUlkKCd3dC1idG4nKSBhcyBIVE1MQnV0dG9uRWxlbWVudCB8IG51bGw7XG4gICAgYnRuPy5jbGljaygpO1xuICB9XG5cbiAgaWYgKChlLm1ldGFLZXkgfHwgZS5jdHJsS2V5KSAmJiBlLnNoaWZ0S2V5ICYmIGUua2V5ID09PSAnVicpIHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgLy8gU2Vjb25kIHNoYWRvdyBob3N0ID0gbWljIGJ1dHRvblxuICAgIGNvbnN0IGJ0biA9IGhvc3RzWzFdPy5zaGFkb3dSb290Py5nZXRFbGVtZW50QnlJZCgnd3QtbWljLWJ0bicpIGFzIEhUTUxCdXR0b25FbGVtZW50IHwgbnVsbDtcbiAgICBidG4/LmNsaWNrKCk7XG4gIH1cbn0pO1xuIl0sCiAgIm1hcHBpbmdzIjogIjs7O0FBSUEsTUFBTSxtQkFBbUI7QUFDekIsTUFBTSxrQkFBa0I7QUFDeEIsTUFBTSxZQUFZO0FBQ2xCLE1BQU0sd0JBQXdCO0FBQzlCLE1BQU0sMEJBQWdDO0FBSXRDLE1BQU0sUUFBdUQ7QUFBQSxJQUMzRCxFQUFFLEtBQUssZ0JBQWdCLE9BQU8sZ0JBQWdCLE9BQU8sVUFBVTtBQUFBLElBQy9ELEVBQUUsS0FBSyxVQUFnQixPQUFPLFVBQWdCLE9BQU8sVUFBVTtBQUFBLElBQy9ELEVBQUUsS0FBSyxZQUFnQixPQUFPLFlBQWdCLE9BQU8sVUFBVTtBQUFBLElBQy9ELEVBQUUsS0FBSyxVQUFnQixPQUFPLFVBQWdCLE9BQU8sVUFBVTtBQUFBLElBQy9ELEVBQUUsS0FBSyxjQUFnQixPQUFPLGNBQWdCLE9BQU8sVUFBVTtBQUFBLElBQy9ELEVBQUUsS0FBSyxhQUFnQixPQUFPLGFBQWdCLE9BQU8sVUFBVTtBQUFBLEVBQ2pFO0FBSUEsTUFBTSxhQUFhO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFtRm5CLE1BQU0scUJBQWdFO0FBQUEsSUFDcEUsRUFBRSxLQUFLLFNBQW1CLE9BQU8sUUFBUTtBQUFBLElBQ3pDLEVBQUUsS0FBSyxTQUFtQixPQUFPLFFBQVE7QUFBQSxJQUN6QyxFQUFFLEtBQUssbUJBQW1CLE9BQU8sa0JBQWtCO0FBQUEsSUFDbkQsRUFBRSxLQUFLLGVBQW1CLE9BQU8sY0FBYztBQUFBLElBQy9DLEVBQUUsS0FBSyxvQkFBbUIsT0FBTyxjQUFjO0FBQUEsRUFDakQ7QUFFQSxNQUFNLFVBQVU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFtRWhCLFdBQVMsZ0JBQWdCLFNBQWtCLGFBQTRCO0FBQ3JFLFVBQU0sVUFBVSxTQUFTLGNBQWMsTUFBTTtBQUM3QyxVQUFNLFNBQVMsUUFBUSxhQUFhLEVBQUUsTUFBTSxPQUFPLENBQUM7QUFFcEQsV0FBTyxZQUFZO0FBQUEsYUFDUixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTVYsbUJBQW1CO0FBQUEsTUFBSSxDQUFDLEdBQUcsTUFDM0IsMEJBQTBCLE1BQU0sSUFBSSxZQUFZLEVBQUUsZ0JBQWdCLEVBQUUsR0FBRyxLQUFLLEVBQUUsS0FBSztBQUFBLElBQ3JGLEVBQUUsS0FBSyxFQUFFLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFXaEIsVUFBTSxTQUFjLE9BQU8sZUFBZSxZQUFZO0FBQ3RELFVBQU0sUUFBYyxPQUFPLGVBQWUsZ0JBQWdCO0FBQzFELFVBQU0sWUFBYyxPQUFPLGVBQWUsZUFBZTtBQUN6RCxVQUFNLFdBQWMsT0FBTyxlQUFlLGlCQUFpQjtBQUMzRCxVQUFNLFlBQWMsT0FBTyxlQUFlLGtCQUFrQjtBQUM1RCxVQUFNLFVBQWMsT0FBTyxlQUFlLFlBQVk7QUFDdEQsVUFBTSxVQUFjLE9BQU8sZUFBZSxZQUFZO0FBRXRELFFBQUksWUFBWTtBQUNoQixRQUFJLGVBQWdDO0FBQ3BDLFFBQUksV0FBaUM7QUFDckMsUUFBSSxZQUFZO0FBQ2hCLFFBQUksU0FBcUIsQ0FBQztBQUMxQixRQUFJLGdCQUErQjtBQUNuQyxRQUFJLGVBQWU7QUFHbkIsV0FBTyxpQkFBb0MsV0FBVyxFQUFFLFFBQVEsU0FBTztBQUNyRSxVQUFJLGlCQUFpQixTQUFTLE1BQU07QUFDbEMsZUFBTyxpQkFBaUIsV0FBVyxFQUFFLFFBQVEsT0FBSyxFQUFFLFVBQVUsT0FBTyxRQUFRLENBQUM7QUFDOUUsWUFBSSxVQUFVLElBQUksUUFBUTtBQUMxQix1QkFBZSxJQUFJLFFBQVE7QUFBQSxNQUM3QixDQUFDO0FBQUEsSUFDSCxDQUFDO0FBRUQsV0FBTyxpQkFBaUIsU0FBUyxNQUFNO0FBQ3JDLGtCQUFZLENBQUM7QUFDYixZQUFNLFVBQVUsT0FBTyxRQUFRLFNBQVM7QUFDeEMsVUFBSSxVQUFXLGVBQWM7QUFBQSxJQUMvQixDQUFDO0FBRUQsYUFBUyxpQkFBaUIsU0FBUyxDQUFDLE1BQU07QUFDeEMsVUFBSSxDQUFDLFFBQVEsU0FBUyxFQUFFLE1BQWMsS0FBSyxXQUFXO0FBQ3BELG9CQUFZO0FBQ1osY0FBTSxVQUFVLE9BQU8sTUFBTTtBQUFBLE1BQy9CO0FBQUEsSUFDRixHQUFHLElBQUk7QUFFUCxhQUFTLGdCQUFzQjtBQUM3QixZQUFNLE9BQU8sT0FBTyxzQkFBc0I7QUFDMUMsWUFBTSxNQUFNLFNBQVMsR0FBRyxPQUFPLGNBQWMsS0FBSyxNQUFNLENBQUM7QUFDekQsWUFBTSxNQUFNLE9BQU8sR0FBRyxLQUFLLElBQUksS0FBSyxNQUFNLE9BQU8sYUFBYSxHQUFHLENBQUM7QUFBQSxJQUNwRTtBQUVBLGNBQVUsaUJBQWlCLFNBQVMsWUFBWTtBQUM5QyxVQUFJLENBQUMsV0FBVztBQUNkLGNBQU0sZUFBZTtBQUFBLE1BQ3ZCLE9BQU87QUFDTCxzQkFBYztBQUFBLE1BQ2hCO0FBQUEsSUFDRixDQUFDO0FBRUQsbUJBQWUsaUJBQWdDO0FBQzdDLFVBQUk7QUFDRixjQUFNLFNBQVMsTUFBTSxVQUFVLGFBQWEsYUFBYSxFQUFFLE9BQU8sS0FBSyxDQUFDO0FBQ3hFLGlCQUFTLENBQUM7QUFDVixtQkFBVyxJQUFJLGNBQWMsUUFBUSxFQUFFLFVBQVUsYUFBYSxDQUFDO0FBRS9ELGlCQUFTLGtCQUFrQixDQUFDLE1BQU07QUFDaEMsY0FBSSxFQUFFLEtBQUssT0FBTyxFQUFHLFFBQU8sS0FBSyxFQUFFLElBQUk7QUFBQSxRQUN6QztBQUVBLGlCQUFTLFNBQVMsWUFBWTtBQUM1QixpQkFBTyxVQUFVLEVBQUUsUUFBUSxPQUFLLEVBQUUsS0FBSyxDQUFDO0FBQ3hDLGdCQUFNLE9BQU8sSUFBSSxLQUFLLFFBQVEsRUFBRSxNQUFNLGFBQWEsQ0FBQztBQUNwRCxnQkFBTSxZQUFZLElBQUk7QUFBQSxRQUN4QjtBQUVBLGlCQUFTLE1BQU07QUFDZixvQkFBWTtBQUNaLGVBQU8sVUFBVSxJQUFJLFdBQVc7QUFDaEMsa0JBQVUsVUFBVSxJQUFJLFdBQVc7QUFDbkMsa0JBQVUsY0FBYztBQUN4Qix1QkFBZSxpQkFBWTtBQUMzQixrQkFBVSxVQUFVLE9BQU8sU0FBUztBQUdwQyxtQkFBVyxNQUFNO0FBQ2YsY0FBSSxVQUFXLGVBQWM7QUFBQSxRQUMvQixHQUFHLEdBQU07QUFBQSxNQUNYLFFBQVE7QUFDTix1QkFBZSw2QkFBNkIsT0FBTztBQUFBLE1BQ3JEO0FBQUEsSUFDRjtBQUVBLGFBQVMsZ0JBQXNCO0FBQzdCLFVBQUksWUFBWSxXQUFXO0FBQ3pCLGlCQUFTLEtBQUs7QUFDZCxvQkFBWTtBQUNaLGVBQU8sVUFBVSxPQUFPLFdBQVc7QUFDbkMsa0JBQVUsVUFBVSxPQUFPLFdBQVc7QUFDdEMsa0JBQVUsY0FBYztBQUN4QixrQkFBVSxXQUFXO0FBQ3JCLHVCQUFlLGdCQUFXO0FBQUEsTUFDNUI7QUFBQSxJQUNGO0FBRUEsbUJBQWUsWUFBWSxNQUEyQjtBQUNwRCxVQUFJO0FBQ0YsY0FBTSxXQUFXLE1BQU0sS0FBSyxZQUFZO0FBQ3hDLGNBQU0sUUFBUSxJQUFJLFdBQVcsUUFBUTtBQUNyQyxZQUFJLFNBQVM7QUFDYixpQkFBUyxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsSUFBSyxXQUFVLE9BQU8sYUFBYSxNQUFNLENBQUMsQ0FBQztBQUM3RSxjQUFNLFlBQVksS0FBSyxNQUFNO0FBRTdCLHVCQUFnQixZQUE0QixVQUFVLEtBQUs7QUFFM0QsY0FBTSxPQUFPLE1BQU0saUJBQXFFO0FBQUEsVUFDdEYsTUFBTTtBQUFBLFVBQ04sU0FBUyxFQUFFLFdBQVcsVUFBVSxjQUFjLFlBQVksYUFBYTtBQUFBLFFBQ3pFLENBQUM7QUFFRCxZQUFJLFdBQVcsS0FBTSxPQUFNLElBQUksTUFBTSxPQUFPLEtBQUssS0FBSyxDQUFDO0FBRXZELHdCQUFnQixLQUFLLE9BQU87QUFDNUIsdUJBQWUsYUFBNEIsS0FBSyxPQUFPLEtBQUs7QUFDNUQsdUJBQWUsYUFBUTtBQUN2QixrQkFBVSxVQUFVLElBQUksU0FBUztBQUFBLE1BQ25DLFNBQVMsS0FBSztBQUNaLGNBQU0sTUFBTSxlQUFlLFFBQVEsSUFBSSxVQUFVO0FBQ2pELHVCQUFlLEtBQUssT0FBTztBQUFBLE1BQzdCLFVBQUU7QUFDQSxrQkFBVSxXQUFXO0FBQUEsTUFDdkI7QUFBQSxJQUNGO0FBRUEsWUFBUSxpQkFBaUIsU0FBUyxNQUFNO0FBQ3RDLFVBQUksZUFBZTtBQUNqQix5QkFBaUI7QUFBQSxVQUNmLE1BQU07QUFBQSxVQUNOLFNBQVMsRUFBRSxXQUFXLGVBQWUsVUFBVSxNQUFNLGFBQWEsS0FBSztBQUFBLFFBQ3pFLENBQUM7QUFBQSxNQUNIO0FBQ0EsZ0JBQVUsVUFBVSxPQUFPLFNBQVM7QUFDcEMsa0JBQVk7QUFDWixZQUFNLFVBQVUsT0FBTyxNQUFNO0FBQzdCLHFCQUFlLEVBQUU7QUFBQSxJQUNuQixDQUFDO0FBRUQsWUFBUSxpQkFBaUIsU0FBUyxNQUFNO0FBQ3RDLFVBQUksYUFBYyxnQkFBZSxhQUE0QixZQUFZO0FBQ3pFLFVBQUksZUFBZTtBQUNqQix5QkFBaUI7QUFBQSxVQUNmLE1BQU07QUFBQSxVQUNOLFNBQVMsRUFBRSxXQUFXLGVBQWUsVUFBVSxPQUFPLGFBQWEsS0FBSztBQUFBLFFBQzFFLENBQUM7QUFBQSxNQUNIO0FBQ0EsZ0JBQVUsVUFBVSxPQUFPLFNBQVM7QUFDcEMscUJBQWUsYUFBYSxTQUFTO0FBQ3JDLGlCQUFXLE1BQU0sZUFBZSxFQUFFLEdBQUcsR0FBSTtBQUFBLElBQzNDLENBQUM7QUFFRCxhQUFTLGVBQWUsS0FBYSxNQUFNLElBQVU7QUFDbkQsZUFBUyxjQUFjO0FBQ3ZCLGVBQVMsWUFBWTtBQUFBLElBQ3ZCO0FBR0EsVUFBTSxlQUFlLE1BQU0sS0FBSyxRQUFRLFFBQVEsRUFBRSxLQUFLLE9BQUssRUFBRSxVQUFVO0FBQ3hFLFFBQUksY0FBYztBQUNoQixjQUFRLGFBQWEsU0FBUyxhQUFhLFdBQVc7QUFBQSxJQUN4RCxPQUFPO0FBQ0wsWUFBTSxVQUFVLFFBQVEsY0FBYyxlQUFlO0FBQ3JELFVBQUksUUFBUyxTQUFRLGFBQWEsU0FBUyxPQUFPO0FBQUEsVUFDN0MsU0FBUSxZQUFZLE9BQU87QUFBQSxJQUNsQztBQUFBLEVBQ0Y7QUFJQSxXQUFTLGtCQUFrQixhQUF1QztBQUVoRSxRQUFJLEtBQXFCO0FBQ3pCLFFBQUksWUFBNEI7QUFDaEMsYUFBUyxJQUFJLEdBQUcsSUFBSSxJQUFJLEtBQUs7QUFDM0IsVUFBSSxDQUFDLEdBQUk7QUFDVCxVQUFJLEdBQUcsY0FBYyw4QkFBOEIsR0FBRztBQUFFLG9CQUFZO0FBQUk7QUFBQSxNQUFPO0FBQy9FLFdBQUssR0FBRztBQUFBLElBQ1Y7QUFFQSxRQUFJO0FBQ0osUUFBSTtBQUVKLFFBQUksV0FBVztBQUViLFlBQU0sT0FBTyxVQUFVLGNBQTJCLDhCQUE4QjtBQUNoRixZQUFNLFFBQVEsTUFBTSxhQUFhLE9BQU8sS0FBSyxNQUFNLGFBQWEsbUJBQW1CLEtBQUs7QUFDeEYsVUFBSSxNQUFNLFNBQVMsR0FBRyxFQUFHLG1CQUFrQixNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUMsRUFBRSxZQUFZO0FBRzNFLFlBQU0sWUFBWSxVQUFVLGNBQWdDLDBCQUEwQjtBQUN0RixVQUFJLFdBQVcsTUFBTyxpQkFBZ0IsVUFBVTtBQUFBLElBQ2xEO0FBRUEsV0FBTztBQUFBLE1BQ0wsVUFBVTtBQUFBLE1BQ1Ysa0JBQWtCO0FBQUEsTUFDbEIsZ0JBQWdCO0FBQUEsSUFDbEI7QUFBQSxFQUNGO0FBSUEsV0FBUyxPQUFPLGFBQTRCO0FBRTFDLFVBQU0sVUFBVSxlQUFlLFdBQVc7QUFDMUMsUUFBSSxDQUFDLFFBQVM7QUFFZCxVQUFNLFVBQVUsUUFBUTtBQUN4QixRQUFJLENBQUMsV0FBVyxRQUFRLGFBQWEsU0FBUyxFQUFHO0FBRWpELFlBQVEsYUFBYSxXQUFXLEdBQUc7QUFHbkMsVUFBTSxPQUFPLFNBQVMsY0FBYyxNQUFNO0FBQzFDLFVBQU0sU0FBUyxLQUFLLGFBQWEsRUFBRSxNQUFNLE9BQU8sQ0FBQztBQUdqRCxRQUFJLGVBQTRCO0FBQ2hDLFFBQUksZ0JBQStCO0FBQ25DLFFBQUksWUFBWTtBQUNoQixRQUFJLHNCQUFzQjtBQUMxQixRQUFJO0FBRUosV0FBTyxZQUFZO0FBQUEsYUFDUixVQUFVO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFnQmIsTUFBTSxJQUFJLE9BQUssc0NBQXNDLEVBQUUsR0FBRyxpQkFBaUIsRUFBRSxLQUFLLEtBQUssRUFBRSxLQUFLLFdBQVcsRUFBRSxLQUFLLEVBQUUsQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBZTNILFVBQU0sTUFBVyxPQUFPLGVBQWUsUUFBUTtBQUMvQyxVQUFNLFdBQVcsT0FBTyxlQUFlLGNBQWM7QUFDckQsVUFBTSxRQUFXLE9BQU8sZUFBZSxVQUFVO0FBQ2pELFVBQU0sYUFBYSxPQUFPLGVBQWUsWUFBWTtBQUNyRCxVQUFNLFdBQVcsT0FBTyxlQUFlLFdBQVc7QUFDbEQsVUFBTSxVQUFVLE9BQU8sZUFBZSxVQUFVO0FBQ2hELFVBQU0sWUFBWSxPQUFPLGVBQWUsWUFBWTtBQUNwRCxVQUFNLFlBQVksT0FBTyxlQUFlLFdBQVc7QUFDbkQsVUFBTSxZQUFZLE9BQU8sZUFBZSxXQUFXO0FBR25ELFdBQU8saUJBQW9DLFVBQVUsRUFBRSxRQUFRLGFBQVc7QUFDeEUsY0FBUSxpQkFBaUIsU0FBUyxNQUFNO0FBQ3RDLGVBQU8saUJBQWlCLFVBQVUsRUFBRSxRQUFRLE9BQUssRUFBRSxVQUFVLE9BQU8sUUFBUSxDQUFDO0FBQzdFLGdCQUFRLFVBQVUsSUFBSSxRQUFRO0FBQzlCLGdCQUFRLE1BQU0sYUFBYSxRQUFRLFFBQVEsU0FBUztBQUNwRCxnQkFBUSxNQUFNLGNBQWMsUUFBUSxRQUFRLFNBQVM7QUFDckQsdUJBQWUsUUFBUSxRQUFRO0FBQy9CLG1CQUFXLFdBQVc7QUFDdEIsaUJBQVMsY0FBYztBQUN2QixpQkFBUyxZQUFZO0FBQ3JCLGdCQUFRLFVBQVUsT0FBTyxTQUFTO0FBQ2xDLGtCQUFVLFVBQVUsT0FBTyxTQUFTO0FBQUEsTUFDdEMsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUdELGVBQVcsTUFBTSxvQkFBb0IsR0FBRyxHQUFHO0FBRTNDLGFBQVMsc0JBQTRCO0FBQ25DLFlBQU0sTUFBTSxrQkFBa0IsV0FBVztBQUN6Qyx1QkFBNEU7QUFBQSxRQUMxRSxNQUFNO0FBQUEsUUFDTixTQUFTO0FBQUEsTUFDWCxDQUFDLEVBQUUsS0FBSyxDQUFDLFNBQVM7QUFDaEIsWUFBSSxZQUFZLFFBQVEsS0FBSyxRQUFRLGNBQWM7QUFDakQsZ0NBQXNCLEtBQUssT0FBTztBQUNsQywyQkFBaUIsbUJBQW1CO0FBQUEsUUFDdEM7QUFBQSxNQUNGLENBQUMsRUFBRSxNQUFNLE1BQU07QUFBQSxNQUFvQixDQUFDO0FBQUEsSUFDdEM7QUFFQSxhQUFTLGlCQUFpQixNQUFvQjtBQUM1QyxZQUFNLFFBQVEsS0FBSyxPQUFPLENBQUMsRUFBRSxZQUFZLElBQUksS0FBSyxNQUFNLENBQUM7QUFDekQsZUFBUyxjQUFjO0FBQ3ZCLGVBQVMsVUFBVSxPQUFPLFFBQVE7QUFBQSxJQUNwQztBQUdBLFVBQU0sZ0JBQWdCLENBQUMsZ0JBQWdCLFlBQVksYUFBYSxjQUFjLFFBQVE7QUFDdEYsYUFBUyxpQkFBaUIsU0FBUyxNQUFNO0FBQ3ZDLFlBQU0sVUFBVSxtQkFBbUI7QUFDbkMsWUFBTSxNQUFNLGNBQWMsUUFBUSxPQUFPO0FBQ3pDLFlBQU0sT0FBTyxlQUFlLE1BQU0sS0FBSyxjQUFjLE1BQU07QUFDM0Qsd0JBQWtCO0FBQ2xCLHVCQUFpQixJQUFJO0FBRXJCLHVCQUFpQjtBQUFBLFFBQ2YsTUFBTTtBQUFBLFFBQ04sU0FBUztBQUFBLFVBQ1Asa0JBQWtCO0FBQUEsVUFDbEIsa0JBQWtCO0FBQUEsVUFDbEIsVUFBVTtBQUFBLFFBQ1o7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNILENBQUM7QUFHRCxRQUFJLGlCQUFpQixTQUFTLE1BQU07QUFDbEMsa0JBQVksQ0FBQztBQUNiLFlBQU0sVUFBVSxPQUFPLFFBQVEsU0FBUztBQUN4QyxVQUFJLFVBQVcsZUFBYztBQUFBLElBQy9CLENBQUM7QUFHRCxhQUFTLGlCQUFpQixTQUFTLENBQUMsTUFBTTtBQUN4QyxVQUFJLENBQUMsS0FBSyxTQUFTLEVBQUUsTUFBYyxLQUFLLFdBQVc7QUFDakQsb0JBQVk7QUFDWixjQUFNLFVBQVUsT0FBTyxNQUFNO0FBQUEsTUFDL0I7QUFBQSxJQUNGLEdBQUcsSUFBSTtBQUVQLGFBQVMsZ0JBQXNCO0FBQzdCLFlBQU0sT0FBTyxJQUFJLHNCQUFzQjtBQUN2QyxZQUFNLE1BQU0sU0FBUyxHQUFHLE9BQU8sY0FBYyxLQUFLLE1BQU0sQ0FBQztBQUN6RCxZQUFNLE1BQU0sT0FBTyxHQUFHLEtBQUssSUFBSSxLQUFLLE1BQU0sT0FBTyxhQUFhLEdBQUcsQ0FBQztBQUFBLElBQ3BFO0FBRUEsUUFBSSxlQUFlO0FBR25CLGVBQVcsaUJBQWlCLFNBQVMsWUFBWTtBQUMvQyxVQUFJLENBQUMsYUFBYztBQUVuQixZQUFNLE9BQVEsWUFBNEIsVUFBVSxLQUFLO0FBQ3pELFVBQUksQ0FBQyxNQUFNO0FBQ1Qsa0JBQVUsMEJBQTBCLE9BQU87QUFDM0M7QUFBQSxNQUNGO0FBRUEscUJBQWU7QUFDZixVQUFJLFdBQVc7QUFDZixpQkFBVyxXQUFXO0FBQ3RCLGdCQUFVLGlCQUFZO0FBQ3RCLGdCQUFVLFVBQVUsT0FBTyxTQUFTO0FBRXBDLFVBQUk7QUFDRixjQUFNLFVBQVUsa0JBQWtCLFdBQVc7QUFDN0MsY0FBTSxPQUFPLE1BQU0saUJBQThDO0FBQUEsVUFDL0QsTUFBTTtBQUFBLFVBQ04sU0FBUztBQUFBLFlBQ1A7QUFBQSxZQUNBLE1BQU07QUFBQSxZQUNOLEtBQUssRUFBRSxHQUFHLFNBQVMsdUJBQXVCLGdCQUFnQjtBQUFBLFVBQzVEO0FBQUEsUUFDRixDQUFDO0FBRUQsWUFBSSxXQUFXLEtBQU0sT0FBTSxJQUFJLE1BQU0sT0FBTyxLQUFLLEtBQUssQ0FBQztBQUV2RCx3QkFBZ0IsS0FBSyxPQUFPO0FBQzVCLHVCQUFlLGFBQTRCLEtBQUssT0FBTyxXQUFXO0FBQ2xFLGtCQUFVLGVBQVUsU0FBUztBQUM3QixrQkFBVSxVQUFVLElBQUksU0FBUztBQUFBLE1BQ25DLFNBQVMsS0FBSztBQUNaLGNBQU0sTUFBTSxlQUFlLFFBQVEsSUFBSSxVQUFVO0FBQ2pELFlBQUksSUFBSSxXQUFXLGdCQUFnQixHQUFHO0FBQ3BDLGtCQUFRLFVBQVUsSUFBSSxTQUFTO0FBQy9CLG9CQUFVLEVBQUU7QUFBQSxRQUNkLE9BQU87QUFDTCxvQkFBVSxLQUFLLE9BQU87QUFBQSxRQUN4QjtBQUFBLE1BQ0YsVUFBRTtBQUNBLFlBQUksV0FBVztBQUNmLG1CQUFXLFdBQVcsaUJBQWlCO0FBQUEsTUFDekM7QUFBQSxJQUNGLENBQUM7QUFHRCxjQUFVLGlCQUFpQixTQUFTLFlBQVk7QUFDOUMsVUFBSSxlQUFlO0FBQ2pCLHlCQUFpQixFQUFFLE1BQU0sWUFBWSxTQUFTLEVBQUUsV0FBVyxlQUFlLFFBQVEsV0FBVyxFQUFFLENBQUM7QUFBQSxNQUNsRztBQUNBLGdCQUFVLFVBQVUsT0FBTyxTQUFTO0FBQ3BDLGtCQUFZO0FBQ1osWUFBTSxVQUFVLE9BQU8sTUFBTTtBQUM3QixnQkFBVSxFQUFFO0FBQUEsSUFDZCxDQUFDO0FBR0QsY0FBVSxpQkFBaUIsU0FBUyxZQUFZO0FBQzlDLFVBQUksYUFBYyxnQkFBZSxhQUE0QixZQUFZO0FBQ3pFLFVBQUksZUFBZTtBQUNqQix5QkFBaUIsRUFBRSxNQUFNLFlBQVksU0FBUyxFQUFFLFdBQVcsZUFBZSxRQUFRLFdBQVcsRUFBRSxDQUFDO0FBQUEsTUFDbEc7QUFDQSxnQkFBVSxVQUFVLE9BQU8sU0FBUztBQUNwQyxnQkFBVSxhQUFhLFNBQVM7QUFDaEMsaUJBQVcsTUFBTSxVQUFVLEVBQUUsR0FBRyxHQUFJO0FBQUEsSUFDdEMsQ0FBQztBQUVELGFBQVMsVUFBVSxLQUFhLE1BQU0sSUFBVTtBQUM5QyxlQUFTLGNBQWM7QUFDdkIsZUFBUyxZQUFZO0FBQUEsSUFDdkI7QUFHQSxZQUFRLGFBQWEsTUFBTSxPQUFPO0FBR2xDLG9CQUFnQixTQUFTLFdBQVc7QUFHcEMsZUFBVyxNQUFNLGFBQWEsV0FBVyxHQUFHLEdBQUc7QUFBQSxFQUNqRDtBQUlBLFdBQVMsZUFBZSxhQUFzQztBQUc1RCxRQUFJLEtBQXFCO0FBQ3pCLGFBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxLQUFLO0FBQzNCLFVBQUksQ0FBQyxHQUFJO0FBQ1QsWUFBTSxPQUFPLEdBQUcsY0FBYyxlQUFlO0FBQzdDLFVBQUksS0FBTSxRQUFPO0FBQ2pCLFdBQUssR0FBRztBQUFBLElBQ1Y7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUVBLFdBQVMsZUFBZSxJQUFpQixNQUFvQjtBQUMzRCxPQUFHLE1BQU07QUFDVCxhQUFTLFlBQVksYUFBYSxPQUFPLE1BQVM7QUFDbEQsYUFBUyxZQUFZLFVBQVUsT0FBTyxNQUFTO0FBRS9DLFVBQU0sUUFBUSxLQUFLLE1BQU0sSUFBSTtBQUM3QixhQUFTLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLO0FBQ3JDLFVBQUksTUFBTSxDQUFDLEVBQUcsVUFBUyxZQUFZLGNBQWMsT0FBTyxNQUFNLENBQUMsQ0FBQztBQUNoRSxVQUFJLElBQUksTUFBTSxTQUFTLEVBQUcsVUFBUyxZQUFZLG1CQUFtQixPQUFPLE1BQVM7QUFBQSxJQUNwRjtBQUFBLEVBQ0Y7QUFFQSxXQUFTLGlCQUFvQixTQUE2QjtBQUN4RCxXQUFPLElBQUksUUFBUSxDQUFDLFlBQVk7QUFDOUIsYUFBTyxRQUFRLFlBQVksU0FBUyxPQUFPO0FBQUEsSUFDN0MsQ0FBQztBQUFBLEVBQ0g7QUFTQSxXQUFTLHNCQUFzQixhQUFzQztBQUNuRSxRQUFJLEtBQXFCO0FBQ3pCLFFBQUksa0JBQWtDO0FBQ3RDLGFBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxLQUFLO0FBQzNCLFVBQUksQ0FBQyxHQUFJO0FBQ1QsVUFBSSxHQUFHLGlCQUFpQixLQUFLLEVBQUUsU0FBUyxHQUFHO0FBQUUsMEJBQWtCO0FBQUk7QUFBQSxNQUFPO0FBQzFFLFdBQUssR0FBRztBQUFBLElBQ1Y7QUFDQSxRQUFJLENBQUMsZ0JBQWlCLFFBQU87QUFHN0IsVUFBTSxPQUFPLE1BQU0sS0FBSyxnQkFBZ0IsaUJBQWlCLEtBQUssQ0FBQztBQUMvRCxhQUFTLElBQUksS0FBSyxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7QUFDekMsVUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLFNBQVMsV0FBVyxFQUFHLFFBQU8sS0FBSyxDQUFDO0FBQUEsSUFDbkQ7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUVBLFdBQVMsb0JBQW9CLE9BQStCO0FBRTFELFVBQU0sU0FDSixNQUFNLGNBQWMsVUFBVSxLQUM5QixNQUFNLGNBQWMsUUFBUSxLQUM1QixNQUFNLGNBQWMsTUFBTTtBQUU1QixRQUFJLENBQUMsT0FBUSxRQUFPO0FBQ3BCLFVBQU0sT0FBTyxPQUFPLFVBQVUsS0FBSztBQUNuQyxRQUFJLEtBQUssU0FBUyxHQUFJLFFBQU87QUFFN0IsV0FBTyxLQUFLLE1BQU0sS0FBSyxFQUFFLE1BQU0sR0FBRyxHQUFHLEVBQUUsS0FBSyxHQUFHO0FBQUEsRUFDakQ7QUFFQSxNQUFNLGtCQUFrQjtBQUV4QixpQkFBZSxhQUFhLGFBQXFDO0FBRS9ELFFBQUksWUFBWSxhQUFhLGVBQWUsRUFBRztBQUMvQyxnQkFBWSxhQUFhLGlCQUFpQixHQUFHO0FBRzdDLFFBQUssWUFBNEIsVUFBVSxLQUFLLE1BQU0sR0FBSTtBQUUxRCxVQUFNLGFBQWEsc0JBQXNCLFdBQVc7QUFDcEQsUUFBSSxDQUFDLFdBQVk7QUFFakIsVUFBTSxlQUFlLG9CQUFvQixVQUFVO0FBQ25ELFFBQUksQ0FBQyxhQUFjO0FBRW5CLFVBQU0sTUFBTSxrQkFBa0IsV0FBVztBQUd6QyxVQUFNLGFBQWEsSUFBSSxnQkFBZ0I7QUFDdkMsVUFBTSxZQUFZLFdBQVcsTUFBTSxXQUFXLE1BQU0sR0FBRyxxQkFBcUI7QUFFNUUsUUFBSTtBQUNKLFFBQUk7QUFDRixZQUFNLE9BQU8sTUFBTSxRQUFRLEtBQUs7QUFBQSxRQUM5QixpQkFBb0U7QUFBQSxVQUNsRSxNQUFNO0FBQUEsVUFDTixTQUFTO0FBQUEsWUFDUDtBQUFBLFlBQ0EsTUFBTTtBQUFBLFlBQ047QUFBQSxVQUNGO0FBQUEsUUFDRixDQUFDO0FBQUEsUUFDRCxJQUFJO0FBQUEsVUFBZSxDQUFDLEdBQUcsV0FDckIsV0FBVyxNQUFNLE9BQU8sSUFBSSxNQUFNLFNBQVMsQ0FBQyxHQUFHLHFCQUFxQjtBQUFBLFFBQ3RFO0FBQUEsTUFDRixDQUFDO0FBQ0QsbUJBQWEsU0FBUztBQUN0QixVQUFJLFdBQVcsS0FBTTtBQUNyQixlQUFTLEtBQUs7QUFBQSxJQUNoQixRQUFRO0FBQ04sbUJBQWEsU0FBUztBQUN0QjtBQUFBLElBQ0Y7QUFHQSxRQUFLLFlBQTRCLFVBQVUsS0FBSyxNQUFNLEdBQUk7QUFFMUQsd0JBQW9CLGFBQWEsTUFBTTtBQUFBLEVBQ3pDO0FBRUEsV0FBUyxvQkFBb0IsYUFBc0IsUUFBaUM7QUFFbEYsYUFBUyxlQUFlLHNCQUFzQixHQUFHLE9BQU87QUFFeEQsVUFBTSxTQUFTLFNBQVMsY0FBYyxLQUFLO0FBQzNDLFdBQU8sS0FBSztBQUNaLFdBQU8sTUFBTSxVQUFVO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFTdkIsVUFBTSxRQUFRLFNBQVMsY0FBYyxNQUFNO0FBQzNDLFVBQU0sTUFBTSxVQUFVO0FBQ3RCLFVBQU0sY0FBYztBQUVwQixVQUFNLFNBQVMsU0FBUyxjQUFjLFFBQVE7QUFDOUMsV0FBTyxNQUFNLFVBQVU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUt2QixXQUFPLGNBQWM7QUFFckIsVUFBTSxhQUFhLFNBQVMsY0FBYyxRQUFRO0FBQ2xELGVBQVcsTUFBTSxVQUFVO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFLM0IsZUFBVyxRQUFRO0FBQ25CLGVBQVcsY0FBYztBQUV6QixXQUFPLE9BQU8sT0FBTyxRQUFRLFVBQVU7QUFDdkMsYUFBUyxLQUFLLFlBQVksTUFBTTtBQUdoQyxhQUFTLGlCQUF1QjtBQUM5QixZQUFNLE9BQU8sWUFBWSxzQkFBc0I7QUFDL0MsYUFBTyxNQUFNLE1BQU0sR0FBRyxLQUFLLElBQUksS0FBSyxNQUFNLElBQUksRUFBRSxDQUFDO0FBQ2pELGFBQU8sTUFBTSxPQUFPLEdBQUcsS0FBSyxJQUFJLEtBQUssTUFBTSxPQUFPLGFBQWEsR0FBRyxDQUFDO0FBQUEsSUFDckU7QUFDQSxtQkFBZTtBQUNmLFdBQU8saUJBQWlCLFVBQVUsZ0JBQWdCLEVBQUUsU0FBUyxLQUFLLENBQUM7QUFFbkUsYUFBUyxlQUFxQjtBQUM1QixhQUFPLE9BQU87QUFDZCxhQUFPLG9CQUFvQixVQUFVLGNBQWM7QUFBQSxJQUNyRDtBQUdBLFdBQU8saUJBQWlCLFNBQVMsTUFBTTtBQUNyQyxxQkFBZSxhQUE0QixPQUFPLEtBQUs7QUFDdkQsdUJBQWlCO0FBQUEsUUFDZixNQUFNO0FBQUEsUUFDTixTQUFTLEVBQUUsU0FBUyxPQUFPLElBQUksTUFBTSxLQUFLO0FBQUEsTUFDNUMsQ0FBQztBQUNELG1CQUFhO0FBQUEsSUFDZixDQUFDO0FBR0QsZUFBVyxpQkFBaUIsU0FBUyxNQUFNO0FBQ3pDLHVCQUFpQjtBQUFBLFFBQ2YsTUFBTTtBQUFBLFFBQ04sU0FBUyxFQUFFLFNBQVMsT0FBTyxJQUFJLE1BQU0sTUFBTTtBQUFBLE1BQzdDLENBQUM7QUFDRCxtQkFBYTtBQUFBLElBQ2YsQ0FBQztBQUdELFVBQU0saUJBQWlCLE1BQVk7QUFDakMsVUFBSyxZQUE0QixVQUFVLEtBQUssTUFBTSxJQUFJO0FBQ3hELHlCQUFpQjtBQUFBLFVBQ2YsTUFBTTtBQUFBLFVBQ04sU0FBUyxFQUFFLFNBQVMsT0FBTyxJQUFJLE1BQU0sTUFBTTtBQUFBLFFBQzdDLENBQUM7QUFDRCxxQkFBYTtBQUNiLG9CQUFZLG9CQUFvQixTQUFTLGNBQWM7QUFBQSxNQUN6RDtBQUFBLElBQ0Y7QUFDQSxnQkFBWSxpQkFBaUIsU0FBUyxjQUFjO0FBR3BELGVBQVcsY0FBYyxHQUFNO0FBQUEsRUFDakM7QUFJQSxNQUFNLE9BQU8sb0JBQUksUUFBaUI7QUFFbEMsV0FBUyxVQUFVLE1BQWdDO0FBQ2pELFNBQUssaUJBQTBCLGdCQUFnQixFQUFFLFFBQVEsQ0FBQyxTQUFTO0FBQ2pFLFVBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxHQUFHO0FBQ25CLGFBQUssSUFBSSxJQUFJO0FBQ2IsZUFBTyxJQUFJO0FBQUEsTUFDYjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFFQSxNQUFNLFdBQVcsSUFBSSxpQkFBaUIsTUFBTSxVQUFVLFFBQVEsQ0FBQztBQUUvRCxXQUFTLFFBQVEsU0FBUyxNQUFNLEVBQUUsV0FBVyxNQUFNLFNBQVMsS0FBSyxDQUFDO0FBR2xFLFlBQVUsUUFBUTtBQUdsQixXQUFTLGlCQUFpQixXQUFXLENBQUMsTUFBTTtBQUMxQyxVQUFNLFVBQVUsU0FBUyxjQUFjLElBQUksU0FBUyxHQUFHO0FBQ3ZELFFBQUksQ0FBQyxRQUFTO0FBQ2QsVUFBTSxRQUFRLE1BQU0sS0FBSyxRQUFRLFFBQVEsRUFBRSxPQUFPLE9BQUssRUFBRSxVQUFVO0FBRW5FLFNBQUssRUFBRSxXQUFXLEVBQUUsWUFBWSxFQUFFLFlBQVksRUFBRSxRQUFRLEtBQUs7QUFDM0QsUUFBRSxlQUFlO0FBRWpCLFlBQU0sTUFBTSxNQUFNLENBQUMsR0FBRyxZQUFZLGVBQWUsUUFBUTtBQUN6RCxXQUFLLE1BQU07QUFBQSxJQUNiO0FBRUEsU0FBSyxFQUFFLFdBQVcsRUFBRSxZQUFZLEVBQUUsWUFBWSxFQUFFLFFBQVEsS0FBSztBQUMzRCxRQUFFLGVBQWU7QUFFakIsWUFBTSxNQUFNLE1BQU0sQ0FBQyxHQUFHLFlBQVksZUFBZSxZQUFZO0FBQzdELFdBQUssTUFBTTtBQUFBLElBQ2I7QUFBQSxFQUNGLENBQUM7IiwKICAibmFtZXMiOiBbXQp9Cg==
