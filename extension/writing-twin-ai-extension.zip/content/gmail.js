"use strict";
(() => {
  // src/content/gmail.ts
  var COMPOSE_BODY_SEL = '[g_editable="true"], div[contenteditable="true"][aria-multiline="true"]';
  var SEND_BUTTON_SEL = '[data-tooltip^="Send"], [aria-label^="Send"]';
  var HOST_ATTR = "data-wt-injected";
  var FREE_DOMAINS = /* @__PURE__ */ new Set(["gmail.com", "yahoo.com", "outlook.com", "hotmail.com", "icloud.com", "protonmail.com", "aol.com", "live.com"]);
  var FORMAL_SUBJECT_RE = /proposal|agreement|contract|invoice|report|presentation|strategy|executive|board|investor|client|partner/i;
  var CASUAL_SUBJECT_RE = /hey|hi|quick|catch up|fyi|heads up|question|help|idea/i;
  function detectContextTone(composeBody) {
    const compose = composeBody.closest("[data-message-id], [data-thread-id]") ?? document;
    const subject = compose.querySelector?.('input[name="subjectbox"]')?.value ?? "";
    const toTokens = Array.from(compose.querySelectorAll?.("[email]") ?? []).map((el) => (el.getAttribute("email") ?? "").toLowerCase().split("@")[1] ?? "");
    const hasExternalRecipient = toTokens.some((domain) => domain && !FREE_DOMAINS.has(domain));
    const hasPersonalEmail = toTokens.every((domain) => FREE_DOMAINS.has(domain));
    if (FORMAL_SUBJECT_RE.test(subject) || hasExternalRecipient && toTokens.length > 0) {
      return "professional";
    }
    if (/board|ceo|vp |cto |cfo |director|investor/i.test(subject)) {
      return "executive";
    }
    if (CASUAL_SUBJECT_RE.test(subject) || hasPersonalEmail) {
      return "friendly";
    }
    return "professional";
  }
  var TONES = [
    { key: "professional", label: "Professional", color: "#4F46E5" },
    { key: "casual", label: "Casual", color: "#06B6D4" },
    { key: "friendly", label: "Friendly", color: "#F59E0B" },
    { key: "direct", label: "Direct", color: "#DC2626" },
    { key: "diplomatic", label: "Diplomatic", color: "#7C3AED" },
    { key: "executive", label: "Executive", color: "#0F172A" }
  ];
  var BUTTON_CSS = `
  :host { display: inline-flex; align-items: center; margin-left: 8px; }

  #wt-btn {
    display: inline-flex; align-items: center; gap: 5px;
    height: 28px; padding: 0 12px; border-radius: 9999px; border: none;
    background: #4F46E5; color: #fff;
    font: 500 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer; white-space: nowrap;
    transition: background 0.15s, box-shadow 0.15s;
  }
  #wt-btn:hover { background: #3F37C9; box-shadow: 0 0 0 3px rgba(79,70,229,0.25); }
  #wt-btn:disabled { opacity: 0.6; cursor: default; box-shadow: none; }

  #wt-panel {
    position: fixed; z-index: 9999;
    background: #fff; border: 1px solid #E8EAED; border-radius: 10px;
    box-shadow: 0 12px 32px rgba(15,23,42,0.14);
    padding: 14px 16px; width: 260px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: none;
  }
  #wt-panel.open { display: block; }

  .wt-title {
    font-size: 12px; font-weight: 600; color: #374151; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase;
  }
  .wt-tones {
    display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 12px;
  }
  .wt-tone {
    padding: 4px 10px; border-radius: 9999px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151;
    cursor: pointer; transition: all 0.1s;
  }
  .wt-tone.active {
    color: #fff; border-color: transparent;
  }
  .wt-tone:hover:not(.active) { border-color: #9BA0FF; }

  #wt-rewrite {
    width: 100%; height: 32px; border-radius: 8px; border: none;
    background: #4F46E5; color: #fff;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer;
  }
  #wt-rewrite:disabled { opacity: 0.45; cursor: default; }

  #wt-status {
    margin-top: 8px; font-size: 11px; text-align: center; min-height: 14px;
  }
  #wt-status.error { color: #EF4444; }
  #wt-status.success { color: #10B981; }

  #wt-limit {
    display: none; margin-top: 10px; padding: 10px 12px; border-radius: 8px;
    background: #FFF8F1; border: 1px solid #FED7AA; text-align: center;
  }
  #wt-limit.visible { display: block; }
  #wt-limit p { font-size: 11px; color: #92400E; margin: 0 0 8px; line-height: 1.4; }
  #wt-limit a {
    display: inline-block; padding: 5px 14px; border-radius: 9999px;
    background: #F59E0B; color: #fff; font-size: 11px; font-weight: 600;
    text-decoration: none;
  }
  #wt-limit a:hover { background: #D97706; }

  #wt-voicematch {
    display: none; align-items: center; gap: 6px;
    margin-top: 10px; padding: 7px 10px; border-radius: 8px;
    background: linear-gradient(135deg, #EDE9FE 0%, #F5F3FF 100%);
    border: 1px solid #DDD6FE;
  }
  #wt-voicematch.visible { display: flex; }
  #wt-voicematch .wt-vm-spark { font-size: 13px; line-height: 1; }
  #wt-voicematch .wt-vm-text { font-size: 11.5px; font-weight: 600; color: #5B21B6; }
  #wt-voicematch .wt-vm-pct {
    margin-left: auto; font-size: 11.5px; font-weight: 700; color: #4F46E5;
  }

  #wt-actions {
    display: none; gap: 6px; margin-top: 8px;
  }
  #wt-actions.visible { display: flex; }
  .wt-action {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151;
    cursor: pointer; transition: background 0.1s, border-color 0.1s;
  }
  .wt-action:disabled { opacity: 0.5; cursor: default; }
  .wt-action.accept { border-color: #10B981; color: #10B981; }
  .wt-action.accept:hover:not(:disabled) { background: #ECFDF5; }
  .wt-action.regen { border-color: #C7D2FE; color: #4F46E5; }
  .wt-action.regen:hover:not(:disabled) { background: #EEF2FF; }
  .wt-action.reject { border-color: #EF4444; color: #EF4444; }
  .wt-action.reject:hover:not(:disabled) { background: #FEF2F2; }
`;
  var VOICE_OUTPUT_TYPES = [
    { key: "reply", label: "Reply" },
    { key: "email", label: "Email" },
    { key: "customer_update", label: "Customer Update" },
    { key: "jira_ticket", label: "Jira Ticket" },
    { key: "technical_report", label: "Tech Report" }
  ];
  var MIC_CSS = `
  :host { display: inline-flex; align-items: center; margin-left: 4px; }

  #wt-mic-btn {
    display: inline-flex; align-items: center; justify-content: center;
    width: 28px; height: 28px; border-radius: 9999px; border: none;
    background: transparent; color: #5F6368; cursor: pointer;
    transition: background 0.15s, color 0.15s;
    font-size: 15px; line-height: 1;
  }
  #wt-mic-btn:hover { background: rgba(0,0,0,0.07); }
  #wt-mic-btn.recording {
    background: #FEE2E2; color: #DC2626;
    animation: wt-pulse 1.2s ease-in-out infinite;
  }
  @keyframes wt-pulse {
    0%, 100% { box-shadow: 0 0 0 0 rgba(220,38,38,0.4); }
    50%       { box-shadow: 0 0 0 5px rgba(220,38,38,0); }
  }
  #wt-mic-btn:disabled { opacity: 0.5; cursor: default; }

  #wt-voice-panel {
    position: fixed; z-index: 9999;
    background: #fff; border: 1px solid #E8EAED; border-radius: 10px;
    box-shadow: 0 12px 32px rgba(15,23,42,0.14);
    padding: 14px 16px; width: 280px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: none;
  }
  #wt-voice-panel.open { display: block; }

  .wt-vt { font-size: 12px; font-weight: 600; color: #374151; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase; }

  #wt-record-btn {
    width: 100%; height: 34px; border-radius: 8px; border: none;
    background: #DC2626; color: #fff; cursor: pointer;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    margin-bottom: 10px;
  }
  #wt-record-btn.recording { background: #7F1D1D; }
  #wt-record-btn:disabled { opacity: 0.5; cursor: default; }

  .wt-otype-label { font-size: 11px; color: #6B7280; margin-bottom: 4px; }
  .wt-otypes { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 10px; }
  .wt-otype {
    padding: 3px 9px; border-radius: 9999px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 11px; color: #374151; cursor: pointer;
    transition: all 0.1s;
  }
  .wt-otype.active { background: #4F46E5; color: #fff; border-color: #4F46E5; }

  #wt-voice-status { font-size: 11px; text-align: center; min-height: 14px; color: #6B7280; }
  #wt-voice-status.error { color: #EF4444; }

  #wt-voice-actions { display: none; gap: 6px; margin-top: 8px; }
  #wt-voice-actions.visible { display: flex; }
  .wt-va {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151; cursor: pointer;
  }
  .wt-va.accept { border-color: #10B981; color: #10B981; }
  .wt-va.reject { border-color: #EF4444; color: #EF4444; }
`;
  function injectMicButton(toolbar, composeBody) {
    const micHost = document.createElement("span");
    const shadow = micHost.attachShadow({ mode: "open" });
    shadow.innerHTML = `
    <style>${MIC_CSS}</style>
    <button id="wt-mic-btn" title="Voice Twin \u2014 speak your email (Cmd+Shift+V)">\u{1F399}</button>
    <div id="wt-voice-panel">
      <p class="wt-vt">Voice Twin</p>
      <div class="wt-otype-label">Output type</div>
      <div class="wt-otypes">
        ${VOICE_OUTPUT_TYPES.map(
      (o, i) => `<button class="wt-otype${i === 0 ? " active" : ""}" data-type="${o.key}">${o.label}</button>`
    ).join("")}
      </div>
      <button id="wt-record-btn">\u{1F399} Start recording</button>
      <div id="wt-voice-status"></div>
      <div id="wt-voice-actions">
        <button class="wt-va accept" id="wt-va-keep">\u2713 Keep it</button>
        <button class="wt-va reject" id="wt-va-undo">\u2717 Undo</button>
      </div>
    </div>
  `;
    const micBtn = shadow.getElementById("wt-mic-btn");
    const panel = shadow.getElementById("wt-voice-panel");
    const recordBtn = shadow.getElementById("wt-record-btn");
    const statusEl = shadow.getElementById("wt-voice-status");
    const actionsEl = shadow.getElementById("wt-voice-actions");
    const keepBtn = shadow.getElementById("wt-va-keep");
    const undoBtn = shadow.getElementById("wt-va-undo");
    let panelOpen = false;
    let selectedType = "reply";
    let recognition = null;
    let recording = false;
    let transcript = "";
    let lastSessionId = null;
    let originalText = "";
    shadow.querySelectorAll(".wt-otype").forEach((btn) => {
      btn.addEventListener("click", () => {
        shadow.querySelectorAll(".wt-otype").forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        selectedType = btn.dataset.type;
      });
    });
    micBtn.addEventListener("click", () => {
      panelOpen = !panelOpen;
      panel.classList.toggle("open", panelOpen);
      if (panelOpen) positionPanel();
    });
    document.addEventListener("click", (e) => {
      if (!micHost.contains(e.target) && panelOpen) {
        panelOpen = false;
        panel.classList.remove("open");
      }
    }, true);
    function positionPanel() {
      const rect = micBtn.getBoundingClientRect();
      panel.style.bottom = `${window.innerHeight - rect.top + 4}px`;
      panel.style.left = `${Math.min(rect.left, window.innerWidth - 296)}px`;
    }
    recordBtn.addEventListener("click", async () => {
      if (!recording) {
        await startRecording();
      } else {
        stopRecording();
      }
    });
    async function startRecording() {
      const SpeechRecognition = window.webkitSpeechRecognition;
      if (!SpeechRecognition) {
        setVoiceStatus("Speech recognition not supported in this browser.", "error");
        return;
      }
      transcript = "";
      recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = "en-US";
      recognition.onresult = (e) => {
        let interim = "";
        for (let i = e.resultIndex; i < e.results.length; i++) {
          if (e.results[i].isFinal) {
            transcript += e.results[i][0].transcript + " ";
          } else {
            interim += e.results[i][0].transcript;
          }
        }
        setVoiceStatus(`\u{1F399} ${(transcript + interim).trim() || "Listening\u2026"}`);
      };
      recognition.onerror = (e) => {
        if (e.error !== "aborted") setVoiceStatus(`Mic error: ${e.error}`, "error");
      };
      recognition.onend = () => {
        if (recording) {
          recognition?.start();
        }
      };
      try {
        recognition.start();
        recording = true;
        micBtn.classList.add("recording");
        recordBtn.classList.add("recording");
        recordBtn.textContent = "\u23F9 Stop recording";
        actionsEl.classList.remove("visible");
        setTimeout(() => {
          if (recording) stopRecording();
        }, 6e4);
      } catch {
        setVoiceStatus("Microphone access denied.", "error");
      }
    }
    function stopRecording() {
      if (recognition && recording) {
        recording = false;
        recognition.onend = null;
        recognition.stop();
        recognition = null;
        micBtn.classList.remove("recording");
        recordBtn.classList.remove("recording");
        recordBtn.textContent = "\u{1F399} Start recording";
        recordBtn.disabled = true;
        setVoiceStatus("Drafting\u2026");
        void submitTranscript();
      }
    }
    async function submitTranscript() {
      try {
        const text = transcript.trim();
        if (!text) {
          setVoiceStatus("Nothing recorded \u2014 try again.", "error");
          recordBtn.disabled = false;
          return;
        }
        originalText = composeBody.innerText.trim();
        const resp = await sendToBackground({
          type: "VOICE_DRAFT",
          payload: { transcript: text, outputType: selectedType }
        });
        if ("error" in resp) throw new Error(String(resp.error));
        lastSessionId = resp.result.id;
        setComposeText(composeBody, resp.result.draft);
        setVoiceStatus("Done \u2713");
        actionsEl.classList.add("visible");
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Failed";
        setVoiceStatus(msg, "error");
      } finally {
        recordBtn.disabled = false;
      }
    }
    keepBtn.addEventListener("click", () => {
      if (lastSessionId) {
        sendToBackground({
          type: "VOICE_FEEDBACK",
          payload: { sessionId: lastSessionId, accepted: true, editedDraft: null }
        });
      }
      actionsEl.classList.remove("visible");
      panelOpen = false;
      panel.classList.remove("open");
      setVoiceStatus("");
    });
    undoBtn.addEventListener("click", () => {
      if (originalText) setComposeText(composeBody, originalText);
      if (lastSessionId) {
        sendToBackground({
          type: "VOICE_FEEDBACK",
          payload: { sessionId: lastSessionId, accepted: false, editedDraft: null }
        });
      }
      actionsEl.classList.remove("visible");
      setVoiceStatus("Reverted.", "success");
      setTimeout(() => setVoiceStatus(""), 2e3);
    });
    function setVoiceStatus(msg, cls = "") {
      statusEl.textContent = msg;
      statusEl.className = cls;
    }
    const humanizeHost = Array.from(toolbar.children).find((c) => c.shadowRoot);
    if (humanizeHost) {
      toolbar.insertBefore(micHost, humanizeHost.nextSibling);
    } else {
      const sendBtn = toolbar.querySelector(SEND_BUTTON_SEL);
      if (sendBtn) toolbar.insertBefore(micHost, sendBtn);
      else toolbar.appendChild(micHost);
    }
  }
  function inject(composeBody) {
    const sendBtn = findSendButton(composeBody);
    if (!sendBtn) return;
    const toolbar = sendBtn.parentElement;
    if (!toolbar || toolbar.hasAttribute(HOST_ATTR)) return;
    toolbar.setAttribute(HOST_ATTR, "1");
    const host = document.createElement("span");
    const shadow = host.attachShadow({ mode: "open" });
    let selectedTone = null;
    let lastRewriteId = null;
    let panelOpen = false;
    shadow.innerHTML = `
    <style>${BUTTON_CSS}</style>
    <button id="wt-btn" title="Humanize with Writing Twin AI (Cmd+Shift+H)">\u2728 Humanize</button>
    <div id="wt-panel">
      <p class="wt-title">Rewrite tone</p>
      <div class="wt-tones">
        ${TONES.map((t) => `<button class="wt-tone" data-tone="${t.key}" data-color="${t.color}">${t.label}</button>`).join("")}
      </div>
      <button id="wt-rewrite" disabled>Rewrite \u2192</button>
      <div id="wt-status"></div>
      <div id="wt-limit">
        <p>You've used all your free rewrites this month.</p>
        <a href="https://writingtwinai.com/pricing" target="_blank" rel="noopener">Upgrade to Pro \u2014 $5/mo</a>
      </div>
      <div id="wt-voicematch">
        <span class="wt-vm-spark">\u2728</span>
        <span class="wt-vm-text">Sounds like you</span>
        <span class="wt-vm-pct" id="wt-vm-pct"></span>
      </div>
      <div id="wt-actions">
        <button class="wt-action accept" id="wt-accept">\u2713 Keep</button>
        <button class="wt-action regen" id="wt-regen">\u21BB Again</button>
        <button class="wt-action reject" id="wt-reject">\u2717 Undo</button>
      </div>
    </div>
  `;
    const btn = shadow.getElementById("wt-btn");
    const panel = shadow.getElementById("wt-panel");
    const rewriteBtn = shadow.getElementById("wt-rewrite");
    const statusEl = shadow.getElementById("wt-status");
    const limitEl = shadow.getElementById("wt-limit");
    const actionsEl = shadow.getElementById("wt-actions");
    const voicematchEl = shadow.getElementById("wt-voicematch");
    const vmPctEl = shadow.getElementById("wt-vm-pct");
    const acceptBtn = shadow.getElementById("wt-accept");
    const regenBtn = shadow.getElementById("wt-regen");
    const rejectBtn = shadow.getElementById("wt-reject");
    shadow.querySelectorAll(".wt-tone").forEach((tonebtn) => {
      tonebtn.addEventListener("click", () => {
        shadow.querySelectorAll(".wt-tone").forEach((b) => b.classList.remove("active"));
        tonebtn.classList.add("active");
        tonebtn.style.background = tonebtn.dataset.color ?? "#4F46E5";
        tonebtn.style.borderColor = tonebtn.dataset.color ?? "#4F46E5";
        selectedTone = tonebtn.dataset.tone;
        rewriteBtn.disabled = false;
        statusEl.textContent = "";
        statusEl.className = "";
        limitEl.classList.remove("visible");
        actionsEl.classList.remove("visible");
        voicematchEl.classList.remove("visible");
      });
    });
    function preselectTone(tone) {
      const toneBtn = shadow.querySelector(`.wt-tone[data-tone="${tone}"]`);
      if (toneBtn && !selectedTone) {
        shadow.querySelectorAll(".wt-tone").forEach((b) => b.classList.remove("active"));
        toneBtn.classList.add("active");
        toneBtn.style.background = toneBtn.dataset.color ?? "#4F46E5";
        toneBtn.style.borderColor = toneBtn.dataset.color ?? "#4F46E5";
        selectedTone = tone;
        rewriteBtn.disabled = false;
      }
    }
    btn.addEventListener("click", () => {
      panelOpen = !panelOpen;
      panel.classList.toggle("open", panelOpen);
      if (panelOpen) {
        positionPanel();
        if (!selectedTone) preselectTone(detectContextTone(composeBody));
      }
    });
    document.addEventListener("click", (e) => {
      if (!host.contains(e.target) && panelOpen) {
        panelOpen = false;
        panel.classList.remove("open");
      }
    }, true);
    function positionPanel() {
      const rect = btn.getBoundingClientRect();
      panel.style.bottom = `${window.innerHeight - rect.top + 4}px`;
      panel.style.left = `${Math.min(rect.left, window.innerWidth - 276)}px`;
    }
    let originalText = "";
    function showVoiceMatch(score) {
      if (typeof score === "number" && score > 0) {
        const pct = Math.round(score <= 1 ? score * 100 : score);
        vmPctEl.textContent = `${pct}% match`;
      } else {
        vmPctEl.textContent = "";
      }
      voicematchEl.classList.add("visible");
    }
    async function runRewrite(regen = false) {
      if (!selectedTone) return;
      const text = regen ? originalText : composeBody.innerText.trim();
      if (!text) {
        setStatus("Write something first.", "error");
        return;
      }
      if (!regen) originalText = text;
      btn.disabled = true;
      rewriteBtn.disabled = true;
      regenBtn.disabled = true;
      setStatus(regen ? "Trying another\u2026" : "Rewriting\u2026");
      actionsEl.classList.remove("visible");
      voicematchEl.classList.remove("visible");
      try {
        const resp = await sendToBackground({
          type: "HUMANIZE",
          payload: { text, tone: selectedTone }
        });
        if ("error" in resp) throw new Error(String(resp.error));
        lastRewriteId = resp.result.id;
        setComposeText(composeBody, resp.result.output_text);
        setStatus("");
        showVoiceMatch(resp.result.quality_score);
        actionsEl.classList.add("visible");
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Failed";
        if (msg.startsWith("LIMIT_REACHED:")) {
          limitEl.classList.add("visible");
          setStatus("");
        } else {
          setStatus(msg, "error");
        }
      } finally {
        btn.disabled = false;
        rewriteBtn.disabled = selectedTone === null;
        regenBtn.disabled = false;
      }
    }
    rewriteBtn.addEventListener("click", () => {
      void runRewrite(false);
    });
    regenBtn.addEventListener("click", () => {
      void runRewrite(true);
    });
    acceptBtn.addEventListener("click", async () => {
      if (lastRewriteId) {
        sendToBackground({ type: "FEEDBACK", payload: { rewriteId: lastRewriteId, action: "accepted" } });
      }
      actionsEl.classList.remove("visible");
      voicematchEl.classList.remove("visible");
      panelOpen = false;
      panel.classList.remove("open");
      setStatus("");
    });
    rejectBtn.addEventListener("click", async () => {
      if (originalText) setComposeText(composeBody, originalText);
      if (lastRewriteId) {
        sendToBackground({ type: "FEEDBACK", payload: { rewriteId: lastRewriteId, action: "rejected" } });
      }
      actionsEl.classList.remove("visible");
      voicematchEl.classList.remove("visible");
      setStatus("Reverted.", "success");
      setTimeout(() => setStatus(""), 2e3);
    });
    function setStatus(msg, cls = "") {
      statusEl.textContent = msg;
      statusEl.className = cls;
    }
    toolbar.insertBefore(host, sendBtn);
    injectMicButton(toolbar, composeBody);
  }
  function findSendButton(composeBody) {
    let el = composeBody;
    for (let i = 0; i < 25; i++) {
      if (!el) break;
      const send = el.querySelector(SEND_BUTTON_SEL);
      if (send) return send;
      el = el.parentElement;
    }
    return null;
  }
  function setComposeText(el, text) {
    el.focus();
    document.execCommand("selectAll", false, void 0);
    document.execCommand("delete", false, void 0);
    const lines = text.split("\n");
    for (let i = 0; i < lines.length; i++) {
      if (lines[i]) document.execCommand("insertText", false, lines[i]);
      if (i < lines.length - 1) document.execCommand("insertParagraph", false, void 0);
    }
  }
  function sendToBackground(message, attempt = 0) {
    return new Promise((resolve, reject) => {
      const retry = () => {
        if (attempt === 0) {
          setTimeout(() => sendToBackground(message, 1).then(resolve).catch(reject), 900);
        } else {
          reject(new Error("Extension restarted \u2014 please reload Gmail and try again."));
        }
      };
      if (!chrome?.runtime?.sendMessage) {
        retry();
        return;
      }
      try {
        chrome.runtime.sendMessage(message, (response) => {
          if (chrome.runtime?.lastError) {
            retry();
          } else {
            resolve(response);
          }
        });
      } catch {
        retry();
      }
    });
  }
  var seen = /* @__PURE__ */ new WeakSet();
  function tryInject(root) {
    root.querySelectorAll(COMPOSE_BODY_SEL).forEach((body) => {
      if (!seen.has(body)) {
        seen.add(body);
        inject(body);
      }
    });
  }
  var observer = new MutationObserver(() => tryInject(document));
  observer.observe(document.body, { childList: true, subtree: true });
  tryInject(document);
  document.addEventListener("keydown", (e) => {
    const toolbar = document.querySelector(`[${HOST_ATTR}]`);
    if (!toolbar) return;
    const hosts = Array.from(toolbar.children).filter((c) => c.shadowRoot);
    if ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key === "H") {
      e.preventDefault();
      const btn = hosts[0]?.shadowRoot?.getElementById("wt-btn");
      btn?.click();
    }
    if ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key === "V") {
      e.preventDefault();
      const btn = hosts[1]?.shadowRoot?.getElementById("wt-mic-btn");
      btn?.click();
    }
  });
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vc3JjL2NvbnRlbnQvZ21haWwudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB0eXBlIHsgVG9uZSwgUmV3cml0ZVJlc3BvbnNlLCBWb2ljZU91dHB1dFR5cGUsIFZvaWNlRHJhZnRSZXNwb25zZSB9IGZyb20gJy4uL2xpYi9hcGknO1xuXG4vLyBHbWFpbCBzZWxlY3RvcnMgXHUyMDE0IHVzZSBwcmVmaXgvc3Vic3RyaW5nIG1hdGNoZXMgc28gbG9jYWxlIHZhcmlhbnRzIHN0aWxsIG1hdGNoXG4vLyBlLmcuIHRvb2x0aXAgY2FuIGJlIFwiU2VuZFwiLCBcIlNlbmQgXHUyMzE4RW50ZXJcIiwgXCJTZW5kIChDdHJsK0VudGVyKVwiXG5jb25zdCBDT01QT1NFX0JPRFlfU0VMID0gJ1tnX2VkaXRhYmxlPVwidHJ1ZVwiXSwgZGl2W2NvbnRlbnRlZGl0YWJsZT1cInRydWVcIl1bYXJpYS1tdWx0aWxpbmU9XCJ0cnVlXCJdJztcbmNvbnN0IFNFTkRfQlVUVE9OX1NFTCA9ICdbZGF0YS10b29sdGlwXj1cIlNlbmRcIl0sIFthcmlhLWxhYmVsXj1cIlNlbmRcIl0nO1xuY29uc3QgSE9TVF9BVFRSID0gJ2RhdGEtd3QtaW5qZWN0ZWQnO1xuXG4vLyBcdTI1MDBcdTI1MDAgQ29udGV4dCBkZXRlY3Rpb24gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmNvbnN0IEZSRUVfRE9NQUlOUyA9IG5ldyBTZXQoWydnbWFpbC5jb20nLCd5YWhvby5jb20nLCdvdXRsb29rLmNvbScsJ2hvdG1haWwuY29tJywnaWNsb3VkLmNvbScsJ3Byb3Rvbm1haWwuY29tJywnYW9sLmNvbScsJ2xpdmUuY29tJ10pO1xuY29uc3QgRk9STUFMX1NVQkpFQ1RfUkUgPSAvcHJvcG9zYWx8YWdyZWVtZW50fGNvbnRyYWN0fGludm9pY2V8cmVwb3J0fHByZXNlbnRhdGlvbnxzdHJhdGVneXxleGVjdXRpdmV8Ym9hcmR8aW52ZXN0b3J8Y2xpZW50fHBhcnRuZXIvaTtcbmNvbnN0IENBU1VBTF9TVUJKRUNUX1JFID0gL2hleXxoaXxxdWlja3xjYXRjaCB1cHxmeWl8aGVhZHMgdXB8cXVlc3Rpb258aGVscHxpZGVhL2k7XG5cbmZ1bmN0aW9uIGRldGVjdENvbnRleHRUb25lKGNvbXBvc2VCb2R5OiBFbGVtZW50KTogVG9uZSB7XG4gIC8vIEZpbmQgdGhlIG5lYXJlc3QgY29tcG9zZSB3cmFwcGVyXG4gIGNvbnN0IGNvbXBvc2UgPSBjb21wb3NlQm9keS5jbG9zZXN0KCdbZGF0YS1tZXNzYWdlLWlkXSwgW2RhdGEtdGhyZWFkLWlkXScpID8/IGRvY3VtZW50O1xuXG4gIC8vIFN1YmplY3RcbiAgY29uc3Qgc3ViamVjdCA9IChjb21wb3NlLnF1ZXJ5U2VsZWN0b3I/LignaW5wdXRbbmFtZT1cInN1YmplY3Rib3hcIl0nKSBhcyBIVE1MSW5wdXRFbGVtZW50IHwgbnVsbCk/LnZhbHVlID8/ICcnO1xuXG4gIC8vIFRvOiByZWNpcGllbnRzXG4gIGNvbnN0IHRvVG9rZW5zID0gQXJyYXkuZnJvbShjb21wb3NlLnF1ZXJ5U2VsZWN0b3JBbGw/LignW2VtYWlsXScpID8/IFtdKVxuICAgIC5tYXAoZWwgPT4gKGVsLmdldEF0dHJpYnV0ZSgnZW1haWwnKSA/PyAnJykudG9Mb3dlckNhc2UoKS5zcGxpdCgnQCcpWzFdID8/ICcnKTtcbiAgY29uc3QgaGFzRXh0ZXJuYWxSZWNpcGllbnQgPSB0b1Rva2Vucy5zb21lKGRvbWFpbiA9PiBkb21haW4gJiYgIUZSRUVfRE9NQUlOUy5oYXMoZG9tYWluKSk7XG4gIGNvbnN0IGhhc1BlcnNvbmFsRW1haWwgPSB0b1Rva2Vucy5ldmVyeShkb21haW4gPT4gRlJFRV9ET01BSU5TLmhhcyhkb21haW4pKTtcblxuICBpZiAoRk9STUFMX1NVQkpFQ1RfUkUudGVzdChzdWJqZWN0KSB8fCAoaGFzRXh0ZXJuYWxSZWNpcGllbnQgJiYgdG9Ub2tlbnMubGVuZ3RoID4gMCkpIHtcbiAgICByZXR1cm4gJ3Byb2Zlc3Npb25hbCc7XG4gIH1cbiAgaWYgKC9ib2FyZHxjZW98dnAgfGN0byB8Y2ZvIHxkaXJlY3RvcnxpbnZlc3Rvci9pLnRlc3Qoc3ViamVjdCkpIHtcbiAgICByZXR1cm4gJ2V4ZWN1dGl2ZSc7XG4gIH1cbiAgaWYgKENBU1VBTF9TVUJKRUNUX1JFLnRlc3Qoc3ViamVjdCkgfHwgaGFzUGVyc29uYWxFbWFpbCkge1xuICAgIHJldHVybiAnZnJpZW5kbHknO1xuICB9XG4gIHJldHVybiAncHJvZmVzc2lvbmFsJzsgLy8gc2FmZSBkZWZhdWx0XG59XG5cbi8vIFx1MjUwMFx1MjUwMCBUb25lIGNvbmZpZyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuY29uc3QgVE9ORVM6IHsga2V5OiBUb25lOyBsYWJlbDogc3RyaW5nOyBjb2xvcjogc3RyaW5nIH1bXSA9IFtcbiAgeyBrZXk6ICdwcm9mZXNzaW9uYWwnLCBsYWJlbDogJ1Byb2Zlc3Npb25hbCcsIGNvbG9yOiAnIzRGNDZFNScgfSxcbiAgeyBrZXk6ICdjYXN1YWwnLCAgICAgICBsYWJlbDogJ0Nhc3VhbCcsICAgICAgIGNvbG9yOiAnIzA2QjZENCcgfSxcbiAgeyBrZXk6ICdmcmllbmRseScsICAgICBsYWJlbDogJ0ZyaWVuZGx5JywgICAgIGNvbG9yOiAnI0Y1OUUwQicgfSxcbiAgeyBrZXk6ICdkaXJlY3QnLCAgICAgICBsYWJlbDogJ0RpcmVjdCcsICAgICAgIGNvbG9yOiAnI0RDMjYyNicgfSxcbiAgeyBrZXk6ICdkaXBsb21hdGljJywgICBsYWJlbDogJ0RpcGxvbWF0aWMnLCAgIGNvbG9yOiAnIzdDM0FFRCcgfSxcbiAgeyBrZXk6ICdleGVjdXRpdmUnLCAgICBsYWJlbDogJ0V4ZWN1dGl2ZScsICAgIGNvbG9yOiAnIzBGMTcyQScgfSxcbl07XG5cbi8vIFx1MjUwMFx1MjUwMCBTaGFkb3cgRE9NIHN0eWxlcyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuY29uc3QgQlVUVE9OX0NTUyA9IGBcbiAgOmhvc3QgeyBkaXNwbGF5OiBpbmxpbmUtZmxleDsgYWxpZ24taXRlbXM6IGNlbnRlcjsgbWFyZ2luLWxlZnQ6IDhweDsgfVxuXG4gICN3dC1idG4ge1xuICAgIGRpc3BsYXk6IGlubGluZS1mbGV4OyBhbGlnbi1pdGVtczogY2VudGVyOyBnYXA6IDVweDtcbiAgICBoZWlnaHQ6IDI4cHg7IHBhZGRpbmc6IDAgMTJweDsgYm9yZGVyLXJhZGl1czogOTk5OXB4OyBib3JkZXI6IG5vbmU7XG4gICAgYmFja2dyb3VuZDogIzRGNDZFNTsgY29sb3I6ICNmZmY7XG4gICAgZm9udDogNTAwIDEycHgvMSAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsIFwiU2Vnb2UgVUlcIiwgUm9ib3RvLCBzYW5zLXNlcmlmO1xuICAgIGN1cnNvcjogcG9pbnRlcjsgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgICB0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kIDAuMTVzLCBib3gtc2hhZG93IDAuMTVzO1xuICB9XG4gICN3dC1idG46aG92ZXIgeyBiYWNrZ3JvdW5kOiAjM0YzN0M5OyBib3gtc2hhZG93OiAwIDAgMCAzcHggcmdiYSg3OSw3MCwyMjksMC4yNSk7IH1cbiAgI3d0LWJ0bjpkaXNhYmxlZCB7IG9wYWNpdHk6IDAuNjsgY3Vyc29yOiBkZWZhdWx0OyBib3gtc2hhZG93OiBub25lOyB9XG5cbiAgI3d0LXBhbmVsIHtcbiAgICBwb3NpdGlvbjogZml4ZWQ7IHotaW5kZXg6IDk5OTk7XG4gICAgYmFja2dyb3VuZDogI2ZmZjsgYm9yZGVyOiAxcHggc29saWQgI0U4RUFFRDsgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICBib3gtc2hhZG93OiAwIDEycHggMzJweCByZ2JhKDE1LDIzLDQyLDAuMTQpO1xuICAgIHBhZGRpbmc6IDE0cHggMTZweDsgd2lkdGg6IDI2MHB4O1xuICAgIGZvbnQtZmFtaWx5OiAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsIFwiU2Vnb2UgVUlcIiwgUm9ib3RvLCBzYW5zLXNlcmlmO1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH1cbiAgI3d0LXBhbmVsLm9wZW4geyBkaXNwbGF5OiBibG9jazsgfVxuXG4gIC53dC10aXRsZSB7XG4gICAgZm9udC1zaXplOiAxMnB4OyBmb250LXdlaWdodDogNjAwOyBjb2xvcjogIzM3NDE1MTsgbWFyZ2luOiAwIDAgMTBweDtcbiAgICBsZXR0ZXItc3BhY2luZzogMC4wNGVtOyB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICB9XG4gIC53dC10b25lcyB7XG4gICAgZGlzcGxheTogZmxleDsgZmxleC13cmFwOiB3cmFwOyBnYXA6IDZweDsgbWFyZ2luLWJvdHRvbTogMTJweDtcbiAgfVxuICAud3QtdG9uZSB7XG4gICAgcGFkZGluZzogNHB4IDEwcHg7IGJvcmRlci1yYWRpdXM6IDk5OTlweDsgYm9yZGVyOiAxLjVweCBzb2xpZCAjRThFQUVEO1xuICAgIGJhY2tncm91bmQ6ICNmZmY7IGZvbnQtc2l6ZTogMTJweDsgZm9udC13ZWlnaHQ6IDUwMDsgY29sb3I6ICMzNzQxNTE7XG4gICAgY3Vyc29yOiBwb2ludGVyOyB0cmFuc2l0aW9uOiBhbGwgMC4xcztcbiAgfVxuICAud3QtdG9uZS5hY3RpdmUge1xuICAgIGNvbG9yOiAjZmZmOyBib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICB9XG4gIC53dC10b25lOmhvdmVyOm5vdCguYWN0aXZlKSB7IGJvcmRlci1jb2xvcjogIzlCQTBGRjsgfVxuXG4gICN3dC1yZXdyaXRlIHtcbiAgICB3aWR0aDogMTAwJTsgaGVpZ2h0OiAzMnB4OyBib3JkZXItcmFkaXVzOiA4cHg7IGJvcmRlcjogbm9uZTtcbiAgICBiYWNrZ3JvdW5kOiAjNEY0NkU1OyBjb2xvcjogI2ZmZjtcbiAgICBmb250OiA2MDAgMTNweC8xIC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgXCJTZWdvZSBVSVwiLCBSb2JvdG8sIHNhbnMtc2VyaWY7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gICN3dC1yZXdyaXRlOmRpc2FibGVkIHsgb3BhY2l0eTogMC40NTsgY3Vyc29yOiBkZWZhdWx0OyB9XG5cbiAgI3d0LXN0YXR1cyB7XG4gICAgbWFyZ2luLXRvcDogOHB4OyBmb250LXNpemU6IDExcHg7IHRleHQtYWxpZ246IGNlbnRlcjsgbWluLWhlaWdodDogMTRweDtcbiAgfVxuICAjd3Qtc3RhdHVzLmVycm9yIHsgY29sb3I6ICNFRjQ0NDQ7IH1cbiAgI3d0LXN0YXR1cy5zdWNjZXNzIHsgY29sb3I6ICMxMEI5ODE7IH1cblxuICAjd3QtbGltaXQge1xuICAgIGRpc3BsYXk6IG5vbmU7IG1hcmdpbi10b3A6IDEwcHg7IHBhZGRpbmc6IDEwcHggMTJweDsgYm9yZGVyLXJhZGl1czogOHB4O1xuICAgIGJhY2tncm91bmQ6ICNGRkY4RjE7IGJvcmRlcjogMXB4IHNvbGlkICNGRUQ3QUE7IHRleHQtYWxpZ246IGNlbnRlcjtcbiAgfVxuICAjd3QtbGltaXQudmlzaWJsZSB7IGRpc3BsYXk6IGJsb2NrOyB9XG4gICN3dC1saW1pdCBwIHsgZm9udC1zaXplOiAxMXB4OyBjb2xvcjogIzkyNDAwRTsgbWFyZ2luOiAwIDAgOHB4OyBsaW5lLWhlaWdodDogMS40OyB9XG4gICN3dC1saW1pdCBhIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7IHBhZGRpbmc6IDVweCAxNHB4OyBib3JkZXItcmFkaXVzOiA5OTk5cHg7XG4gICAgYmFja2dyb3VuZDogI0Y1OUUwQjsgY29sb3I6ICNmZmY7IGZvbnQtc2l6ZTogMTFweDsgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gIH1cbiAgI3d0LWxpbWl0IGE6aG92ZXIgeyBiYWNrZ3JvdW5kOiAjRDk3NzA2OyB9XG5cbiAgI3d0LXZvaWNlbWF0Y2gge1xuICAgIGRpc3BsYXk6IG5vbmU7IGFsaWduLWl0ZW1zOiBjZW50ZXI7IGdhcDogNnB4O1xuICAgIG1hcmdpbi10b3A6IDEwcHg7IHBhZGRpbmc6IDdweCAxMHB4OyBib3JkZXItcmFkaXVzOiA4cHg7XG4gICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDEzNWRlZywgI0VERTlGRSAwJSwgI0Y1RjNGRiAxMDAlKTtcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjRERENkZFO1xuICB9XG4gICN3dC12b2ljZW1hdGNoLnZpc2libGUgeyBkaXNwbGF5OiBmbGV4OyB9XG4gICN3dC12b2ljZW1hdGNoIC53dC12bS1zcGFyayB7IGZvbnQtc2l6ZTogMTNweDsgbGluZS1oZWlnaHQ6IDE7IH1cbiAgI3d0LXZvaWNlbWF0Y2ggLnd0LXZtLXRleHQgeyBmb250LXNpemU6IDExLjVweDsgZm9udC13ZWlnaHQ6IDYwMDsgY29sb3I6ICM1QjIxQjY7IH1cbiAgI3d0LXZvaWNlbWF0Y2ggLnd0LXZtLXBjdCB7XG4gICAgbWFyZ2luLWxlZnQ6IGF1dG87IGZvbnQtc2l6ZTogMTEuNXB4OyBmb250LXdlaWdodDogNzAwOyBjb2xvcjogIzRGNDZFNTtcbiAgfVxuXG4gICN3dC1hY3Rpb25zIHtcbiAgICBkaXNwbGF5OiBub25lOyBnYXA6IDZweDsgbWFyZ2luLXRvcDogOHB4O1xuICB9XG4gICN3dC1hY3Rpb25zLnZpc2libGUgeyBkaXNwbGF5OiBmbGV4OyB9XG4gIC53dC1hY3Rpb24ge1xuICAgIGZsZXg6IDE7IGhlaWdodDogMjhweDsgYm9yZGVyLXJhZGl1czogOHB4OyBib3JkZXI6IDEuNXB4IHNvbGlkICNFOEVBRUQ7XG4gICAgYmFja2dyb3VuZDogI2ZmZjsgZm9udC1zaXplOiAxMnB4OyBmb250LXdlaWdodDogNTAwOyBjb2xvcjogIzM3NDE1MTtcbiAgICBjdXJzb3I6IHBvaW50ZXI7IHRyYW5zaXRpb246IGJhY2tncm91bmQgMC4xcywgYm9yZGVyLWNvbG9yIDAuMXM7XG4gIH1cbiAgLnd0LWFjdGlvbjpkaXNhYmxlZCB7IG9wYWNpdHk6IDAuNTsgY3Vyc29yOiBkZWZhdWx0OyB9XG4gIC53dC1hY3Rpb24uYWNjZXB0IHsgYm9yZGVyLWNvbG9yOiAjMTBCOTgxOyBjb2xvcjogIzEwQjk4MTsgfVxuICAud3QtYWN0aW9uLmFjY2VwdDpob3Zlcjpub3QoOmRpc2FibGVkKSB7IGJhY2tncm91bmQ6ICNFQ0ZERjU7IH1cbiAgLnd0LWFjdGlvbi5yZWdlbiB7IGJvcmRlci1jb2xvcjogI0M3RDJGRTsgY29sb3I6ICM0RjQ2RTU7IH1cbiAgLnd0LWFjdGlvbi5yZWdlbjpob3Zlcjpub3QoOmRpc2FibGVkKSB7IGJhY2tncm91bmQ6ICNFRUYyRkY7IH1cbiAgLnd0LWFjdGlvbi5yZWplY3QgeyBib3JkZXItY29sb3I6ICNFRjQ0NDQ7IGNvbG9yOiAjRUY0NDQ0OyB9XG4gIC53dC1hY3Rpb24ucmVqZWN0OmhvdmVyOm5vdCg6ZGlzYWJsZWQpIHsgYmFja2dyb3VuZDogI0ZFRjJGMjsgfVxuYDtcblxuLy8gXHUyNTAwXHUyNTAwIFZvaWNlIG91dHB1dCB0eXBlcyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuY29uc3QgVk9JQ0VfT1VUUFVUX1RZUEVTOiB7IGtleTogVm9pY2VPdXRwdXRUeXBlOyBsYWJlbDogc3RyaW5nIH1bXSA9IFtcbiAgeyBrZXk6ICdyZXBseScsICAgICAgICAgICBsYWJlbDogJ1JlcGx5JyB9LFxuICB7IGtleTogJ2VtYWlsJywgICAgICAgICAgIGxhYmVsOiAnRW1haWwnIH0sXG4gIHsga2V5OiAnY3VzdG9tZXJfdXBkYXRlJywgbGFiZWw6ICdDdXN0b21lciBVcGRhdGUnIH0sXG4gIHsga2V5OiAnamlyYV90aWNrZXQnLCAgICAgbGFiZWw6ICdKaXJhIFRpY2tldCcgfSxcbiAgeyBrZXk6ICd0ZWNobmljYWxfcmVwb3J0JyxsYWJlbDogJ1RlY2ggUmVwb3J0JyB9LFxuXTtcblxuY29uc3QgTUlDX0NTUyA9IGBcbiAgOmhvc3QgeyBkaXNwbGF5OiBpbmxpbmUtZmxleDsgYWxpZ24taXRlbXM6IGNlbnRlcjsgbWFyZ2luLWxlZnQ6IDRweDsgfVxuXG4gICN3dC1taWMtYnRuIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtZmxleDsgYWxpZ24taXRlbXM6IGNlbnRlcjsganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgd2lkdGg6IDI4cHg7IGhlaWdodDogMjhweDsgYm9yZGVyLXJhZGl1czogOTk5OXB4OyBib3JkZXI6IG5vbmU7XG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7IGNvbG9yOiAjNUY2MzY4OyBjdXJzb3I6IHBvaW50ZXI7XG4gICAgdHJhbnNpdGlvbjogYmFja2dyb3VuZCAwLjE1cywgY29sb3IgMC4xNXM7XG4gICAgZm9udC1zaXplOiAxNXB4OyBsaW5lLWhlaWdodDogMTtcbiAgfVxuICAjd3QtbWljLWJ0bjpob3ZlciB7IGJhY2tncm91bmQ6IHJnYmEoMCwwLDAsMC4wNyk7IH1cbiAgI3d0LW1pYy1idG4ucmVjb3JkaW5nIHtcbiAgICBiYWNrZ3JvdW5kOiAjRkVFMkUyOyBjb2xvcjogI0RDMjYyNjtcbiAgICBhbmltYXRpb246IHd0LXB1bHNlIDEuMnMgZWFzZS1pbi1vdXQgaW5maW5pdGU7XG4gIH1cbiAgQGtleWZyYW1lcyB3dC1wdWxzZSB7XG4gICAgMCUsIDEwMCUgeyBib3gtc2hhZG93OiAwIDAgMCAwIHJnYmEoMjIwLDM4LDM4LDAuNCk7IH1cbiAgICA1MCUgICAgICAgeyBib3gtc2hhZG93OiAwIDAgMCA1cHggcmdiYSgyMjAsMzgsMzgsMCk7IH1cbiAgfVxuICAjd3QtbWljLWJ0bjpkaXNhYmxlZCB7IG9wYWNpdHk6IDAuNTsgY3Vyc29yOiBkZWZhdWx0OyB9XG5cbiAgI3d0LXZvaWNlLXBhbmVsIHtcbiAgICBwb3NpdGlvbjogZml4ZWQ7IHotaW5kZXg6IDk5OTk7XG4gICAgYmFja2dyb3VuZDogI2ZmZjsgYm9yZGVyOiAxcHggc29saWQgI0U4RUFFRDsgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICBib3gtc2hhZG93OiAwIDEycHggMzJweCByZ2JhKDE1LDIzLDQyLDAuMTQpO1xuICAgIHBhZGRpbmc6IDE0cHggMTZweDsgd2lkdGg6IDI4MHB4O1xuICAgIGZvbnQtZmFtaWx5OiAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsIFwiU2Vnb2UgVUlcIiwgUm9ib3RvLCBzYW5zLXNlcmlmO1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH1cbiAgI3d0LXZvaWNlLXBhbmVsLm9wZW4geyBkaXNwbGF5OiBibG9jazsgfVxuXG4gIC53dC12dCB7IGZvbnQtc2l6ZTogMTJweDsgZm9udC13ZWlnaHQ6IDYwMDsgY29sb3I6ICMzNzQxNTE7IG1hcmdpbjogMCAwIDEwcHg7XG4gICAgbGV0dGVyLXNwYWNpbmc6IDAuMDRlbTsgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTsgfVxuXG4gICN3dC1yZWNvcmQtYnRuIHtcbiAgICB3aWR0aDogMTAwJTsgaGVpZ2h0OiAzNHB4OyBib3JkZXItcmFkaXVzOiA4cHg7IGJvcmRlcjogbm9uZTtcbiAgICBiYWNrZ3JvdW5kOiAjREMyNjI2OyBjb2xvcjogI2ZmZjsgY3Vyc29yOiBwb2ludGVyO1xuICAgIGZvbnQ6IDYwMCAxM3B4LzEgLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCBcIlNlZ29lIFVJXCIsIFJvYm90bywgc2Fucy1zZXJpZjtcbiAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICB9XG4gICN3dC1yZWNvcmQtYnRuLnJlY29yZGluZyB7IGJhY2tncm91bmQ6ICM3RjFEMUQ7IH1cbiAgI3d0LXJlY29yZC1idG46ZGlzYWJsZWQgeyBvcGFjaXR5OiAwLjU7IGN1cnNvcjogZGVmYXVsdDsgfVxuXG4gIC53dC1vdHlwZS1sYWJlbCB7IGZvbnQtc2l6ZTogMTFweDsgY29sb3I6ICM2QjcyODA7IG1hcmdpbi1ib3R0b206IDRweDsgfVxuICAud3Qtb3R5cGVzIHsgZGlzcGxheTogZmxleDsgZmxleC13cmFwOiB3cmFwOyBnYXA6IDVweDsgbWFyZ2luLWJvdHRvbTogMTBweDsgfVxuICAud3Qtb3R5cGUge1xuICAgIHBhZGRpbmc6IDNweCA5cHg7IGJvcmRlci1yYWRpdXM6IDk5OTlweDsgYm9yZGVyOiAxLjVweCBzb2xpZCAjRThFQUVEO1xuICAgIGJhY2tncm91bmQ6ICNmZmY7IGZvbnQtc2l6ZTogMTFweDsgY29sb3I6ICMzNzQxNTE7IGN1cnNvcjogcG9pbnRlcjtcbiAgICB0cmFuc2l0aW9uOiBhbGwgMC4xcztcbiAgfVxuICAud3Qtb3R5cGUuYWN0aXZlIHsgYmFja2dyb3VuZDogIzRGNDZFNTsgY29sb3I6ICNmZmY7IGJvcmRlci1jb2xvcjogIzRGNDZFNTsgfVxuXG4gICN3dC12b2ljZS1zdGF0dXMgeyBmb250LXNpemU6IDExcHg7IHRleHQtYWxpZ246IGNlbnRlcjsgbWluLWhlaWdodDogMTRweDsgY29sb3I6ICM2QjcyODA7IH1cbiAgI3d0LXZvaWNlLXN0YXR1cy5lcnJvciB7IGNvbG9yOiAjRUY0NDQ0OyB9XG5cbiAgI3d0LXZvaWNlLWFjdGlvbnMgeyBkaXNwbGF5OiBub25lOyBnYXA6IDZweDsgbWFyZ2luLXRvcDogOHB4OyB9XG4gICN3dC12b2ljZS1hY3Rpb25zLnZpc2libGUgeyBkaXNwbGF5OiBmbGV4OyB9XG4gIC53dC12YSB7XG4gICAgZmxleDogMTsgaGVpZ2h0OiAyOHB4OyBib3JkZXItcmFkaXVzOiA4cHg7IGJvcmRlcjogMS41cHggc29saWQgI0U4RUFFRDtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmOyBmb250LXNpemU6IDEycHg7IGZvbnQtd2VpZ2h0OiA1MDA7IGNvbG9yOiAjMzc0MTUxOyBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cbiAgLnd0LXZhLmFjY2VwdCB7IGJvcmRlci1jb2xvcjogIzEwQjk4MTsgY29sb3I6ICMxMEI5ODE7IH1cbiAgLnd0LXZhLnJlamVjdCB7IGJvcmRlci1jb2xvcjogI0VGNDQ0NDsgY29sb3I6ICNFRjQ0NDQ7IH1cbmA7XG5cbi8vIFx1MjUwMFx1MjUwMCBJbmplY3QgVm9pY2UgVHdpbiBtaWMgYnV0dG9uIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5mdW5jdGlvbiBpbmplY3RNaWNCdXR0b24odG9vbGJhcjogRWxlbWVudCwgY29tcG9zZUJvZHk6IEVsZW1lbnQpOiB2b2lkIHtcbiAgY29uc3QgbWljSG9zdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgY29uc3Qgc2hhZG93ID0gbWljSG9zdC5hdHRhY2hTaGFkb3coeyBtb2RlOiAnb3BlbicgfSk7XG5cbiAgc2hhZG93LmlubmVySFRNTCA9IGBcbiAgICA8c3R5bGU+JHtNSUNfQ1NTfTwvc3R5bGU+XG4gICAgPGJ1dHRvbiBpZD1cInd0LW1pYy1idG5cIiB0aXRsZT1cIlZvaWNlIFR3aW4gXHUyMDE0IHNwZWFrIHlvdXIgZW1haWwgKENtZCtTaGlmdCtWKVwiPlx1RDgzQ1x1REY5OTwvYnV0dG9uPlxuICAgIDxkaXYgaWQ9XCJ3dC12b2ljZS1wYW5lbFwiPlxuICAgICAgPHAgY2xhc3M9XCJ3dC12dFwiPlZvaWNlIFR3aW48L3A+XG4gICAgICA8ZGl2IGNsYXNzPVwid3Qtb3R5cGUtbGFiZWxcIj5PdXRwdXQgdHlwZTwvZGl2PlxuICAgICAgPGRpdiBjbGFzcz1cInd0LW90eXBlc1wiPlxuICAgICAgICAke1ZPSUNFX09VVFBVVF9UWVBFUy5tYXAoKG8sIGkpID0+XG4gICAgICAgICAgYDxidXR0b24gY2xhc3M9XCJ3dC1vdHlwZSR7aSA9PT0gMCA/ICcgYWN0aXZlJyA6ICcnfVwiIGRhdGEtdHlwZT1cIiR7by5rZXl9XCI+JHtvLmxhYmVsfTwvYnV0dG9uPmBcbiAgICAgICAgKS5qb2luKCcnKX1cbiAgICAgIDwvZGl2PlxuICAgICAgPGJ1dHRvbiBpZD1cInd0LXJlY29yZC1idG5cIj5cdUQ4M0NcdURGOTkgU3RhcnQgcmVjb3JkaW5nPC9idXR0b24+XG4gICAgICA8ZGl2IGlkPVwid3Qtdm9pY2Utc3RhdHVzXCI+PC9kaXY+XG4gICAgICA8ZGl2IGlkPVwid3Qtdm9pY2UtYWN0aW9uc1wiPlxuICAgICAgICA8YnV0dG9uIGNsYXNzPVwid3QtdmEgYWNjZXB0XCIgaWQ9XCJ3dC12YS1rZWVwXCI+XHUyNzEzIEtlZXAgaXQ8L2J1dHRvbj5cbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cInd0LXZhIHJlamVjdFwiIGlkPVwid3QtdmEtdW5kb1wiPlx1MjcxNyBVbmRvPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgYDtcblxuICBjb25zdCBtaWNCdG4gICAgICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtbWljLWJ0bicpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICBjb25zdCBwYW5lbCAgICAgICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3Qtdm9pY2UtcGFuZWwnKSBhcyBIVE1MRGl2RWxlbWVudDtcbiAgY29uc3QgcmVjb3JkQnRuICAgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LXJlY29yZC1idG4nKSBhcyBIVE1MQnV0dG9uRWxlbWVudDtcbiAgY29uc3Qgc3RhdHVzRWwgICAgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LXZvaWNlLXN0YXR1cycpIGFzIEhUTUxEaXZFbGVtZW50O1xuICBjb25zdCBhY3Rpb25zRWwgICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3Qtdm9pY2UtYWN0aW9ucycpIGFzIEhUTUxEaXZFbGVtZW50O1xuICBjb25zdCBrZWVwQnRuICAgICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtdmEta2VlcCcpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICBjb25zdCB1bmRvQnRuICAgICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtdmEtdW5kbycpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuXG4gIGxldCBwYW5lbE9wZW4gPSBmYWxzZTtcbiAgbGV0IHNlbGVjdGVkVHlwZTogVm9pY2VPdXRwdXRUeXBlID0gJ3JlcGx5JztcbiAgbGV0IHJlY29nbml0aW9uOiBJbnN0YW5jZVR5cGU8dHlwZW9mIHdlYmtpdFNwZWVjaFJlY29nbml0aW9uPiB8IG51bGwgPSBudWxsO1xuICBsZXQgcmVjb3JkaW5nID0gZmFsc2U7XG4gIGxldCB0cmFuc2NyaXB0ID0gJyc7XG4gIGxldCBsYXN0U2Vzc2lvbklkOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcbiAgbGV0IG9yaWdpbmFsVGV4dCA9ICcnO1xuXG4gIC8vIE91dHB1dCB0eXBlIHNlbGVjdGlvblxuICBzaGFkb3cucXVlcnlTZWxlY3RvckFsbDxIVE1MQnV0dG9uRWxlbWVudD4oJy53dC1vdHlwZScpLmZvckVhY2goYnRuID0+IHtcbiAgICBidG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgICBzaGFkb3cucXVlcnlTZWxlY3RvckFsbCgnLnd0LW90eXBlJykuZm9yRWFjaChiID0+IGIuY2xhc3NMaXN0LnJlbW92ZSgnYWN0aXZlJykpO1xuICAgICAgYnRuLmNsYXNzTGlzdC5hZGQoJ2FjdGl2ZScpO1xuICAgICAgc2VsZWN0ZWRUeXBlID0gYnRuLmRhdGFzZXQudHlwZSBhcyBWb2ljZU91dHB1dFR5cGU7XG4gICAgfSk7XG4gIH0pO1xuXG4gIG1pY0J0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBwYW5lbE9wZW4gPSAhcGFuZWxPcGVuO1xuICAgIHBhbmVsLmNsYXNzTGlzdC50b2dnbGUoJ29wZW4nLCBwYW5lbE9wZW4pO1xuICAgIGlmIChwYW5lbE9wZW4pIHBvc2l0aW9uUGFuZWwoKTtcbiAgfSk7XG5cbiAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZSkgPT4ge1xuICAgIGlmICghbWljSG9zdC5jb250YWlucyhlLnRhcmdldCBhcyBOb2RlKSAmJiBwYW5lbE9wZW4pIHtcbiAgICAgIHBhbmVsT3BlbiA9IGZhbHNlO1xuICAgICAgcGFuZWwuY2xhc3NMaXN0LnJlbW92ZSgnb3BlbicpO1xuICAgIH1cbiAgfSwgdHJ1ZSk7XG5cbiAgZnVuY3Rpb24gcG9zaXRpb25QYW5lbCgpOiB2b2lkIHtcbiAgICBjb25zdCByZWN0ID0gbWljQnRuLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIHBhbmVsLnN0eWxlLmJvdHRvbSA9IGAke3dpbmRvdy5pbm5lckhlaWdodCAtIHJlY3QudG9wICsgNH1weGA7XG4gICAgcGFuZWwuc3R5bGUubGVmdCA9IGAke01hdGgubWluKHJlY3QubGVmdCwgd2luZG93LmlubmVyV2lkdGggLSAyOTYpfXB4YDtcbiAgfVxuXG4gIHJlY29yZEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgICBpZiAoIXJlY29yZGluZykge1xuICAgICAgYXdhaXQgc3RhcnRSZWNvcmRpbmcoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgc3RvcFJlY29yZGluZygpO1xuICAgIH1cbiAgfSk7XG5cbiAgYXN5bmMgZnVuY3Rpb24gc3RhcnRSZWNvcmRpbmcoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgU3BlZWNoUmVjb2duaXRpb24gPSAod2luZG93IGFzIHVua25vd24gYXMgeyB3ZWJraXRTcGVlY2hSZWNvZ25pdGlvbj86IHR5cGVvZiB3ZWJraXRTcGVlY2hSZWNvZ25pdGlvbiB9KS53ZWJraXRTcGVlY2hSZWNvZ25pdGlvbjtcbiAgICBpZiAoIVNwZWVjaFJlY29nbml0aW9uKSB7XG4gICAgICBzZXRWb2ljZVN0YXR1cygnU3BlZWNoIHJlY29nbml0aW9uIG5vdCBzdXBwb3J0ZWQgaW4gdGhpcyBicm93c2VyLicsICdlcnJvcicpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHRyYW5zY3JpcHQgPSAnJztcbiAgICByZWNvZ25pdGlvbiA9IG5ldyBTcGVlY2hSZWNvZ25pdGlvbigpO1xuICAgIHJlY29nbml0aW9uLmNvbnRpbnVvdXMgPSB0cnVlO1xuICAgIHJlY29nbml0aW9uLmludGVyaW1SZXN1bHRzID0gdHJ1ZTtcbiAgICByZWNvZ25pdGlvbi5sYW5nID0gJ2VuLVVTJztcblxuICAgIHJlY29nbml0aW9uLm9ucmVzdWx0ID0gKGU6IFNwZWVjaFJlY29nbml0aW9uRXZlbnQpID0+IHtcbiAgICAgIGxldCBpbnRlcmltID0gJyc7XG4gICAgICBmb3IgKGxldCBpID0gZS5yZXN1bHRJbmRleDsgaSA8IGUucmVzdWx0cy5sZW5ndGg7IGkrKykge1xuICAgICAgICBpZiAoZS5yZXN1bHRzW2ldLmlzRmluYWwpIHtcbiAgICAgICAgICB0cmFuc2NyaXB0ICs9IGUucmVzdWx0c1tpXVswXS50cmFuc2NyaXB0ICsgJyAnO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGludGVyaW0gKz0gZS5yZXN1bHRzW2ldWzBdLnRyYW5zY3JpcHQ7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHNldFZvaWNlU3RhdHVzKGBcdUQ4M0NcdURGOTkgJHsodHJhbnNjcmlwdCArIGludGVyaW0pLnRyaW0oKSB8fCAnTGlzdGVuaW5nXHUyMDI2J31gKTtcbiAgICB9O1xuXG4gICAgcmVjb2duaXRpb24ub25lcnJvciA9IChlOiBTcGVlY2hSZWNvZ25pdGlvbkVycm9yRXZlbnQpID0+IHtcbiAgICAgIGlmIChlLmVycm9yICE9PSAnYWJvcnRlZCcpIHNldFZvaWNlU3RhdHVzKGBNaWMgZXJyb3I6ICR7ZS5lcnJvcn1gLCAnZXJyb3InKTtcbiAgICB9O1xuXG4gICAgcmVjb2duaXRpb24ub25lbmQgPSAoKSA9PiB7XG4gICAgICBpZiAocmVjb3JkaW5nKSB7XG4gICAgICAgIC8vIGJyb3dzZXIgY3V0IG9mZiBcdTIwMTQgcmVzdGFydCB0byBrZWVwIGxpc3RlbmluZ1xuICAgICAgICByZWNvZ25pdGlvbj8uc3RhcnQoKTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgdHJ5IHtcbiAgICAgIHJlY29nbml0aW9uLnN0YXJ0KCk7XG4gICAgICByZWNvcmRpbmcgPSB0cnVlO1xuICAgICAgbWljQnRuLmNsYXNzTGlzdC5hZGQoJ3JlY29yZGluZycpO1xuICAgICAgcmVjb3JkQnRuLmNsYXNzTGlzdC5hZGQoJ3JlY29yZGluZycpO1xuICAgICAgcmVjb3JkQnRuLnRleHRDb250ZW50ID0gJ1x1MjNGOSBTdG9wIHJlY29yZGluZyc7XG4gICAgICBhY3Rpb25zRWwuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xuXG4gICAgICAvLyBBdXRvLXN0b3AgYXQgNjAgc2Vjb25kc1xuICAgICAgc2V0VGltZW91dCgoKSA9PiB7IGlmIChyZWNvcmRpbmcpIHN0b3BSZWNvcmRpbmcoKTsgfSwgNjBfMDAwKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHNldFZvaWNlU3RhdHVzKCdNaWNyb3Bob25lIGFjY2VzcyBkZW5pZWQuJywgJ2Vycm9yJyk7XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gc3RvcFJlY29yZGluZygpOiB2b2lkIHtcbiAgICBpZiAocmVjb2duaXRpb24gJiYgcmVjb3JkaW5nKSB7XG4gICAgICByZWNvcmRpbmcgPSBmYWxzZTtcbiAgICAgIHJlY29nbml0aW9uLm9uZW5kID0gbnVsbDtcbiAgICAgIHJlY29nbml0aW9uLnN0b3AoKTtcbiAgICAgIHJlY29nbml0aW9uID0gbnVsbDtcbiAgICAgIG1pY0J0bi5jbGFzc0xpc3QucmVtb3ZlKCdyZWNvcmRpbmcnKTtcbiAgICAgIHJlY29yZEJ0bi5jbGFzc0xpc3QucmVtb3ZlKCdyZWNvcmRpbmcnKTtcbiAgICAgIHJlY29yZEJ0bi50ZXh0Q29udGVudCA9ICdcdUQ4M0NcdURGOTkgU3RhcnQgcmVjb3JkaW5nJztcbiAgICAgIHJlY29yZEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gICAgICBzZXRWb2ljZVN0YXR1cygnRHJhZnRpbmdcdTIwMjYnKTtcbiAgICAgIHZvaWQgc3VibWl0VHJhbnNjcmlwdCgpO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIHN1Ym1pdFRyYW5zY3JpcHQoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHRleHQgPSB0cmFuc2NyaXB0LnRyaW0oKTtcbiAgICAgIGlmICghdGV4dCkge1xuICAgICAgICBzZXRWb2ljZVN0YXR1cygnTm90aGluZyByZWNvcmRlZCBcdTIwMTQgdHJ5IGFnYWluLicsICdlcnJvcicpO1xuICAgICAgICByZWNvcmRCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBvcmlnaW5hbFRleHQgPSAoY29tcG9zZUJvZHkgYXMgSFRNTEVsZW1lbnQpLmlubmVyVGV4dC50cmltKCk7XG5cbiAgICAgIGNvbnN0IHJlc3AgPSBhd2FpdCBzZW5kVG9CYWNrZ3JvdW5kPHsgcmVzdWx0OiBWb2ljZURyYWZ0UmVzcG9uc2UgfSB8IHsgZXJyb3I6IHN0cmluZyB9Pih7XG4gICAgICAgIHR5cGU6ICdWT0lDRV9EUkFGVCcsXG4gICAgICAgIHBheWxvYWQ6IHsgdHJhbnNjcmlwdDogdGV4dCwgb3V0cHV0VHlwZTogc2VsZWN0ZWRUeXBlIH0sXG4gICAgICB9KTtcblxuICAgICAgaWYgKCdlcnJvcicgaW4gcmVzcCkgdGhyb3cgbmV3IEVycm9yKFN0cmluZyhyZXNwLmVycm9yKSk7XG5cbiAgICAgIGxhc3RTZXNzaW9uSWQgPSByZXNwLnJlc3VsdC5pZDtcbiAgICAgIHNldENvbXBvc2VUZXh0KGNvbXBvc2VCb2R5IGFzIEhUTUxFbGVtZW50LCByZXNwLnJlc3VsdC5kcmFmdCk7XG4gICAgICBzZXRWb2ljZVN0YXR1cygnRG9uZSBcdTI3MTMnKTtcbiAgICAgIGFjdGlvbnNFbC5jbGFzc0xpc3QuYWRkKCd2aXNpYmxlJyk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zdCBtc2cgPSBlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogJ0ZhaWxlZCc7XG4gICAgICBzZXRWb2ljZVN0YXR1cyhtc2csICdlcnJvcicpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICByZWNvcmRCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgICB9XG4gIH1cblxuICBrZWVwQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgIGlmIChsYXN0U2Vzc2lvbklkKSB7XG4gICAgICBzZW5kVG9CYWNrZ3JvdW5kKHtcbiAgICAgICAgdHlwZTogJ1ZPSUNFX0ZFRURCQUNLJyxcbiAgICAgICAgcGF5bG9hZDogeyBzZXNzaW9uSWQ6IGxhc3RTZXNzaW9uSWQsIGFjY2VwdGVkOiB0cnVlLCBlZGl0ZWREcmFmdDogbnVsbCB9LFxuICAgICAgfSk7XG4gICAgfVxuICAgIGFjdGlvbnNFbC5jbGFzc0xpc3QucmVtb3ZlKCd2aXNpYmxlJyk7XG4gICAgcGFuZWxPcGVuID0gZmFsc2U7XG4gICAgcGFuZWwuY2xhc3NMaXN0LnJlbW92ZSgnb3BlbicpO1xuICAgIHNldFZvaWNlU3RhdHVzKCcnKTtcbiAgfSk7XG5cbiAgdW5kb0J0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBpZiAob3JpZ2luYWxUZXh0KSBzZXRDb21wb3NlVGV4dChjb21wb3NlQm9keSBhcyBIVE1MRWxlbWVudCwgb3JpZ2luYWxUZXh0KTtcbiAgICBpZiAobGFzdFNlc3Npb25JZCkge1xuICAgICAgc2VuZFRvQmFja2dyb3VuZCh7XG4gICAgICAgIHR5cGU6ICdWT0lDRV9GRUVEQkFDSycsXG4gICAgICAgIHBheWxvYWQ6IHsgc2Vzc2lvbklkOiBsYXN0U2Vzc2lvbklkLCBhY2NlcHRlZDogZmFsc2UsIGVkaXRlZERyYWZ0OiBudWxsIH0sXG4gICAgICB9KTtcbiAgICB9XG4gICAgYWN0aW9uc0VsLmNsYXNzTGlzdC5yZW1vdmUoJ3Zpc2libGUnKTtcbiAgICBzZXRWb2ljZVN0YXR1cygnUmV2ZXJ0ZWQuJywgJ3N1Y2Nlc3MnKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHNldFZvaWNlU3RhdHVzKCcnKSwgMjAwMCk7XG4gIH0pO1xuXG4gIGZ1bmN0aW9uIHNldFZvaWNlU3RhdHVzKG1zZzogc3RyaW5nLCBjbHMgPSAnJyk6IHZvaWQge1xuICAgIHN0YXR1c0VsLnRleHRDb250ZW50ID0gbXNnO1xuICAgIHN0YXR1c0VsLmNsYXNzTmFtZSA9IGNscztcbiAgfVxuXG4gIC8vIEluc2VydCBtaWMgaG9zdCBhZnRlciB0aGUgaHVtYW5pemUgaG9zdCAod2hpY2ggaXMgcmlnaHQgYmVmb3JlIHRoZSBTZW5kIGJ1dHRvbilcbiAgY29uc3QgaHVtYW5pemVIb3N0ID0gQXJyYXkuZnJvbSh0b29sYmFyLmNoaWxkcmVuKS5maW5kKGMgPT4gYy5zaGFkb3dSb290KTtcbiAgaWYgKGh1bWFuaXplSG9zdCkge1xuICAgIHRvb2xiYXIuaW5zZXJ0QmVmb3JlKG1pY0hvc3QsIGh1bWFuaXplSG9zdC5uZXh0U2libGluZyk7XG4gIH0gZWxzZSB7XG4gICAgY29uc3Qgc2VuZEJ0biA9IHRvb2xiYXIucXVlcnlTZWxlY3RvcihTRU5EX0JVVFRPTl9TRUwpO1xuICAgIGlmIChzZW5kQnRuKSB0b29sYmFyLmluc2VydEJlZm9yZShtaWNIb3N0LCBzZW5kQnRuKTtcbiAgICBlbHNlIHRvb2xiYXIuYXBwZW5kQ2hpbGQobWljSG9zdCk7XG4gIH1cbn1cblxuLy8gXHUyNTAwXHUyNTAwIEluamVjdCBIdW1hbml6ZSBidXR0b24gaW50byBhIGNvbXBvc2Ugd2luZG93IFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5mdW5jdGlvbiBpbmplY3QoY29tcG9zZUJvZHk6IEVsZW1lbnQpOiB2b2lkIHtcbiAgLy8gRmluZCB0aGUgcGFyZW50IGNvbXBvc2UgY29udGFpbmVyICh3YWxrIHVwIHRvIGZpbmQgZWxlbWVudCB3aXRoIFNlbmQgYnV0dG9uKVxuICBjb25zdCBzZW5kQnRuID0gZmluZFNlbmRCdXR0b24oY29tcG9zZUJvZHkpO1xuICBpZiAoIXNlbmRCdG4pIHJldHVybjtcblxuICBjb25zdCB0b29sYmFyID0gc2VuZEJ0bi5wYXJlbnRFbGVtZW50O1xuICBpZiAoIXRvb2xiYXIgfHwgdG9vbGJhci5oYXNBdHRyaWJ1dGUoSE9TVF9BVFRSKSkgcmV0dXJuO1xuXG4gIHRvb2xiYXIuc2V0QXR0cmlidXRlKEhPU1RfQVRUUiwgJzEnKTtcblxuICAvLyBDcmVhdGUgc2hhZG93IGhvc3RcbiAgY29uc3QgaG9zdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NwYW4nKTtcbiAgY29uc3Qgc2hhZG93ID0gaG9zdC5hdHRhY2hTaGFkb3coeyBtb2RlOiAnb3BlbicgfSk7XG5cbiAgLy8gU3RhdGVcbiAgbGV0IHNlbGVjdGVkVG9uZTogVG9uZSB8IG51bGwgPSBudWxsO1xuICBsZXQgbGFzdFJld3JpdGVJZDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG4gIGxldCBwYW5lbE9wZW4gPSBmYWxzZTtcblxuICBzaGFkb3cuaW5uZXJIVE1MID0gYFxuICAgIDxzdHlsZT4ke0JVVFRPTl9DU1N9PC9zdHlsZT5cbiAgICA8YnV0dG9uIGlkPVwid3QtYnRuXCIgdGl0bGU9XCJIdW1hbml6ZSB3aXRoIFdyaXRpbmcgVHdpbiBBSSAoQ21kK1NoaWZ0K0gpXCI+XHUyNzI4IEh1bWFuaXplPC9idXR0b24+XG4gICAgPGRpdiBpZD1cInd0LXBhbmVsXCI+XG4gICAgICA8cCBjbGFzcz1cInd0LXRpdGxlXCI+UmV3cml0ZSB0b25lPC9wPlxuICAgICAgPGRpdiBjbGFzcz1cInd0LXRvbmVzXCI+XG4gICAgICAgICR7VE9ORVMubWFwKHQgPT4gYDxidXR0b24gY2xhc3M9XCJ3dC10b25lXCIgZGF0YS10b25lPVwiJHt0LmtleX1cIiBkYXRhLWNvbG9yPVwiJHt0LmNvbG9yfVwiPiR7dC5sYWJlbH08L2J1dHRvbj5gKS5qb2luKCcnKX1cbiAgICAgIDwvZGl2PlxuICAgICAgPGJ1dHRvbiBpZD1cInd0LXJld3JpdGVcIiBkaXNhYmxlZD5SZXdyaXRlIFx1MjE5MjwvYnV0dG9uPlxuICAgICAgPGRpdiBpZD1cInd0LXN0YXR1c1wiPjwvZGl2PlxuICAgICAgPGRpdiBpZD1cInd0LWxpbWl0XCI+XG4gICAgICAgIDxwPllvdSd2ZSB1c2VkIGFsbCB5b3VyIGZyZWUgcmV3cml0ZXMgdGhpcyBtb250aC48L3A+XG4gICAgICAgIDxhIGhyZWY9XCJodHRwczovL3dyaXRpbmd0d2luYWkuY29tL3ByaWNpbmdcIiB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub29wZW5lclwiPlVwZ3JhZGUgdG8gUHJvIFx1MjAxNCAkNS9tbzwvYT5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBpZD1cInd0LXZvaWNlbWF0Y2hcIj5cbiAgICAgICAgPHNwYW4gY2xhc3M9XCJ3dC12bS1zcGFya1wiPlx1MjcyODwvc3Bhbj5cbiAgICAgICAgPHNwYW4gY2xhc3M9XCJ3dC12bS10ZXh0XCI+U291bmRzIGxpa2UgeW91PC9zcGFuPlxuICAgICAgICA8c3BhbiBjbGFzcz1cInd0LXZtLXBjdFwiIGlkPVwid3Qtdm0tcGN0XCI+PC9zcGFuPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGlkPVwid3QtYWN0aW9uc1wiPlxuICAgICAgICA8YnV0dG9uIGNsYXNzPVwid3QtYWN0aW9uIGFjY2VwdFwiIGlkPVwid3QtYWNjZXB0XCI+XHUyNzEzIEtlZXA8L2J1dHRvbj5cbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cInd0LWFjdGlvbiByZWdlblwiIGlkPVwid3QtcmVnZW5cIj5cdTIxQkIgQWdhaW48L2J1dHRvbj5cbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cInd0LWFjdGlvbiByZWplY3RcIiBpZD1cInd0LXJlamVjdFwiPlx1MjcxNyBVbmRvPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgYDtcblxuICBjb25zdCBidG4gPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LWJ0bicpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICBjb25zdCBwYW5lbCA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtcGFuZWwnKSBhcyBIVE1MRGl2RWxlbWVudDtcbiAgY29uc3QgcmV3cml0ZUJ0biA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtcmV3cml0ZScpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICBjb25zdCBzdGF0dXNFbCA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3Qtc3RhdHVzJykgYXMgSFRNTERpdkVsZW1lbnQ7XG4gIGNvbnN0IGxpbWl0RWwgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LWxpbWl0JykgYXMgSFRNTERpdkVsZW1lbnQ7XG4gIGNvbnN0IGFjdGlvbnNFbCA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtYWN0aW9ucycpIGFzIEhUTUxEaXZFbGVtZW50O1xuICBjb25zdCB2b2ljZW1hdGNoRWwgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LXZvaWNlbWF0Y2gnKSBhcyBIVE1MRGl2RWxlbWVudDtcbiAgY29uc3Qgdm1QY3RFbCA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3Qtdm0tcGN0JykgYXMgSFRNTFNwYW5FbGVtZW50O1xuICBjb25zdCBhY2NlcHRCdG4gPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LWFjY2VwdCcpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICBjb25zdCByZWdlbkJ0biA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtcmVnZW4nKSBhcyBIVE1MQnV0dG9uRWxlbWVudDtcbiAgY29uc3QgcmVqZWN0QnRuID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC1yZWplY3QnKSBhcyBIVE1MQnV0dG9uRWxlbWVudDtcblxuICAvLyBUb25lIHNlbGVjdGlvblxuICBzaGFkb3cucXVlcnlTZWxlY3RvckFsbDxIVE1MQnV0dG9uRWxlbWVudD4oJy53dC10b25lJykuZm9yRWFjaCh0b25lYnRuID0+IHtcbiAgICB0b25lYnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgICAgc2hhZG93LnF1ZXJ5U2VsZWN0b3JBbGwoJy53dC10b25lJykuZm9yRWFjaChiID0+IGIuY2xhc3NMaXN0LnJlbW92ZSgnYWN0aXZlJykpO1xuICAgICAgdG9uZWJ0bi5jbGFzc0xpc3QuYWRkKCdhY3RpdmUnKTtcbiAgICAgIHRvbmVidG4uc3R5bGUuYmFja2dyb3VuZCA9IHRvbmVidG4uZGF0YXNldC5jb2xvciA/PyAnIzRGNDZFNSc7XG4gICAgICB0b25lYnRuLnN0eWxlLmJvcmRlckNvbG9yID0gdG9uZWJ0bi5kYXRhc2V0LmNvbG9yID8/ICcjNEY0NkU1JztcbiAgICAgIHNlbGVjdGVkVG9uZSA9IHRvbmVidG4uZGF0YXNldC50b25lIGFzIFRvbmU7XG4gICAgICByZXdyaXRlQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gICAgICBzdGF0dXNFbC50ZXh0Q29udGVudCA9ICcnO1xuICAgICAgc3RhdHVzRWwuY2xhc3NOYW1lID0gJyc7XG4gICAgICBsaW1pdEVsLmNsYXNzTGlzdC5yZW1vdmUoJ3Zpc2libGUnKTtcbiAgICAgIGFjdGlvbnNFbC5jbGFzc0xpc3QucmVtb3ZlKCd2aXNpYmxlJyk7XG4gICAgICB2b2ljZW1hdGNoRWwuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xuICAgIH0pO1xuICB9KTtcblxuICAvLyBBdXRvLXNlbGVjdCB0b25lIG9uIGZpcnN0IG9wZW4gYmFzZWQgb24gY29udGV4dFxuICBmdW5jdGlvbiBwcmVzZWxlY3RUb25lKHRvbmU6IFRvbmUpIHtcbiAgICBjb25zdCB0b25lQnRuID0gc2hhZG93LnF1ZXJ5U2VsZWN0b3I8SFRNTEJ1dHRvbkVsZW1lbnQ+KGAud3QtdG9uZVtkYXRhLXRvbmU9XCIke3RvbmV9XCJdYCk7XG4gICAgaWYgKHRvbmVCdG4gJiYgIXNlbGVjdGVkVG9uZSkge1xuICAgICAgc2hhZG93LnF1ZXJ5U2VsZWN0b3JBbGwoJy53dC10b25lJykuZm9yRWFjaChiID0+IGIuY2xhc3NMaXN0LnJlbW92ZSgnYWN0aXZlJykpO1xuICAgICAgdG9uZUJ0bi5jbGFzc0xpc3QuYWRkKCdhY3RpdmUnKTtcbiAgICAgICh0b25lQnRuIGFzIEhUTUxFbGVtZW50KS5zdHlsZS5iYWNrZ3JvdW5kID0gdG9uZUJ0bi5kYXRhc2V0LmNvbG9yID8/ICcjNEY0NkU1JztcbiAgICAgICh0b25lQnRuIGFzIEhUTUxFbGVtZW50KS5zdHlsZS5ib3JkZXJDb2xvciA9IHRvbmVCdG4uZGF0YXNldC5jb2xvciA/PyAnIzRGNDZFNSc7XG4gICAgICBzZWxlY3RlZFRvbmUgPSB0b25lO1xuICAgICAgcmV3cml0ZUJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICAgIH1cbiAgfVxuXG4gIC8vIFRvZ2dsZSBwYW5lbFxuICBidG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgcGFuZWxPcGVuID0gIXBhbmVsT3BlbjtcbiAgICBwYW5lbC5jbGFzc0xpc3QudG9nZ2xlKCdvcGVuJywgcGFuZWxPcGVuKTtcbiAgICBpZiAocGFuZWxPcGVuKSB7XG4gICAgICBwb3NpdGlvblBhbmVsKCk7XG4gICAgICBpZiAoIXNlbGVjdGVkVG9uZSkgcHJlc2VsZWN0VG9uZShkZXRlY3RDb250ZXh0VG9uZShjb21wb3NlQm9keSkpO1xuICAgIH1cbiAgfSk7XG5cbiAgLy8gQ2xvc2UgcGFuZWwgb24gb3V0c2lkZSBjbGlja1xuICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChlKSA9PiB7XG4gICAgaWYgKCFob3N0LmNvbnRhaW5zKGUudGFyZ2V0IGFzIE5vZGUpICYmIHBhbmVsT3Blbikge1xuICAgICAgcGFuZWxPcGVuID0gZmFsc2U7XG4gICAgICBwYW5lbC5jbGFzc0xpc3QucmVtb3ZlKCdvcGVuJyk7XG4gICAgfVxuICB9LCB0cnVlKTtcblxuICBmdW5jdGlvbiBwb3NpdGlvblBhbmVsKCk6IHZvaWQge1xuICAgIGNvbnN0IHJlY3QgPSBidG4uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgcGFuZWwuc3R5bGUuYm90dG9tID0gYCR7d2luZG93LmlubmVySGVpZ2h0IC0gcmVjdC50b3AgKyA0fXB4YDtcbiAgICBwYW5lbC5zdHlsZS5sZWZ0ID0gYCR7TWF0aC5taW4ocmVjdC5sZWZ0LCB3aW5kb3cuaW5uZXJXaWR0aCAtIDI3Nil9cHhgO1xuICB9XG5cbiAgbGV0IG9yaWdpbmFsVGV4dCA9ICcnO1xuXG4gIC8vIFNob3cgdGhlIFwiU291bmRzIGxpa2UgeW91XCIgYWZmaXJtYXRpb24uIFdoZW4gdGhlIGJhY2tlbmQgcmV0dXJucyBhXG4gIC8vIHF1YWxpdHlfc2NvcmUsIHN1cmZhY2UgaXQgaG9uZXN0bHkgYXMgYSBtYXRjaCAlOyBvdGhlcndpc2UganVzdCBhZmZpcm0uXG4gIGZ1bmN0aW9uIHNob3dWb2ljZU1hdGNoKHNjb3JlOiBudW1iZXIgfCBudWxsIHwgdW5kZWZpbmVkKTogdm9pZCB7XG4gICAgaWYgKHR5cGVvZiBzY29yZSA9PT0gJ251bWJlcicgJiYgc2NvcmUgPiAwKSB7XG4gICAgICBjb25zdCBwY3QgPSBNYXRoLnJvdW5kKHNjb3JlIDw9IDEgPyBzY29yZSAqIDEwMCA6IHNjb3JlKTtcbiAgICAgIHZtUGN0RWwudGV4dENvbnRlbnQgPSBgJHtwY3R9JSBtYXRjaGA7XG4gICAgfSBlbHNlIHtcbiAgICAgIHZtUGN0RWwudGV4dENvbnRlbnQgPSAnJztcbiAgICB9XG4gICAgdm9pY2VtYXRjaEVsLmNsYXNzTGlzdC5hZGQoJ3Zpc2libGUnKTtcbiAgfVxuXG4gIC8vIENvcmUgcmV3cml0ZS4gYHJlZ2VuYCByZS1yZXdyaXRlcyBmcm9tIHRoZSB1c2VyJ3MgT1JJR0lOQUwgdGV4dCBzb1xuICAvLyByZXBlYXRlZCB0YWtlcyBzdGF5IGFuY2hvcmVkIHRvIGludGVudCBpbnN0ZWFkIG9mIGRyaWZ0aW5nLlxuICBhc3luYyBmdW5jdGlvbiBydW5SZXdyaXRlKHJlZ2VuID0gZmFsc2UpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBpZiAoIXNlbGVjdGVkVG9uZSkgcmV0dXJuO1xuXG4gICAgY29uc3QgdGV4dCA9IHJlZ2VuID8gb3JpZ2luYWxUZXh0IDogKGNvbXBvc2VCb2R5IGFzIEhUTUxFbGVtZW50KS5pbm5lclRleHQudHJpbSgpO1xuICAgIGlmICghdGV4dCkge1xuICAgICAgc2V0U3RhdHVzKCdXcml0ZSBzb21ldGhpbmcgZmlyc3QuJywgJ2Vycm9yJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICghcmVnZW4pIG9yaWdpbmFsVGV4dCA9IHRleHQ7XG5cbiAgICBidG4uZGlzYWJsZWQgPSB0cnVlO1xuICAgIHJld3JpdGVCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICAgIHJlZ2VuQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgICBzZXRTdGF0dXMocmVnZW4gPyAnVHJ5aW5nIGFub3RoZXJcdTIwMjYnIDogJ1Jld3JpdGluZ1x1MjAyNicpO1xuICAgIGFjdGlvbnNFbC5jbGFzc0xpc3QucmVtb3ZlKCd2aXNpYmxlJyk7XG4gICAgdm9pY2VtYXRjaEVsLmNsYXNzTGlzdC5yZW1vdmUoJ3Zpc2libGUnKTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwID0gYXdhaXQgc2VuZFRvQmFja2dyb3VuZDx7IHJlc3VsdDogUmV3cml0ZVJlc3BvbnNlIH0+KHtcbiAgICAgICAgdHlwZTogJ0hVTUFOSVpFJyxcbiAgICAgICAgcGF5bG9hZDogeyB0ZXh0LCB0b25lOiBzZWxlY3RlZFRvbmUgfSxcbiAgICAgIH0pO1xuXG4gICAgICBpZiAoJ2Vycm9yJyBpbiByZXNwKSB0aHJvdyBuZXcgRXJyb3IoU3RyaW5nKHJlc3AuZXJyb3IpKTtcblxuICAgICAgbGFzdFJld3JpdGVJZCA9IHJlc3AucmVzdWx0LmlkO1xuICAgICAgc2V0Q29tcG9zZVRleHQoY29tcG9zZUJvZHkgYXMgSFRNTEVsZW1lbnQsIHJlc3AucmVzdWx0Lm91dHB1dF90ZXh0KTtcbiAgICAgIHNldFN0YXR1cygnJyk7XG4gICAgICBzaG93Vm9pY2VNYXRjaChyZXNwLnJlc3VsdC5xdWFsaXR5X3Njb3JlKTtcbiAgICAgIGFjdGlvbnNFbC5jbGFzc0xpc3QuYWRkKCd2aXNpYmxlJyk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zdCBtc2cgPSBlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogJ0ZhaWxlZCc7XG4gICAgICBpZiAobXNnLnN0YXJ0c1dpdGgoJ0xJTUlUX1JFQUNIRUQ6JykpIHtcbiAgICAgICAgbGltaXRFbC5jbGFzc0xpc3QuYWRkKCd2aXNpYmxlJyk7XG4gICAgICAgIHNldFN0YXR1cygnJyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRTdGF0dXMobXNnLCAnZXJyb3InKTtcbiAgICAgIH1cbiAgICB9IGZpbmFsbHkge1xuICAgICAgYnRuLmRpc2FibGVkID0gZmFsc2U7XG4gICAgICByZXdyaXRlQnRuLmRpc2FibGVkID0gc2VsZWN0ZWRUb25lID09PSBudWxsO1xuICAgICAgcmVnZW5CdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgICB9XG4gIH1cblxuICAvLyBSZXdyaXRlXG4gIHJld3JpdGVCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7IHZvaWQgcnVuUmV3cml0ZShmYWxzZSk7IH0pO1xuXG4gIC8vIFRyeSBhbm90aGVyIFx1MjAxNCByZWdlbmVyYXRlIGFuIGFsdGVybmF0aXZlIGZyb20gdGhlIG9yaWdpbmFsIHRleHRcbiAgcmVnZW5CdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7IHZvaWQgcnVuUmV3cml0ZSh0cnVlKTsgfSk7XG5cbiAgLy8gQWNjZXB0IGZlZWRiYWNrXG4gIGFjY2VwdEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgICBpZiAobGFzdFJld3JpdGVJZCkge1xuICAgICAgc2VuZFRvQmFja2dyb3VuZCh7IHR5cGU6ICdGRUVEQkFDSycsIHBheWxvYWQ6IHsgcmV3cml0ZUlkOiBsYXN0UmV3cml0ZUlkLCBhY3Rpb246ICdhY2NlcHRlZCcgfSB9KTtcbiAgICB9XG4gICAgYWN0aW9uc0VsLmNsYXNzTGlzdC5yZW1vdmUoJ3Zpc2libGUnKTtcbiAgICB2b2ljZW1hdGNoRWwuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xuICAgIHBhbmVsT3BlbiA9IGZhbHNlO1xuICAgIHBhbmVsLmNsYXNzTGlzdC5yZW1vdmUoJ29wZW4nKTtcbiAgICBzZXRTdGF0dXMoJycpO1xuICB9KTtcblxuICAvLyBSZWplY3QgLyB1bmRvXG4gIHJlamVjdEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgICBpZiAob3JpZ2luYWxUZXh0KSBzZXRDb21wb3NlVGV4dChjb21wb3NlQm9keSBhcyBIVE1MRWxlbWVudCwgb3JpZ2luYWxUZXh0KTtcbiAgICBpZiAobGFzdFJld3JpdGVJZCkge1xuICAgICAgc2VuZFRvQmFja2dyb3VuZCh7IHR5cGU6ICdGRUVEQkFDSycsIHBheWxvYWQ6IHsgcmV3cml0ZUlkOiBsYXN0UmV3cml0ZUlkLCBhY3Rpb246ICdyZWplY3RlZCcgfSB9KTtcbiAgICB9XG4gICAgYWN0aW9uc0VsLmNsYXNzTGlzdC5yZW1vdmUoJ3Zpc2libGUnKTtcbiAgICB2b2ljZW1hdGNoRWwuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xuICAgIHNldFN0YXR1cygnUmV2ZXJ0ZWQuJywgJ3N1Y2Nlc3MnKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHNldFN0YXR1cygnJyksIDIwMDApO1xuICB9KTtcblxuICBmdW5jdGlvbiBzZXRTdGF0dXMobXNnOiBzdHJpbmcsIGNscyA9ICcnKTogdm9pZCB7XG4gICAgc3RhdHVzRWwudGV4dENvbnRlbnQgPSBtc2c7XG4gICAgc3RhdHVzRWwuY2xhc3NOYW1lID0gY2xzO1xuICB9XG5cbiAgLy8gSW5zZXJ0IGh1bWFuaXplIGhvc3QgYmVmb3JlIFNlbmQgYnV0dG9uIGluIHRoZSB0b29sYmFyXG4gIHRvb2xiYXIuaW5zZXJ0QmVmb3JlKGhvc3QsIHNlbmRCdG4pO1xuXG4gIC8vIEluamVjdCBtaWMgYnV0dG9uIGltbWVkaWF0ZWx5IGFmdGVyXG4gIGluamVjdE1pY0J1dHRvbih0b29sYmFyLCBjb21wb3NlQm9keSk7XG59XG5cbi8vIFx1MjUwMFx1MjUwMCBIZWxwZXJzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5mdW5jdGlvbiBmaW5kU2VuZEJ1dHRvbihjb21wb3NlQm9keTogRWxlbWVudCk6IEVsZW1lbnQgfCBudWxsIHtcbiAgLy8gV2FsayB1cCB0aGUgdHJlZSB0byBmaW5kIHRoZSBjb21wb3NlIGNvbnRhaW5lciB0aGF0IGhvbGRzIHRoZSBTZW5kIGJ1dHRvbi5cbiAgLy8gR21haWwgbmVzdHMgdGhlIHRvb2xiYXIgZGVlcCBcdTIwMTQgMjUgbGV2ZWxzIGlzIHNhZmUgaGVhZHJvb20uXG4gIGxldCBlbDogRWxlbWVudCB8IG51bGwgPSBjb21wb3NlQm9keTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCAyNTsgaSsrKSB7XG4gICAgaWYgKCFlbCkgYnJlYWs7XG4gICAgY29uc3Qgc2VuZCA9IGVsLnF1ZXJ5U2VsZWN0b3IoU0VORF9CVVRUT05fU0VMKTtcbiAgICBpZiAoc2VuZCkgcmV0dXJuIHNlbmQ7XG4gICAgZWwgPSBlbC5wYXJlbnRFbGVtZW50O1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG5mdW5jdGlvbiBzZXRDb21wb3NlVGV4dChlbDogSFRNTEVsZW1lbnQsIHRleHQ6IHN0cmluZyk6IHZvaWQge1xuICBlbC5mb2N1cygpO1xuICBkb2N1bWVudC5leGVjQ29tbWFuZCgnc2VsZWN0QWxsJywgZmFsc2UsIHVuZGVmaW5lZCk7XG4gIGRvY3VtZW50LmV4ZWNDb21tYW5kKCdkZWxldGUnLCBmYWxzZSwgdW5kZWZpbmVkKTtcbiAgLy8gSW5zZXJ0IGxpbmUgYnkgbGluZSB0byBwcmVzZXJ2ZSBwYXJhZ3JhcGggc3RydWN0dXJlXG4gIGNvbnN0IGxpbmVzID0gdGV4dC5zcGxpdCgnXFxuJyk7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbGluZXMubGVuZ3RoOyBpKyspIHtcbiAgICBpZiAobGluZXNbaV0pIGRvY3VtZW50LmV4ZWNDb21tYW5kKCdpbnNlcnRUZXh0JywgZmFsc2UsIGxpbmVzW2ldKTtcbiAgICBpZiAoaSA8IGxpbmVzLmxlbmd0aCAtIDEpIGRvY3VtZW50LmV4ZWNDb21tYW5kKCdpbnNlcnRQYXJhZ3JhcGgnLCBmYWxzZSwgdW5kZWZpbmVkKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBzZW5kVG9CYWNrZ3JvdW5kPFQ+KG1lc3NhZ2U6IG9iamVjdCwgYXR0ZW1wdCA9IDApOiBQcm9taXNlPFQ+IHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICBjb25zdCByZXRyeSA9ICgpID0+IHtcbiAgICAgIC8vIFNlcnZpY2Ugd29ya2VyIHdha2luZyB1cCBcdTIwMTQgZ2l2ZSBpdCA5MDBtcyB0aGVuIHRyeSBvbmNlIG1vcmVcbiAgICAgIGlmIChhdHRlbXB0ID09PSAwKSB7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2VuZFRvQmFja2dyb3VuZDxUPihtZXNzYWdlLCAxKS50aGVuKHJlc29sdmUpLmNhdGNoKHJlamVjdCksIDkwMCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZWplY3QobmV3IEVycm9yKCdFeHRlbnNpb24gcmVzdGFydGVkIFx1MjAxNCBwbGVhc2UgcmVsb2FkIEdtYWlsIGFuZCB0cnkgYWdhaW4uJykpO1xuICAgICAgfVxuICAgIH07XG4gICAgLy8gY2hyb21lLnJ1bnRpbWUgaXMgdW5kZWZpbmVkIHdoZW4gdGhlIGV4dGVuc2lvbiBjb250ZXh0IGlzIGZ1bGx5IGludmFsaWRhdGVkXG4gICAgaWYgKCFjaHJvbWU/LnJ1bnRpbWU/LnNlbmRNZXNzYWdlKSB7IHJldHJ5KCk7IHJldHVybjsgfVxuICAgIHRyeSB7XG4gICAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZShtZXNzYWdlLCAocmVzcG9uc2UpID0+IHtcbiAgICAgICAgaWYgKGNocm9tZS5ydW50aW1lPy5sYXN0RXJyb3IpIHtcbiAgICAgICAgICByZXRyeSgpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJlc29sdmUocmVzcG9uc2UpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHJldHJ5KCk7XG4gICAgfVxuICB9KTtcbn1cblxuLy8gXHUyNTAwXHUyNTAwIE11dGF0aW9uT2JzZXJ2ZXIgXHUyMDE0IHdhdGNoIGZvciBuZXcgY29tcG9zZSB3aW5kb3dzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5jb25zdCBzZWVuID0gbmV3IFdlYWtTZXQ8RWxlbWVudD4oKTtcblxuZnVuY3Rpb24gdHJ5SW5qZWN0KHJvb3Q6IEVsZW1lbnQgfCBEb2N1bWVudCk6IHZvaWQge1xuICByb290LnF1ZXJ5U2VsZWN0b3JBbGw8RWxlbWVudD4oQ09NUE9TRV9CT0RZX1NFTCkuZm9yRWFjaCgoYm9keSkgPT4ge1xuICAgIGlmICghc2Vlbi5oYXMoYm9keSkpIHtcbiAgICAgIHNlZW4uYWRkKGJvZHkpO1xuICAgICAgaW5qZWN0KGJvZHkpO1xuICAgIH1cbiAgfSk7XG59XG5cbmNvbnN0IG9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoKCkgPT4gdHJ5SW5qZWN0KGRvY3VtZW50KSk7XG5cbm9ic2VydmVyLm9ic2VydmUoZG9jdW1lbnQuYm9keSwgeyBjaGlsZExpc3Q6IHRydWUsIHN1YnRyZWU6IHRydWUgfSk7XG5cbi8vIEhhbmRsZSBjb21wb3NlIHdpbmRvd3MgYWxyZWFkeSBvcGVuIG9uIGxvYWRcbnRyeUluamVjdChkb2N1bWVudCk7XG5cbi8vIEtleWJvYXJkIHNob3J0Y3V0c1xuZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIChlKSA9PiB7XG4gIGNvbnN0IHRvb2xiYXIgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGBbJHtIT1NUX0FUVFJ9XWApO1xuICBpZiAoIXRvb2xiYXIpIHJldHVybjtcbiAgY29uc3QgaG9zdHMgPSBBcnJheS5mcm9tKHRvb2xiYXIuY2hpbGRyZW4pLmZpbHRlcihjID0+IGMuc2hhZG93Um9vdCkgYXMgSFRNTEVsZW1lbnRbXTtcblxuICBpZiAoKGUubWV0YUtleSB8fCBlLmN0cmxLZXkpICYmIGUuc2hpZnRLZXkgJiYgZS5rZXkgPT09ICdIJykge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAvLyBGaXJzdCBzaGFkb3cgaG9zdCA9IGh1bWFuaXplIGJ1dHRvblxuICAgIGNvbnN0IGJ0biA9IGhvc3RzWzBdPy5zaGFkb3dSb290Py5nZXRFbGVtZW50QnlJZCgnd3QtYnRuJykgYXMgSFRNTEJ1dHRvbkVsZW1lbnQgfCBudWxsO1xuICAgIGJ0bj8uY2xpY2soKTtcbiAgfVxuXG4gIGlmICgoZS5tZXRhS2V5IHx8IGUuY3RybEtleSkgJiYgZS5zaGlmdEtleSAmJiBlLmtleSA9PT0gJ1YnKSB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIC8vIFNlY29uZCBzaGFkb3cgaG9zdCA9IG1pYyBidXR0b25cbiAgICBjb25zdCBidG4gPSBob3N0c1sxXT8uc2hhZG93Um9vdD8uZ2V0RWxlbWVudEJ5SWQoJ3d0LW1pYy1idG4nKSBhcyBIVE1MQnV0dG9uRWxlbWVudCB8IG51bGw7XG4gICAgYnRuPy5jbGljaygpO1xuICB9XG59KTtcbiJdLAogICJtYXBwaW5ncyI6ICI7OztBQUlBLE1BQU0sbUJBQW1CO0FBQ3pCLE1BQU0sa0JBQWtCO0FBQ3hCLE1BQU0sWUFBWTtBQUlsQixNQUFNLGVBQWUsb0JBQUksSUFBSSxDQUFDLGFBQVksYUFBWSxlQUFjLGVBQWMsY0FBYSxrQkFBaUIsV0FBVSxVQUFVLENBQUM7QUFDckksTUFBTSxvQkFBb0I7QUFDMUIsTUFBTSxvQkFBb0I7QUFFMUIsV0FBUyxrQkFBa0IsYUFBNEI7QUFFckQsVUFBTSxVQUFVLFlBQVksUUFBUSxxQ0FBcUMsS0FBSztBQUc5RSxVQUFNLFVBQVcsUUFBUSxnQkFBZ0IsMEJBQTBCLEdBQStCLFNBQVM7QUFHM0csVUFBTSxXQUFXLE1BQU0sS0FBSyxRQUFRLG1CQUFtQixTQUFTLEtBQUssQ0FBQyxDQUFDLEVBQ3BFLElBQUksU0FBTyxHQUFHLGFBQWEsT0FBTyxLQUFLLElBQUksWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUMsS0FBSyxFQUFFO0FBQy9FLFVBQU0sdUJBQXVCLFNBQVMsS0FBSyxZQUFVLFVBQVUsQ0FBQyxhQUFhLElBQUksTUFBTSxDQUFDO0FBQ3hGLFVBQU0sbUJBQW1CLFNBQVMsTUFBTSxZQUFVLGFBQWEsSUFBSSxNQUFNLENBQUM7QUFFMUUsUUFBSSxrQkFBa0IsS0FBSyxPQUFPLEtBQU0sd0JBQXdCLFNBQVMsU0FBUyxHQUFJO0FBQ3BGLGFBQU87QUFBQSxJQUNUO0FBQ0EsUUFBSSw2Q0FBNkMsS0FBSyxPQUFPLEdBQUc7QUFDOUQsYUFBTztBQUFBLElBQ1Q7QUFDQSxRQUFJLGtCQUFrQixLQUFLLE9BQU8sS0FBSyxrQkFBa0I7QUFDdkQsYUFBTztBQUFBLElBQ1Q7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUlBLE1BQU0sUUFBdUQ7QUFBQSxJQUMzRCxFQUFFLEtBQUssZ0JBQWdCLE9BQU8sZ0JBQWdCLE9BQU8sVUFBVTtBQUFBLElBQy9ELEVBQUUsS0FBSyxVQUFnQixPQUFPLFVBQWdCLE9BQU8sVUFBVTtBQUFBLElBQy9ELEVBQUUsS0FBSyxZQUFnQixPQUFPLFlBQWdCLE9BQU8sVUFBVTtBQUFBLElBQy9ELEVBQUUsS0FBSyxVQUFnQixPQUFPLFVBQWdCLE9BQU8sVUFBVTtBQUFBLElBQy9ELEVBQUUsS0FBSyxjQUFnQixPQUFPLGNBQWdCLE9BQU8sVUFBVTtBQUFBLElBQy9ELEVBQUUsS0FBSyxhQUFnQixPQUFPLGFBQWdCLE9BQU8sVUFBVTtBQUFBLEVBQ2pFO0FBSUEsTUFBTSxhQUFhO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFxR25CLE1BQU0scUJBQWdFO0FBQUEsSUFDcEUsRUFBRSxLQUFLLFNBQW1CLE9BQU8sUUFBUTtBQUFBLElBQ3pDLEVBQUUsS0FBSyxTQUFtQixPQUFPLFFBQVE7QUFBQSxJQUN6QyxFQUFFLEtBQUssbUJBQW1CLE9BQU8sa0JBQWtCO0FBQUEsSUFDbkQsRUFBRSxLQUFLLGVBQW1CLE9BQU8sY0FBYztBQUFBLElBQy9DLEVBQUUsS0FBSyxvQkFBbUIsT0FBTyxjQUFjO0FBQUEsRUFDakQ7QUFFQSxNQUFNLFVBQVU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFtRWhCLFdBQVMsZ0JBQWdCLFNBQWtCLGFBQTRCO0FBQ3JFLFVBQU0sVUFBVSxTQUFTLGNBQWMsTUFBTTtBQUM3QyxVQUFNLFNBQVMsUUFBUSxhQUFhLEVBQUUsTUFBTSxPQUFPLENBQUM7QUFFcEQsV0FBTyxZQUFZO0FBQUEsYUFDUixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTVYsbUJBQW1CO0FBQUEsTUFBSSxDQUFDLEdBQUcsTUFDM0IsMEJBQTBCLE1BQU0sSUFBSSxZQUFZLEVBQUUsZ0JBQWdCLEVBQUUsR0FBRyxLQUFLLEVBQUUsS0FBSztBQUFBLElBQ3JGLEVBQUUsS0FBSyxFQUFFLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFXaEIsVUFBTSxTQUFjLE9BQU8sZUFBZSxZQUFZO0FBQ3RELFVBQU0sUUFBYyxPQUFPLGVBQWUsZ0JBQWdCO0FBQzFELFVBQU0sWUFBYyxPQUFPLGVBQWUsZUFBZTtBQUN6RCxVQUFNLFdBQWMsT0FBTyxlQUFlLGlCQUFpQjtBQUMzRCxVQUFNLFlBQWMsT0FBTyxlQUFlLGtCQUFrQjtBQUM1RCxVQUFNLFVBQWMsT0FBTyxlQUFlLFlBQVk7QUFDdEQsVUFBTSxVQUFjLE9BQU8sZUFBZSxZQUFZO0FBRXRELFFBQUksWUFBWTtBQUNoQixRQUFJLGVBQWdDO0FBQ3BDLFFBQUksY0FBbUU7QUFDdkUsUUFBSSxZQUFZO0FBQ2hCLFFBQUksYUFBYTtBQUNqQixRQUFJLGdCQUErQjtBQUNuQyxRQUFJLGVBQWU7QUFHbkIsV0FBTyxpQkFBb0MsV0FBVyxFQUFFLFFBQVEsU0FBTztBQUNyRSxVQUFJLGlCQUFpQixTQUFTLE1BQU07QUFDbEMsZUFBTyxpQkFBaUIsV0FBVyxFQUFFLFFBQVEsT0FBSyxFQUFFLFVBQVUsT0FBTyxRQUFRLENBQUM7QUFDOUUsWUFBSSxVQUFVLElBQUksUUFBUTtBQUMxQix1QkFBZSxJQUFJLFFBQVE7QUFBQSxNQUM3QixDQUFDO0FBQUEsSUFDSCxDQUFDO0FBRUQsV0FBTyxpQkFBaUIsU0FBUyxNQUFNO0FBQ3JDLGtCQUFZLENBQUM7QUFDYixZQUFNLFVBQVUsT0FBTyxRQUFRLFNBQVM7QUFDeEMsVUFBSSxVQUFXLGVBQWM7QUFBQSxJQUMvQixDQUFDO0FBRUQsYUFBUyxpQkFBaUIsU0FBUyxDQUFDLE1BQU07QUFDeEMsVUFBSSxDQUFDLFFBQVEsU0FBUyxFQUFFLE1BQWMsS0FBSyxXQUFXO0FBQ3BELG9CQUFZO0FBQ1osY0FBTSxVQUFVLE9BQU8sTUFBTTtBQUFBLE1BQy9CO0FBQUEsSUFDRixHQUFHLElBQUk7QUFFUCxhQUFTLGdCQUFzQjtBQUM3QixZQUFNLE9BQU8sT0FBTyxzQkFBc0I7QUFDMUMsWUFBTSxNQUFNLFNBQVMsR0FBRyxPQUFPLGNBQWMsS0FBSyxNQUFNLENBQUM7QUFDekQsWUFBTSxNQUFNLE9BQU8sR0FBRyxLQUFLLElBQUksS0FBSyxNQUFNLE9BQU8sYUFBYSxHQUFHLENBQUM7QUFBQSxJQUNwRTtBQUVBLGNBQVUsaUJBQWlCLFNBQVMsWUFBWTtBQUM5QyxVQUFJLENBQUMsV0FBVztBQUNkLGNBQU0sZUFBZTtBQUFBLE1BQ3ZCLE9BQU87QUFDTCxzQkFBYztBQUFBLE1BQ2hCO0FBQUEsSUFDRixDQUFDO0FBRUQsbUJBQWUsaUJBQWdDO0FBQzdDLFlBQU0sb0JBQXFCLE9BQW1GO0FBQzlHLFVBQUksQ0FBQyxtQkFBbUI7QUFDdEIsdUJBQWUscURBQXFELE9BQU87QUFDM0U7QUFBQSxNQUNGO0FBRUEsbUJBQWE7QUFDYixvQkFBYyxJQUFJLGtCQUFrQjtBQUNwQyxrQkFBWSxhQUFhO0FBQ3pCLGtCQUFZLGlCQUFpQjtBQUM3QixrQkFBWSxPQUFPO0FBRW5CLGtCQUFZLFdBQVcsQ0FBQyxNQUE4QjtBQUNwRCxZQUFJLFVBQVU7QUFDZCxpQkFBUyxJQUFJLEVBQUUsYUFBYSxJQUFJLEVBQUUsUUFBUSxRQUFRLEtBQUs7QUFDckQsY0FBSSxFQUFFLFFBQVEsQ0FBQyxFQUFFLFNBQVM7QUFDeEIsMEJBQWMsRUFBRSxRQUFRLENBQUMsRUFBRSxDQUFDLEVBQUUsYUFBYTtBQUFBLFVBQzdDLE9BQU87QUFDTCx1QkFBVyxFQUFFLFFBQVEsQ0FBQyxFQUFFLENBQUMsRUFBRTtBQUFBLFVBQzdCO0FBQUEsUUFDRjtBQUNBLHVCQUFlLGNBQU8sYUFBYSxTQUFTLEtBQUssS0FBSyxpQkFBWSxFQUFFO0FBQUEsTUFDdEU7QUFFQSxrQkFBWSxVQUFVLENBQUMsTUFBbUM7QUFDeEQsWUFBSSxFQUFFLFVBQVUsVUFBVyxnQkFBZSxjQUFjLEVBQUUsS0FBSyxJQUFJLE9BQU87QUFBQSxNQUM1RTtBQUVBLGtCQUFZLFFBQVEsTUFBTTtBQUN4QixZQUFJLFdBQVc7QUFFYix1QkFBYSxNQUFNO0FBQUEsUUFDckI7QUFBQSxNQUNGO0FBRUEsVUFBSTtBQUNGLG9CQUFZLE1BQU07QUFDbEIsb0JBQVk7QUFDWixlQUFPLFVBQVUsSUFBSSxXQUFXO0FBQ2hDLGtCQUFVLFVBQVUsSUFBSSxXQUFXO0FBQ25DLGtCQUFVLGNBQWM7QUFDeEIsa0JBQVUsVUFBVSxPQUFPLFNBQVM7QUFHcEMsbUJBQVcsTUFBTTtBQUFFLGNBQUksVUFBVyxlQUFjO0FBQUEsUUFBRyxHQUFHLEdBQU07QUFBQSxNQUM5RCxRQUFRO0FBQ04sdUJBQWUsNkJBQTZCLE9BQU87QUFBQSxNQUNyRDtBQUFBLElBQ0Y7QUFFQSxhQUFTLGdCQUFzQjtBQUM3QixVQUFJLGVBQWUsV0FBVztBQUM1QixvQkFBWTtBQUNaLG9CQUFZLFFBQVE7QUFDcEIsb0JBQVksS0FBSztBQUNqQixzQkFBYztBQUNkLGVBQU8sVUFBVSxPQUFPLFdBQVc7QUFDbkMsa0JBQVUsVUFBVSxPQUFPLFdBQVc7QUFDdEMsa0JBQVUsY0FBYztBQUN4QixrQkFBVSxXQUFXO0FBQ3JCLHVCQUFlLGdCQUFXO0FBQzFCLGFBQUssaUJBQWlCO0FBQUEsTUFDeEI7QUFBQSxJQUNGO0FBRUEsbUJBQWUsbUJBQWtDO0FBQy9DLFVBQUk7QUFDRixjQUFNLE9BQU8sV0FBVyxLQUFLO0FBQzdCLFlBQUksQ0FBQyxNQUFNO0FBQ1QseUJBQWUsc0NBQWlDLE9BQU87QUFDdkQsb0JBQVUsV0FBVztBQUNyQjtBQUFBLFFBQ0Y7QUFFQSx1QkFBZ0IsWUFBNEIsVUFBVSxLQUFLO0FBRTNELGNBQU0sT0FBTyxNQUFNLGlCQUFxRTtBQUFBLFVBQ3RGLE1BQU07QUFBQSxVQUNOLFNBQVMsRUFBRSxZQUFZLE1BQU0sWUFBWSxhQUFhO0FBQUEsUUFDeEQsQ0FBQztBQUVELFlBQUksV0FBVyxLQUFNLE9BQU0sSUFBSSxNQUFNLE9BQU8sS0FBSyxLQUFLLENBQUM7QUFFdkQsd0JBQWdCLEtBQUssT0FBTztBQUM1Qix1QkFBZSxhQUE0QixLQUFLLE9BQU8sS0FBSztBQUM1RCx1QkFBZSxhQUFRO0FBQ3ZCLGtCQUFVLFVBQVUsSUFBSSxTQUFTO0FBQUEsTUFDbkMsU0FBUyxLQUFLO0FBQ1osY0FBTSxNQUFNLGVBQWUsUUFBUSxJQUFJLFVBQVU7QUFDakQsdUJBQWUsS0FBSyxPQUFPO0FBQUEsTUFDN0IsVUFBRTtBQUNBLGtCQUFVLFdBQVc7QUFBQSxNQUN2QjtBQUFBLElBQ0Y7QUFFQSxZQUFRLGlCQUFpQixTQUFTLE1BQU07QUFDdEMsVUFBSSxlQUFlO0FBQ2pCLHlCQUFpQjtBQUFBLFVBQ2YsTUFBTTtBQUFBLFVBQ04sU0FBUyxFQUFFLFdBQVcsZUFBZSxVQUFVLE1BQU0sYUFBYSxLQUFLO0FBQUEsUUFDekUsQ0FBQztBQUFBLE1BQ0g7QUFDQSxnQkFBVSxVQUFVLE9BQU8sU0FBUztBQUNwQyxrQkFBWTtBQUNaLFlBQU0sVUFBVSxPQUFPLE1BQU07QUFDN0IscUJBQWUsRUFBRTtBQUFBLElBQ25CLENBQUM7QUFFRCxZQUFRLGlCQUFpQixTQUFTLE1BQU07QUFDdEMsVUFBSSxhQUFjLGdCQUFlLGFBQTRCLFlBQVk7QUFDekUsVUFBSSxlQUFlO0FBQ2pCLHlCQUFpQjtBQUFBLFVBQ2YsTUFBTTtBQUFBLFVBQ04sU0FBUyxFQUFFLFdBQVcsZUFBZSxVQUFVLE9BQU8sYUFBYSxLQUFLO0FBQUEsUUFDMUUsQ0FBQztBQUFBLE1BQ0g7QUFDQSxnQkFBVSxVQUFVLE9BQU8sU0FBUztBQUNwQyxxQkFBZSxhQUFhLFNBQVM7QUFDckMsaUJBQVcsTUFBTSxlQUFlLEVBQUUsR0FBRyxHQUFJO0FBQUEsSUFDM0MsQ0FBQztBQUVELGFBQVMsZUFBZSxLQUFhLE1BQU0sSUFBVTtBQUNuRCxlQUFTLGNBQWM7QUFDdkIsZUFBUyxZQUFZO0FBQUEsSUFDdkI7QUFHQSxVQUFNLGVBQWUsTUFBTSxLQUFLLFFBQVEsUUFBUSxFQUFFLEtBQUssT0FBSyxFQUFFLFVBQVU7QUFDeEUsUUFBSSxjQUFjO0FBQ2hCLGNBQVEsYUFBYSxTQUFTLGFBQWEsV0FBVztBQUFBLElBQ3hELE9BQU87QUFDTCxZQUFNLFVBQVUsUUFBUSxjQUFjLGVBQWU7QUFDckQsVUFBSSxRQUFTLFNBQVEsYUFBYSxTQUFTLE9BQU87QUFBQSxVQUM3QyxTQUFRLFlBQVksT0FBTztBQUFBLElBQ2xDO0FBQUEsRUFDRjtBQUlBLFdBQVMsT0FBTyxhQUE0QjtBQUUxQyxVQUFNLFVBQVUsZUFBZSxXQUFXO0FBQzFDLFFBQUksQ0FBQyxRQUFTO0FBRWQsVUFBTSxVQUFVLFFBQVE7QUFDeEIsUUFBSSxDQUFDLFdBQVcsUUFBUSxhQUFhLFNBQVMsRUFBRztBQUVqRCxZQUFRLGFBQWEsV0FBVyxHQUFHO0FBR25DLFVBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxVQUFNLFNBQVMsS0FBSyxhQUFhLEVBQUUsTUFBTSxPQUFPLENBQUM7QUFHakQsUUFBSSxlQUE0QjtBQUNoQyxRQUFJLGdCQUErQjtBQUNuQyxRQUFJLFlBQVk7QUFFaEIsV0FBTyxZQUFZO0FBQUEsYUFDUixVQUFVO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtiLE1BQU0sSUFBSSxPQUFLLHNDQUFzQyxFQUFFLEdBQUcsaUJBQWlCLEVBQUUsS0FBSyxLQUFLLEVBQUUsS0FBSyxXQUFXLEVBQUUsS0FBSyxFQUFFLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQXFCM0gsVUFBTSxNQUFNLE9BQU8sZUFBZSxRQUFRO0FBQzFDLFVBQU0sUUFBUSxPQUFPLGVBQWUsVUFBVTtBQUM5QyxVQUFNLGFBQWEsT0FBTyxlQUFlLFlBQVk7QUFDckQsVUFBTSxXQUFXLE9BQU8sZUFBZSxXQUFXO0FBQ2xELFVBQU0sVUFBVSxPQUFPLGVBQWUsVUFBVTtBQUNoRCxVQUFNLFlBQVksT0FBTyxlQUFlLFlBQVk7QUFDcEQsVUFBTSxlQUFlLE9BQU8sZUFBZSxlQUFlO0FBQzFELFVBQU0sVUFBVSxPQUFPLGVBQWUsV0FBVztBQUNqRCxVQUFNLFlBQVksT0FBTyxlQUFlLFdBQVc7QUFDbkQsVUFBTSxXQUFXLE9BQU8sZUFBZSxVQUFVO0FBQ2pELFVBQU0sWUFBWSxPQUFPLGVBQWUsV0FBVztBQUduRCxXQUFPLGlCQUFvQyxVQUFVLEVBQUUsUUFBUSxhQUFXO0FBQ3hFLGNBQVEsaUJBQWlCLFNBQVMsTUFBTTtBQUN0QyxlQUFPLGlCQUFpQixVQUFVLEVBQUUsUUFBUSxPQUFLLEVBQUUsVUFBVSxPQUFPLFFBQVEsQ0FBQztBQUM3RSxnQkFBUSxVQUFVLElBQUksUUFBUTtBQUM5QixnQkFBUSxNQUFNLGFBQWEsUUFBUSxRQUFRLFNBQVM7QUFDcEQsZ0JBQVEsTUFBTSxjQUFjLFFBQVEsUUFBUSxTQUFTO0FBQ3JELHVCQUFlLFFBQVEsUUFBUTtBQUMvQixtQkFBVyxXQUFXO0FBQ3RCLGlCQUFTLGNBQWM7QUFDdkIsaUJBQVMsWUFBWTtBQUNyQixnQkFBUSxVQUFVLE9BQU8sU0FBUztBQUNsQyxrQkFBVSxVQUFVLE9BQU8sU0FBUztBQUNwQyxxQkFBYSxVQUFVLE9BQU8sU0FBUztBQUFBLE1BQ3pDLENBQUM7QUFBQSxJQUNILENBQUM7QUFHRCxhQUFTLGNBQWMsTUFBWTtBQUNqQyxZQUFNLFVBQVUsT0FBTyxjQUFpQyx1QkFBdUIsSUFBSSxJQUFJO0FBQ3ZGLFVBQUksV0FBVyxDQUFDLGNBQWM7QUFDNUIsZUFBTyxpQkFBaUIsVUFBVSxFQUFFLFFBQVEsT0FBSyxFQUFFLFVBQVUsT0FBTyxRQUFRLENBQUM7QUFDN0UsZ0JBQVEsVUFBVSxJQUFJLFFBQVE7QUFDOUIsUUFBQyxRQUF3QixNQUFNLGFBQWEsUUFBUSxRQUFRLFNBQVM7QUFDckUsUUFBQyxRQUF3QixNQUFNLGNBQWMsUUFBUSxRQUFRLFNBQVM7QUFDdEUsdUJBQWU7QUFDZixtQkFBVyxXQUFXO0FBQUEsTUFDeEI7QUFBQSxJQUNGO0FBR0EsUUFBSSxpQkFBaUIsU0FBUyxNQUFNO0FBQ2xDLGtCQUFZLENBQUM7QUFDYixZQUFNLFVBQVUsT0FBTyxRQUFRLFNBQVM7QUFDeEMsVUFBSSxXQUFXO0FBQ2Isc0JBQWM7QUFDZCxZQUFJLENBQUMsYUFBYyxlQUFjLGtCQUFrQixXQUFXLENBQUM7QUFBQSxNQUNqRTtBQUFBLElBQ0YsQ0FBQztBQUdELGFBQVMsaUJBQWlCLFNBQVMsQ0FBQyxNQUFNO0FBQ3hDLFVBQUksQ0FBQyxLQUFLLFNBQVMsRUFBRSxNQUFjLEtBQUssV0FBVztBQUNqRCxvQkFBWTtBQUNaLGNBQU0sVUFBVSxPQUFPLE1BQU07QUFBQSxNQUMvQjtBQUFBLElBQ0YsR0FBRyxJQUFJO0FBRVAsYUFBUyxnQkFBc0I7QUFDN0IsWUFBTSxPQUFPLElBQUksc0JBQXNCO0FBQ3ZDLFlBQU0sTUFBTSxTQUFTLEdBQUcsT0FBTyxjQUFjLEtBQUssTUFBTSxDQUFDO0FBQ3pELFlBQU0sTUFBTSxPQUFPLEdBQUcsS0FBSyxJQUFJLEtBQUssTUFBTSxPQUFPLGFBQWEsR0FBRyxDQUFDO0FBQUEsSUFDcEU7QUFFQSxRQUFJLGVBQWU7QUFJbkIsYUFBUyxlQUFlLE9BQXdDO0FBQzlELFVBQUksT0FBTyxVQUFVLFlBQVksUUFBUSxHQUFHO0FBQzFDLGNBQU0sTUFBTSxLQUFLLE1BQU0sU0FBUyxJQUFJLFFBQVEsTUFBTSxLQUFLO0FBQ3ZELGdCQUFRLGNBQWMsR0FBRyxHQUFHO0FBQUEsTUFDOUIsT0FBTztBQUNMLGdCQUFRLGNBQWM7QUFBQSxNQUN4QjtBQUNBLG1CQUFhLFVBQVUsSUFBSSxTQUFTO0FBQUEsSUFDdEM7QUFJQSxtQkFBZSxXQUFXLFFBQVEsT0FBc0I7QUFDdEQsVUFBSSxDQUFDLGFBQWM7QUFFbkIsWUFBTSxPQUFPLFFBQVEsZUFBZ0IsWUFBNEIsVUFBVSxLQUFLO0FBQ2hGLFVBQUksQ0FBQyxNQUFNO0FBQ1Qsa0JBQVUsMEJBQTBCLE9BQU87QUFDM0M7QUFBQSxNQUNGO0FBQ0EsVUFBSSxDQUFDLE1BQU8sZ0JBQWU7QUFFM0IsVUFBSSxXQUFXO0FBQ2YsaUJBQVcsV0FBVztBQUN0QixlQUFTLFdBQVc7QUFDcEIsZ0JBQVUsUUFBUSx5QkFBb0IsaUJBQVk7QUFDbEQsZ0JBQVUsVUFBVSxPQUFPLFNBQVM7QUFDcEMsbUJBQWEsVUFBVSxPQUFPLFNBQVM7QUFFdkMsVUFBSTtBQUNGLGNBQU0sT0FBTyxNQUFNLGlCQUE4QztBQUFBLFVBQy9ELE1BQU07QUFBQSxVQUNOLFNBQVMsRUFBRSxNQUFNLE1BQU0sYUFBYTtBQUFBLFFBQ3RDLENBQUM7QUFFRCxZQUFJLFdBQVcsS0FBTSxPQUFNLElBQUksTUFBTSxPQUFPLEtBQUssS0FBSyxDQUFDO0FBRXZELHdCQUFnQixLQUFLLE9BQU87QUFDNUIsdUJBQWUsYUFBNEIsS0FBSyxPQUFPLFdBQVc7QUFDbEUsa0JBQVUsRUFBRTtBQUNaLHVCQUFlLEtBQUssT0FBTyxhQUFhO0FBQ3hDLGtCQUFVLFVBQVUsSUFBSSxTQUFTO0FBQUEsTUFDbkMsU0FBUyxLQUFLO0FBQ1osY0FBTSxNQUFNLGVBQWUsUUFBUSxJQUFJLFVBQVU7QUFDakQsWUFBSSxJQUFJLFdBQVcsZ0JBQWdCLEdBQUc7QUFDcEMsa0JBQVEsVUFBVSxJQUFJLFNBQVM7QUFDL0Isb0JBQVUsRUFBRTtBQUFBLFFBQ2QsT0FBTztBQUNMLG9CQUFVLEtBQUssT0FBTztBQUFBLFFBQ3hCO0FBQUEsTUFDRixVQUFFO0FBQ0EsWUFBSSxXQUFXO0FBQ2YsbUJBQVcsV0FBVyxpQkFBaUI7QUFDdkMsaUJBQVMsV0FBVztBQUFBLE1BQ3RCO0FBQUEsSUFDRjtBQUdBLGVBQVcsaUJBQWlCLFNBQVMsTUFBTTtBQUFFLFdBQUssV0FBVyxLQUFLO0FBQUEsSUFBRyxDQUFDO0FBR3RFLGFBQVMsaUJBQWlCLFNBQVMsTUFBTTtBQUFFLFdBQUssV0FBVyxJQUFJO0FBQUEsSUFBRyxDQUFDO0FBR25FLGNBQVUsaUJBQWlCLFNBQVMsWUFBWTtBQUM5QyxVQUFJLGVBQWU7QUFDakIseUJBQWlCLEVBQUUsTUFBTSxZQUFZLFNBQVMsRUFBRSxXQUFXLGVBQWUsUUFBUSxXQUFXLEVBQUUsQ0FBQztBQUFBLE1BQ2xHO0FBQ0EsZ0JBQVUsVUFBVSxPQUFPLFNBQVM7QUFDcEMsbUJBQWEsVUFBVSxPQUFPLFNBQVM7QUFDdkMsa0JBQVk7QUFDWixZQUFNLFVBQVUsT0FBTyxNQUFNO0FBQzdCLGdCQUFVLEVBQUU7QUFBQSxJQUNkLENBQUM7QUFHRCxjQUFVLGlCQUFpQixTQUFTLFlBQVk7QUFDOUMsVUFBSSxhQUFjLGdCQUFlLGFBQTRCLFlBQVk7QUFDekUsVUFBSSxlQUFlO0FBQ2pCLHlCQUFpQixFQUFFLE1BQU0sWUFBWSxTQUFTLEVBQUUsV0FBVyxlQUFlLFFBQVEsV0FBVyxFQUFFLENBQUM7QUFBQSxNQUNsRztBQUNBLGdCQUFVLFVBQVUsT0FBTyxTQUFTO0FBQ3BDLG1CQUFhLFVBQVUsT0FBTyxTQUFTO0FBQ3ZDLGdCQUFVLGFBQWEsU0FBUztBQUNoQyxpQkFBVyxNQUFNLFVBQVUsRUFBRSxHQUFHLEdBQUk7QUFBQSxJQUN0QyxDQUFDO0FBRUQsYUFBUyxVQUFVLEtBQWEsTUFBTSxJQUFVO0FBQzlDLGVBQVMsY0FBYztBQUN2QixlQUFTLFlBQVk7QUFBQSxJQUN2QjtBQUdBLFlBQVEsYUFBYSxNQUFNLE9BQU87QUFHbEMsb0JBQWdCLFNBQVMsV0FBVztBQUFBLEVBQ3RDO0FBSUEsV0FBUyxlQUFlLGFBQXNDO0FBRzVELFFBQUksS0FBcUI7QUFDekIsYUFBUyxJQUFJLEdBQUcsSUFBSSxJQUFJLEtBQUs7QUFDM0IsVUFBSSxDQUFDLEdBQUk7QUFDVCxZQUFNLE9BQU8sR0FBRyxjQUFjLGVBQWU7QUFDN0MsVUFBSSxLQUFNLFFBQU87QUFDakIsV0FBSyxHQUFHO0FBQUEsSUFDVjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBRUEsV0FBUyxlQUFlLElBQWlCLE1BQW9CO0FBQzNELE9BQUcsTUFBTTtBQUNULGFBQVMsWUFBWSxhQUFhLE9BQU8sTUFBUztBQUNsRCxhQUFTLFlBQVksVUFBVSxPQUFPLE1BQVM7QUFFL0MsVUFBTSxRQUFRLEtBQUssTUFBTSxJQUFJO0FBQzdCLGFBQVMsSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUs7QUFDckMsVUFBSSxNQUFNLENBQUMsRUFBRyxVQUFTLFlBQVksY0FBYyxPQUFPLE1BQU0sQ0FBQyxDQUFDO0FBQ2hFLFVBQUksSUFBSSxNQUFNLFNBQVMsRUFBRyxVQUFTLFlBQVksbUJBQW1CLE9BQU8sTUFBUztBQUFBLElBQ3BGO0FBQUEsRUFDRjtBQUVBLFdBQVMsaUJBQW9CLFNBQWlCLFVBQVUsR0FBZTtBQUNyRSxXQUFPLElBQUksUUFBUSxDQUFDLFNBQVMsV0FBVztBQUN0QyxZQUFNLFFBQVEsTUFBTTtBQUVsQixZQUFJLFlBQVksR0FBRztBQUNqQixxQkFBVyxNQUFNLGlCQUFvQixTQUFTLENBQUMsRUFBRSxLQUFLLE9BQU8sRUFBRSxNQUFNLE1BQU0sR0FBRyxHQUFHO0FBQUEsUUFDbkYsT0FBTztBQUNMLGlCQUFPLElBQUksTUFBTSwrREFBMEQsQ0FBQztBQUFBLFFBQzlFO0FBQUEsTUFDRjtBQUVBLFVBQUksQ0FBQyxRQUFRLFNBQVMsYUFBYTtBQUFFLGNBQU07QUFBRztBQUFBLE1BQVE7QUFDdEQsVUFBSTtBQUNGLGVBQU8sUUFBUSxZQUFZLFNBQVMsQ0FBQyxhQUFhO0FBQ2hELGNBQUksT0FBTyxTQUFTLFdBQVc7QUFDN0Isa0JBQU07QUFBQSxVQUNSLE9BQU87QUFDTCxvQkFBUSxRQUFRO0FBQUEsVUFDbEI7QUFBQSxRQUNGLENBQUM7QUFBQSxNQUNILFFBQVE7QUFDTixjQUFNO0FBQUEsTUFDUjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFJQSxNQUFNLE9BQU8sb0JBQUksUUFBaUI7QUFFbEMsV0FBUyxVQUFVLE1BQWdDO0FBQ2pELFNBQUssaUJBQTBCLGdCQUFnQixFQUFFLFFBQVEsQ0FBQyxTQUFTO0FBQ2pFLFVBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxHQUFHO0FBQ25CLGFBQUssSUFBSSxJQUFJO0FBQ2IsZUFBTyxJQUFJO0FBQUEsTUFDYjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFFQSxNQUFNLFdBQVcsSUFBSSxpQkFBaUIsTUFBTSxVQUFVLFFBQVEsQ0FBQztBQUUvRCxXQUFTLFFBQVEsU0FBUyxNQUFNLEVBQUUsV0FBVyxNQUFNLFNBQVMsS0FBSyxDQUFDO0FBR2xFLFlBQVUsUUFBUTtBQUdsQixXQUFTLGlCQUFpQixXQUFXLENBQUMsTUFBTTtBQUMxQyxVQUFNLFVBQVUsU0FBUyxjQUFjLElBQUksU0FBUyxHQUFHO0FBQ3ZELFFBQUksQ0FBQyxRQUFTO0FBQ2QsVUFBTSxRQUFRLE1BQU0sS0FBSyxRQUFRLFFBQVEsRUFBRSxPQUFPLE9BQUssRUFBRSxVQUFVO0FBRW5FLFNBQUssRUFBRSxXQUFXLEVBQUUsWUFBWSxFQUFFLFlBQVksRUFBRSxRQUFRLEtBQUs7QUFDM0QsUUFBRSxlQUFlO0FBRWpCLFlBQU0sTUFBTSxNQUFNLENBQUMsR0FBRyxZQUFZLGVBQWUsUUFBUTtBQUN6RCxXQUFLLE1BQU07QUFBQSxJQUNiO0FBRUEsU0FBSyxFQUFFLFdBQVcsRUFBRSxZQUFZLEVBQUUsWUFBWSxFQUFFLFFBQVEsS0FBSztBQUMzRCxRQUFFLGVBQWU7QUFFakIsWUFBTSxNQUFNLE1BQU0sQ0FBQyxHQUFHLFlBQVksZUFBZSxZQUFZO0FBQzdELFdBQUssTUFBTTtBQUFBLElBQ2I7QUFBQSxFQUNGLENBQUM7IiwKICAibmFtZXMiOiBbXQp9Cg==
