"use strict";(()=>{var _='[g_editable="true"], div[contenteditable="true"][aria-multiline="true"]',R='[data-tooltip^="Send"], [aria-label^="Send"]',F="data-wt-injected",z=[{key:"professional",label:"Professional",color:"#4F46E5"},{key:"casual",label:"Casual",color:"#06B6D4"},{key:"friendly",label:"Friendly",color:"#F59E0B"},{key:"direct",label:"Direct",color:"#DC2626"},{key:"diplomatic",label:"Diplomatic",color:"#7C3AED"},{key:"executive",label:"Executive",color:"#0F172A"}],j=`
  :host { display: inline-flex; align-items: center; margin-left: 8px; }

  #wt-btn {
    display: inline-flex; align-items: center; gap: 5px;
    height: 28px; padding: 0 12px; border-radius: 9999px; border: none;
    background: #4F46E5; color: #fff;
    font: 500 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer; white-space: nowrap;
    transition: background 0.15s, box-shadow 0.15s;
  }
  #wt-btn:hover { background: #3F37C9; box-shadow: 0 0 0 3px rgba(79,70,229,0.25); }
  #wt-btn:disabled { opacity: 0.6; cursor: default; box-shadow: none; }

  #wt-panel {
    position: fixed; z-index: 9999;
    background: #fff; border: 1px solid #E8EAED; border-radius: 10px;
    box-shadow: 0 12px 32px rgba(15,23,42,0.14);
    padding: 14px 16px; width: 260px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: none;
  }
  #wt-panel.open { display: block; }

  .wt-title {
    font-size: 12px; font-weight: 600; color: #374151; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase;
  }
  .wt-tones {
    display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 12px;
  }
  .wt-tone {
    padding: 4px 10px; border-radius: 9999px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151;
    cursor: pointer; transition: all 0.1s;
  }
  .wt-tone.active {
    color: #fff; border-color: transparent;
  }
  .wt-tone:hover:not(.active) { border-color: #9BA0FF; }

  #wt-rewrite {
    width: 100%; height: 32px; border-radius: 8px; border: none;
    background: #4F46E5; color: #fff;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer;
  }
  #wt-rewrite:disabled { opacity: 0.45; cursor: default; }

  #wt-status {
    margin-top: 8px; font-size: 11px; text-align: center; min-height: 14px;
  }
  #wt-status.error { color: #EF4444; }
  #wt-status.success { color: #10B981; }

  #wt-limit {
    display: none; margin-top: 10px; padding: 10px 12px; border-radius: 8px;
    background: #FFF8F1; border: 1px solid #FED7AA; text-align: center;
  }
  #wt-limit.visible { display: block; }
  #wt-limit p { font-size: 11px; color: #92400E; margin: 0 0 8px; line-height: 1.4; }
  #wt-limit a {
    display: inline-block; padding: 5px 14px; border-radius: 9999px;
    background: #F59E0B; color: #fff; font-size: 11px; font-weight: 600;
    text-decoration: none;
  }
  #wt-limit a:hover { background: #D97706; }

  #wt-actions {
    display: none; gap: 6px; margin-top: 8px;
  }
  #wt-actions.visible { display: flex; }
  .wt-action {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151;
    cursor: pointer;
  }
  .wt-action.accept { border-color: #10B981; color: #10B981; }
  .wt-action.reject { border-color: #EF4444; color: #EF4444; }
`,U=[{key:"reply",label:"Reply"},{key:"email",label:"Email"},{key:"customer_update",label:"Customer Update"},{key:"jira_ticket",label:"Jira Ticket"},{key:"technical_report",label:"Tech Report"}],V=`
  :host { display: inline-flex; align-items: center; margin-left: 4px; }

  #wt-mic-btn {
    display: inline-flex; align-items: center; justify-content: center;
    width: 28px; height: 28px; border-radius: 9999px; border: none;
    background: transparent; color: #5F6368; cursor: pointer;
    transition: background 0.15s, color 0.15s;
    font-size: 15px; line-height: 1;
  }
  #wt-mic-btn:hover { background: rgba(0,0,0,0.07); }
  #wt-mic-btn.recording {
    background: #FEE2E2; color: #DC2626;
    animation: wt-pulse 1.2s ease-in-out infinite;
  }
  @keyframes wt-pulse {
    0%, 100% { box-shadow: 0 0 0 0 rgba(220,38,38,0.4); }
    50%       { box-shadow: 0 0 0 5px rgba(220,38,38,0); }
  }
  #wt-mic-btn:disabled { opacity: 0.5; cursor: default; }

  #wt-voice-panel {
    position: fixed; z-index: 9999;
    background: #fff; border: 1px solid #E8EAED; border-radius: 10px;
    box-shadow: 0 12px 32px rgba(15,23,42,0.14);
    padding: 14px 16px; width: 280px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: none;
  }
  #wt-voice-panel.open { display: block; }

  .wt-vt { font-size: 12px; font-weight: 600; color: #374151; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase; }

  #wt-record-btn {
    width: 100%; height: 34px; border-radius: 8px; border: none;
    background: #DC2626; color: #fff; cursor: pointer;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    margin-bottom: 10px;
  }
  #wt-record-btn.recording { background: #7F1D1D; }
  #wt-record-btn:disabled { opacity: 0.5; cursor: default; }

  .wt-otype-label { font-size: 11px; color: #6B7280; margin-bottom: 4px; }
  .wt-otypes { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 10px; }
  .wt-otype {
    padding: 3px 9px; border-radius: 9999px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 11px; color: #374151; cursor: pointer;
    transition: all 0.1s;
  }
  .wt-otype.active { background: #4F46E5; color: #fff; border-color: #4F46E5; }

  #wt-voice-status { font-size: 11px; text-align: center; min-height: 14px; color: #6B7280; }
  #wt-voice-status.error { color: #EF4444; }

  #wt-voice-actions { display: none; gap: 6px; margin-top: 8px; }
  #wt-voice-actions.visible { display: flex; }
  .wt-va {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151; cursor: pointer;
  }
  .wt-va.accept { border-color: #10B981; color: #10B981; }
  .wt-va.reject { border-color: #EF4444; color: #EF4444; }
`;function $(e,n){let r=document.createElement("span"),t=r.attachShadow({mode:"open"});t.innerHTML=`
    <style>${V}</style>
    <button id="wt-mic-btn" title="Voice Twin \u2014 speak your email (Cmd+Shift+V)">\u{1F399}</button>
    <div id="wt-voice-panel">
      <p class="wt-vt">Voice Twin</p>
      <div class="wt-otype-label">Output type</div>
      <div class="wt-otypes">
        ${U.map((i,a)=>`<button class="wt-otype${a===0?" active":""}" data-type="${i.key}">${i.label}</button>`).join("")}
      </div>
      <button id="wt-record-btn">\u{1F399} Start recording</button>
      <div id="wt-voice-status"></div>
      <div id="wt-voice-actions">
        <button class="wt-va accept" id="wt-va-keep">\u2713 Keep it</button>
        <button class="wt-va reject" id="wt-va-undo">\u2717 Undo</button>
      </div>
    </div>
  `;let s=t.getElementById("wt-mic-btn"),u=t.getElementById("wt-voice-panel"),c=t.getElementById("wt-record-btn"),m=t.getElementById("wt-voice-status"),b=t.getElementById("wt-voice-actions"),g=t.getElementById("wt-va-keep"),v=t.getElementById("wt-va-undo"),d=!1,T="reply",p=null,y=!1,L=[],E=null,x="";t.querySelectorAll(".wt-otype").forEach(i=>{i.addEventListener("click",()=>{t.querySelectorAll(".wt-otype").forEach(a=>a.classList.remove("active")),i.classList.add("active"),T=i.dataset.type})}),s.addEventListener("click",()=>{d=!d,u.classList.toggle("open",d),d&&f()}),document.addEventListener("click",i=>{!r.contains(i.target)&&d&&(d=!1,u.classList.remove("open"))},!0);function f(){let i=s.getBoundingClientRect();u.style.bottom=`${window.innerHeight-i.top+4}px`,u.style.left=`${Math.min(i.left,window.innerWidth-296)}px`}c.addEventListener("click",async()=>{y?l():await o()});async function o(){try{let i=await navigator.mediaDevices.getUserMedia({audio:!0});L=[],p=new MediaRecorder(i,{mimeType:"audio/webm"}),p.ondataavailable=a=>{a.data.size>0&&L.push(a.data)},p.onstop=async()=>{i.getTracks().forEach(h=>h.stop());let a=new Blob(L,{type:"audio/webm"});await B(a)},p.start(),y=!0,s.classList.add("recording"),c.classList.add("recording"),c.textContent="\u23F9 Stop recording",w("Recording\u2026"),b.classList.remove("visible"),setTimeout(()=>{y&&l()},6e4)}catch{w("Microphone access denied.","error")}}function l(){p&&y&&(p.stop(),y=!1,s.classList.remove("recording"),c.classList.remove("recording"),c.textContent="\u{1F399} Start recording",c.disabled=!0,w("Drafting\u2026"))}async function B(i){try{let a=await i.arrayBuffer(),h=new Uint8Array(a),C="";for(let D=0;D<h.length;D++)C+=String.fromCharCode(h[D]);let O=btoa(C);x=n.innerText.trim();let M=await k({type:"VOICE_DRAFT",payload:{audioData:O,mimeType:"audio/webm",outputType:T}});if("error"in M)throw new Error(String(M.error));E=M.result.id,S(n,M.result.draft),w("Done \u2713"),b.classList.add("visible")}catch(a){let h=a instanceof Error?a.message:"Failed";w(h,"error")}finally{c.disabled=!1}}g.addEventListener("click",()=>{E&&k({type:"VOICE_FEEDBACK",payload:{sessionId:E,accepted:!0,editedDraft:null}}),b.classList.remove("visible"),d=!1,u.classList.remove("open"),w("")}),v.addEventListener("click",()=>{x&&S(n,x),E&&k({type:"VOICE_FEEDBACK",payload:{sessionId:E,accepted:!1,editedDraft:null}}),b.classList.remove("visible"),w("Reverted.","success"),setTimeout(()=>w(""),2e3)});function w(i,a=""){m.textContent=i,m.className=a}let H=Array.from(e.children).find(i=>i.shadowRoot);if(H)e.insertBefore(r,H.nextSibling);else{let i=e.querySelector(R);i?e.insertBefore(r,i):e.appendChild(r)}}function P(e){let n=K(e);if(!n)return;let r=n.parentElement;if(!r||r.hasAttribute(F))return;r.setAttribute(F,"1");let t=document.createElement("span"),s=t.attachShadow({mode:"open"}),u=null,c=null,m=!1;s.innerHTML=`
    <style>${j}</style>
    <button id="wt-btn" title="Humanize with Writing Twin AI (Cmd+Shift+H)">\u2728 Humanize</button>
    <div id="wt-panel">
      <p class="wt-title">Rewrite tone</p>
      <div class="wt-tones">
        ${z.map(o=>`<button class="wt-tone" data-tone="${o.key}" data-color="${o.color}">${o.label}</button>`).join("")}
      </div>
      <button id="wt-rewrite" disabled>Rewrite \u2192</button>
      <div id="wt-status"></div>
      <div id="wt-limit">
        <p>You've used all your free rewrites this month.</p>
        <a href="https://writingtwinai.com/pricing" target="_blank" rel="noopener">Upgrade to Pro \u2014 $5/mo</a>
      </div>
      <div id="wt-actions">
        <button class="wt-action accept" id="wt-accept">\u2713 Keep it</button>
        <button class="wt-action reject" id="wt-reject">\u2717 Undo</button>
      </div>
    </div>
  `;let b=s.getElementById("wt-btn"),g=s.getElementById("wt-panel"),v=s.getElementById("wt-rewrite"),d=s.getElementById("wt-status"),T=s.getElementById("wt-limit"),p=s.getElementById("wt-actions"),y=s.getElementById("wt-accept"),L=s.getElementById("wt-reject");s.querySelectorAll(".wt-tone").forEach(o=>{o.addEventListener("click",()=>{s.querySelectorAll(".wt-tone").forEach(l=>l.classList.remove("active")),o.classList.add("active"),o.style.background=o.dataset.color??"#4F46E5",o.style.borderColor=o.dataset.color??"#4F46E5",u=o.dataset.tone,v.disabled=!1,d.textContent="",d.className="",T.classList.remove("visible"),p.classList.remove("visible")})}),b.addEventListener("click",()=>{m=!m,g.classList.toggle("open",m),m&&E()}),document.addEventListener("click",o=>{!t.contains(o.target)&&m&&(m=!1,g.classList.remove("open"))},!0);function E(){let o=b.getBoundingClientRect();g.style.bottom=`${window.innerHeight-o.top+4}px`,g.style.left=`${Math.min(o.left,window.innerWidth-276)}px`}let x="";v.addEventListener("click",async()=>{if(!u)return;let o=e.innerText.trim();if(!o){f("Write something first.","error");return}x=o,b.disabled=!0,v.disabled=!0,f("Rewriting\u2026"),p.classList.remove("visible");try{let l=await k({type:"HUMANIZE",payload:{text:o,tone:u}});if("error"in l)throw new Error(String(l.error));c=l.result.id,S(e,l.result.output_text),f("Done \u2713","success"),p.classList.add("visible")}catch(l){let B=l instanceof Error?l.message:"Failed";B.startsWith("LIMIT_REACHED:")?(T.classList.add("visible"),f("")):f(B,"error")}finally{b.disabled=!1,v.disabled=u===null}}),y.addEventListener("click",async()=>{c&&k({type:"FEEDBACK",payload:{rewriteId:c,action:"accepted"}}),p.classList.remove("visible"),m=!1,g.classList.remove("open"),f("")}),L.addEventListener("click",async()=>{x&&S(e,x),c&&k({type:"FEEDBACK",payload:{rewriteId:c,action:"rejected"}}),p.classList.remove("visible"),f("Reverted.","success"),setTimeout(()=>f(""),2e3)});function f(o,l=""){d.textContent=o,d.className=l}r.insertBefore(t,n),$(r,e)}function K(e){let n=e;for(let r=0;r<25&&n;r++){let t=n.querySelector(R);if(t)return t;n=n.parentElement}return null}function S(e,n){e.focus(),document.execCommand("selectAll",!1,void 0),document.execCommand("delete",!1,void 0);let r=n.split(`
`);for(let t=0;t<r.length;t++)r[t]&&document.execCommand("insertText",!1,r[t]),t<r.length-1&&document.execCommand("insertParagraph",!1,void 0)}function k(e){return new Promise(n=>{chrome.runtime.sendMessage(e,n)})}var I=new WeakSet;function A(e){e.querySelectorAll(_).forEach(n=>{I.has(n)||(I.add(n),P(n))})}var N=new MutationObserver(()=>A(document));N.observe(document.body,{childList:!0,subtree:!0});A(document);document.addEventListener("keydown",e=>{let n=document.querySelector(`[${F}]`);if(!n)return;let r=Array.from(n.children).filter(t=>t.shadowRoot);(e.metaKey||e.ctrlKey)&&e.shiftKey&&e.key==="H"&&(e.preventDefault(),r[0]?.shadowRoot?.getElementById("wt-btn")?.click()),(e.metaKey||e.ctrlKey)&&e.shiftKey&&e.key==="V"&&(e.preventDefault(),r[1]?.shadowRoot?.getElementById("wt-mic-btn")?.click())});})();
