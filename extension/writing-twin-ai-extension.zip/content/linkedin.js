"use strict";
(() => {
  // src/content/linkedin.ts
  var COMPOSE_BODY_SEL = 'div.ql-editor[contenteditable="true"]';
  var HOST_ATTR = "data-wt-li-injected";
  var FIXED_CONTEXT_OVERRIDE = "social";
  var TONES = [
    { key: "professional", label: "Professional", color: "#0A66C2" },
    { key: "casual", label: "Casual", color: "#06B6D4" },
    { key: "friendly", label: "Friendly", color: "#F59E0B" },
    { key: "direct", label: "Direct", color: "#DC2626" },
    { key: "executive", label: "Executive", color: "#0F172A" }
  ];
  var VOICE_OUTPUT_TYPES = [
    { key: "linkedin_comment", label: "Comment" },
    { key: "email", label: "Message" },
    { key: "reply", label: "Reply" }
  ];
  var BUTTON_CSS = `
  :host { display: inline-flex; align-items: center; }

  #wt-btn {
    display: inline-flex; align-items: center; gap: 5px;
    height: 28px; padding: 0 12px; border-radius: 9999px; border: none;
    background: #0A66C2; color: #fff;
    font: 500 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer; white-space: nowrap;
    transition: background 0.15s, box-shadow 0.15s;
  }
  #wt-btn:hover { background: #084fa0; box-shadow: 0 0 0 3px rgba(10,102,194,0.25); }
  #wt-btn:disabled { opacity: 0.6; cursor: default; box-shadow: none; }

  #wt-panel {
    position: fixed; z-index: 99999;
    background: #fff; border: 1px solid #E2E8F0; border-radius: 10px;
    box-shadow: 0 12px 32px rgba(0,0,0,0.14);
    padding: 14px 16px; width: 260px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: none;
  }
  #wt-panel.open { display: block; }

  .wt-title { font-size: 12px; font-weight: 600; color: #374151; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase; }
  .wt-tones { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 12px; }
  .wt-tone {
    padding: 4px 10px; border-radius: 9999px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151;
    cursor: pointer; transition: all 0.1s;
  }
  .wt-tone.active { color: #fff; border-color: transparent; }
  .wt-tone:hover:not(.active) { border-color: #93C5FD; }

  #wt-rewrite {
    width: 100%; height: 32px; border-radius: 8px; border: none;
    background: #0A66C2; color: #fff;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer;
  }
  #wt-rewrite:disabled { opacity: 0.45; cursor: default; }

  #wt-status { margin-top: 8px; font-size: 11px; text-align: center; min-height: 14px; }
  #wt-status.error { color: #EF4444; }
  #wt-status.success { color: #10B981; }

  #wt-actions { display: none; gap: 6px; margin-top: 8px; }
  #wt-actions.visible { display: flex; }
  .wt-action {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151;
    cursor: pointer;
  }
  .wt-action.accept { border-color: #10B981; color: #10B981; }
  .wt-action.reject { border-color: #EF4444; color: #EF4444; }

  #wt-limit { display: none; margin-top: 10px; padding: 10px 12px; border-radius: 8px;
    background: #FFF8F1; border: 1px solid #FED7AA; text-align: center; }
  #wt-limit.visible { display: block; }
  #wt-limit p { font-size: 11px; color: #92400E; margin: 0 0 8px; line-height: 1.4; }
  #wt-limit a {
    display: inline-block; padding: 5px 14px; border-radius: 9999px;
    background: #F59E0B; color: #fff; font-size: 11px; font-weight: 600;
    text-decoration: none;
  }
`;
  var MIC_CSS = `
  :host { display: inline-flex; align-items: center; margin-left: 4px; }

  #wt-mic-btn {
    display: inline-flex; align-items: center; justify-content: center;
    width: 28px; height: 28px; border-radius: 9999px; border: none;
    background: transparent; color: #666; cursor: pointer;
    transition: background 0.15s, color 0.15s; font-size: 15px; line-height: 1;
  }
  #wt-mic-btn:hover { background: rgba(0,0,0,0.07); }
  #wt-mic-btn.recording { background: #FEE2E2; color: #DC2626;
    animation: wt-pulse 1.2s ease-in-out infinite; }
  @keyframes wt-pulse {
    0%, 100% { box-shadow: 0 0 0 0 rgba(220,38,38,0.4); }
    50%       { box-shadow: 0 0 0 5px rgba(220,38,38,0); }
  }
  #wt-mic-btn:disabled { opacity: 0.5; cursor: default; }

  #wt-voice-panel {
    position: fixed; z-index: 99999;
    background: #fff; border: 1px solid #E2E8F0; border-radius: 10px;
    box-shadow: 0 12px 32px rgba(0,0,0,0.14);
    padding: 14px 16px; width: 280px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: none;
  }
  #wt-voice-panel.open { display: block; }

  .wt-vt { font-size: 12px; font-weight: 600; color: #374151; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase; }
  #wt-record-btn {
    width: 100%; height: 34px; border-radius: 8px; border: none;
    background: #DC2626; color: #fff; cursor: pointer;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    margin-bottom: 10px;
  }
  #wt-record-btn.recording { background: #7F1D1D; }
  #wt-record-btn:disabled { opacity: 0.5; cursor: default; }
  .wt-otype-label { font-size: 11px; color: #6B7280; margin-bottom: 4px; }
  .wt-otypes { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 10px; }
  .wt-otype {
    padding: 3px 9px; border-radius: 9999px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 11px; color: #374151; cursor: pointer;
    transition: all 0.1s;
  }
  .wt-otype.active { background: #0A66C2; color: #fff; border-color: #0A66C2; }
  #wt-voice-status { font-size: 11px; text-align: center; min-height: 14px; color: #6B7280; }
  #wt-voice-status.error { color: #EF4444; }
  #wt-voice-actions { display: none; gap: 6px; margin-top: 8px; }
  #wt-voice-actions.visible { display: flex; }
  .wt-va {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151; cursor: pointer;
  }
  .wt-va.accept { border-color: #10B981; color: #10B981; }
  .wt-va.reject { border-color: #EF4444; color: #EF4444; }
`;
  var openPanel = null;
  document.addEventListener("click", (e) => {
    if (openPanel && !openPanel.host.contains(e.target)) {
      openPanel.close();
      openPanel = null;
    }
  }, true);
  function openPanelFor(host, close) {
    if (openPanel && openPanel.host !== host) openPanel.close();
    openPanel = { host, close };
  }
  function clearOpenPanel(host) {
    if (openPanel?.host === host) openPanel = null;
  }
  function sendToBackground(message) {
    return new Promise((resolve) => chrome.runtime.sendMessage(message, resolve));
  }
  function setComposeText(el, text) {
    el.focus();
    document.execCommand("selectAll", false, void 0);
    document.execCommand("delete", false, void 0);
    const lines = text.split("\n");
    for (let i = 0; i < lines.length; i++) {
      if (lines[i]) document.execCommand("insertText", false, lines[i]);
      if (i < lines.length - 1) document.execCommand("insertParagraph", false, void 0);
    }
  }
  function getComposeText(el) {
    return el.innerText.trim();
  }
  function injectMicButton(container, composeBody) {
    const micHost = document.createElement("span");
    micHost.style.cssText = "display:inline-flex;align-items:center;margin-left:4px;";
    const shadow = micHost.attachShadow({ mode: "open" });
    shadow.innerHTML = `
    <style>${MIC_CSS}</style>
    <button id="wt-mic-btn" title="Voice Twin">\u{1F399}</button>
    <div id="wt-voice-panel">
      <p class="wt-vt">Voice Twin</p>
      <div class="wt-otype-label">Output type</div>
      <div class="wt-otypes">
        ${VOICE_OUTPUT_TYPES.map(
      (o, i) => `<button class="wt-otype${i === 0 ? " active" : ""}" data-type="${o.key}">${o.label}</button>`
    ).join("")}
      </div>
      <button id="wt-record-btn">\u{1F399} Start recording</button>
      <div id="wt-voice-status"></div>
      <div id="wt-voice-actions">
        <button class="wt-va accept" id="wt-va-keep">\u2713 Keep it</button>
        <button class="wt-va reject" id="wt-va-undo">\u2717 Undo</button>
      </div>
    </div>
  `;
    const micBtn = shadow.getElementById("wt-mic-btn");
    const panel = shadow.getElementById("wt-voice-panel");
    const recordBtn = shadow.getElementById("wt-record-btn");
    const statusEl = shadow.getElementById("wt-voice-status");
    const actionsEl = shadow.getElementById("wt-voice-actions");
    const keepBtn = shadow.getElementById("wt-va-keep");
    const undoBtn = shadow.getElementById("wt-va-undo");
    let panelOpen = false;
    let selectedType = VOICE_OUTPUT_TYPES[0].key;
    let recorder = null;
    let recording = false;
    let chunks = [];
    let lastSessionId = null;
    let originalText = "";
    shadow.querySelectorAll(".wt-otype").forEach((btn) => {
      btn.addEventListener("click", () => {
        shadow.querySelectorAll(".wt-otype").forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        selectedType = btn.dataset.type;
      });
    });
    micBtn.addEventListener("click", () => {
      if (panelOpen) {
        panelOpen = false;
        panel.classList.remove("open");
        clearOpenPanel(micHost);
      } else {
        panelOpen = true;
        panel.classList.add("open");
        positionPanel();
        openPanelFor(micHost, () => {
          panelOpen = false;
          panel.classList.remove("open");
        });
      }
    });
    function positionPanel() {
      const rect = micBtn.getBoundingClientRect();
      panel.style.bottom = `${window.innerHeight - rect.top + 4}px`;
      panel.style.left = `${Math.min(rect.left, window.innerWidth - 296)}px`;
    }
    recordBtn.addEventListener("click", async () => {
      if (!recording) await startRecording();
      else stopRecording();
    });
    async function startRecording() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        chunks = [];
        recorder = new MediaRecorder(stream, { mimeType: "audio/webm" });
        recorder.ondataavailable = (e) => {
          if (e.data.size > 0) chunks.push(e.data);
        };
        recorder.onstop = async () => {
          stream.getTracks().forEach((t) => t.stop());
          await submitVoice(new Blob(chunks, { type: "audio/webm" }));
        };
        recorder.start();
        recording = true;
        micBtn.classList.add("recording");
        recordBtn.classList.add("recording");
        recordBtn.textContent = "\u23F9 Stop recording";
        setVStatus("Recording\u2026");
        actionsEl.classList.remove("visible");
        setTimeout(() => {
          if (recording) stopRecording();
        }, 6e4);
      } catch {
        setVStatus("Microphone access denied.", "error");
      }
    }
    function stopRecording() {
      if (recorder && recording) {
        recorder.stop();
        recording = false;
        micBtn.classList.remove("recording");
        recordBtn.classList.remove("recording");
        recordBtn.textContent = "\u{1F399} Start recording";
        recordBtn.disabled = true;
        setVStatus("Drafting\u2026");
      }
    }
    async function submitVoice(blob) {
      try {
        const buf = await blob.arrayBuffer();
        const audioData = btoa(Array.from(new Uint8Array(buf), (b) => String.fromCharCode(b)).join(""));
        originalText = getComposeText(composeBody);
        const resp = await sendToBackground({
          type: "VOICE_DRAFT",
          payload: { audioData, mimeType: "audio/webm", outputType: selectedType }
        });
        if ("error" in resp) throw new Error(String(resp.error));
        lastSessionId = resp.result.id;
        setComposeText(composeBody, resp.result.draft);
        setVStatus("Done \u2713");
        actionsEl.classList.add("visible");
      } catch (err) {
        setVStatus(err instanceof Error ? err.message : "Failed", "error");
      } finally {
        recordBtn.disabled = false;
      }
    }
    keepBtn.addEventListener("click", () => {
      if (lastSessionId) sendToBackground({ type: "VOICE_FEEDBACK", payload: { sessionId: lastSessionId, accepted: true, editedDraft: null } });
      actionsEl.classList.remove("visible");
      panelOpen = false;
      panel.classList.remove("open");
      clearOpenPanel(micHost);
      setVStatus("");
    });
    undoBtn.addEventListener("click", () => {
      if (originalText) setComposeText(composeBody, originalText);
      if (lastSessionId) sendToBackground({ type: "VOICE_FEEDBACK", payload: { sessionId: lastSessionId, accepted: false, editedDraft: null } });
      actionsEl.classList.remove("visible");
      setVStatus("Reverted.", "success");
      setTimeout(() => setVStatus(""), 2e3);
    });
    function setVStatus(msg, cls = "") {
      statusEl.textContent = msg;
      statusEl.className = cls;
    }
    container.appendChild(micHost);
  }
  function inject(composeBody) {
    if (composeBody.hasAttribute(HOST_ATTR)) return;
    composeBody.setAttribute(HOST_ATTR, "1");
    const wrapper = document.createElement("div");
    wrapper.style.cssText = "display:flex;align-items:center;gap:4px;margin-top:8px;padding:0 2px;";
    const insertionPoint = composeBody.closest(".ql-container, .comments-comment-texteditor, .editor-content") ?? composeBody.parentElement;
    insertionPoint?.insertAdjacentElement("afterend", wrapper);
    if (!wrapper.parentElement) {
      composeBody.parentElement?.appendChild(wrapper);
    }
    const host = document.createElement("span");
    const shadow = host.attachShadow({ mode: "open" });
    let selectedTone = null;
    let lastRewriteId = null;
    let panelOpen = false;
    shadow.innerHTML = `
    <style>${BUTTON_CSS}</style>
    <button id="wt-btn" title="Humanize with Writing Twin AI">\u2728 Humanize</button>
    <div id="wt-panel">
      <p class="wt-title">Rewrite tone</p>
      <div class="wt-tones">
        ${TONES.map((t) => `<button class="wt-tone" data-tone="${t.key}" data-color="${t.color}">${t.label}</button>`).join("")}
      </div>
      <button id="wt-rewrite" disabled>Rewrite \u2192</button>
      <div id="wt-status"></div>
      <div id="wt-limit">
        <p>You've used all your free rewrites this month.</p>
        <a href="https://writingtwinai.com/pricing" target="_blank" rel="noopener">Upgrade to Pro \u2014 $5/mo</a>
      </div>
      <div id="wt-actions">
        <button class="wt-action accept" id="wt-accept">\u2713 Keep it</button>
        <button class="wt-action reject" id="wt-reject">\u2717 Undo</button>
      </div>
    </div>
  `;
    const btn = shadow.getElementById("wt-btn");
    const panel = shadow.getElementById("wt-panel");
    const rewriteBtn = shadow.getElementById("wt-rewrite");
    const statusEl = shadow.getElementById("wt-status");
    const limitEl = shadow.getElementById("wt-limit");
    const actionsEl = shadow.getElementById("wt-actions");
    const acceptBtn = shadow.getElementById("wt-accept");
    const rejectBtn = shadow.getElementById("wt-reject");
    shadow.querySelectorAll(".wt-tone").forEach((tb) => {
      tb.addEventListener("click", () => {
        shadow.querySelectorAll(".wt-tone").forEach((b) => b.classList.remove("active"));
        tb.classList.add("active");
        tb.style.background = tb.dataset.color ?? "#0A66C2";
        tb.style.borderColor = tb.dataset.color ?? "#0A66C2";
        selectedTone = tb.dataset.tone;
        rewriteBtn.disabled = false;
        statusEl.textContent = "";
        statusEl.className = "";
        limitEl.classList.remove("visible");
        actionsEl.classList.remove("visible");
      });
    });
    btn.addEventListener("click", () => {
      if (panelOpen) {
        panelOpen = false;
        panel.classList.remove("open");
        clearOpenPanel(host);
      } else {
        panelOpen = true;
        panel.classList.add("open");
        positionPanel();
        openPanelFor(host, () => {
          panelOpen = false;
          panel.classList.remove("open");
        });
      }
    });
    function positionPanel() {
      const rect = btn.getBoundingClientRect();
      panel.style.bottom = `${window.innerHeight - rect.top + 4}px`;
      panel.style.left = `${Math.min(rect.left, window.innerWidth - 276)}px`;
    }
    let originalText = "";
    rewriteBtn.addEventListener("click", async () => {
      if (!selectedTone) return;
      const text = composeBody.innerText.trim();
      if (!text) {
        setStatus("Write something first.", "error");
        return;
      }
      originalText = text;
      btn.disabled = true;
      rewriteBtn.disabled = true;
      setStatus("Rewriting\u2026");
      actionsEl.classList.remove("visible");
      try {
        const resp = await sendToBackground({
          type: "HUMANIZE",
          payload: {
            text,
            tone: selectedTone,
            ctx: { platform: "linkedin", context_twin_override: FIXED_CONTEXT_OVERRIDE }
          }
        });
        if ("error" in resp) throw new Error(String(resp.error));
        lastRewriteId = resp.result.id;
        setComposeText(composeBody, resp.result.output_text);
        setStatus("Done \u2713", "success");
        actionsEl.classList.add("visible");
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Failed";
        if (msg.startsWith("LIMIT_REACHED:")) {
          limitEl.classList.add("visible");
          setStatus("");
        } else {
          setStatus(msg, "error");
        }
      } finally {
        btn.disabled = false;
        rewriteBtn.disabled = selectedTone === null;
      }
    });
    acceptBtn.addEventListener("click", () => {
      if (lastRewriteId) sendToBackground({ type: "FEEDBACK", payload: { rewriteId: lastRewriteId, action: "accepted" } });
      actionsEl.classList.remove("visible");
      panelOpen = false;
      panel.classList.remove("open");
      clearOpenPanel(host);
      setStatus("");
    });
    rejectBtn.addEventListener("click", () => {
      if (originalText) setComposeText(composeBody, originalText);
      if (lastRewriteId) sendToBackground({ type: "FEEDBACK", payload: { rewriteId: lastRewriteId, action: "rejected" } });
      actionsEl.classList.remove("visible");
      setStatus("Reverted.", "success");
      setTimeout(() => setStatus(""), 2e3);
    });
    function setStatus(msg, cls = "") {
      statusEl.textContent = msg;
      statusEl.className = cls;
    }
    wrapper.appendChild(host);
    injectMicButton(wrapper, composeBody);
  }
  var seen = /* @__PURE__ */ new WeakSet();
  function tryInject(root) {
    root.querySelectorAll(COMPOSE_BODY_SEL).forEach((body) => {
      if (!seen.has(body)) {
        seen.add(body);
        inject(body);
      }
    });
  }
  var observer = new MutationObserver(() => {
    requestIdleCallback(() => tryInject(document), { timeout: 500 });
  });
  observer.observe(document.body, { childList: true, subtree: true });
  tryInject(document);
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vc3JjL2NvbnRlbnQvbGlua2VkaW4udHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCB0eXBlIHsgVG9uZSwgUmV3cml0ZVJlc3BvbnNlLCBWb2ljZU91dHB1dFR5cGUsIFZvaWNlRHJhZnRSZXNwb25zZSB9IGZyb20gJy4uL2xpYi9hcGknO1xuXG4vLyBMaW5rZWRJbiB1c2VzIFF1aWxsIGVkaXRvciB0aHJvdWdob3V0IFx1MjAxNCBzYW1lIHNlbGVjdG9yIGZvciBwb3N0IGNvbXBvc2UgKyBjb21tZW50IGJveGVzXG5jb25zdCBDT01QT1NFX0JPRFlfU0VMID0gJ2Rpdi5xbC1lZGl0b3JbY29udGVudGVkaXRhYmxlPVwidHJ1ZVwiXSc7XG5jb25zdCBIT1NUX0FUVFIgPSAnZGF0YS13dC1saS1pbmplY3RlZCc7XG5cbi8vIExpbmtlZEluIGlzIFNvY2lhbCBjb250ZXh0IGJ5IGRlZmF1bHRcbmNvbnN0IEZJWEVEX0NPTlRFWFRfT1ZFUlJJREUgPSAnc29jaWFsJztcblxuY29uc3QgVE9ORVM6IHsga2V5OiBUb25lOyBsYWJlbDogc3RyaW5nOyBjb2xvcjogc3RyaW5nIH1bXSA9IFtcbiAgeyBrZXk6ICdwcm9mZXNzaW9uYWwnLCBsYWJlbDogJ1Byb2Zlc3Npb25hbCcsIGNvbG9yOiAnIzBBNjZDMicgfSxcbiAgeyBrZXk6ICdjYXN1YWwnLCAgICAgICBsYWJlbDogJ0Nhc3VhbCcsICAgICAgIGNvbG9yOiAnIzA2QjZENCcgfSxcbiAgeyBrZXk6ICdmcmllbmRseScsICAgICBsYWJlbDogJ0ZyaWVuZGx5JywgICAgIGNvbG9yOiAnI0Y1OUUwQicgfSxcbiAgeyBrZXk6ICdkaXJlY3QnLCAgICAgICBsYWJlbDogJ0RpcmVjdCcsICAgICAgIGNvbG9yOiAnI0RDMjYyNicgfSxcbiAgeyBrZXk6ICdleGVjdXRpdmUnLCAgICBsYWJlbDogJ0V4ZWN1dGl2ZScsICAgIGNvbG9yOiAnIzBGMTcyQScgfSxcbl07XG5cbmNvbnN0IFZPSUNFX09VVFBVVF9UWVBFUzogeyBrZXk6IFZvaWNlT3V0cHV0VHlwZTsgbGFiZWw6IHN0cmluZyB9W10gPSBbXG4gIHsga2V5OiAnbGlua2VkaW5fY29tbWVudCcsIGxhYmVsOiAnQ29tbWVudCcgfSxcbiAgeyBrZXk6ICdlbWFpbCcsICAgICAgICAgICAgbGFiZWw6ICdNZXNzYWdlJyB9LFxuICB7IGtleTogJ3JlcGx5JywgICAgICAgICAgICBsYWJlbDogJ1JlcGx5JyB9LFxuXTtcblxuLy8gXHUyNTAwXHUyNTAwIFNoYWRvdyBET00gc3R5bGVzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5jb25zdCBCVVRUT05fQ1NTID0gYFxuICA6aG9zdCB7IGRpc3BsYXk6IGlubGluZS1mbGV4OyBhbGlnbi1pdGVtczogY2VudGVyOyB9XG5cbiAgI3d0LWJ0biB7XG4gICAgZGlzcGxheTogaW5saW5lLWZsZXg7IGFsaWduLWl0ZW1zOiBjZW50ZXI7IGdhcDogNXB4O1xuICAgIGhlaWdodDogMjhweDsgcGFkZGluZzogMCAxMnB4OyBib3JkZXItcmFkaXVzOiA5OTk5cHg7IGJvcmRlcjogbm9uZTtcbiAgICBiYWNrZ3JvdW5kOiAjMEE2NkMyOyBjb2xvcjogI2ZmZjtcbiAgICBmb250OiA1MDAgMTJweC8xIC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgXCJTZWdvZSBVSVwiLCBSb2JvdG8sIHNhbnMtc2VyaWY7XG4gICAgY3Vyc29yOiBwb2ludGVyOyB3aGl0ZS1zcGFjZTogbm93cmFwO1xuICAgIHRyYW5zaXRpb246IGJhY2tncm91bmQgMC4xNXMsIGJveC1zaGFkb3cgMC4xNXM7XG4gIH1cbiAgI3d0LWJ0bjpob3ZlciB7IGJhY2tncm91bmQ6ICMwODRmYTA7IGJveC1zaGFkb3c6IDAgMCAwIDNweCByZ2JhKDEwLDEwMiwxOTQsMC4yNSk7IH1cbiAgI3d0LWJ0bjpkaXNhYmxlZCB7IG9wYWNpdHk6IDAuNjsgY3Vyc29yOiBkZWZhdWx0OyBib3gtc2hhZG93OiBub25lOyB9XG5cbiAgI3d0LXBhbmVsIHtcbiAgICBwb3NpdGlvbjogZml4ZWQ7IHotaW5kZXg6IDk5OTk5O1xuICAgIGJhY2tncm91bmQ6ICNmZmY7IGJvcmRlcjogMXB4IHNvbGlkICNFMkU4RjA7IGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgYm94LXNoYWRvdzogMCAxMnB4IDMycHggcmdiYSgwLDAsMCwwLjE0KTtcbiAgICBwYWRkaW5nOiAxNHB4IDE2cHg7IHdpZHRoOiAyNjBweDtcbiAgICBmb250LWZhbWlseTogLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCBcIlNlZ29lIFVJXCIsIFJvYm90bywgc2Fucy1zZXJpZjtcbiAgICBkaXNwbGF5OiBub25lO1xuICB9XG4gICN3dC1wYW5lbC5vcGVuIHsgZGlzcGxheTogYmxvY2s7IH1cblxuICAud3QtdGl0bGUgeyBmb250LXNpemU6IDEycHg7IGZvbnQtd2VpZ2h0OiA2MDA7IGNvbG9yOiAjMzc0MTUxOyBtYXJnaW46IDAgMCAxMHB4O1xuICAgIGxldHRlci1zcGFjaW5nOiAwLjA0ZW07IHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7IH1cbiAgLnd0LXRvbmVzIHsgZGlzcGxheTogZmxleDsgZmxleC13cmFwOiB3cmFwOyBnYXA6IDZweDsgbWFyZ2luLWJvdHRvbTogMTJweDsgfVxuICAud3QtdG9uZSB7XG4gICAgcGFkZGluZzogNHB4IDEwcHg7IGJvcmRlci1yYWRpdXM6IDk5OTlweDsgYm9yZGVyOiAxLjVweCBzb2xpZCAjRThFQUVEO1xuICAgIGJhY2tncm91bmQ6ICNmZmY7IGZvbnQtc2l6ZTogMTJweDsgZm9udC13ZWlnaHQ6IDUwMDsgY29sb3I6ICMzNzQxNTE7XG4gICAgY3Vyc29yOiBwb2ludGVyOyB0cmFuc2l0aW9uOiBhbGwgMC4xcztcbiAgfVxuICAud3QtdG9uZS5hY3RpdmUgeyBjb2xvcjogI2ZmZjsgYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDsgfVxuICAud3QtdG9uZTpob3Zlcjpub3QoLmFjdGl2ZSkgeyBib3JkZXItY29sb3I6ICM5M0M1RkQ7IH1cblxuICAjd3QtcmV3cml0ZSB7XG4gICAgd2lkdGg6IDEwMCU7IGhlaWdodDogMzJweDsgYm9yZGVyLXJhZGl1czogOHB4OyBib3JkZXI6IG5vbmU7XG4gICAgYmFja2dyb3VuZDogIzBBNjZDMjsgY29sb3I6ICNmZmY7XG4gICAgZm9udDogNjAwIDEzcHgvMSAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsIFwiU2Vnb2UgVUlcIiwgUm9ib3RvLCBzYW5zLXNlcmlmO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAjd3QtcmV3cml0ZTpkaXNhYmxlZCB7IG9wYWNpdHk6IDAuNDU7IGN1cnNvcjogZGVmYXVsdDsgfVxuXG4gICN3dC1zdGF0dXMgeyBtYXJnaW4tdG9wOiA4cHg7IGZvbnQtc2l6ZTogMTFweDsgdGV4dC1hbGlnbjogY2VudGVyOyBtaW4taGVpZ2h0OiAxNHB4OyB9XG4gICN3dC1zdGF0dXMuZXJyb3IgeyBjb2xvcjogI0VGNDQ0NDsgfVxuICAjd3Qtc3RhdHVzLnN1Y2Nlc3MgeyBjb2xvcjogIzEwQjk4MTsgfVxuXG4gICN3dC1hY3Rpb25zIHsgZGlzcGxheTogbm9uZTsgZ2FwOiA2cHg7IG1hcmdpbi10b3A6IDhweDsgfVxuICAjd3QtYWN0aW9ucy52aXNpYmxlIHsgZGlzcGxheTogZmxleDsgfVxuICAud3QtYWN0aW9uIHtcbiAgICBmbGV4OiAxOyBoZWlnaHQ6IDI4cHg7IGJvcmRlci1yYWRpdXM6IDhweDsgYm9yZGVyOiAxLjVweCBzb2xpZCAjRThFQUVEO1xuICAgIGJhY2tncm91bmQ6ICNmZmY7IGZvbnQtc2l6ZTogMTJweDsgZm9udC13ZWlnaHQ6IDUwMDsgY29sb3I6ICMzNzQxNTE7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIC53dC1hY3Rpb24uYWNjZXB0IHsgYm9yZGVyLWNvbG9yOiAjMTBCOTgxOyBjb2xvcjogIzEwQjk4MTsgfVxuICAud3QtYWN0aW9uLnJlamVjdCB7IGJvcmRlci1jb2xvcjogI0VGNDQ0NDsgY29sb3I6ICNFRjQ0NDQ7IH1cblxuICAjd3QtbGltaXQgeyBkaXNwbGF5OiBub25lOyBtYXJnaW4tdG9wOiAxMHB4OyBwYWRkaW5nOiAxMHB4IDEycHg7IGJvcmRlci1yYWRpdXM6IDhweDtcbiAgICBiYWNrZ3JvdW5kOiAjRkZGOEYxOyBib3JkZXI6IDFweCBzb2xpZCAjRkVEN0FBOyB0ZXh0LWFsaWduOiBjZW50ZXI7IH1cbiAgI3d0LWxpbWl0LnZpc2libGUgeyBkaXNwbGF5OiBibG9jazsgfVxuICAjd3QtbGltaXQgcCB7IGZvbnQtc2l6ZTogMTFweDsgY29sb3I6ICM5MjQwMEU7IG1hcmdpbjogMCAwIDhweDsgbGluZS1oZWlnaHQ6IDEuNDsgfVxuICAjd3QtbGltaXQgYSB7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrOyBwYWRkaW5nOiA1cHggMTRweDsgYm9yZGVyLXJhZGl1czogOTk5OXB4O1xuICAgIGJhY2tncm91bmQ6ICNGNTlFMEI7IGNvbG9yOiAjZmZmOyBmb250LXNpemU6IDExcHg7IGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xuICB9XG5gO1xuXG5jb25zdCBNSUNfQ1NTID0gYFxuICA6aG9zdCB7IGRpc3BsYXk6IGlubGluZS1mbGV4OyBhbGlnbi1pdGVtczogY2VudGVyOyBtYXJnaW4tbGVmdDogNHB4OyB9XG5cbiAgI3d0LW1pYy1idG4ge1xuICAgIGRpc3BsYXk6IGlubGluZS1mbGV4OyBhbGlnbi1pdGVtczogY2VudGVyOyBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICB3aWR0aDogMjhweDsgaGVpZ2h0OiAyOHB4OyBib3JkZXItcmFkaXVzOiA5OTk5cHg7IGJvcmRlcjogbm9uZTtcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDsgY29sb3I6ICM2NjY7IGN1cnNvcjogcG9pbnRlcjtcbiAgICB0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kIDAuMTVzLCBjb2xvciAwLjE1czsgZm9udC1zaXplOiAxNXB4OyBsaW5lLWhlaWdodDogMTtcbiAgfVxuICAjd3QtbWljLWJ0bjpob3ZlciB7IGJhY2tncm91bmQ6IHJnYmEoMCwwLDAsMC4wNyk7IH1cbiAgI3d0LW1pYy1idG4ucmVjb3JkaW5nIHsgYmFja2dyb3VuZDogI0ZFRTJFMjsgY29sb3I6ICNEQzI2MjY7XG4gICAgYW5pbWF0aW9uOiB3dC1wdWxzZSAxLjJzIGVhc2UtaW4tb3V0IGluZmluaXRlOyB9XG4gIEBrZXlmcmFtZXMgd3QtcHVsc2Uge1xuICAgIDAlLCAxMDAlIHsgYm94LXNoYWRvdzogMCAwIDAgMCByZ2JhKDIyMCwzOCwzOCwwLjQpOyB9XG4gICAgNTAlICAgICAgIHsgYm94LXNoYWRvdzogMCAwIDAgNXB4IHJnYmEoMjIwLDM4LDM4LDApOyB9XG4gIH1cbiAgI3d0LW1pYy1idG46ZGlzYWJsZWQgeyBvcGFjaXR5OiAwLjU7IGN1cnNvcjogZGVmYXVsdDsgfVxuXG4gICN3dC12b2ljZS1wYW5lbCB7XG4gICAgcG9zaXRpb246IGZpeGVkOyB6LWluZGV4OiA5OTk5OTtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmOyBib3JkZXI6IDFweCBzb2xpZCAjRTJFOEYwOyBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIGJveC1zaGFkb3c6IDAgMTJweCAzMnB4IHJnYmEoMCwwLDAsMC4xNCk7XG4gICAgcGFkZGluZzogMTRweCAxNnB4OyB3aWR0aDogMjgwcHg7XG4gICAgZm9udC1mYW1pbHk6IC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgXCJTZWdvZSBVSVwiLCBSb2JvdG8sIHNhbnMtc2VyaWY7XG4gICAgZGlzcGxheTogbm9uZTtcbiAgfVxuICAjd3Qtdm9pY2UtcGFuZWwub3BlbiB7IGRpc3BsYXk6IGJsb2NrOyB9XG5cbiAgLnd0LXZ0IHsgZm9udC1zaXplOiAxMnB4OyBmb250LXdlaWdodDogNjAwOyBjb2xvcjogIzM3NDE1MTsgbWFyZ2luOiAwIDAgMTBweDtcbiAgICBsZXR0ZXItc3BhY2luZzogMC4wNGVtOyB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlOyB9XG4gICN3dC1yZWNvcmQtYnRuIHtcbiAgICB3aWR0aDogMTAwJTsgaGVpZ2h0OiAzNHB4OyBib3JkZXItcmFkaXVzOiA4cHg7IGJvcmRlcjogbm9uZTtcbiAgICBiYWNrZ3JvdW5kOiAjREMyNjI2OyBjb2xvcjogI2ZmZjsgY3Vyc29yOiBwb2ludGVyO1xuICAgIGZvbnQ6IDYwMCAxM3B4LzEgLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCBcIlNlZ29lIFVJXCIsIFJvYm90bywgc2Fucy1zZXJpZjtcbiAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICB9XG4gICN3dC1yZWNvcmQtYnRuLnJlY29yZGluZyB7IGJhY2tncm91bmQ6ICM3RjFEMUQ7IH1cbiAgI3d0LXJlY29yZC1idG46ZGlzYWJsZWQgeyBvcGFjaXR5OiAwLjU7IGN1cnNvcjogZGVmYXVsdDsgfVxuICAud3Qtb3R5cGUtbGFiZWwgeyBmb250LXNpemU6IDExcHg7IGNvbG9yOiAjNkI3MjgwOyBtYXJnaW4tYm90dG9tOiA0cHg7IH1cbiAgLnd0LW90eXBlcyB7IGRpc3BsYXk6IGZsZXg7IGZsZXgtd3JhcDogd3JhcDsgZ2FwOiA1cHg7IG1hcmdpbi1ib3R0b206IDEwcHg7IH1cbiAgLnd0LW90eXBlIHtcbiAgICBwYWRkaW5nOiAzcHggOXB4OyBib3JkZXItcmFkaXVzOiA5OTk5cHg7IGJvcmRlcjogMS41cHggc29saWQgI0U4RUFFRDtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmOyBmb250LXNpemU6IDExcHg7IGNvbG9yOiAjMzc0MTUxOyBjdXJzb3I6IHBvaW50ZXI7XG4gICAgdHJhbnNpdGlvbjogYWxsIDAuMXM7XG4gIH1cbiAgLnd0LW90eXBlLmFjdGl2ZSB7IGJhY2tncm91bmQ6ICMwQTY2QzI7IGNvbG9yOiAjZmZmOyBib3JkZXItY29sb3I6ICMwQTY2QzI7IH1cbiAgI3d0LXZvaWNlLXN0YXR1cyB7IGZvbnQtc2l6ZTogMTFweDsgdGV4dC1hbGlnbjogY2VudGVyOyBtaW4taGVpZ2h0OiAxNHB4OyBjb2xvcjogIzZCNzI4MDsgfVxuICAjd3Qtdm9pY2Utc3RhdHVzLmVycm9yIHsgY29sb3I6ICNFRjQ0NDQ7IH1cbiAgI3d0LXZvaWNlLWFjdGlvbnMgeyBkaXNwbGF5OiBub25lOyBnYXA6IDZweDsgbWFyZ2luLXRvcDogOHB4OyB9XG4gICN3dC12b2ljZS1hY3Rpb25zLnZpc2libGUgeyBkaXNwbGF5OiBmbGV4OyB9XG4gIC53dC12YSB7XG4gICAgZmxleDogMTsgaGVpZ2h0OiAyOHB4OyBib3JkZXItcmFkaXVzOiA4cHg7IGJvcmRlcjogMS41cHggc29saWQgI0U4RUFFRDtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmOyBmb250LXNpemU6IDEycHg7IGZvbnQtd2VpZ2h0OiA1MDA7IGNvbG9yOiAjMzc0MTUxOyBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cbiAgLnd0LXZhLmFjY2VwdCB7IGJvcmRlci1jb2xvcjogIzEwQjk4MTsgY29sb3I6ICMxMEI5ODE7IH1cbiAgLnd0LXZhLnJlamVjdCB7IGJvcmRlci1jb2xvcjogI0VGNDQ0NDsgY29sb3I6ICNFRjQ0NDQ7IH1cbmA7XG5cbi8vIFx1MjUwMFx1MjUwMCBNb2R1bGUtbGV2ZWwgcGFuZWwgbWFuYWdlciAoc2luZ2xlIGRlbGVnYXRlZCBjbGljayBsaXN0ZW5lcikgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmxldCBvcGVuUGFuZWw6IHsgaG9zdDogRWxlbWVudDsgY2xvc2U6ICgpID0+IHZvaWQgfSB8IG51bGwgPSBudWxsO1xuXG5kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChlKSA9PiB7XG4gIGlmIChvcGVuUGFuZWwgJiYgIW9wZW5QYW5lbC5ob3N0LmNvbnRhaW5zKGUudGFyZ2V0IGFzIE5vZGUpKSB7XG4gICAgb3BlblBhbmVsLmNsb3NlKCk7XG4gICAgb3BlblBhbmVsID0gbnVsbDtcbiAgfVxufSwgdHJ1ZSk7XG5cbmZ1bmN0aW9uIG9wZW5QYW5lbEZvcihob3N0OiBFbGVtZW50LCBjbG9zZTogKCkgPT4gdm9pZCk6IHZvaWQge1xuICBpZiAob3BlblBhbmVsICYmIG9wZW5QYW5lbC5ob3N0ICE9PSBob3N0KSBvcGVuUGFuZWwuY2xvc2UoKTtcbiAgb3BlblBhbmVsID0geyBob3N0LCBjbG9zZSB9O1xufVxuXG5mdW5jdGlvbiBjbGVhck9wZW5QYW5lbChob3N0OiBFbGVtZW50KTogdm9pZCB7XG4gIGlmIChvcGVuUGFuZWw/Lmhvc3QgPT09IGhvc3QpIG9wZW5QYW5lbCA9IG51bGw7XG59XG5cbi8vIFx1MjUwMFx1MjUwMCBIZWxwZXJzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5mdW5jdGlvbiBzZW5kVG9CYWNrZ3JvdW5kPFQ+KG1lc3NhZ2U6IG9iamVjdCk6IFByb21pc2U8VD4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKG1lc3NhZ2UsIHJlc29sdmUpKTtcbn1cblxuZnVuY3Rpb24gc2V0Q29tcG9zZVRleHQoZWw6IEhUTUxFbGVtZW50LCB0ZXh0OiBzdHJpbmcpOiB2b2lkIHtcbiAgZWwuZm9jdXMoKTtcbiAgLy8gTGlua2VkSW4gUXVpbGw6IHVzZSBleGVjQ29tbWFuZCBmb3IgcmVsaWFibGUgaW5zZXJ0aW9uXG4gIGRvY3VtZW50LmV4ZWNDb21tYW5kKCdzZWxlY3RBbGwnLCBmYWxzZSwgdW5kZWZpbmVkKTtcbiAgZG9jdW1lbnQuZXhlY0NvbW1hbmQoJ2RlbGV0ZScsIGZhbHNlLCB1bmRlZmluZWQpO1xuICBjb25zdCBsaW5lcyA9IHRleHQuc3BsaXQoJ1xcbicpO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGxpbmVzLmxlbmd0aDsgaSsrKSB7XG4gICAgaWYgKGxpbmVzW2ldKSBkb2N1bWVudC5leGVjQ29tbWFuZCgnaW5zZXJ0VGV4dCcsIGZhbHNlLCBsaW5lc1tpXSk7XG4gICAgaWYgKGkgPCBsaW5lcy5sZW5ndGggLSAxKSBkb2N1bWVudC5leGVjQ29tbWFuZCgnaW5zZXJ0UGFyYWdyYXBoJywgZmFsc2UsIHVuZGVmaW5lZCk7XG4gIH1cbn1cblxuLy8gXHUyNTAwXHUyNTAwIEhlbHBlcnMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmZ1bmN0aW9uIGdldENvbXBvc2VUZXh0KGVsOiBFbGVtZW50KTogc3RyaW5nIHtcbiAgcmV0dXJuIChlbCBhcyBIVE1MRWxlbWVudCkuaW5uZXJUZXh0LnRyaW0oKTtcbn1cblxuLy8gXHUyNTAwXHUyNTAwIE1pYyBidXR0b24gKFZvaWNlIFR3aW4pIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5mdW5jdGlvbiBpbmplY3RNaWNCdXR0b24oY29udGFpbmVyOiBFbGVtZW50LCBjb21wb3NlQm9keTogRWxlbWVudCk6IHZvaWQge1xuICBjb25zdCBtaWNIb3N0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICBtaWNIb3N0LnN0eWxlLmNzc1RleHQgPSAnZGlzcGxheTppbmxpbmUtZmxleDthbGlnbi1pdGVtczpjZW50ZXI7bWFyZ2luLWxlZnQ6NHB4Oyc7XG4gIGNvbnN0IHNoYWRvdyA9IG1pY0hvc3QuYXR0YWNoU2hhZG93KHsgbW9kZTogJ29wZW4nIH0pO1xuXG4gIHNoYWRvdy5pbm5lckhUTUwgPSBgXG4gICAgPHN0eWxlPiR7TUlDX0NTU308L3N0eWxlPlxuICAgIDxidXR0b24gaWQ9XCJ3dC1taWMtYnRuXCIgdGl0bGU9XCJWb2ljZSBUd2luXCI+XHVEODNDXHVERjk5PC9idXR0b24+XG4gICAgPGRpdiBpZD1cInd0LXZvaWNlLXBhbmVsXCI+XG4gICAgICA8cCBjbGFzcz1cInd0LXZ0XCI+Vm9pY2UgVHdpbjwvcD5cbiAgICAgIDxkaXYgY2xhc3M9XCJ3dC1vdHlwZS1sYWJlbFwiPk91dHB1dCB0eXBlPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzPVwid3Qtb3R5cGVzXCI+XG4gICAgICAgICR7Vk9JQ0VfT1VUUFVUX1RZUEVTLm1hcCgobywgaSkgPT5cbiAgICAgICAgICBgPGJ1dHRvbiBjbGFzcz1cInd0LW90eXBlJHtpID09PSAwID8gJyBhY3RpdmUnIDogJyd9XCIgZGF0YS10eXBlPVwiJHtvLmtleX1cIj4ke28ubGFiZWx9PC9idXR0b24+YFxuICAgICAgICApLmpvaW4oJycpfVxuICAgICAgPC9kaXY+XG4gICAgICA8YnV0dG9uIGlkPVwid3QtcmVjb3JkLWJ0blwiPlx1RDgzQ1x1REY5OSBTdGFydCByZWNvcmRpbmc8L2J1dHRvbj5cbiAgICAgIDxkaXYgaWQ9XCJ3dC12b2ljZS1zdGF0dXNcIj48L2Rpdj5cbiAgICAgIDxkaXYgaWQ9XCJ3dC12b2ljZS1hY3Rpb25zXCI+XG4gICAgICAgIDxidXR0b24gY2xhc3M9XCJ3dC12YSBhY2NlcHRcIiBpZD1cInd0LXZhLWtlZXBcIj5cdTI3MTMgS2VlcCBpdDwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uIGNsYXNzPVwid3QtdmEgcmVqZWN0XCIgaWQ9XCJ3dC12YS11bmRvXCI+XHUyNzE3IFVuZG88L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICBgO1xuXG4gIGNvbnN0IG1pY0J0biAgICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtbWljLWJ0bicpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICBjb25zdCBwYW5lbCAgICAgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LXZvaWNlLXBhbmVsJykgYXMgSFRNTERpdkVsZW1lbnQ7XG4gIGNvbnN0IHJlY29yZEJ0biA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtcmVjb3JkLWJ0bicpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICBjb25zdCBzdGF0dXNFbCAgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LXZvaWNlLXN0YXR1cycpIGFzIEhUTUxEaXZFbGVtZW50O1xuICBjb25zdCBhY3Rpb25zRWwgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LXZvaWNlLWFjdGlvbnMnKSBhcyBIVE1MRGl2RWxlbWVudDtcbiAgY29uc3Qga2VlcEJ0biAgID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC12YS1rZWVwJykgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG4gIGNvbnN0IHVuZG9CdG4gICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtdmEtdW5kbycpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuXG4gIGxldCBwYW5lbE9wZW4gPSBmYWxzZTtcbiAgbGV0IHNlbGVjdGVkVHlwZTogVm9pY2VPdXRwdXRUeXBlID0gVk9JQ0VfT1VUUFVUX1RZUEVTWzBdLmtleTtcbiAgbGV0IHJlY29yZGVyOiBNZWRpYVJlY29yZGVyIHwgbnVsbCA9IG51bGw7XG4gIGxldCByZWNvcmRpbmcgPSBmYWxzZTtcbiAgbGV0IGNodW5rczogQmxvYlBhcnRbXSA9IFtdO1xuICBsZXQgbGFzdFNlc3Npb25JZDogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG4gIGxldCBvcmlnaW5hbFRleHQgPSAnJztcblxuICBzaGFkb3cucXVlcnlTZWxlY3RvckFsbDxIVE1MQnV0dG9uRWxlbWVudD4oJy53dC1vdHlwZScpLmZvckVhY2goYnRuID0+IHtcbiAgICBidG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgICBzaGFkb3cucXVlcnlTZWxlY3RvckFsbCgnLnd0LW90eXBlJykuZm9yRWFjaChiID0+IGIuY2xhc3NMaXN0LnJlbW92ZSgnYWN0aXZlJykpO1xuICAgICAgYnRuLmNsYXNzTGlzdC5hZGQoJ2FjdGl2ZScpO1xuICAgICAgc2VsZWN0ZWRUeXBlID0gYnRuLmRhdGFzZXQudHlwZSBhcyBWb2ljZU91dHB1dFR5cGU7XG4gICAgfSk7XG4gIH0pO1xuXG4gIG1pY0J0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBpZiAocGFuZWxPcGVuKSB7XG4gICAgICBwYW5lbE9wZW4gPSBmYWxzZTtcbiAgICAgIHBhbmVsLmNsYXNzTGlzdC5yZW1vdmUoJ29wZW4nKTtcbiAgICAgIGNsZWFyT3BlblBhbmVsKG1pY0hvc3QpO1xuICAgIH0gZWxzZSB7XG4gICAgICBwYW5lbE9wZW4gPSB0cnVlO1xuICAgICAgcGFuZWwuY2xhc3NMaXN0LmFkZCgnb3BlbicpO1xuICAgICAgcG9zaXRpb25QYW5lbCgpO1xuICAgICAgb3BlblBhbmVsRm9yKG1pY0hvc3QsICgpID0+IHsgcGFuZWxPcGVuID0gZmFsc2U7IHBhbmVsLmNsYXNzTGlzdC5yZW1vdmUoJ29wZW4nKTsgfSk7XG4gICAgfVxuICB9KTtcblxuICBmdW5jdGlvbiBwb3NpdGlvblBhbmVsKCk6IHZvaWQge1xuICAgIGNvbnN0IHJlY3QgPSBtaWNCdG4uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgcGFuZWwuc3R5bGUuYm90dG9tID0gYCR7d2luZG93LmlubmVySGVpZ2h0IC0gcmVjdC50b3AgKyA0fXB4YDtcbiAgICBwYW5lbC5zdHlsZS5sZWZ0ID0gYCR7TWF0aC5taW4ocmVjdC5sZWZ0LCB3aW5kb3cuaW5uZXJXaWR0aCAtIDI5Nil9cHhgO1xuICB9XG5cbiAgcmVjb3JkQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICAgIGlmICghcmVjb3JkaW5nKSBhd2FpdCBzdGFydFJlY29yZGluZygpOyBlbHNlIHN0b3BSZWNvcmRpbmcoKTtcbiAgfSk7XG5cbiAgYXN5bmMgZnVuY3Rpb24gc3RhcnRSZWNvcmRpbmcoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHN0cmVhbSA9IGF3YWl0IG5hdmlnYXRvci5tZWRpYURldmljZXMuZ2V0VXNlck1lZGlhKHsgYXVkaW86IHRydWUgfSk7XG4gICAgICBjaHVua3MgPSBbXTtcbiAgICAgIHJlY29yZGVyID0gbmV3IE1lZGlhUmVjb3JkZXIoc3RyZWFtLCB7IG1pbWVUeXBlOiAnYXVkaW8vd2VibScgfSk7XG4gICAgICByZWNvcmRlci5vbmRhdGFhdmFpbGFibGUgPSAoZSkgPT4geyBpZiAoZS5kYXRhLnNpemUgPiAwKSBjaHVua3MucHVzaChlLmRhdGEpOyB9O1xuICAgICAgcmVjb3JkZXIub25zdG9wID0gYXN5bmMgKCkgPT4ge1xuICAgICAgICBzdHJlYW0uZ2V0VHJhY2tzKCkuZm9yRWFjaCh0ID0+IHQuc3RvcCgpKTtcbiAgICAgICAgYXdhaXQgc3VibWl0Vm9pY2UobmV3IEJsb2IoY2h1bmtzLCB7IHR5cGU6ICdhdWRpby93ZWJtJyB9KSk7XG4gICAgICB9O1xuICAgICAgcmVjb3JkZXIuc3RhcnQoKTtcbiAgICAgIHJlY29yZGluZyA9IHRydWU7XG4gICAgICBtaWNCdG4uY2xhc3NMaXN0LmFkZCgncmVjb3JkaW5nJyk7XG4gICAgICByZWNvcmRCdG4uY2xhc3NMaXN0LmFkZCgncmVjb3JkaW5nJyk7XG4gICAgICByZWNvcmRCdG4udGV4dENvbnRlbnQgPSAnXHUyM0Y5IFN0b3AgcmVjb3JkaW5nJztcbiAgICAgIHNldFZTdGF0dXMoJ1JlY29yZGluZ1x1MjAyNicpO1xuICAgICAgYWN0aW9uc0VsLmNsYXNzTGlzdC5yZW1vdmUoJ3Zpc2libGUnKTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4geyBpZiAocmVjb3JkaW5nKSBzdG9wUmVjb3JkaW5nKCk7IH0sIDYwXzAwMCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICBzZXRWU3RhdHVzKCdNaWNyb3Bob25lIGFjY2VzcyBkZW5pZWQuJywgJ2Vycm9yJyk7XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gc3RvcFJlY29yZGluZygpOiB2b2lkIHtcbiAgICBpZiAocmVjb3JkZXIgJiYgcmVjb3JkaW5nKSB7XG4gICAgICByZWNvcmRlci5zdG9wKCk7IHJlY29yZGluZyA9IGZhbHNlO1xuICAgICAgbWljQnRuLmNsYXNzTGlzdC5yZW1vdmUoJ3JlY29yZGluZycpO1xuICAgICAgcmVjb3JkQnRuLmNsYXNzTGlzdC5yZW1vdmUoJ3JlY29yZGluZycpO1xuICAgICAgcmVjb3JkQnRuLnRleHRDb250ZW50ID0gJ1x1RDgzQ1x1REY5OSBTdGFydCByZWNvcmRpbmcnO1xuICAgICAgcmVjb3JkQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgICAgIHNldFZTdGF0dXMoJ0RyYWZ0aW5nXHUyMDI2Jyk7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgZnVuY3Rpb24gc3VibWl0Vm9pY2UoYmxvYjogQmxvYik6IFByb21pc2U8dm9pZD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBidWYgPSBhd2FpdCBibG9iLmFycmF5QnVmZmVyKCk7XG4gICAgICBjb25zdCBhdWRpb0RhdGEgPSBidG9hKEFycmF5LmZyb20obmV3IFVpbnQ4QXJyYXkoYnVmKSwgYiA9PiBTdHJpbmcuZnJvbUNoYXJDb2RlKGIpKS5qb2luKCcnKSk7XG4gICAgICBvcmlnaW5hbFRleHQgPSBnZXRDb21wb3NlVGV4dChjb21wb3NlQm9keSk7XG4gICAgICBjb25zdCByZXNwID0gYXdhaXQgc2VuZFRvQmFja2dyb3VuZDx7IHJlc3VsdDogVm9pY2VEcmFmdFJlc3BvbnNlIH0gfCB7IGVycm9yOiBzdHJpbmcgfT4oe1xuICAgICAgICB0eXBlOiAnVk9JQ0VfRFJBRlQnLFxuICAgICAgICBwYXlsb2FkOiB7IGF1ZGlvRGF0YSwgbWltZVR5cGU6ICdhdWRpby93ZWJtJywgb3V0cHV0VHlwZTogc2VsZWN0ZWRUeXBlIH0sXG4gICAgICB9KTtcbiAgICAgIGlmICgnZXJyb3InIGluIHJlc3ApIHRocm93IG5ldyBFcnJvcihTdHJpbmcocmVzcC5lcnJvcikpO1xuICAgICAgbGFzdFNlc3Npb25JZCA9IHJlc3AucmVzdWx0LmlkO1xuICAgICAgc2V0Q29tcG9zZVRleHQoY29tcG9zZUJvZHkgYXMgSFRNTEVsZW1lbnQsIHJlc3AucmVzdWx0LmRyYWZ0KTtcbiAgICAgIHNldFZTdGF0dXMoJ0RvbmUgXHUyNzEzJyk7XG4gICAgICBhY3Rpb25zRWwuY2xhc3NMaXN0LmFkZCgndmlzaWJsZScpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0VlN0YXR1cyhlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogJ0ZhaWxlZCcsICdlcnJvcicpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICByZWNvcmRCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgICB9XG4gIH1cblxuICBrZWVwQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgIGlmIChsYXN0U2Vzc2lvbklkKSBzZW5kVG9CYWNrZ3JvdW5kKHsgdHlwZTogJ1ZPSUNFX0ZFRURCQUNLJywgcGF5bG9hZDogeyBzZXNzaW9uSWQ6IGxhc3RTZXNzaW9uSWQsIGFjY2VwdGVkOiB0cnVlLCBlZGl0ZWREcmFmdDogbnVsbCB9IH0pO1xuICAgIGFjdGlvbnNFbC5jbGFzc0xpc3QucmVtb3ZlKCd2aXNpYmxlJyk7XG4gICAgcGFuZWxPcGVuID0gZmFsc2U7IHBhbmVsLmNsYXNzTGlzdC5yZW1vdmUoJ29wZW4nKTtcbiAgICBjbGVhck9wZW5QYW5lbChtaWNIb3N0KTtcbiAgICBzZXRWU3RhdHVzKCcnKTtcbiAgfSk7XG5cbiAgdW5kb0J0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBpZiAob3JpZ2luYWxUZXh0KSBzZXRDb21wb3NlVGV4dChjb21wb3NlQm9keSBhcyBIVE1MRWxlbWVudCwgb3JpZ2luYWxUZXh0KTtcbiAgICBpZiAobGFzdFNlc3Npb25JZCkgc2VuZFRvQmFja2dyb3VuZCh7IHR5cGU6ICdWT0lDRV9GRUVEQkFDSycsIHBheWxvYWQ6IHsgc2Vzc2lvbklkOiBsYXN0U2Vzc2lvbklkLCBhY2NlcHRlZDogZmFsc2UsIGVkaXRlZERyYWZ0OiBudWxsIH0gfSk7XG4gICAgYWN0aW9uc0VsLmNsYXNzTGlzdC5yZW1vdmUoJ3Zpc2libGUnKTtcbiAgICBzZXRWU3RhdHVzKCdSZXZlcnRlZC4nLCAnc3VjY2VzcycpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0VlN0YXR1cygnJyksIDIwMDApO1xuICB9KTtcblxuICBmdW5jdGlvbiBzZXRWU3RhdHVzKG1zZzogc3RyaW5nLCBjbHMgPSAnJyk6IHZvaWQge1xuICAgIHN0YXR1c0VsLnRleHRDb250ZW50ID0gbXNnOyBzdGF0dXNFbC5jbGFzc05hbWUgPSBjbHM7XG4gIH1cblxuICBjb250YWluZXIuYXBwZW5kQ2hpbGQobWljSG9zdCk7XG59XG5cbi8vIFx1MjUwMFx1MjUwMCBIdW1hbml6ZSBidXR0b24gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmZ1bmN0aW9uIGluamVjdChjb21wb3NlQm9keTogRWxlbWVudCk6IHZvaWQge1xuICAvLyBHdWFyZDogbWFyayB0aGUgY29tcG9zZSBib2R5IGl0c2VsZiwgbm90IGEgdG9vbGJhciB0aGF0IG1heSBzaGlmdCBpbiB0aGUgRE9NXG4gIGlmIChjb21wb3NlQm9keS5oYXNBdHRyaWJ1dGUoSE9TVF9BVFRSKSkgcmV0dXJuO1xuICBjb21wb3NlQm9keS5zZXRBdHRyaWJ1dGUoSE9TVF9BVFRSLCAnMScpO1xuXG4gIC8vIEJ1aWxkIGEgd3JhcHBlciBkaXYgdG8gaG9sZCBvdXIgYnV0dG9ucyBcdTIwMTQgYXBwZW5kIGFmdGVyIGNvbXBvc2UgYm9keSBwYXJlbnRcbiAgY29uc3Qgd3JhcHBlciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICB3cmFwcGVyLnN0eWxlLmNzc1RleHQgPSAnZGlzcGxheTpmbGV4O2FsaWduLWl0ZW1zOmNlbnRlcjtnYXA6NHB4O21hcmdpbi10b3A6OHB4O3BhZGRpbmc6MCAycHg7JztcblxuICAvLyBJbnNlcnQgd3JhcHBlciBhZnRlciB0aGUgY29tcG9zZSBib2R5J3MgbmVhcmVzdCBibG9jayBwYXJlbnRcbiAgY29uc3QgaW5zZXJ0aW9uUG9pbnQgPSBjb21wb3NlQm9keS5jbG9zZXN0KCcucWwtY29udGFpbmVyLCAuY29tbWVudHMtY29tbWVudC10ZXh0ZWRpdG9yLCAuZWRpdG9yLWNvbnRlbnQnKVxuICAgID8/IGNvbXBvc2VCb2R5LnBhcmVudEVsZW1lbnQ7XG4gIGluc2VydGlvblBvaW50Py5pbnNlcnRBZGphY2VudEVsZW1lbnQoJ2FmdGVyZW5kJywgd3JhcHBlcik7XG4gIGlmICghd3JhcHBlci5wYXJlbnRFbGVtZW50KSB7XG4gICAgLy8gZmFsbGJhY2s6IGFwcGVuZCB0byBjb21wb3NlIGJvZHkgcGFyZW50XG4gICAgY29tcG9zZUJvZHkucGFyZW50RWxlbWVudD8uYXBwZW5kQ2hpbGQod3JhcHBlcik7XG4gIH1cblxuICBjb25zdCBob3N0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICBjb25zdCBzaGFkb3cgPSBob3N0LmF0dGFjaFNoYWRvdyh7IG1vZGU6ICdvcGVuJyB9KTtcblxuICBsZXQgc2VsZWN0ZWRUb25lOiBUb25lIHwgbnVsbCA9IG51bGw7XG4gIGxldCBsYXN0UmV3cml0ZUlkOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcbiAgbGV0IHBhbmVsT3BlbiA9IGZhbHNlO1xuXG4gIHNoYWRvdy5pbm5lckhUTUwgPSBgXG4gICAgPHN0eWxlPiR7QlVUVE9OX0NTU308L3N0eWxlPlxuICAgIDxidXR0b24gaWQ9XCJ3dC1idG5cIiB0aXRsZT1cIkh1bWFuaXplIHdpdGggV3JpdGluZyBUd2luIEFJXCI+XHUyNzI4IEh1bWFuaXplPC9idXR0b24+XG4gICAgPGRpdiBpZD1cInd0LXBhbmVsXCI+XG4gICAgICA8cCBjbGFzcz1cInd0LXRpdGxlXCI+UmV3cml0ZSB0b25lPC9wPlxuICAgICAgPGRpdiBjbGFzcz1cInd0LXRvbmVzXCI+XG4gICAgICAgICR7VE9ORVMubWFwKHQgPT4gYDxidXR0b24gY2xhc3M9XCJ3dC10b25lXCIgZGF0YS10b25lPVwiJHt0LmtleX1cIiBkYXRhLWNvbG9yPVwiJHt0LmNvbG9yfVwiPiR7dC5sYWJlbH08L2J1dHRvbj5gKS5qb2luKCcnKX1cbiAgICAgIDwvZGl2PlxuICAgICAgPGJ1dHRvbiBpZD1cInd0LXJld3JpdGVcIiBkaXNhYmxlZD5SZXdyaXRlIFx1MjE5MjwvYnV0dG9uPlxuICAgICAgPGRpdiBpZD1cInd0LXN0YXR1c1wiPjwvZGl2PlxuICAgICAgPGRpdiBpZD1cInd0LWxpbWl0XCI+XG4gICAgICAgIDxwPllvdSd2ZSB1c2VkIGFsbCB5b3VyIGZyZWUgcmV3cml0ZXMgdGhpcyBtb250aC48L3A+XG4gICAgICAgIDxhIGhyZWY9XCJodHRwczovL3dyaXRpbmd0d2luYWkuY29tL3ByaWNpbmdcIiB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub29wZW5lclwiPlVwZ3JhZGUgdG8gUHJvIFx1MjAxNCAkNS9tbzwvYT5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBpZD1cInd0LWFjdGlvbnNcIj5cbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cInd0LWFjdGlvbiBhY2NlcHRcIiBpZD1cInd0LWFjY2VwdFwiPlx1MjcxMyBLZWVwIGl0PC9idXR0b24+XG4gICAgICAgIDxidXR0b24gY2xhc3M9XCJ3dC1hY3Rpb24gcmVqZWN0XCIgaWQ9XCJ3dC1yZWplY3RcIj5cdTI3MTcgVW5kbzwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIGA7XG5cbiAgY29uc3QgYnRuICAgICAgID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC1idG4nKSBhcyBIVE1MQnV0dG9uRWxlbWVudDtcbiAgY29uc3QgcGFuZWwgICAgID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC1wYW5lbCcpIGFzIEhUTUxEaXZFbGVtZW50O1xuICBjb25zdCByZXdyaXRlQnRuID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC1yZXdyaXRlJykgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG4gIGNvbnN0IHN0YXR1c0VsICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3Qtc3RhdHVzJykgYXMgSFRNTERpdkVsZW1lbnQ7XG4gIGNvbnN0IGxpbWl0RWwgICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtbGltaXQnKSBhcyBIVE1MRGl2RWxlbWVudDtcbiAgY29uc3QgYWN0aW9uc0VsID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC1hY3Rpb25zJykgYXMgSFRNTERpdkVsZW1lbnQ7XG4gIGNvbnN0IGFjY2VwdEJ0biA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtYWNjZXB0JykgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG4gIGNvbnN0IHJlamVjdEJ0biA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtcmVqZWN0JykgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG5cbiAgc2hhZG93LnF1ZXJ5U2VsZWN0b3JBbGw8SFRNTEJ1dHRvbkVsZW1lbnQ+KCcud3QtdG9uZScpLmZvckVhY2godGIgPT4ge1xuICAgIHRiLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgICAgc2hhZG93LnF1ZXJ5U2VsZWN0b3JBbGwoJy53dC10b25lJykuZm9yRWFjaChiID0+IGIuY2xhc3NMaXN0LnJlbW92ZSgnYWN0aXZlJykpO1xuICAgICAgdGIuY2xhc3NMaXN0LmFkZCgnYWN0aXZlJyk7XG4gICAgICB0Yi5zdHlsZS5iYWNrZ3JvdW5kID0gdGIuZGF0YXNldC5jb2xvciA/PyAnIzBBNjZDMic7XG4gICAgICB0Yi5zdHlsZS5ib3JkZXJDb2xvciA9IHRiLmRhdGFzZXQuY29sb3IgPz8gJyMwQTY2QzInO1xuICAgICAgc2VsZWN0ZWRUb25lID0gdGIuZGF0YXNldC50b25lIGFzIFRvbmU7XG4gICAgICByZXdyaXRlQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gICAgICBzdGF0dXNFbC50ZXh0Q29udGVudCA9ICcnOyBzdGF0dXNFbC5jbGFzc05hbWUgPSAnJztcbiAgICAgIGxpbWl0RWwuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xuICAgICAgYWN0aW9uc0VsLmNsYXNzTGlzdC5yZW1vdmUoJ3Zpc2libGUnKTtcbiAgICB9KTtcbiAgfSk7XG5cbiAgYnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgIGlmIChwYW5lbE9wZW4pIHtcbiAgICAgIHBhbmVsT3BlbiA9IGZhbHNlO1xuICAgICAgcGFuZWwuY2xhc3NMaXN0LnJlbW92ZSgnb3BlbicpO1xuICAgICAgY2xlYXJPcGVuUGFuZWwoaG9zdCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHBhbmVsT3BlbiA9IHRydWU7XG4gICAgICBwYW5lbC5jbGFzc0xpc3QuYWRkKCdvcGVuJyk7XG4gICAgICBwb3NpdGlvblBhbmVsKCk7XG4gICAgICBvcGVuUGFuZWxGb3IoaG9zdCwgKCkgPT4geyBwYW5lbE9wZW4gPSBmYWxzZTsgcGFuZWwuY2xhc3NMaXN0LnJlbW92ZSgnb3BlbicpOyB9KTtcbiAgICB9XG4gIH0pO1xuXG4gIGZ1bmN0aW9uIHBvc2l0aW9uUGFuZWwoKTogdm9pZCB7XG4gICAgY29uc3QgcmVjdCA9IGJ0bi5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICBwYW5lbC5zdHlsZS5ib3R0b20gPSBgJHt3aW5kb3cuaW5uZXJIZWlnaHQgLSByZWN0LnRvcCArIDR9cHhgO1xuICAgIHBhbmVsLnN0eWxlLmxlZnQgPSBgJHtNYXRoLm1pbihyZWN0LmxlZnQsIHdpbmRvdy5pbm5lcldpZHRoIC0gMjc2KX1weGA7XG4gIH1cblxuICBsZXQgb3JpZ2luYWxUZXh0ID0gJyc7XG5cbiAgcmV3cml0ZUJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgICBpZiAoIXNlbGVjdGVkVG9uZSkgcmV0dXJuO1xuICAgIGNvbnN0IHRleHQgPSAoY29tcG9zZUJvZHkgYXMgSFRNTEVsZW1lbnQpLmlubmVyVGV4dC50cmltKCk7XG4gICAgaWYgKCF0ZXh0KSB7IHNldFN0YXR1cygnV3JpdGUgc29tZXRoaW5nIGZpcnN0LicsICdlcnJvcicpOyByZXR1cm47IH1cbiAgICBvcmlnaW5hbFRleHQgPSB0ZXh0O1xuICAgIGJ0bi5kaXNhYmxlZCA9IHRydWU7IHJld3JpdGVCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICAgIHNldFN0YXR1cygnUmV3cml0aW5nXHUyMDI2Jyk7XG4gICAgYWN0aW9uc0VsLmNsYXNzTGlzdC5yZW1vdmUoJ3Zpc2libGUnKTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwID0gYXdhaXQgc2VuZFRvQmFja2dyb3VuZDx7IHJlc3VsdDogUmV3cml0ZVJlc3BvbnNlIH0gfCB7IGVycm9yOiBzdHJpbmcgfT4oe1xuICAgICAgICB0eXBlOiAnSFVNQU5JWkUnLFxuICAgICAgICBwYXlsb2FkOiB7XG4gICAgICAgICAgdGV4dCxcbiAgICAgICAgICB0b25lOiBzZWxlY3RlZFRvbmUsXG4gICAgICAgICAgY3R4OiB7IHBsYXRmb3JtOiAnbGlua2VkaW4nLCBjb250ZXh0X3R3aW5fb3ZlcnJpZGU6IEZJWEVEX0NPTlRFWFRfT1ZFUlJJREUgfSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgICAgaWYgKCdlcnJvcicgaW4gcmVzcCkgdGhyb3cgbmV3IEVycm9yKFN0cmluZyhyZXNwLmVycm9yKSk7XG4gICAgICBsYXN0UmV3cml0ZUlkID0gcmVzcC5yZXN1bHQuaWQ7XG4gICAgICBzZXRDb21wb3NlVGV4dChjb21wb3NlQm9keSBhcyBIVE1MRWxlbWVudCwgcmVzcC5yZXN1bHQub3V0cHV0X3RleHQpO1xuICAgICAgc2V0U3RhdHVzKCdEb25lIFx1MjcxMycsICdzdWNjZXNzJyk7XG4gICAgICBhY3Rpb25zRWwuY2xhc3NMaXN0LmFkZCgndmlzaWJsZScpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc3QgbXNnID0gZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6ICdGYWlsZWQnO1xuICAgICAgaWYgKG1zZy5zdGFydHNXaXRoKCdMSU1JVF9SRUFDSEVEOicpKSB7XG4gICAgICAgIGxpbWl0RWwuY2xhc3NMaXN0LmFkZCgndmlzaWJsZScpOyBzZXRTdGF0dXMoJycpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2V0U3RhdHVzKG1zZywgJ2Vycm9yJyk7XG4gICAgICB9XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIGJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICAgICAgcmV3cml0ZUJ0bi5kaXNhYmxlZCA9IHNlbGVjdGVkVG9uZSA9PT0gbnVsbDtcbiAgICB9XG4gIH0pO1xuXG4gIGFjY2VwdEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBpZiAobGFzdFJld3JpdGVJZCkgc2VuZFRvQmFja2dyb3VuZCh7IHR5cGU6ICdGRUVEQkFDSycsIHBheWxvYWQ6IHsgcmV3cml0ZUlkOiBsYXN0UmV3cml0ZUlkLCBhY3Rpb246ICdhY2NlcHRlZCcgfSB9KTtcbiAgICBhY3Rpb25zRWwuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xuICAgIHBhbmVsT3BlbiA9IGZhbHNlOyBwYW5lbC5jbGFzc0xpc3QucmVtb3ZlKCdvcGVuJyk7XG4gICAgY2xlYXJPcGVuUGFuZWwoaG9zdCk7XG4gICAgc2V0U3RhdHVzKCcnKTtcbiAgfSk7XG5cbiAgcmVqZWN0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgIGlmIChvcmlnaW5hbFRleHQpIHNldENvbXBvc2VUZXh0KGNvbXBvc2VCb2R5IGFzIEhUTUxFbGVtZW50LCBvcmlnaW5hbFRleHQpO1xuICAgIGlmIChsYXN0UmV3cml0ZUlkKSBzZW5kVG9CYWNrZ3JvdW5kKHsgdHlwZTogJ0ZFRURCQUNLJywgcGF5bG9hZDogeyByZXdyaXRlSWQ6IGxhc3RSZXdyaXRlSWQsIGFjdGlvbjogJ3JlamVjdGVkJyB9IH0pO1xuICAgIGFjdGlvbnNFbC5jbGFzc0xpc3QucmVtb3ZlKCd2aXNpYmxlJyk7XG4gICAgc2V0U3RhdHVzKCdSZXZlcnRlZC4nLCAnc3VjY2VzcycpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0U3RhdHVzKCcnKSwgMjAwMCk7XG4gIH0pO1xuXG4gIGZ1bmN0aW9uIHNldFN0YXR1cyhtc2c6IHN0cmluZywgY2xzID0gJycpOiB2b2lkIHtcbiAgICBzdGF0dXNFbC50ZXh0Q29udGVudCA9IG1zZzsgc3RhdHVzRWwuY2xhc3NOYW1lID0gY2xzO1xuICB9XG5cbiAgd3JhcHBlci5hcHBlbmRDaGlsZChob3N0KTtcbiAgaW5qZWN0TWljQnV0dG9uKHdyYXBwZXIsIGNvbXBvc2VCb2R5KTtcbn1cblxuLy8gXHUyNTAwXHUyNTAwIE11dGF0aW9uT2JzZXJ2ZXIgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmNvbnN0IHNlZW4gPSBuZXcgV2Vha1NldDxFbGVtZW50PigpO1xuXG5mdW5jdGlvbiB0cnlJbmplY3Qocm9vdDogRWxlbWVudCB8IERvY3VtZW50KTogdm9pZCB7XG4gIHJvb3QucXVlcnlTZWxlY3RvckFsbDxFbGVtZW50PihDT01QT1NFX0JPRFlfU0VMKS5mb3JFYWNoKChib2R5KSA9PiB7XG4gICAgLy8gU2tpcCB0aW55IHBsYWNlaG9sZGVycyAocGxhY2Vob2xkZXIgdGV4dCBvbmx5LCBubyByZWFsIGNvbnRlbnQgYm94KVxuICAgIGlmICghc2Vlbi5oYXMoYm9keSkpIHtcbiAgICAgIHNlZW4uYWRkKGJvZHkpO1xuICAgICAgaW5qZWN0KGJvZHkpO1xuICAgIH1cbiAgfSk7XG59XG5cbmNvbnN0IG9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoKCkgPT4ge1xuICByZXF1ZXN0SWRsZUNhbGxiYWNrKCgpID0+IHRyeUluamVjdChkb2N1bWVudCksIHsgdGltZW91dDogNTAwIH0pO1xufSk7XG5vYnNlcnZlci5vYnNlcnZlKGRvY3VtZW50LmJvZHksIHsgY2hpbGRMaXN0OiB0cnVlLCBzdWJ0cmVlOiB0cnVlIH0pO1xudHJ5SW5qZWN0KGRvY3VtZW50KTtcbiJdLAogICJtYXBwaW5ncyI6ICI7OztBQUdBLE1BQU0sbUJBQW1CO0FBQ3pCLE1BQU0sWUFBWTtBQUdsQixNQUFNLHlCQUF5QjtBQUUvQixNQUFNLFFBQXVEO0FBQUEsSUFDM0QsRUFBRSxLQUFLLGdCQUFnQixPQUFPLGdCQUFnQixPQUFPLFVBQVU7QUFBQSxJQUMvRCxFQUFFLEtBQUssVUFBZ0IsT0FBTyxVQUFnQixPQUFPLFVBQVU7QUFBQSxJQUMvRCxFQUFFLEtBQUssWUFBZ0IsT0FBTyxZQUFnQixPQUFPLFVBQVU7QUFBQSxJQUMvRCxFQUFFLEtBQUssVUFBZ0IsT0FBTyxVQUFnQixPQUFPLFVBQVU7QUFBQSxJQUMvRCxFQUFFLEtBQUssYUFBZ0IsT0FBTyxhQUFnQixPQUFPLFVBQVU7QUFBQSxFQUNqRTtBQUVBLE1BQU0scUJBQWdFO0FBQUEsSUFDcEUsRUFBRSxLQUFLLG9CQUFvQixPQUFPLFVBQVU7QUFBQSxJQUM1QyxFQUFFLEtBQUssU0FBb0IsT0FBTyxVQUFVO0FBQUEsSUFDNUMsRUFBRSxLQUFLLFNBQW9CLE9BQU8sUUFBUTtBQUFBLEVBQzVDO0FBSUEsTUFBTSxhQUFhO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBb0VuQixNQUFNLFVBQVU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBNERoQixNQUFJLFlBQXlEO0FBRTdELFdBQVMsaUJBQWlCLFNBQVMsQ0FBQyxNQUFNO0FBQ3hDLFFBQUksYUFBYSxDQUFDLFVBQVUsS0FBSyxTQUFTLEVBQUUsTUFBYyxHQUFHO0FBQzNELGdCQUFVLE1BQU07QUFDaEIsa0JBQVk7QUFBQSxJQUNkO0FBQUEsRUFDRixHQUFHLElBQUk7QUFFUCxXQUFTLGFBQWEsTUFBZSxPQUF5QjtBQUM1RCxRQUFJLGFBQWEsVUFBVSxTQUFTLEtBQU0sV0FBVSxNQUFNO0FBQzFELGdCQUFZLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFDNUI7QUFFQSxXQUFTLGVBQWUsTUFBcUI7QUFDM0MsUUFBSSxXQUFXLFNBQVMsS0FBTSxhQUFZO0FBQUEsRUFDNUM7QUFJQSxXQUFTLGlCQUFvQixTQUE2QjtBQUN4RCxXQUFPLElBQUksUUFBUSxDQUFDLFlBQVksT0FBTyxRQUFRLFlBQVksU0FBUyxPQUFPLENBQUM7QUFBQSxFQUM5RTtBQUVBLFdBQVMsZUFBZSxJQUFpQixNQUFvQjtBQUMzRCxPQUFHLE1BQU07QUFFVCxhQUFTLFlBQVksYUFBYSxPQUFPLE1BQVM7QUFDbEQsYUFBUyxZQUFZLFVBQVUsT0FBTyxNQUFTO0FBQy9DLFVBQU0sUUFBUSxLQUFLLE1BQU0sSUFBSTtBQUM3QixhQUFTLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLO0FBQ3JDLFVBQUksTUFBTSxDQUFDLEVBQUcsVUFBUyxZQUFZLGNBQWMsT0FBTyxNQUFNLENBQUMsQ0FBQztBQUNoRSxVQUFJLElBQUksTUFBTSxTQUFTLEVBQUcsVUFBUyxZQUFZLG1CQUFtQixPQUFPLE1BQVM7QUFBQSxJQUNwRjtBQUFBLEVBQ0Y7QUFJQSxXQUFTLGVBQWUsSUFBcUI7QUFDM0MsV0FBUSxHQUFtQixVQUFVLEtBQUs7QUFBQSxFQUM1QztBQUlBLFdBQVMsZ0JBQWdCLFdBQW9CLGFBQTRCO0FBQ3ZFLFVBQU0sVUFBVSxTQUFTLGNBQWMsTUFBTTtBQUM3QyxZQUFRLE1BQU0sVUFBVTtBQUN4QixVQUFNLFNBQVMsUUFBUSxhQUFhLEVBQUUsTUFBTSxPQUFPLENBQUM7QUFFcEQsV0FBTyxZQUFZO0FBQUEsYUFDUixPQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBTVYsbUJBQW1CO0FBQUEsTUFBSSxDQUFDLEdBQUcsTUFDM0IsMEJBQTBCLE1BQU0sSUFBSSxZQUFZLEVBQUUsZ0JBQWdCLEVBQUUsR0FBRyxLQUFLLEVBQUUsS0FBSztBQUFBLElBQ3JGLEVBQUUsS0FBSyxFQUFFLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFXaEIsVUFBTSxTQUFZLE9BQU8sZUFBZSxZQUFZO0FBQ3BELFVBQU0sUUFBWSxPQUFPLGVBQWUsZ0JBQWdCO0FBQ3hELFVBQU0sWUFBWSxPQUFPLGVBQWUsZUFBZTtBQUN2RCxVQUFNLFdBQVksT0FBTyxlQUFlLGlCQUFpQjtBQUN6RCxVQUFNLFlBQVksT0FBTyxlQUFlLGtCQUFrQjtBQUMxRCxVQUFNLFVBQVksT0FBTyxlQUFlLFlBQVk7QUFDcEQsVUFBTSxVQUFZLE9BQU8sZUFBZSxZQUFZO0FBRXBELFFBQUksWUFBWTtBQUNoQixRQUFJLGVBQWdDLG1CQUFtQixDQUFDLEVBQUU7QUFDMUQsUUFBSSxXQUFpQztBQUNyQyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxTQUFxQixDQUFDO0FBQzFCLFFBQUksZ0JBQStCO0FBQ25DLFFBQUksZUFBZTtBQUVuQixXQUFPLGlCQUFvQyxXQUFXLEVBQUUsUUFBUSxTQUFPO0FBQ3JFLFVBQUksaUJBQWlCLFNBQVMsTUFBTTtBQUNsQyxlQUFPLGlCQUFpQixXQUFXLEVBQUUsUUFBUSxPQUFLLEVBQUUsVUFBVSxPQUFPLFFBQVEsQ0FBQztBQUM5RSxZQUFJLFVBQVUsSUFBSSxRQUFRO0FBQzFCLHVCQUFlLElBQUksUUFBUTtBQUFBLE1BQzdCLENBQUM7QUFBQSxJQUNILENBQUM7QUFFRCxXQUFPLGlCQUFpQixTQUFTLE1BQU07QUFDckMsVUFBSSxXQUFXO0FBQ2Isb0JBQVk7QUFDWixjQUFNLFVBQVUsT0FBTyxNQUFNO0FBQzdCLHVCQUFlLE9BQU87QUFBQSxNQUN4QixPQUFPO0FBQ0wsb0JBQVk7QUFDWixjQUFNLFVBQVUsSUFBSSxNQUFNO0FBQzFCLHNCQUFjO0FBQ2QscUJBQWEsU0FBUyxNQUFNO0FBQUUsc0JBQVk7QUFBTyxnQkFBTSxVQUFVLE9BQU8sTUFBTTtBQUFBLFFBQUcsQ0FBQztBQUFBLE1BQ3BGO0FBQUEsSUFDRixDQUFDO0FBRUQsYUFBUyxnQkFBc0I7QUFDN0IsWUFBTSxPQUFPLE9BQU8sc0JBQXNCO0FBQzFDLFlBQU0sTUFBTSxTQUFTLEdBQUcsT0FBTyxjQUFjLEtBQUssTUFBTSxDQUFDO0FBQ3pELFlBQU0sTUFBTSxPQUFPLEdBQUcsS0FBSyxJQUFJLEtBQUssTUFBTSxPQUFPLGFBQWEsR0FBRyxDQUFDO0FBQUEsSUFDcEU7QUFFQSxjQUFVLGlCQUFpQixTQUFTLFlBQVk7QUFDOUMsVUFBSSxDQUFDLFVBQVcsT0FBTSxlQUFlO0FBQUEsVUFBUSxlQUFjO0FBQUEsSUFDN0QsQ0FBQztBQUVELG1CQUFlLGlCQUFnQztBQUM3QyxVQUFJO0FBQ0YsY0FBTSxTQUFTLE1BQU0sVUFBVSxhQUFhLGFBQWEsRUFBRSxPQUFPLEtBQUssQ0FBQztBQUN4RSxpQkFBUyxDQUFDO0FBQ1YsbUJBQVcsSUFBSSxjQUFjLFFBQVEsRUFBRSxVQUFVLGFBQWEsQ0FBQztBQUMvRCxpQkFBUyxrQkFBa0IsQ0FBQyxNQUFNO0FBQUUsY0FBSSxFQUFFLEtBQUssT0FBTyxFQUFHLFFBQU8sS0FBSyxFQUFFLElBQUk7QUFBQSxRQUFHO0FBQzlFLGlCQUFTLFNBQVMsWUFBWTtBQUM1QixpQkFBTyxVQUFVLEVBQUUsUUFBUSxPQUFLLEVBQUUsS0FBSyxDQUFDO0FBQ3hDLGdCQUFNLFlBQVksSUFBSSxLQUFLLFFBQVEsRUFBRSxNQUFNLGFBQWEsQ0FBQyxDQUFDO0FBQUEsUUFDNUQ7QUFDQSxpQkFBUyxNQUFNO0FBQ2Ysb0JBQVk7QUFDWixlQUFPLFVBQVUsSUFBSSxXQUFXO0FBQ2hDLGtCQUFVLFVBQVUsSUFBSSxXQUFXO0FBQ25DLGtCQUFVLGNBQWM7QUFDeEIsbUJBQVcsaUJBQVk7QUFDdkIsa0JBQVUsVUFBVSxPQUFPLFNBQVM7QUFDcEMsbUJBQVcsTUFBTTtBQUFFLGNBQUksVUFBVyxlQUFjO0FBQUEsUUFBRyxHQUFHLEdBQU07QUFBQSxNQUM5RCxRQUFRO0FBQ04sbUJBQVcsNkJBQTZCLE9BQU87QUFBQSxNQUNqRDtBQUFBLElBQ0Y7QUFFQSxhQUFTLGdCQUFzQjtBQUM3QixVQUFJLFlBQVksV0FBVztBQUN6QixpQkFBUyxLQUFLO0FBQUcsb0JBQVk7QUFDN0IsZUFBTyxVQUFVLE9BQU8sV0FBVztBQUNuQyxrQkFBVSxVQUFVLE9BQU8sV0FBVztBQUN0QyxrQkFBVSxjQUFjO0FBQ3hCLGtCQUFVLFdBQVc7QUFDckIsbUJBQVcsZ0JBQVc7QUFBQSxNQUN4QjtBQUFBLElBQ0Y7QUFFQSxtQkFBZSxZQUFZLE1BQTJCO0FBQ3BELFVBQUk7QUFDRixjQUFNLE1BQU0sTUFBTSxLQUFLLFlBQVk7QUFDbkMsY0FBTSxZQUFZLEtBQUssTUFBTSxLQUFLLElBQUksV0FBVyxHQUFHLEdBQUcsT0FBSyxPQUFPLGFBQWEsQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUM7QUFDNUYsdUJBQWUsZUFBZSxXQUFXO0FBQ3pDLGNBQU0sT0FBTyxNQUFNLGlCQUFxRTtBQUFBLFVBQ3RGLE1BQU07QUFBQSxVQUNOLFNBQVMsRUFBRSxXQUFXLFVBQVUsY0FBYyxZQUFZLGFBQWE7QUFBQSxRQUN6RSxDQUFDO0FBQ0QsWUFBSSxXQUFXLEtBQU0sT0FBTSxJQUFJLE1BQU0sT0FBTyxLQUFLLEtBQUssQ0FBQztBQUN2RCx3QkFBZ0IsS0FBSyxPQUFPO0FBQzVCLHVCQUFlLGFBQTRCLEtBQUssT0FBTyxLQUFLO0FBQzVELG1CQUFXLGFBQVE7QUFDbkIsa0JBQVUsVUFBVSxJQUFJLFNBQVM7QUFBQSxNQUNuQyxTQUFTLEtBQUs7QUFDWixtQkFBVyxlQUFlLFFBQVEsSUFBSSxVQUFVLFVBQVUsT0FBTztBQUFBLE1BQ25FLFVBQUU7QUFDQSxrQkFBVSxXQUFXO0FBQUEsTUFDdkI7QUFBQSxJQUNGO0FBRUEsWUFBUSxpQkFBaUIsU0FBUyxNQUFNO0FBQ3RDLFVBQUksY0FBZSxrQkFBaUIsRUFBRSxNQUFNLGtCQUFrQixTQUFTLEVBQUUsV0FBVyxlQUFlLFVBQVUsTUFBTSxhQUFhLEtBQUssRUFBRSxDQUFDO0FBQ3hJLGdCQUFVLFVBQVUsT0FBTyxTQUFTO0FBQ3BDLGtCQUFZO0FBQU8sWUFBTSxVQUFVLE9BQU8sTUFBTTtBQUNoRCxxQkFBZSxPQUFPO0FBQ3RCLGlCQUFXLEVBQUU7QUFBQSxJQUNmLENBQUM7QUFFRCxZQUFRLGlCQUFpQixTQUFTLE1BQU07QUFDdEMsVUFBSSxhQUFjLGdCQUFlLGFBQTRCLFlBQVk7QUFDekUsVUFBSSxjQUFlLGtCQUFpQixFQUFFLE1BQU0sa0JBQWtCLFNBQVMsRUFBRSxXQUFXLGVBQWUsVUFBVSxPQUFPLGFBQWEsS0FBSyxFQUFFLENBQUM7QUFDekksZ0JBQVUsVUFBVSxPQUFPLFNBQVM7QUFDcEMsaUJBQVcsYUFBYSxTQUFTO0FBQ2pDLGlCQUFXLE1BQU0sV0FBVyxFQUFFLEdBQUcsR0FBSTtBQUFBLElBQ3ZDLENBQUM7QUFFRCxhQUFTLFdBQVcsS0FBYSxNQUFNLElBQVU7QUFDL0MsZUFBUyxjQUFjO0FBQUssZUFBUyxZQUFZO0FBQUEsSUFDbkQ7QUFFQSxjQUFVLFlBQVksT0FBTztBQUFBLEVBQy9CO0FBSUEsV0FBUyxPQUFPLGFBQTRCO0FBRTFDLFFBQUksWUFBWSxhQUFhLFNBQVMsRUFBRztBQUN6QyxnQkFBWSxhQUFhLFdBQVcsR0FBRztBQUd2QyxVQUFNLFVBQVUsU0FBUyxjQUFjLEtBQUs7QUFDNUMsWUFBUSxNQUFNLFVBQVU7QUFHeEIsVUFBTSxpQkFBaUIsWUFBWSxRQUFRLDhEQUE4RCxLQUNwRyxZQUFZO0FBQ2pCLG9CQUFnQixzQkFBc0IsWUFBWSxPQUFPO0FBQ3pELFFBQUksQ0FBQyxRQUFRLGVBQWU7QUFFMUIsa0JBQVksZUFBZSxZQUFZLE9BQU87QUFBQSxJQUNoRDtBQUVBLFVBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxVQUFNLFNBQVMsS0FBSyxhQUFhLEVBQUUsTUFBTSxPQUFPLENBQUM7QUFFakQsUUFBSSxlQUE0QjtBQUNoQyxRQUFJLGdCQUErQjtBQUNuQyxRQUFJLFlBQVk7QUFFaEIsV0FBTyxZQUFZO0FBQUEsYUFDUixVQUFVO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtiLE1BQU0sSUFBSSxPQUFLLHNDQUFzQyxFQUFFLEdBQUcsaUJBQWlCLEVBQUUsS0FBSyxLQUFLLEVBQUUsS0FBSyxXQUFXLEVBQUUsS0FBSyxFQUFFLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWUzSCxVQUFNLE1BQVksT0FBTyxlQUFlLFFBQVE7QUFDaEQsVUFBTSxRQUFZLE9BQU8sZUFBZSxVQUFVO0FBQ2xELFVBQU0sYUFBYSxPQUFPLGVBQWUsWUFBWTtBQUNyRCxVQUFNLFdBQVksT0FBTyxlQUFlLFdBQVc7QUFDbkQsVUFBTSxVQUFZLE9BQU8sZUFBZSxVQUFVO0FBQ2xELFVBQU0sWUFBWSxPQUFPLGVBQWUsWUFBWTtBQUNwRCxVQUFNLFlBQVksT0FBTyxlQUFlLFdBQVc7QUFDbkQsVUFBTSxZQUFZLE9BQU8sZUFBZSxXQUFXO0FBRW5ELFdBQU8saUJBQW9DLFVBQVUsRUFBRSxRQUFRLFFBQU07QUFDbkUsU0FBRyxpQkFBaUIsU0FBUyxNQUFNO0FBQ2pDLGVBQU8saUJBQWlCLFVBQVUsRUFBRSxRQUFRLE9BQUssRUFBRSxVQUFVLE9BQU8sUUFBUSxDQUFDO0FBQzdFLFdBQUcsVUFBVSxJQUFJLFFBQVE7QUFDekIsV0FBRyxNQUFNLGFBQWEsR0FBRyxRQUFRLFNBQVM7QUFDMUMsV0FBRyxNQUFNLGNBQWMsR0FBRyxRQUFRLFNBQVM7QUFDM0MsdUJBQWUsR0FBRyxRQUFRO0FBQzFCLG1CQUFXLFdBQVc7QUFDdEIsaUJBQVMsY0FBYztBQUFJLGlCQUFTLFlBQVk7QUFDaEQsZ0JBQVEsVUFBVSxPQUFPLFNBQVM7QUFDbEMsa0JBQVUsVUFBVSxPQUFPLFNBQVM7QUFBQSxNQUN0QyxDQUFDO0FBQUEsSUFDSCxDQUFDO0FBRUQsUUFBSSxpQkFBaUIsU0FBUyxNQUFNO0FBQ2xDLFVBQUksV0FBVztBQUNiLG9CQUFZO0FBQ1osY0FBTSxVQUFVLE9BQU8sTUFBTTtBQUM3Qix1QkFBZSxJQUFJO0FBQUEsTUFDckIsT0FBTztBQUNMLG9CQUFZO0FBQ1osY0FBTSxVQUFVLElBQUksTUFBTTtBQUMxQixzQkFBYztBQUNkLHFCQUFhLE1BQU0sTUFBTTtBQUFFLHNCQUFZO0FBQU8sZ0JBQU0sVUFBVSxPQUFPLE1BQU07QUFBQSxRQUFHLENBQUM7QUFBQSxNQUNqRjtBQUFBLElBQ0YsQ0FBQztBQUVELGFBQVMsZ0JBQXNCO0FBQzdCLFlBQU0sT0FBTyxJQUFJLHNCQUFzQjtBQUN2QyxZQUFNLE1BQU0sU0FBUyxHQUFHLE9BQU8sY0FBYyxLQUFLLE1BQU0sQ0FBQztBQUN6RCxZQUFNLE1BQU0sT0FBTyxHQUFHLEtBQUssSUFBSSxLQUFLLE1BQU0sT0FBTyxhQUFhLEdBQUcsQ0FBQztBQUFBLElBQ3BFO0FBRUEsUUFBSSxlQUFlO0FBRW5CLGVBQVcsaUJBQWlCLFNBQVMsWUFBWTtBQUMvQyxVQUFJLENBQUMsYUFBYztBQUNuQixZQUFNLE9BQVEsWUFBNEIsVUFBVSxLQUFLO0FBQ3pELFVBQUksQ0FBQyxNQUFNO0FBQUUsa0JBQVUsMEJBQTBCLE9BQU87QUFBRztBQUFBLE1BQVE7QUFDbkUscUJBQWU7QUFDZixVQUFJLFdBQVc7QUFBTSxpQkFBVyxXQUFXO0FBQzNDLGdCQUFVLGlCQUFZO0FBQ3RCLGdCQUFVLFVBQVUsT0FBTyxTQUFTO0FBRXBDLFVBQUk7QUFDRixjQUFNLE9BQU8sTUFBTSxpQkFBa0U7QUFBQSxVQUNuRixNQUFNO0FBQUEsVUFDTixTQUFTO0FBQUEsWUFDUDtBQUFBLFlBQ0EsTUFBTTtBQUFBLFlBQ04sS0FBSyxFQUFFLFVBQVUsWUFBWSx1QkFBdUIsdUJBQXVCO0FBQUEsVUFDN0U7QUFBQSxRQUNGLENBQUM7QUFDRCxZQUFJLFdBQVcsS0FBTSxPQUFNLElBQUksTUFBTSxPQUFPLEtBQUssS0FBSyxDQUFDO0FBQ3ZELHdCQUFnQixLQUFLLE9BQU87QUFDNUIsdUJBQWUsYUFBNEIsS0FBSyxPQUFPLFdBQVc7QUFDbEUsa0JBQVUsZUFBVSxTQUFTO0FBQzdCLGtCQUFVLFVBQVUsSUFBSSxTQUFTO0FBQUEsTUFDbkMsU0FBUyxLQUFLO0FBQ1osY0FBTSxNQUFNLGVBQWUsUUFBUSxJQUFJLFVBQVU7QUFDakQsWUFBSSxJQUFJLFdBQVcsZ0JBQWdCLEdBQUc7QUFDcEMsa0JBQVEsVUFBVSxJQUFJLFNBQVM7QUFBRyxvQkFBVSxFQUFFO0FBQUEsUUFDaEQsT0FBTztBQUNMLG9CQUFVLEtBQUssT0FBTztBQUFBLFFBQ3hCO0FBQUEsTUFDRixVQUFFO0FBQ0EsWUFBSSxXQUFXO0FBQ2YsbUJBQVcsV0FBVyxpQkFBaUI7QUFBQSxNQUN6QztBQUFBLElBQ0YsQ0FBQztBQUVELGNBQVUsaUJBQWlCLFNBQVMsTUFBTTtBQUN4QyxVQUFJLGNBQWUsa0JBQWlCLEVBQUUsTUFBTSxZQUFZLFNBQVMsRUFBRSxXQUFXLGVBQWUsUUFBUSxXQUFXLEVBQUUsQ0FBQztBQUNuSCxnQkFBVSxVQUFVLE9BQU8sU0FBUztBQUNwQyxrQkFBWTtBQUFPLFlBQU0sVUFBVSxPQUFPLE1BQU07QUFDaEQscUJBQWUsSUFBSTtBQUNuQixnQkFBVSxFQUFFO0FBQUEsSUFDZCxDQUFDO0FBRUQsY0FBVSxpQkFBaUIsU0FBUyxNQUFNO0FBQ3hDLFVBQUksYUFBYyxnQkFBZSxhQUE0QixZQUFZO0FBQ3pFLFVBQUksY0FBZSxrQkFBaUIsRUFBRSxNQUFNLFlBQVksU0FBUyxFQUFFLFdBQVcsZUFBZSxRQUFRLFdBQVcsRUFBRSxDQUFDO0FBQ25ILGdCQUFVLFVBQVUsT0FBTyxTQUFTO0FBQ3BDLGdCQUFVLGFBQWEsU0FBUztBQUNoQyxpQkFBVyxNQUFNLFVBQVUsRUFBRSxHQUFHLEdBQUk7QUFBQSxJQUN0QyxDQUFDO0FBRUQsYUFBUyxVQUFVLEtBQWEsTUFBTSxJQUFVO0FBQzlDLGVBQVMsY0FBYztBQUFLLGVBQVMsWUFBWTtBQUFBLElBQ25EO0FBRUEsWUFBUSxZQUFZLElBQUk7QUFDeEIsb0JBQWdCLFNBQVMsV0FBVztBQUFBLEVBQ3RDO0FBSUEsTUFBTSxPQUFPLG9CQUFJLFFBQWlCO0FBRWxDLFdBQVMsVUFBVSxNQUFnQztBQUNqRCxTQUFLLGlCQUEwQixnQkFBZ0IsRUFBRSxRQUFRLENBQUMsU0FBUztBQUVqRSxVQUFJLENBQUMsS0FBSyxJQUFJLElBQUksR0FBRztBQUNuQixhQUFLLElBQUksSUFBSTtBQUNiLGVBQU8sSUFBSTtBQUFBLE1BQ2I7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBRUEsTUFBTSxXQUFXLElBQUksaUJBQWlCLE1BQU07QUFDMUMsd0JBQW9CLE1BQU0sVUFBVSxRQUFRLEdBQUcsRUFBRSxTQUFTLElBQUksQ0FBQztBQUFBLEVBQ2pFLENBQUM7QUFDRCxXQUFTLFFBQVEsU0FBUyxNQUFNLEVBQUUsV0FBVyxNQUFNLFNBQVMsS0FBSyxDQUFDO0FBQ2xFLFlBQVUsUUFBUTsiLAogICJuYW1lcyI6IFtdCn0K
