"use strict";(()=>{var _='div.ql-editor[contenteditable="true"]',S="data-wt-li-injected",O="social";var j=[{key:"professional",label:"Professional",color:"#0A66C2"},{key:"casual",label:"Casual",color:"#06B6D4"},{key:"friendly",label:"Friendly",color:"#F59E0B"},{key:"direct",label:"Direct",color:"#DC2626"},{key:"executive",label:"Executive",color:"#0F172A"}],A=[{key:"linkedin_comment",label:"Comment"},{key:"email",label:"Message"},{key:"reply",label:"Reply"}],z=`
  :host { display: inline-flex; align-items: center; }

  #wt-btn {
    display: inline-flex; align-items: center; gap: 5px;
    height: 28px; padding: 0 12px; border-radius: 9999px; border: none;
    background: #0A66C2; color: #fff;
    font: 500 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer; white-space: nowrap;
    transition: background 0.15s, box-shadow 0.15s;
  }
  #wt-btn:hover { background: #084fa0; box-shadow: 0 0 0 3px rgba(10,102,194,0.25); }
  #wt-btn:disabled { opacity: 0.6; cursor: default; box-shadow: none; }

  #wt-panel {
    position: fixed; z-index: 99999;
    background: #fff; border: 1px solid #E2E8F0; border-radius: 10px;
    box-shadow: 0 12px 32px rgba(0,0,0,0.14);
    padding: 14px 16px; width: 260px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: none;
  }
  #wt-panel.open { display: block; }

  .wt-title { font-size: 12px; font-weight: 600; color: #374151; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase; }
  .wt-tones { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 12px; }
  .wt-tone {
    padding: 4px 10px; border-radius: 9999px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151;
    cursor: pointer; transition: all 0.1s;
  }
  .wt-tone.active { color: #fff; border-color: transparent; }
  .wt-tone:hover:not(.active) { border-color: #93C5FD; }

  #wt-rewrite {
    width: 100%; height: 32px; border-radius: 8px; border: none;
    background: #0A66C2; color: #fff;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer;
  }
  #wt-rewrite:disabled { opacity: 0.45; cursor: default; }

  #wt-status { margin-top: 8px; font-size: 11px; text-align: center; min-height: 14px; }
  #wt-status.error { color: #EF4444; }
  #wt-status.success { color: #10B981; }

  #wt-actions { display: none; gap: 6px; margin-top: 8px; }
  #wt-actions.visible { display: flex; }
  .wt-action {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151;
    cursor: pointer;
  }
  .wt-action.accept { border-color: #10B981; color: #10B981; }
  .wt-action.reject { border-color: #EF4444; color: #EF4444; }

  #wt-limit { display: none; margin-top: 10px; padding: 10px 12px; border-radius: 8px;
    background: #FFF8F1; border: 1px solid #FED7AA; text-align: center; }
  #wt-limit.visible { display: block; }
  #wt-limit p { font-size: 11px; color: #92400E; margin: 0 0 8px; line-height: 1.4; }
  #wt-limit a {
    display: inline-block; padding: 5px 14px; border-radius: 9999px;
    background: #F59E0B; color: #fff; font-size: 11px; font-weight: 600;
    text-decoration: none;
  }
`,P=`
  :host { display: inline-flex; align-items: center; margin-left: 4px; }

  #wt-mic-btn {
    display: inline-flex; align-items: center; justify-content: center;
    width: 28px; height: 28px; border-radius: 9999px; border: none;
    background: transparent; color: #666; cursor: pointer;
    transition: background 0.15s, color 0.15s; font-size: 15px; line-height: 1;
  }
  #wt-mic-btn:hover { background: rgba(0,0,0,0.07); }
  #wt-mic-btn.recording { background: #FEE2E2; color: #DC2626;
    animation: wt-pulse 1.2s ease-in-out infinite; }
  @keyframes wt-pulse {
    0%, 100% { box-shadow: 0 0 0 0 rgba(220,38,38,0.4); }
    50%       { box-shadow: 0 0 0 5px rgba(220,38,38,0); }
  }
  #wt-mic-btn:disabled { opacity: 0.5; cursor: default; }

  #wt-voice-panel {
    position: fixed; z-index: 99999;
    background: #fff; border: 1px solid #E2E8F0; border-radius: 10px;
    box-shadow: 0 12px 32px rgba(0,0,0,0.14);
    padding: 14px 16px; width: 280px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: none;
  }
  #wt-voice-panel.open { display: block; }

  .wt-vt { font-size: 12px; font-weight: 600; color: #374151; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase; }
  #wt-record-btn {
    width: 100%; height: 34px; border-radius: 8px; border: none;
    background: #DC2626; color: #fff; cursor: pointer;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    margin-bottom: 10px;
  }
  #wt-record-btn.recording { background: #7F1D1D; }
  #wt-record-btn:disabled { opacity: 0.5; cursor: default; }
  .wt-otype-label { font-size: 11px; color: #6B7280; margin-bottom: 4px; }
  .wt-otypes { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 10px; }
  .wt-otype {
    padding: 3px 9px; border-radius: 9999px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 11px; color: #374151; cursor: pointer;
    transition: all 0.1s;
  }
  .wt-otype.active { background: #0A66C2; color: #fff; border-color: #0A66C2; }
  #wt-voice-status { font-size: 11px; text-align: center; min-height: 14px; color: #6B7280; }
  #wt-voice-status.error { color: #EF4444; }
  #wt-voice-actions { display: none; gap: 6px; margin-top: 8px; }
  #wt-voice-actions.visible { display: flex; }
  .wt-va {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #E8EAED;
    background: #fff; font-size: 12px; font-weight: 500; color: #374151; cursor: pointer;
  }
  .wt-va.accept { border-color: #10B981; color: #10B981; }
  .wt-va.reject { border-color: #EF4444; color: #EF4444; }
`;function h(i){return new Promise(n=>chrome.runtime.sendMessage(i,n))}function C(i,n){i.focus(),document.execCommand("selectAll",!1,void 0),document.execCommand("delete",!1,void 0);let p=n.split(`
`);for(let t=0;t<p.length;t++)p[t]&&document.execCommand("insertText",!1,p[t]),t<p.length-1&&document.execCommand("insertParagraph",!1,void 0)}function U(i,n){let p=document.createElement("span");p.style.cssText="display:inline-flex;align-items:center;margin-left:4px;";let t=p.attachShadow({mode:"open"});t.innerHTML=`
    <style>${P}</style>
    <button id="wt-mic-btn" title="Voice Twin">\u{1F399}</button>
    <div id="wt-voice-panel">
      <p class="wt-vt">Voice Twin</p>
      <div class="wt-otype-label">Output type</div>
      <div class="wt-otypes">
        ${A.map((o,s)=>`<button class="wt-otype${s===0?" active":""}" data-type="${o.key}">${o.label}</button>`).join("")}
      </div>
      <button id="wt-record-btn">\u{1F399} Start recording</button>
      <div id="wt-voice-status"></div>
      <div id="wt-voice-actions">
        <button class="wt-va accept" id="wt-va-keep">\u2713 Keep it</button>
        <button class="wt-va reject" id="wt-va-undo">\u2717 Undo</button>
      </div>
    </div>
  `;let r=t.getElementById("wt-mic-btn"),u=t.getElementById("wt-voice-panel"),l=t.getElementById("wt-record-btn"),m=t.getElementById("wt-voice-status"),b=t.getElementById("wt-voice-actions"),g=t.getElementById("wt-va-keep"),y=t.getElementById("wt-va-undo"),c=!1,T=A[0].key,d=null,x=!1,L=[],E=null,v="";t.querySelectorAll(".wt-otype").forEach(o=>{o.addEventListener("click",()=>{t.querySelectorAll(".wt-otype").forEach(s=>s.classList.remove("active")),o.classList.add("active"),T=o.dataset.type})}),r.addEventListener("click",()=>{c=!c,u.classList.toggle("open",c),c&&f()}),document.addEventListener("click",o=>{!p.contains(o.target)&&c&&(c=!1,u.classList.remove("open"))},!0);function f(){let o=r.getBoundingClientRect();u.style.bottom=`${window.innerHeight-o.top+4}px`,u.style.left=`${Math.min(o.left,window.innerWidth-296)}px`}l.addEventListener("click",async()=>{x?a():await e()});async function e(){try{let o=await navigator.mediaDevices.getUserMedia({audio:!0});L=[],d=new MediaRecorder(o,{mimeType:"audio/webm"}),d.ondataavailable=s=>{s.data.size>0&&L.push(s.data)},d.onstop=async()=>{o.getTracks().forEach(s=>s.stop()),await k(new Blob(L,{type:"audio/webm"}))},d.start(),x=!0,r.classList.add("recording"),l.classList.add("recording"),l.textContent="\u23F9 Stop recording",w("Recording\u2026"),b.classList.remove("visible"),setTimeout(()=>{x&&a()},6e4)}catch{w("Microphone access denied.","error")}}function a(){d&&x&&(d.stop(),x=!1,r.classList.remove("recording"),l.classList.remove("recording"),l.textContent="\u{1F399} Start recording",l.disabled=!0,w("Drafting\u2026"))}async function k(o){try{let s=await o.arrayBuffer(),D=new Uint8Array(s),I="";for(let M=0;M<D.length;M++)I+=String.fromCharCode(D[M]);let R=btoa(I);v=n.innerText.trim();let B=await h({type:"VOICE_DRAFT",payload:{audioData:R,mimeType:"audio/webm",outputType:T}});if("error"in B)throw new Error(String(B.error));E=B.result.id,C(n,B.result.draft),w("Done \u2713"),b.classList.add("visible")}catch(s){w(s instanceof Error?s.message:"Failed","error")}finally{l.disabled=!1}}g.addEventListener("click",()=>{E&&h({type:"VOICE_FEEDBACK",payload:{sessionId:E,accepted:!0,editedDraft:null}}),b.classList.remove("visible"),c=!1,u.classList.remove("open"),w("")}),y.addEventListener("click",()=>{v&&C(n,v),E&&h({type:"VOICE_FEEDBACK",payload:{sessionId:E,accepted:!1,editedDraft:null}}),b.classList.remove("visible"),w("Reverted.","success"),setTimeout(()=>w(""),2e3)});function w(o,s=""){m.textContent=o,m.className=s}i.appendChild(p)}function V(i){if(i.hasAttribute(S))return;i.setAttribute(S,"1");let n=document.createElement("div");n.style.cssText="display:flex;align-items:center;gap:4px;margin-top:8px;padding:0 2px;",(i.closest(".ql-container, .comments-comment-texteditor, .editor-content")??i.parentElement)?.insertAdjacentElement("afterend",n),n.parentElement||i.parentElement?.appendChild(n);let t=document.createElement("span"),r=t.attachShadow({mode:"open"}),u=null,l=null,m=!1;r.innerHTML=`
    <style>${z}</style>
    <button id="wt-btn" title="Humanize with Writing Twin AI">\u2728 Humanize</button>
    <div id="wt-panel">
      <p class="wt-title">Rewrite tone</p>
      <div class="wt-tones">
        ${j.map(e=>`<button class="wt-tone" data-tone="${e.key}" data-color="${e.color}">${e.label}</button>`).join("")}
      </div>
      <button id="wt-rewrite" disabled>Rewrite \u2192</button>
      <div id="wt-status"></div>
      <div id="wt-limit">
        <p>You've used all your free rewrites this month.</p>
        <a href="https://writingtwinai.com/pricing" target="_blank" rel="noopener">Upgrade to Pro \u2014 $5/mo</a>
      </div>
      <div id="wt-actions">
        <button class="wt-action accept" id="wt-accept">\u2713 Keep it</button>
        <button class="wt-action reject" id="wt-reject">\u2717 Undo</button>
      </div>
    </div>
  `;let b=r.getElementById("wt-btn"),g=r.getElementById("wt-panel"),y=r.getElementById("wt-rewrite"),c=r.getElementById("wt-status"),T=r.getElementById("wt-limit"),d=r.getElementById("wt-actions"),x=r.getElementById("wt-accept"),L=r.getElementById("wt-reject");r.querySelectorAll(".wt-tone").forEach(e=>{e.addEventListener("click",()=>{r.querySelectorAll(".wt-tone").forEach(a=>a.classList.remove("active")),e.classList.add("active"),e.style.background=e.dataset.color??"#0A66C2",e.style.borderColor=e.dataset.color??"#0A66C2",u=e.dataset.tone,y.disabled=!1,c.textContent="",c.className="",T.classList.remove("visible"),d.classList.remove("visible")})}),b.addEventListener("click",()=>{m=!m,g.classList.toggle("open",m),m&&E()}),document.addEventListener("click",e=>{!t.contains(e.target)&&m&&(m=!1,g.classList.remove("open"))},!0);function E(){let e=b.getBoundingClientRect();g.style.bottom=`${window.innerHeight-e.top+4}px`,g.style.left=`${Math.min(e.left,window.innerWidth-276)}px`}let v="";y.addEventListener("click",async()=>{if(!u)return;let e=i.innerText.trim();if(!e){f("Write something first.","error");return}v=e,b.disabled=!0,y.disabled=!0,f("Rewriting\u2026"),d.classList.remove("visible");try{let a=await h({type:"HUMANIZE",payload:{text:e,tone:u,ctx:{platform:"linkedin",context_twin_override:O}}});if("error"in a)throw new Error(String(a.error));l=a.result.id,C(i,a.result.output_text),f("Done \u2713","success"),d.classList.add("visible")}catch(a){let k=a instanceof Error?a.message:"Failed";k.startsWith("LIMIT_REACHED:")?(T.classList.add("visible"),f("")):f(k,"error")}finally{b.disabled=!1,y.disabled=u===null}}),x.addEventListener("click",()=>{l&&h({type:"FEEDBACK",payload:{rewriteId:l,action:"accepted"}}),d.classList.remove("visible"),m=!1,g.classList.remove("open"),f("")}),L.addEventListener("click",()=>{v&&C(i,v),l&&h({type:"FEEDBACK",payload:{rewriteId:l,action:"rejected"}}),d.classList.remove("visible"),f("Reverted.","success"),setTimeout(()=>f(""),2e3)});function f(e,a=""){c.textContent=e,c.className=a}n.appendChild(t),U(n,i)}var F=new WeakSet;function H(i){i.querySelectorAll(_).forEach(n=>{F.has(n)||(F.add(n),V(n))})}var $=new MutationObserver(()=>H(document));$.observe(document.body,{childList:!0,subtree:!0});H(document);})();
