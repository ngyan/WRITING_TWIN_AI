"use strict";
(() => {
  // src/content/outlook.ts
  var COMPOSE_BODY_SEL = [
    'div[role="textbox"][aria-multiline="true"]',
    'div[contenteditable="true"][aria-multiline="true"]'
  ].join(", ");
  var SEND_BUTTON_SEL = [
    'button[aria-label^="Send"]',
    'button[aria-label*=" (Ctrl+Enter)"]',
    'button[aria-label*=" (\u2318+Enter)"]',
    'button[data-testid*="sendButton" i]'
  ].join(", ");
  var HOST_ATTR = "data-wt-ol-injected";
  var TONES = [
    { key: "professional", label: "Professional", color: "#4F46E5" },
    { key: "casual", label: "Casual", color: "#06B6D4" },
    { key: "friendly", label: "Friendly", color: "#F59E0B" },
    { key: "direct", label: "Direct", color: "#DC2626" },
    { key: "diplomatic", label: "Diplomatic", color: "#7C3AED" },
    { key: "executive", label: "Executive", color: "#0F172A" }
  ];
  var VOICE_OUTPUT_TYPES = [
    { key: "reply", label: "Reply" },
    { key: "email", label: "Email" },
    { key: "customer_update", label: "Customer Update" },
    { key: "jira_ticket", label: "Jira Ticket" },
    { key: "technical_report", label: "Tech Report" }
  ];
  var BASE_CSS = `
  :host { display: inline-flex; align-items: center; margin: 0 4px; }

  /* \u2500\u2500 Humanize button \u2500\u2500 */
  #wt-btn {
    display: inline-flex; align-items: center; gap: 5px;
    height: 26px; padding: 0 11px; border-radius: 9999px; border: none;
    background: #4F46E5; color: #fff;
    font: 500 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer; white-space: nowrap; transition: background 0.15s, box-shadow 0.15s;
  }
  #wt-btn:hover  { background: #3F37C9; box-shadow: 0 0 0 3px rgba(79,70,229,0.25); }
  #wt-btn:disabled { opacity: 0.6; cursor: default; box-shadow: none; }

  /* \u2500\u2500 Mic button \u2500\u2500 */
  #wt-mic-btn {
    display: inline-flex; align-items: center; justify-content: center;
    width: 26px; height: 26px; border-radius: 9999px; border: none;
    background: transparent; color: #323130; cursor: pointer;
    font-size: 14px; line-height: 1; margin-left: 3px;
    transition: background 0.15s;
  }
  #wt-mic-btn:hover { background: rgba(0,0,0,0.06); }
  #wt-mic-btn.recording {
    background: #FEE2E2; color: #DC2626;
    animation: wt-pulse 1.2s ease-in-out infinite;
  }
  @keyframes wt-pulse {
    0%, 100% { box-shadow: 0 0 0 0 rgba(220,38,38,0.4); }
    50%       { box-shadow: 0 0 0 5px rgba(220,38,38,0); }
  }

  /* \u2500\u2500 Shared panel \u2500\u2500 */
  .wt-panel {
    position: fixed; z-index: 100000;
    background: #fff; border: 1px solid #EDEBE9; border-radius: 10px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.18);
    padding: 14px 16px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: none;
  }
  .wt-panel.open { display: block; }

  /* \u2500\u2500 Humanize panel \u2500\u2500 */
  #wt-panel { width: 260px; }
  .wt-title {
    font-size: 12px; font-weight: 600; color: #323130; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase;
  }
  .wt-tones { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 12px; }
  .wt-tone {
    padding: 4px 10px; border-radius: 9999px; border: 1.5px solid #EDEBE9;
    background: #fff; font-size: 12px; font-weight: 500; color: #323130; cursor: pointer;
    transition: all 0.1s;
  }
  .wt-tone.active { color: #fff; border-color: transparent; }
  .wt-tone:hover:not(.active) { border-color: #9BA0FF; }

  #wt-rewrite {
    width: 100%; height: 32px; border-radius: 8px; border: none;
    background: #4F46E5; color: #fff;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer;
  }
  #wt-rewrite:disabled { opacity: 0.45; cursor: default; }

  #wt-status {
    margin-top: 8px; font-size: 11px; text-align: center; min-height: 14px;
  }
  #wt-status.error   { color: #A4262C; }
  #wt-status.success { color: #107C10; }

  #wt-limit {
    display: none; margin-top: 10px; padding: 10px 12px; border-radius: 8px;
    background: #FFF8F1; border: 1px solid #FED7AA; text-align: center;
  }
  #wt-limit.visible { display: block; }
  #wt-limit p { font-size: 11px; color: #92400E; margin: 0 0 8px; line-height: 1.4; }
  #wt-limit a {
    display: inline-block; padding: 5px 14px; border-radius: 9999px;
    background: #F59E0B; color: #fff; font-size: 11px; font-weight: 600;
    text-decoration: none;
  }

  #wt-actions { display: none; gap: 6px; margin-top: 8px; }
  #wt-actions.visible { display: flex; }
  .wt-action {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #EDEBE9;
    background: #fff; font-size: 12px; font-weight: 500; color: #323130; cursor: pointer;
  }
  .wt-action.accept { border-color: #107C10; color: #107C10; }
  .wt-action.reject { border-color: #A4262C; color: #A4262C; }

  /* \u2500\u2500 Voice panel \u2500\u2500 */
  #wt-voice-panel { width: 280px; }
  .wt-vt { font-size: 12px; font-weight: 600; color: #323130; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase; }
  .wt-otype-label { font-size: 11px; color: #605E5C; margin-bottom: 4px; }
  .wt-otypes { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 10px; }
  .wt-otype {
    padding: 3px 9px; border-radius: 9999px; border: 1.5px solid #EDEBE9;
    background: #fff; font-size: 11px; color: #323130; cursor: pointer; transition: all 0.1s;
  }
  .wt-otype.active { background: #4F46E5; color: #fff; border-color: #4F46E5; }
  #wt-record-btn {
    width: 100%; height: 32px; border-radius: 8px; border: none;
    background: #DC2626; color: #fff; cursor: pointer; margin-bottom: 10px;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }
  #wt-record-btn.recording { background: #7F1D1D; }
  #wt-record-btn:disabled  { opacity: 0.5; cursor: default; }
  #wt-voice-status { font-size: 11px; text-align: center; min-height: 14px; color: #605E5C; }
  #wt-voice-status.error { color: #A4262C; }
  #wt-voice-actions { display: none; gap: 6px; margin-top: 8px; }
  #wt-voice-actions.visible { display: flex; }
  .wt-va {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #EDEBE9;
    background: #fff; font-size: 12px; font-weight: 500; color: #323130; cursor: pointer;
  }
  .wt-va.accept { border-color: #107C10; color: #107C10; }
  .wt-va.reject { border-color: #A4262C; color: #A4262C; }
`;
  function buildOutlookContext(composeBody) {
    let el = composeBody;
    let container = null;
    for (let i = 0; i < 25; i++) {
      if (!el) break;
      if (el.querySelector('[role="list"][aria-label*="To" i], input[aria-label*="To" i]')) {
        container = el;
        break;
      }
      el = el.parentElement;
    }
    let recipientDomain;
    let threadSubject;
    if (container) {
      const chip = container.querySelector(
        '[data-email], [title*="@"], [aria-label*="@"]'
      );
      if (chip) {
        const email = chip.getAttribute("data-email") ?? chip.getAttribute("title") ?? chip.getAttribute("aria-label") ?? "";
        if (email.includes("@")) recipientDomain = email.split("@")[1].split(">")[0].toLowerCase().trim();
      }
      const subjectEl = container.querySelector(
        'input[aria-label*="Subject" i], input[placeholder*="Subject" i]'
      );
      if (subjectEl?.value) threadSubject = subjectEl.value;
    }
    return { platform: "outlook", recipient_domain: recipientDomain, thread_subject: threadSubject };
  }
  function inject(composeBody) {
    const sendBtn = findSendButton(composeBody);
    if (!sendBtn) return;
    const toolbar = sendBtn.closest('[role="toolbar"]') ?? sendBtn.closest('[role="group"]') ?? sendBtn.parentElement;
    if (!toolbar || toolbar.hasAttribute(HOST_ATTR)) return;
    toolbar.setAttribute(HOST_ATTR, "1");
    const host = document.createElement("span");
    const shadow = host.attachShadow({ mode: "open" });
    let selectedTone = null;
    let lastRewriteId = null;
    let panelOpen = false;
    let voicePanelOpen = false;
    let selectedOutputType = "reply";
    let detectedContextTwin = "professional";
    let contextOverride;
    let recorder = null;
    let recording = false;
    let audioChunks = [];
    let lastVoiceSessionId = null;
    let originalText = "";
    let originalVoiceText = "";
    shadow.innerHTML = `
    <style>${BASE_CSS}
    #wt-ctx-badge {
      display: inline-flex; align-items: center;
      height: 18px; padding: 0 7px; border-radius: 9999px;
      background: #EEF2FF; color: #4338CA; font-size: 10px; font-weight: 600;
      margin-left: 4px; cursor: pointer; white-space: nowrap; transition: background 0.1s;
    }
    #wt-ctx-badge:hover { background: #E0E7FF; }
    #wt-ctx-badge.hidden { display: none; }
    </style>

    <button id="wt-btn" title="Humanize with Writing Twin AI (Ctrl+Shift+H)">\u2728 Humanize</button>
    <span id="wt-ctx-badge" class="hidden" title="Detected context \u2014 click to override"></span>
    <button id="wt-mic-btn" title="Voice Twin \u2014 speak your email (Ctrl+Shift+V)">\u{1F399}</button>

    <div id="wt-panel" class="wt-panel">
      <p class="wt-title">Rewrite tone</p>
      <div class="wt-tones">
        ${TONES.map((t) => `<button class="wt-tone" data-tone="${t.key}" data-color="${t.color}">${t.label}</button>`).join("")}
      </div>
      <button id="wt-rewrite" disabled>Rewrite \u2192</button>
      <div id="wt-status"></div>
      <div id="wt-limit">
        <p>You've used all your free rewrites this month.</p>
        <a href="https://writingtwinai.com/pricing" target="_blank" rel="noopener">Upgrade to Pro \u2014 $5/mo</a>
      </div>
      <div id="wt-actions">
        <button class="wt-action accept" id="wt-accept">\u2713 Keep it</button>
        <button class="wt-action reject" id="wt-reject">\u2717 Undo</button>
      </div>
    </div>

    <div id="wt-voice-panel" class="wt-panel">
      <p class="wt-vt">Voice Twin</p>
      <div class="wt-otype-label">Output type</div>
      <div class="wt-otypes">
        ${VOICE_OUTPUT_TYPES.map(
      (o, i) => `<button class="wt-otype${i === 0 ? " active" : ""}" data-type="${o.key}">${o.label}</button>`
    ).join("")}
      </div>
      <button id="wt-record-btn">\u{1F399} Start recording</button>
      <div id="wt-voice-status"></div>
      <div id="wt-voice-actions">
        <button class="wt-va accept" id="wt-va-keep">\u2713 Keep it</button>
        <button class="wt-va reject" id="wt-va-undo">\u2717 Undo</button>
      </div>
    </div>
  `;
    const btn = shadow.getElementById("wt-btn");
    const ctxBadge = shadow.getElementById("wt-ctx-badge");
    const micBtn = shadow.getElementById("wt-mic-btn");
    const panel = shadow.getElementById("wt-panel");
    const voicePanel = shadow.getElementById("wt-voice-panel");
    const rewriteBtn = shadow.getElementById("wt-rewrite");
    const statusEl = shadow.getElementById("wt-status");
    const limitEl = shadow.getElementById("wt-limit");
    const actionsEl = shadow.getElementById("wt-actions");
    const acceptBtn = shadow.getElementById("wt-accept");
    const rejectBtn = shadow.getElementById("wt-reject");
    const recordBtn = shadow.getElementById("wt-record-btn");
    const vStatusEl = shadow.getElementById("wt-voice-status");
    const vActionsEl = shadow.getElementById("wt-voice-actions");
    const vKeepBtn = shadow.getElementById("wt-va-keep");
    const vUndoBtn = shadow.getElementById("wt-va-undo");
    shadow.querySelectorAll(".wt-tone").forEach((tb) => {
      tb.addEventListener("click", () => {
        shadow.querySelectorAll(".wt-tone").forEach((b) => b.classList.remove("active"));
        tb.classList.add("active");
        tb.style.background = tb.dataset.color ?? "#4F46E5";
        tb.style.borderColor = tb.dataset.color ?? "#4F46E5";
        selectedTone = tb.dataset.tone;
        rewriteBtn.disabled = false;
        setStatus("");
        limitEl.classList.remove("visible");
        actionsEl.classList.remove("visible");
      });
    });
    shadow.querySelectorAll(".wt-otype").forEach((ob) => {
      ob.addEventListener("click", () => {
        shadow.querySelectorAll(".wt-otype").forEach((b) => b.classList.remove("active"));
        ob.classList.add("active");
        selectedOutputType = ob.dataset.type;
      });
    });
    setTimeout(() => {
      const ctx = buildOutlookContext(composeBody);
      sendToBackground({
        type: "DETECT_CONTEXT",
        payload: ctx
      }).then((resp) => {
        if ("result" in resp && resp.result?.context_twin) {
          detectedContextTwin = resp.result.context_twin;
          const label = detectedContextTwin.charAt(0).toUpperCase() + detectedContextTwin.slice(1);
          ctxBadge.textContent = label;
          ctxBadge.classList.remove("hidden");
        }
      }).catch(() => {
      });
    }, 800);
    const CONTEXT_CYCLE = ["professional", "customer", "technical", "escalation", "casual"];
    ctxBadge.addEventListener("click", () => {
      const current = contextOverride ?? detectedContextTwin;
      const idx = CONTEXT_CYCLE.indexOf(current);
      contextOverride = CONTEXT_CYCLE[(idx + 1) % CONTEXT_CYCLE.length];
      const label = contextOverride.charAt(0).toUpperCase() + contextOverride.slice(1);
      ctxBadge.textContent = label;
      sendToBackground({
        type: "CONTEXT_OVERRIDE",
        payload: {
          detected_context: detectedContextTwin,
          selected_context: contextOverride,
          platform: "outlook"
        }
      });
    });
    btn.addEventListener("click", () => {
      panelOpen = !panelOpen;
      if (panelOpen) {
        voicePanelOpen = false;
        voicePanel.classList.remove("open");
      }
      panel.classList.toggle("open", panelOpen);
      if (panelOpen) positionPanel(btn, panel);
    });
    micBtn.addEventListener("click", () => {
      voicePanelOpen = !voicePanelOpen;
      if (voicePanelOpen) {
        panelOpen = false;
        panel.classList.remove("open");
      }
      voicePanel.classList.toggle("open", voicePanelOpen);
      if (voicePanelOpen) positionPanel(micBtn, voicePanel);
    });
    document.addEventListener("click", (e) => {
      if (!host.contains(e.target)) {
        panelOpen = false;
        panel.classList.remove("open");
        voicePanelOpen = false;
        voicePanel.classList.remove("open");
      }
    }, true);
    function positionPanel(anchor, p) {
      const rect = anchor.getBoundingClientRect();
      const panelWidth = parseInt(p.style.width || "260");
      p.style.bottom = `${window.innerHeight - rect.top + 6}px`;
      p.style.left = `${Math.min(rect.left, window.innerWidth - panelWidth - 20)}px`;
    }
    rewriteBtn.addEventListener("click", async () => {
      if (!selectedTone) return;
      const text = readCompose(composeBody);
      if (!text) {
        setStatus("Write something first.", "error");
        return;
      }
      originalText = text;
      btn.disabled = true;
      rewriteBtn.disabled = true;
      setStatus("Rewriting\u2026");
      actionsEl.classList.remove("visible");
      try {
        const baseCtx = buildOutlookContext(composeBody);
        const resp = await sendToBackground({
          type: "HUMANIZE",
          payload: { text, tone: selectedTone, ctx: { ...baseCtx, context_twin_override: contextOverride } }
        });
        if ("error" in resp) throw new Error(String(resp.error));
        lastRewriteId = resp.result.id;
        writeCompose(composeBody, resp.result.output_text);
        setStatus("Done \u2713", "success");
        actionsEl.classList.add("visible");
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Failed";
        if (msg.startsWith("LIMIT_REACHED:")) {
          limitEl.classList.add("visible");
          setStatus("");
        } else {
          setStatus(msg, "error");
        }
      } finally {
        btn.disabled = false;
        rewriteBtn.disabled = selectedTone === null;
      }
    });
    acceptBtn.addEventListener("click", () => {
      if (lastRewriteId) sendToBackground({ type: "FEEDBACK", payload: { rewriteId: lastRewriteId, action: "accepted" } });
      actionsEl.classList.remove("visible");
      panelOpen = false;
      panel.classList.remove("open");
      setStatus("");
    });
    rejectBtn.addEventListener("click", () => {
      if (originalText) writeCompose(composeBody, originalText);
      if (lastRewriteId) sendToBackground({ type: "FEEDBACK", payload: { rewriteId: lastRewriteId, action: "rejected" } });
      actionsEl.classList.remove("visible");
      setStatus("Reverted.", "success");
      setTimeout(() => setStatus(""), 2e3);
    });
    function setStatus(msg, cls = "") {
      statusEl.textContent = msg;
      statusEl.className = cls;
    }
    recordBtn.addEventListener("click", async () => {
      if (!recording) await startRecording();
      else stopRecording();
    });
    async function startRecording() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        audioChunks = [];
        recorder = new MediaRecorder(stream, { mimeType: "audio/webm" });
        recorder.ondataavailable = (e) => {
          if (e.data.size > 0) audioChunks.push(e.data);
        };
        recorder.onstop = async () => {
          stream.getTracks().forEach((t) => t.stop());
          await submitVoice(new Blob(audioChunks, { type: "audio/webm" }));
        };
        recorder.start();
        recording = true;
        micBtn.classList.add("recording");
        recordBtn.classList.add("recording");
        recordBtn.textContent = "\u23F9 Stop recording";
        setVoiceStatus("Recording\u2026");
        vActionsEl.classList.remove("visible");
        setTimeout(() => {
          if (recording) stopRecording();
        }, 6e4);
      } catch {
        setVoiceStatus("Microphone access denied.", "error");
      }
    }
    function stopRecording() {
      if (recorder && recording) {
        recorder.stop();
        recording = false;
        micBtn.classList.remove("recording");
        recordBtn.classList.remove("recording");
        recordBtn.textContent = "\u{1F399} Start recording";
        recordBtn.disabled = true;
        setVoiceStatus("Drafting\u2026");
      }
    }
    async function submitVoice(blob) {
      try {
        const ab = await blob.arrayBuffer();
        const u8 = new Uint8Array(ab);
        let bin = "";
        for (let i = 0; i < u8.length; i++) bin += String.fromCharCode(u8[i]);
        const audioData = btoa(bin);
        originalVoiceText = readCompose(composeBody);
        const resp = await sendToBackground({
          type: "VOICE_DRAFT",
          payload: { audioData, mimeType: "audio/webm", outputType: selectedOutputType }
        });
        if ("error" in resp) throw new Error(String(resp.error));
        lastVoiceSessionId = resp.result.id;
        writeCompose(composeBody, resp.result.draft);
        setVoiceStatus("Done \u2713");
        vActionsEl.classList.add("visible");
      } catch (err) {
        setVoiceStatus(err instanceof Error ? err.message : "Failed", "error");
      } finally {
        recordBtn.disabled = false;
      }
    }
    vKeepBtn.addEventListener("click", () => {
      if (lastVoiceSessionId) sendToBackground({ type: "VOICE_FEEDBACK", payload: { sessionId: lastVoiceSessionId, accepted: true, editedDraft: null } });
      vActionsEl.classList.remove("visible");
      voicePanelOpen = false;
      voicePanel.classList.remove("open");
      setVoiceStatus("");
    });
    vUndoBtn.addEventListener("click", () => {
      if (originalVoiceText) writeCompose(composeBody, originalVoiceText);
      if (lastVoiceSessionId) sendToBackground({ type: "VOICE_FEEDBACK", payload: { sessionId: lastVoiceSessionId, accepted: false, editedDraft: null } });
      vActionsEl.classList.remove("visible");
      setVoiceStatus("Reverted.", "success");
      setTimeout(() => setVoiceStatus(""), 2e3);
    });
    function setVoiceStatus(msg, cls = "") {
      vStatusEl.textContent = msg;
      vStatusEl.className = cls;
    }
    toolbar.insertBefore(host, sendBtn);
  }
  function findSendButton(composeBody) {
    let el = composeBody;
    for (let i = 0; i < 30; i++) {
      if (!el) break;
      const send = el.querySelector(SEND_BUTTON_SEL);
      if (send) return send;
      el = el.parentElement;
    }
    return null;
  }
  function readCompose(el) {
    return el.innerText.trim();
  }
  function writeCompose(el, text) {
    el.focus();
    document.execCommand("selectAll", false, void 0);
    document.execCommand("delete", false, void 0);
    const lines = text.split("\n");
    for (let i = 0; i < lines.length; i++) {
      if (lines[i]) document.execCommand("insertText", false, lines[i]);
      if (i < lines.length - 1) document.execCommand("insertParagraph", false, void 0);
    }
  }
  function sendToBackground(message) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(message, resolve);
    });
  }
  var seen = /* @__PURE__ */ new WeakSet();
  function tryInject(root) {
    root.querySelectorAll(COMPOSE_BODY_SEL).forEach((body) => {
      if (!findSendButton(body)) return;
      if (!seen.has(body)) {
        seen.add(body);
        inject(body);
      }
    });
  }
  var observer = new MutationObserver(() => tryInject(document));
  observer.observe(document.body, { childList: true, subtree: true });
  setInterval(() => tryInject(document), 1e3);
  tryInject(document);
  document.addEventListener("keydown", (e) => {
    if (!(e.ctrlKey || e.metaKey) || !e.shiftKey) return;
    const toolbarEl = document.querySelector(`[${HOST_ATTR}]`);
    if (!toolbarEl) return;
    const hosts = Array.from(toolbarEl.children).filter((c) => c.shadowRoot);
    if (e.key === "H") {
      e.preventDefault();
      hosts[0]?.shadowRoot?.getElementById("wt-btn")?.click();
    }
    if (e.key === "V") {
      e.preventDefault();
      hosts[0]?.shadowRoot?.getElementById("wt-mic-btn")?.click();
    }
  });
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vc3JjL2NvbnRlbnQvb3V0bG9vay50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLyoqXG4gKiBPdXRsb29rIFdlYiBBcHAgY29udGVudCBzY3JpcHQgXHUyMDE0IGluamVjdHMgXHUyNzI4IEh1bWFuaXplICsgXHVEODNDXHVERjk5IFZvaWNlIFR3aW5cbiAqIGludG8gY29tcG9zZSB3aW5kb3dzIG9uIG91dGxvb2subGl2ZS5jb20gYW5kIG91dGxvb2sub2ZmaWNlLmNvbS5cbiAqXG4gKiBPdXRsb29rIHVzZXMgUmVhY3Qgc28gdGhlIERPTSBtdXRhdGVzIGhlYXZpbHkgYW5kIGFzeW5jaHJvbm91c2x5LlxuICogU3RyYXRlZ3k6IE11dGF0aW9uT2JzZXJ2ZXIgKHByaW1hcnkpICsgMSBzIHBvbGxpbmcgaW50ZXJ2YWwgKGZhbGxiYWNrKS5cbiAqL1xuaW1wb3J0IHR5cGUgeyBUb25lLCBSZXdyaXRlUmVzcG9uc2UsIFZvaWNlT3V0cHV0VHlwZSwgVm9pY2VEcmFmdFJlc3BvbnNlLCBIdW1hbml6ZUNvbnRleHQgfSBmcm9tICcuLi9saWIvYXBpJztcblxuLy8gXHUyNTAwXHUyNTAwIFNlbGVjdG9ycyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbi8vXG4vLyBPdXRsb29rIGFsd2F5cyBnaXZlcyB0aGUgY29tcG9zZSBib2R5IHJvbGU9XCJ0ZXh0Ym94XCIgKyBhcmlhLW11bHRpbGluZT1cInRydWVcIi5cbi8vIFdlIG1hdGNoIGJyb2FkbHkgc28gbG9jYWxlIHZhcmlhbnRzIChcIk1lc3NhZ2UgYm9keVwiLCBcIkNvcnBvIGRvIGVtYWlsXCIsIGV0Yy4pIGFsbCB3b3JrLlxuY29uc3QgQ09NUE9TRV9CT0RZX1NFTCA9IFtcbiAgJ2Rpdltyb2xlPVwidGV4dGJveFwiXVthcmlhLW11bHRpbGluZT1cInRydWVcIl0nLFxuICAnZGl2W2NvbnRlbnRlZGl0YWJsZT1cInRydWVcIl1bYXJpYS1tdWx0aWxpbmU9XCJ0cnVlXCJdJyxcbl0uam9pbignLCAnKTtcblxuLy8gU2VuZCBidXR0b24gXHUyMDE0IE91dGxvb2sgc3VyZmFjZXMgYXJpYS1sYWJlbCB3aXRoIG9wdGlvbmFsIGtleWJvYXJkLXNob3J0Y3V0IHN1ZmZpeFxuLy8gZS5nLiBcIlNlbmRcIiwgXCJTZW5kIChDdHJsK0VudGVyKVwiLCBcIlZlcnplbmRlbiAoQ3RybCtFbnRlcilcIlxuY29uc3QgU0VORF9CVVRUT05fU0VMID0gW1xuICAnYnV0dG9uW2FyaWEtbGFiZWxePVwiU2VuZFwiXScsXG4gICdidXR0b25bYXJpYS1sYWJlbCo9XCIgKEN0cmwrRW50ZXIpXCJdJyxcbiAgJ2J1dHRvblthcmlhLWxhYmVsKj1cIiAoXHUyMzE4K0VudGVyKVwiXScsXG4gICdidXR0b25bZGF0YS10ZXN0aWQqPVwic2VuZEJ1dHRvblwiIGldJyxcbl0uam9pbignLCAnKTtcblxuY29uc3QgSE9TVF9BVFRSID0gJ2RhdGEtd3Qtb2wtaW5qZWN0ZWQnO1xuXG4vLyBcdTI1MDBcdTI1MDAgVG9uZXMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmNvbnN0IFRPTkVTOiB7IGtleTogVG9uZTsgbGFiZWw6IHN0cmluZzsgY29sb3I6IHN0cmluZyB9W10gPSBbXG4gIHsga2V5OiAncHJvZmVzc2lvbmFsJywgbGFiZWw6ICdQcm9mZXNzaW9uYWwnLCBjb2xvcjogJyM0RjQ2RTUnIH0sXG4gIHsga2V5OiAnY2FzdWFsJywgICAgICAgbGFiZWw6ICdDYXN1YWwnLCAgICAgICBjb2xvcjogJyMwNkI2RDQnIH0sXG4gIHsga2V5OiAnZnJpZW5kbHknLCAgICAgbGFiZWw6ICdGcmllbmRseScsICAgICBjb2xvcjogJyNGNTlFMEInIH0sXG4gIHsga2V5OiAnZGlyZWN0JywgICAgICAgbGFiZWw6ICdEaXJlY3QnLCAgICAgICBjb2xvcjogJyNEQzI2MjYnIH0sXG4gIHsga2V5OiAnZGlwbG9tYXRpYycsICAgbGFiZWw6ICdEaXBsb21hdGljJywgICBjb2xvcjogJyM3QzNBRUQnIH0sXG4gIHsga2V5OiAnZXhlY3V0aXZlJywgICAgbGFiZWw6ICdFeGVjdXRpdmUnLCAgICBjb2xvcjogJyMwRjE3MkEnIH0sXG5dO1xuXG4vLyBcdTI1MDBcdTI1MDAgVm9pY2Ugb3V0cHV0IHR5cGVzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5jb25zdCBWT0lDRV9PVVRQVVRfVFlQRVM6IHsga2V5OiBWb2ljZU91dHB1dFR5cGU7IGxhYmVsOiBzdHJpbmcgfVtdID0gW1xuICB7IGtleTogJ3JlcGx5JywgICAgICAgICAgICBsYWJlbDogJ1JlcGx5JyB9LFxuICB7IGtleTogJ2VtYWlsJywgICAgICAgICAgICBsYWJlbDogJ0VtYWlsJyB9LFxuICB7IGtleTogJ2N1c3RvbWVyX3VwZGF0ZScsICBsYWJlbDogJ0N1c3RvbWVyIFVwZGF0ZScgfSxcbiAgeyBrZXk6ICdqaXJhX3RpY2tldCcsICAgICAgbGFiZWw6ICdKaXJhIFRpY2tldCcgfSxcbiAgeyBrZXk6ICd0ZWNobmljYWxfcmVwb3J0JywgbGFiZWw6ICdUZWNoIFJlcG9ydCcgfSxcbl07XG5cbi8vIFx1MjUwMFx1MjUwMCBTaGFkb3cgRE9NIENTUyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuY29uc3QgQkFTRV9DU1MgPSBgXG4gIDpob3N0IHsgZGlzcGxheTogaW5saW5lLWZsZXg7IGFsaWduLWl0ZW1zOiBjZW50ZXI7IG1hcmdpbjogMCA0cHg7IH1cblxuICAvKiBcdTI1MDBcdTI1MDAgSHVtYW5pemUgYnV0dG9uIFx1MjUwMFx1MjUwMCAqL1xuICAjd3QtYnRuIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtZmxleDsgYWxpZ24taXRlbXM6IGNlbnRlcjsgZ2FwOiA1cHg7XG4gICAgaGVpZ2h0OiAyNnB4OyBwYWRkaW5nOiAwIDExcHg7IGJvcmRlci1yYWRpdXM6IDk5OTlweDsgYm9yZGVyOiBub25lO1xuICAgIGJhY2tncm91bmQ6ICM0RjQ2RTU7IGNvbG9yOiAjZmZmO1xuICAgIGZvbnQ6IDUwMCAxMnB4LzEgLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCBcIlNlZ29lIFVJXCIsIFJvYm90bywgc2Fucy1zZXJpZjtcbiAgICBjdXJzb3I6IHBvaW50ZXI7IHdoaXRlLXNwYWNlOiBub3dyYXA7IHRyYW5zaXRpb246IGJhY2tncm91bmQgMC4xNXMsIGJveC1zaGFkb3cgMC4xNXM7XG4gIH1cbiAgI3d0LWJ0bjpob3ZlciAgeyBiYWNrZ3JvdW5kOiAjM0YzN0M5OyBib3gtc2hhZG93OiAwIDAgMCAzcHggcmdiYSg3OSw3MCwyMjksMC4yNSk7IH1cbiAgI3d0LWJ0bjpkaXNhYmxlZCB7IG9wYWNpdHk6IDAuNjsgY3Vyc29yOiBkZWZhdWx0OyBib3gtc2hhZG93OiBub25lOyB9XG5cbiAgLyogXHUyNTAwXHUyNTAwIE1pYyBidXR0b24gXHUyNTAwXHUyNTAwICovXG4gICN3dC1taWMtYnRuIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtZmxleDsgYWxpZ24taXRlbXM6IGNlbnRlcjsganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgd2lkdGg6IDI2cHg7IGhlaWdodDogMjZweDsgYm9yZGVyLXJhZGl1czogOTk5OXB4OyBib3JkZXI6IG5vbmU7XG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7IGNvbG9yOiAjMzIzMTMwOyBjdXJzb3I6IHBvaW50ZXI7XG4gICAgZm9udC1zaXplOiAxNHB4OyBsaW5lLWhlaWdodDogMTsgbWFyZ2luLWxlZnQ6IDNweDtcbiAgICB0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kIDAuMTVzO1xuICB9XG4gICN3dC1taWMtYnRuOmhvdmVyIHsgYmFja2dyb3VuZDogcmdiYSgwLDAsMCwwLjA2KTsgfVxuICAjd3QtbWljLWJ0bi5yZWNvcmRpbmcge1xuICAgIGJhY2tncm91bmQ6ICNGRUUyRTI7IGNvbG9yOiAjREMyNjI2O1xuICAgIGFuaW1hdGlvbjogd3QtcHVsc2UgMS4ycyBlYXNlLWluLW91dCBpbmZpbml0ZTtcbiAgfVxuICBAa2V5ZnJhbWVzIHd0LXB1bHNlIHtcbiAgICAwJSwgMTAwJSB7IGJveC1zaGFkb3c6IDAgMCAwIDAgcmdiYSgyMjAsMzgsMzgsMC40KTsgfVxuICAgIDUwJSAgICAgICB7IGJveC1zaGFkb3c6IDAgMCAwIDVweCByZ2JhKDIyMCwzOCwzOCwwKTsgfVxuICB9XG5cbiAgLyogXHUyNTAwXHUyNTAwIFNoYXJlZCBwYW5lbCBcdTI1MDBcdTI1MDAgKi9cbiAgLnd0LXBhbmVsIHtcbiAgICBwb3NpdGlvbjogZml4ZWQ7IHotaW5kZXg6IDEwMDAwMDtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmOyBib3JkZXI6IDFweCBzb2xpZCAjRURFQkU5OyBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIGJveC1zaGFkb3c6IDAgOHB4IDMycHggcmdiYSgwLDAsMCwwLjE4KTtcbiAgICBwYWRkaW5nOiAxNHB4IDE2cHg7XG4gICAgZm9udC1mYW1pbHk6IC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgXCJTZWdvZSBVSVwiLCBSb2JvdG8sIHNhbnMtc2VyaWY7XG4gICAgZGlzcGxheTogbm9uZTtcbiAgfVxuICAud3QtcGFuZWwub3BlbiB7IGRpc3BsYXk6IGJsb2NrOyB9XG5cbiAgLyogXHUyNTAwXHUyNTAwIEh1bWFuaXplIHBhbmVsIFx1MjUwMFx1MjUwMCAqL1xuICAjd3QtcGFuZWwgeyB3aWR0aDogMjYwcHg7IH1cbiAgLnd0LXRpdGxlIHtcbiAgICBmb250LXNpemU6IDEycHg7IGZvbnQtd2VpZ2h0OiA2MDA7IGNvbG9yOiAjMzIzMTMwOyBtYXJnaW46IDAgMCAxMHB4O1xuICAgIGxldHRlci1zcGFjaW5nOiAwLjA0ZW07IHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gIH1cbiAgLnd0LXRvbmVzIHsgZGlzcGxheTogZmxleDsgZmxleC13cmFwOiB3cmFwOyBnYXA6IDZweDsgbWFyZ2luLWJvdHRvbTogMTJweDsgfVxuICAud3QtdG9uZSB7XG4gICAgcGFkZGluZzogNHB4IDEwcHg7IGJvcmRlci1yYWRpdXM6IDk5OTlweDsgYm9yZGVyOiAxLjVweCBzb2xpZCAjRURFQkU5O1xuICAgIGJhY2tncm91bmQ6ICNmZmY7IGZvbnQtc2l6ZTogMTJweDsgZm9udC13ZWlnaHQ6IDUwMDsgY29sb3I6ICMzMjMxMzA7IGN1cnNvcjogcG9pbnRlcjtcbiAgICB0cmFuc2l0aW9uOiBhbGwgMC4xcztcbiAgfVxuICAud3QtdG9uZS5hY3RpdmUgeyBjb2xvcjogI2ZmZjsgYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudDsgfVxuICAud3QtdG9uZTpob3Zlcjpub3QoLmFjdGl2ZSkgeyBib3JkZXItY29sb3I6ICM5QkEwRkY7IH1cblxuICAjd3QtcmV3cml0ZSB7XG4gICAgd2lkdGg6IDEwMCU7IGhlaWdodDogMzJweDsgYm9yZGVyLXJhZGl1czogOHB4OyBib3JkZXI6IG5vbmU7XG4gICAgYmFja2dyb3VuZDogIzRGNDZFNTsgY29sb3I6ICNmZmY7XG4gICAgZm9udDogNjAwIDEzcHgvMSAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsIFwiU2Vnb2UgVUlcIiwgUm9ib3RvLCBzYW5zLXNlcmlmO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAjd3QtcmV3cml0ZTpkaXNhYmxlZCB7IG9wYWNpdHk6IDAuNDU7IGN1cnNvcjogZGVmYXVsdDsgfVxuXG4gICN3dC1zdGF0dXMge1xuICAgIG1hcmdpbi10b3A6IDhweDsgZm9udC1zaXplOiAxMXB4OyB0ZXh0LWFsaWduOiBjZW50ZXI7IG1pbi1oZWlnaHQ6IDE0cHg7XG4gIH1cbiAgI3d0LXN0YXR1cy5lcnJvciAgIHsgY29sb3I6ICNBNDI2MkM7IH1cbiAgI3d0LXN0YXR1cy5zdWNjZXNzIHsgY29sb3I6ICMxMDdDMTA7IH1cblxuICAjd3QtbGltaXQge1xuICAgIGRpc3BsYXk6IG5vbmU7IG1hcmdpbi10b3A6IDEwcHg7IHBhZGRpbmc6IDEwcHggMTJweDsgYm9yZGVyLXJhZGl1czogOHB4O1xuICAgIGJhY2tncm91bmQ6ICNGRkY4RjE7IGJvcmRlcjogMXB4IHNvbGlkICNGRUQ3QUE7IHRleHQtYWxpZ246IGNlbnRlcjtcbiAgfVxuICAjd3QtbGltaXQudmlzaWJsZSB7IGRpc3BsYXk6IGJsb2NrOyB9XG4gICN3dC1saW1pdCBwIHsgZm9udC1zaXplOiAxMXB4OyBjb2xvcjogIzkyNDAwRTsgbWFyZ2luOiAwIDAgOHB4OyBsaW5lLWhlaWdodDogMS40OyB9XG4gICN3dC1saW1pdCBhIHtcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7IHBhZGRpbmc6IDVweCAxNHB4OyBib3JkZXItcmFkaXVzOiA5OTk5cHg7XG4gICAgYmFja2dyb3VuZDogI0Y1OUUwQjsgY29sb3I6ICNmZmY7IGZvbnQtc2l6ZTogMTFweDsgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gIH1cblxuICAjd3QtYWN0aW9ucyB7IGRpc3BsYXk6IG5vbmU7IGdhcDogNnB4OyBtYXJnaW4tdG9wOiA4cHg7IH1cbiAgI3d0LWFjdGlvbnMudmlzaWJsZSB7IGRpc3BsYXk6IGZsZXg7IH1cbiAgLnd0LWFjdGlvbiB7XG4gICAgZmxleDogMTsgaGVpZ2h0OiAyOHB4OyBib3JkZXItcmFkaXVzOiA4cHg7IGJvcmRlcjogMS41cHggc29saWQgI0VERUJFOTtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmOyBmb250LXNpemU6IDEycHg7IGZvbnQtd2VpZ2h0OiA1MDA7IGNvbG9yOiAjMzIzMTMwOyBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cbiAgLnd0LWFjdGlvbi5hY2NlcHQgeyBib3JkZXItY29sb3I6ICMxMDdDMTA7IGNvbG9yOiAjMTA3QzEwOyB9XG4gIC53dC1hY3Rpb24ucmVqZWN0IHsgYm9yZGVyLWNvbG9yOiAjQTQyNjJDOyBjb2xvcjogI0E0MjYyQzsgfVxuXG4gIC8qIFx1MjUwMFx1MjUwMCBWb2ljZSBwYW5lbCBcdTI1MDBcdTI1MDAgKi9cbiAgI3d0LXZvaWNlLXBhbmVsIHsgd2lkdGg6IDI4MHB4OyB9XG4gIC53dC12dCB7IGZvbnQtc2l6ZTogMTJweDsgZm9udC13ZWlnaHQ6IDYwMDsgY29sb3I6ICMzMjMxMzA7IG1hcmdpbjogMCAwIDEwcHg7XG4gICAgbGV0dGVyLXNwYWNpbmc6IDAuMDRlbTsgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTsgfVxuICAud3Qtb3R5cGUtbGFiZWwgeyBmb250LXNpemU6IDExcHg7IGNvbG9yOiAjNjA1RTVDOyBtYXJnaW4tYm90dG9tOiA0cHg7IH1cbiAgLnd0LW90eXBlcyB7IGRpc3BsYXk6IGZsZXg7IGZsZXgtd3JhcDogd3JhcDsgZ2FwOiA1cHg7IG1hcmdpbi1ib3R0b206IDEwcHg7IH1cbiAgLnd0LW90eXBlIHtcbiAgICBwYWRkaW5nOiAzcHggOXB4OyBib3JkZXItcmFkaXVzOiA5OTk5cHg7IGJvcmRlcjogMS41cHggc29saWQgI0VERUJFOTtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmOyBmb250LXNpemU6IDExcHg7IGNvbG9yOiAjMzIzMTMwOyBjdXJzb3I6IHBvaW50ZXI7IHRyYW5zaXRpb246IGFsbCAwLjFzO1xuICB9XG4gIC53dC1vdHlwZS5hY3RpdmUgeyBiYWNrZ3JvdW5kOiAjNEY0NkU1OyBjb2xvcjogI2ZmZjsgYm9yZGVyLWNvbG9yOiAjNEY0NkU1OyB9XG4gICN3dC1yZWNvcmQtYnRuIHtcbiAgICB3aWR0aDogMTAwJTsgaGVpZ2h0OiAzMnB4OyBib3JkZXItcmFkaXVzOiA4cHg7IGJvcmRlcjogbm9uZTtcbiAgICBiYWNrZ3JvdW5kOiAjREMyNjI2OyBjb2xvcjogI2ZmZjsgY3Vyc29yOiBwb2ludGVyOyBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICAgIGZvbnQ6IDYwMCAxM3B4LzEgLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCBcIlNlZ29lIFVJXCIsIFJvYm90bywgc2Fucy1zZXJpZjtcbiAgfVxuICAjd3QtcmVjb3JkLWJ0bi5yZWNvcmRpbmcgeyBiYWNrZ3JvdW5kOiAjN0YxRDFEOyB9XG4gICN3dC1yZWNvcmQtYnRuOmRpc2FibGVkICB7IG9wYWNpdHk6IDAuNTsgY3Vyc29yOiBkZWZhdWx0OyB9XG4gICN3dC12b2ljZS1zdGF0dXMgeyBmb250LXNpemU6IDExcHg7IHRleHQtYWxpZ246IGNlbnRlcjsgbWluLWhlaWdodDogMTRweDsgY29sb3I6ICM2MDVFNUM7IH1cbiAgI3d0LXZvaWNlLXN0YXR1cy5lcnJvciB7IGNvbG9yOiAjQTQyNjJDOyB9XG4gICN3dC12b2ljZS1hY3Rpb25zIHsgZGlzcGxheTogbm9uZTsgZ2FwOiA2cHg7IG1hcmdpbi10b3A6IDhweDsgfVxuICAjd3Qtdm9pY2UtYWN0aW9ucy52aXNpYmxlIHsgZGlzcGxheTogZmxleDsgfVxuICAud3QtdmEge1xuICAgIGZsZXg6IDE7IGhlaWdodDogMjhweDsgYm9yZGVyLXJhZGl1czogOHB4OyBib3JkZXI6IDEuNXB4IHNvbGlkICNFREVCRTk7XG4gICAgYmFja2dyb3VuZDogI2ZmZjsgZm9udC1zaXplOiAxMnB4OyBmb250LXdlaWdodDogNTAwOyBjb2xvcjogIzMyMzEzMDsgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIC53dC12YS5hY2NlcHQgeyBib3JkZXItY29sb3I6ICMxMDdDMTA7IGNvbG9yOiAjMTA3QzEwOyB9XG4gIC53dC12YS5yZWplY3QgeyBib3JkZXItY29sb3I6ICNBNDI2MkM7IGNvbG9yOiAjQTQyNjJDOyB9XG5gO1xuXG4vLyBcdTI1MDBcdTI1MDAgQ29udGV4dCBoZWxwZXJzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5mdW5jdGlvbiBidWlsZE91dGxvb2tDb250ZXh0KGNvbXBvc2VCb2R5OiBFbGVtZW50KTogSHVtYW5pemVDb250ZXh0IHtcbiAgLy8gV2FsayB1cCB0byBmaW5kIHRoZSBjb21wb3NlIGNvbnRhaW5lciwgdGhlbiByZWFkIFRvIGZpZWxkIGFuZCBTdWJqZWN0XG4gIGxldCBlbDogRWxlbWVudCB8IG51bGwgPSBjb21wb3NlQm9keTtcbiAgbGV0IGNvbnRhaW5lcjogRWxlbWVudCB8IG51bGwgPSBudWxsO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IDI1OyBpKyspIHtcbiAgICBpZiAoIWVsKSBicmVhaztcbiAgICAvLyBPdXRsb29rIFRvIGZpZWxkIGNvbnRhaW5zIGEgZGl2IHdpdGggcm9sZT1cImxpc3RcIiAocmVjaXBpZW50IGNoaXBzKVxuICAgIGlmIChlbC5xdWVyeVNlbGVjdG9yKCdbcm9sZT1cImxpc3RcIl1bYXJpYS1sYWJlbCo9XCJUb1wiIGldLCBpbnB1dFthcmlhLWxhYmVsKj1cIlRvXCIgaV0nKSkge1xuICAgICAgY29udGFpbmVyID0gZWw7IGJyZWFrO1xuICAgIH1cbiAgICBlbCA9IGVsLnBhcmVudEVsZW1lbnQ7XG4gIH1cblxuICBsZXQgcmVjaXBpZW50RG9tYWluOiBzdHJpbmcgfCB1bmRlZmluZWQ7XG4gIGxldCB0aHJlYWRTdWJqZWN0OiBzdHJpbmcgfCB1bmRlZmluZWQ7XG5cbiAgaWYgKGNvbnRhaW5lcikge1xuICAgIC8vIFJlY2lwaWVudCBjaGlwOiBPdXRsb29rIHJlbmRlcnMgcmVjaXBpZW50IGFzIGEgYnV0dG9uIHdpdGggZGF0YS1lbWFpbCBvciBzaW1pbGFyXG4gICAgY29uc3QgY2hpcCA9IGNvbnRhaW5lci5xdWVyeVNlbGVjdG9yPEhUTUxFbGVtZW50PihcbiAgICAgICdbZGF0YS1lbWFpbF0sIFt0aXRsZSo9XCJAXCJdLCBbYXJpYS1sYWJlbCo9XCJAXCJdJ1xuICAgICk7XG4gICAgaWYgKGNoaXApIHtcbiAgICAgIGNvbnN0IGVtYWlsID1cbiAgICAgICAgY2hpcC5nZXRBdHRyaWJ1dGUoJ2RhdGEtZW1haWwnKSA/P1xuICAgICAgICBjaGlwLmdldEF0dHJpYnV0ZSgndGl0bGUnKSA/P1xuICAgICAgICBjaGlwLmdldEF0dHJpYnV0ZSgnYXJpYS1sYWJlbCcpID8/ICcnO1xuICAgICAgaWYgKGVtYWlsLmluY2x1ZGVzKCdAJykpIHJlY2lwaWVudERvbWFpbiA9IGVtYWlsLnNwbGl0KCdAJylbMV0uc3BsaXQoJz4nKVswXS50b0xvd2VyQ2FzZSgpLnRyaW0oKTtcbiAgICB9XG5cbiAgICAvLyBTdWJqZWN0IGlucHV0XG4gICAgY29uc3Qgc3ViamVjdEVsID0gY29udGFpbmVyLnF1ZXJ5U2VsZWN0b3I8SFRNTElucHV0RWxlbWVudD4oXG4gICAgICAnaW5wdXRbYXJpYS1sYWJlbCo9XCJTdWJqZWN0XCIgaV0sIGlucHV0W3BsYWNlaG9sZGVyKj1cIlN1YmplY3RcIiBpXSdcbiAgICApO1xuICAgIGlmIChzdWJqZWN0RWw/LnZhbHVlKSB0aHJlYWRTdWJqZWN0ID0gc3ViamVjdEVsLnZhbHVlO1xuICB9XG5cbiAgcmV0dXJuIHsgcGxhdGZvcm06ICdvdXRsb29rJywgcmVjaXBpZW50X2RvbWFpbjogcmVjaXBpZW50RG9tYWluLCB0aHJlYWRfc3ViamVjdDogdGhyZWFkU3ViamVjdCB9O1xufVxuXG4vLyBcdTI1MDBcdTI1MDAgTWFpbiBpbmplY3Rpb24gXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmZ1bmN0aW9uIGluamVjdChjb21wb3NlQm9keTogRWxlbWVudCk6IHZvaWQge1xuICBjb25zdCBzZW5kQnRuID0gZmluZFNlbmRCdXR0b24oY29tcG9zZUJvZHkpO1xuICBpZiAoIXNlbmRCdG4pIHJldHVybjtcblxuICAvLyBVc2UgdGhlIHNlbmQgYnV0dG9uJ3MgY2xvc2VzdCB0b29sYmFyLCBvciBmYWxsIGJhY2sgdG8gaXRzIHBhcmVudFxuICBjb25zdCB0b29sYmFyID1cbiAgICBzZW5kQnRuLmNsb3Nlc3QoJ1tyb2xlPVwidG9vbGJhclwiXScpID8/XG4gICAgc2VuZEJ0bi5jbG9zZXN0KCdbcm9sZT1cImdyb3VwXCJdJykgPz9cbiAgICBzZW5kQnRuLnBhcmVudEVsZW1lbnQ7XG4gIGlmICghdG9vbGJhciB8fCB0b29sYmFyLmhhc0F0dHJpYnV0ZShIT1NUX0FUVFIpKSByZXR1cm47XG5cbiAgdG9vbGJhci5zZXRBdHRyaWJ1dGUoSE9TVF9BVFRSLCAnMScpO1xuXG4gIGNvbnN0IGhvc3QgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7XG4gIGNvbnN0IHNoYWRvdyA9IGhvc3QuYXR0YWNoU2hhZG93KHsgbW9kZTogJ29wZW4nIH0pO1xuXG4gIGxldCBzZWxlY3RlZFRvbmU6IFRvbmUgfCBudWxsID0gbnVsbDtcbiAgbGV0IGxhc3RSZXdyaXRlSWQ6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuICBsZXQgcGFuZWxPcGVuID0gZmFsc2U7XG4gIGxldCB2b2ljZVBhbmVsT3BlbiA9IGZhbHNlO1xuICBsZXQgc2VsZWN0ZWRPdXRwdXRUeXBlOiBWb2ljZU91dHB1dFR5cGUgPSAncmVwbHknO1xuICBsZXQgZGV0ZWN0ZWRDb250ZXh0VHdpbiA9ICdwcm9mZXNzaW9uYWwnO1xuICBsZXQgY29udGV4dE92ZXJyaWRlOiBzdHJpbmcgfCB1bmRlZmluZWQ7XG4gIGxldCByZWNvcmRlcjogTWVkaWFSZWNvcmRlciB8IG51bGwgPSBudWxsO1xuICBsZXQgcmVjb3JkaW5nID0gZmFsc2U7XG4gIGxldCBhdWRpb0NodW5rczogQmxvYlBhcnRbXSA9IFtdO1xuICBsZXQgbGFzdFZvaWNlU2Vzc2lvbklkOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcbiAgbGV0IG9yaWdpbmFsVGV4dCA9ICcnO1xuICBsZXQgb3JpZ2luYWxWb2ljZVRleHQgPSAnJztcblxuICBzaGFkb3cuaW5uZXJIVE1MID0gYFxuICAgIDxzdHlsZT4ke0JBU0VfQ1NTfVxuICAgICN3dC1jdHgtYmFkZ2Uge1xuICAgICAgZGlzcGxheTogaW5saW5lLWZsZXg7IGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICBoZWlnaHQ6IDE4cHg7IHBhZGRpbmc6IDAgN3B4OyBib3JkZXItcmFkaXVzOiA5OTk5cHg7XG4gICAgICBiYWNrZ3JvdW5kOiAjRUVGMkZGOyBjb2xvcjogIzQzMzhDQTsgZm9udC1zaXplOiAxMHB4OyBmb250LXdlaWdodDogNjAwO1xuICAgICAgbWFyZ2luLWxlZnQ6IDRweDsgY3Vyc29yOiBwb2ludGVyOyB3aGl0ZS1zcGFjZTogbm93cmFwOyB0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kIDAuMXM7XG4gICAgfVxuICAgICN3dC1jdHgtYmFkZ2U6aG92ZXIgeyBiYWNrZ3JvdW5kOiAjRTBFN0ZGOyB9XG4gICAgI3d0LWN0eC1iYWRnZS5oaWRkZW4geyBkaXNwbGF5OiBub25lOyB9XG4gICAgPC9zdHlsZT5cblxuICAgIDxidXR0b24gaWQ9XCJ3dC1idG5cIiB0aXRsZT1cIkh1bWFuaXplIHdpdGggV3JpdGluZyBUd2luIEFJIChDdHJsK1NoaWZ0K0gpXCI+XHUyNzI4IEh1bWFuaXplPC9idXR0b24+XG4gICAgPHNwYW4gaWQ9XCJ3dC1jdHgtYmFkZ2VcIiBjbGFzcz1cImhpZGRlblwiIHRpdGxlPVwiRGV0ZWN0ZWQgY29udGV4dCBcdTIwMTQgY2xpY2sgdG8gb3ZlcnJpZGVcIj48L3NwYW4+XG4gICAgPGJ1dHRvbiBpZD1cInd0LW1pYy1idG5cIiB0aXRsZT1cIlZvaWNlIFR3aW4gXHUyMDE0IHNwZWFrIHlvdXIgZW1haWwgKEN0cmwrU2hpZnQrVilcIj5cdUQ4M0NcdURGOTk8L2J1dHRvbj5cblxuICAgIDxkaXYgaWQ9XCJ3dC1wYW5lbFwiIGNsYXNzPVwid3QtcGFuZWxcIj5cbiAgICAgIDxwIGNsYXNzPVwid3QtdGl0bGVcIj5SZXdyaXRlIHRvbmU8L3A+XG4gICAgICA8ZGl2IGNsYXNzPVwid3QtdG9uZXNcIj5cbiAgICAgICAgJHtUT05FUy5tYXAodCA9PiBgPGJ1dHRvbiBjbGFzcz1cInd0LXRvbmVcIiBkYXRhLXRvbmU9XCIke3Qua2V5fVwiIGRhdGEtY29sb3I9XCIke3QuY29sb3J9XCI+JHt0LmxhYmVsfTwvYnV0dG9uPmApLmpvaW4oJycpfVxuICAgICAgPC9kaXY+XG4gICAgICA8YnV0dG9uIGlkPVwid3QtcmV3cml0ZVwiIGRpc2FibGVkPlJld3JpdGUgXHUyMTkyPC9idXR0b24+XG4gICAgICA8ZGl2IGlkPVwid3Qtc3RhdHVzXCI+PC9kaXY+XG4gICAgICA8ZGl2IGlkPVwid3QtbGltaXRcIj5cbiAgICAgICAgPHA+WW91J3ZlIHVzZWQgYWxsIHlvdXIgZnJlZSByZXdyaXRlcyB0aGlzIG1vbnRoLjwvcD5cbiAgICAgICAgPGEgaHJlZj1cImh0dHBzOi8vd3JpdGluZ3R3aW5haS5jb20vcHJpY2luZ1wiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyXCI+VXBncmFkZSB0byBQcm8gXHUyMDE0ICQ1L21vPC9hPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGlkPVwid3QtYWN0aW9uc1wiPlxuICAgICAgICA8YnV0dG9uIGNsYXNzPVwid3QtYWN0aW9uIGFjY2VwdFwiIGlkPVwid3QtYWNjZXB0XCI+XHUyNzEzIEtlZXAgaXQ8L2J1dHRvbj5cbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cInd0LWFjdGlvbiByZWplY3RcIiBpZD1cInd0LXJlamVjdFwiPlx1MjcxNyBVbmRvPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cblxuICAgIDxkaXYgaWQ9XCJ3dC12b2ljZS1wYW5lbFwiIGNsYXNzPVwid3QtcGFuZWxcIj5cbiAgICAgIDxwIGNsYXNzPVwid3QtdnRcIj5Wb2ljZSBUd2luPC9wPlxuICAgICAgPGRpdiBjbGFzcz1cInd0LW90eXBlLWxhYmVsXCI+T3V0cHV0IHR5cGU8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3M9XCJ3dC1vdHlwZXNcIj5cbiAgICAgICAgJHtWT0lDRV9PVVRQVVRfVFlQRVMubWFwKChvLCBpKSA9PlxuICAgICAgICAgIGA8YnV0dG9uIGNsYXNzPVwid3Qtb3R5cGUke2kgPT09IDAgPyAnIGFjdGl2ZScgOiAnJ31cIiBkYXRhLXR5cGU9XCIke28ua2V5fVwiPiR7by5sYWJlbH08L2J1dHRvbj5gXG4gICAgICAgICkuam9pbignJyl9XG4gICAgICA8L2Rpdj5cbiAgICAgIDxidXR0b24gaWQ9XCJ3dC1yZWNvcmQtYnRuXCI+XHVEODNDXHVERjk5IFN0YXJ0IHJlY29yZGluZzwvYnV0dG9uPlxuICAgICAgPGRpdiBpZD1cInd0LXZvaWNlLXN0YXR1c1wiPjwvZGl2PlxuICAgICAgPGRpdiBpZD1cInd0LXZvaWNlLWFjdGlvbnNcIj5cbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cInd0LXZhIGFjY2VwdFwiIGlkPVwid3QtdmEta2VlcFwiPlx1MjcxMyBLZWVwIGl0PC9idXR0b24+XG4gICAgICAgIDxidXR0b24gY2xhc3M9XCJ3dC12YSByZWplY3RcIiBpZD1cInd0LXZhLXVuZG9cIj5cdTI3MTcgVW5kbzwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIGA7XG5cbiAgLy8gXHUyNTAwXHUyNTAwIEVsZW1lbnQgcmVmcyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbiAgY29uc3QgYnRuICAgICAgICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtYnRuJykgICAgICAgICBhcyBIVE1MQnV0dG9uRWxlbWVudDtcbiAgY29uc3QgY3R4QmFkZ2UgICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtY3R4LWJhZGdlJykgICBhcyBIVE1MU3BhbkVsZW1lbnQ7XG4gIGNvbnN0IG1pY0J0biAgICAgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LW1pYy1idG4nKSAgICBhcyBIVE1MQnV0dG9uRWxlbWVudDtcbiAgY29uc3QgcGFuZWwgICAgICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtcGFuZWwnKSAgICAgIGFzIEhUTUxEaXZFbGVtZW50O1xuICBjb25zdCB2b2ljZVBhbmVsID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC12b2ljZS1wYW5lbCcpIGFzIEhUTUxEaXZFbGVtZW50O1xuICBjb25zdCByZXdyaXRlQnRuID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC1yZXdyaXRlJykgICAgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG4gIGNvbnN0IHN0YXR1c0VsICAgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LXN0YXR1cycpICAgICBhcyBIVE1MRGl2RWxlbWVudDtcbiAgY29uc3QgbGltaXRFbCAgICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtbGltaXQnKSAgICAgIGFzIEhUTUxEaXZFbGVtZW50O1xuICBjb25zdCBhY3Rpb25zRWwgID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC1hY3Rpb25zJykgICAgYXMgSFRNTERpdkVsZW1lbnQ7XG4gIGNvbnN0IGFjY2VwdEJ0biAgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LWFjY2VwdCcpICAgICBhcyBIVE1MQnV0dG9uRWxlbWVudDtcbiAgY29uc3QgcmVqZWN0QnRuICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtcmVqZWN0JykgICAgIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICBjb25zdCByZWNvcmRCdG4gID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC1yZWNvcmQtYnRuJykgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG4gIGNvbnN0IHZTdGF0dXNFbCAgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LXZvaWNlLXN0YXR1cycpIGFzIEhUTUxEaXZFbGVtZW50O1xuICBjb25zdCB2QWN0aW9uc0VsID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC12b2ljZS1hY3Rpb25zJykgYXMgSFRNTERpdkVsZW1lbnQ7XG4gIGNvbnN0IHZLZWVwQnRuICAgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LXZhLWtlZXAnKSAgICBhcyBIVE1MQnV0dG9uRWxlbWVudDtcbiAgY29uc3QgdlVuZG9CdG4gICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtdmEtdW5kbycpICAgIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuXG4gIC8vIFx1MjUwMFx1MjUwMCBUb25lIHNlbGVjdG9yIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuICBzaGFkb3cucXVlcnlTZWxlY3RvckFsbDxIVE1MQnV0dG9uRWxlbWVudD4oJy53dC10b25lJykuZm9yRWFjaCh0YiA9PiB7XG4gICAgdGIuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgICBzaGFkb3cucXVlcnlTZWxlY3RvckFsbCgnLnd0LXRvbmUnKS5mb3JFYWNoKGIgPT4gYi5jbGFzc0xpc3QucmVtb3ZlKCdhY3RpdmUnKSk7XG4gICAgICB0Yi5jbGFzc0xpc3QuYWRkKCdhY3RpdmUnKTtcbiAgICAgIHRiLnN0eWxlLmJhY2tncm91bmQgICAgPSB0Yi5kYXRhc2V0LmNvbG9yID8/ICcjNEY0NkU1JztcbiAgICAgIHRiLnN0eWxlLmJvcmRlckNvbG9yICAgPSB0Yi5kYXRhc2V0LmNvbG9yID8/ICcjNEY0NkU1JztcbiAgICAgIHNlbGVjdGVkVG9uZSA9IHRiLmRhdGFzZXQudG9uZSBhcyBUb25lO1xuICAgICAgcmV3cml0ZUJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICAgICAgc2V0U3RhdHVzKCcnKTsgbGltaXRFbC5jbGFzc0xpc3QucmVtb3ZlKCd2aXNpYmxlJyk7XG4gICAgICBhY3Rpb25zRWwuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xuICAgIH0pO1xuICB9KTtcblxuICAvLyBcdTI1MDBcdTI1MDAgVm9pY2Ugb3V0cHV0IHR5cGUgc2VsZWN0b3IgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4gIHNoYWRvdy5xdWVyeVNlbGVjdG9yQWxsPEhUTUxCdXR0b25FbGVtZW50PignLnd0LW90eXBlJykuZm9yRWFjaChvYiA9PiB7XG4gICAgb2IuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgICBzaGFkb3cucXVlcnlTZWxlY3RvckFsbCgnLnd0LW90eXBlJykuZm9yRWFjaChiID0+IGIuY2xhc3NMaXN0LnJlbW92ZSgnYWN0aXZlJykpO1xuICAgICAgb2IuY2xhc3NMaXN0LmFkZCgnYWN0aXZlJyk7XG4gICAgICBzZWxlY3RlZE91dHB1dFR5cGUgPSBvYi5kYXRhc2V0LnR5cGUgYXMgVm9pY2VPdXRwdXRUeXBlO1xuICAgIH0pO1xuICB9KTtcblxuICAvLyBcdTI1MDBcdTI1MDAgQ29udGV4dCBiYWRnZSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbiAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgY29uc3QgY3R4ID0gYnVpbGRPdXRsb29rQ29udGV4dChjb21wb3NlQm9keSk7XG4gICAgc2VuZFRvQmFja2dyb3VuZDx7IHJlc3VsdD86IHsgY29udGV4dF90d2luOiBzdHJpbmcgfSB9IHwgeyBlcnJvcjogc3RyaW5nIH0+KHtcbiAgICAgIHR5cGU6ICdERVRFQ1RfQ09OVEVYVCcsXG4gICAgICBwYXlsb2FkOiBjdHgsXG4gICAgfSkudGhlbigocmVzcCkgPT4ge1xuICAgICAgaWYgKCdyZXN1bHQnIGluIHJlc3AgJiYgcmVzcC5yZXN1bHQ/LmNvbnRleHRfdHdpbikge1xuICAgICAgICBkZXRlY3RlZENvbnRleHRUd2luID0gcmVzcC5yZXN1bHQuY29udGV4dF90d2luO1xuICAgICAgICBjb25zdCBsYWJlbCA9IGRldGVjdGVkQ29udGV4dFR3aW4uY2hhckF0KDApLnRvVXBwZXJDYXNlKCkgKyBkZXRlY3RlZENvbnRleHRUd2luLnNsaWNlKDEpO1xuICAgICAgICBjdHhCYWRnZS50ZXh0Q29udGVudCA9IGxhYmVsO1xuICAgICAgICBjdHhCYWRnZS5jbGFzc0xpc3QucmVtb3ZlKCdoaWRkZW4nKTtcbiAgICAgIH1cbiAgICB9KS5jYXRjaCgoKSA9PiB7fSk7XG4gIH0sIDgwMCk7XG5cbiAgY29uc3QgQ09OVEVYVF9DWUNMRSA9IFsncHJvZmVzc2lvbmFsJywgJ2N1c3RvbWVyJywgJ3RlY2huaWNhbCcsICdlc2NhbGF0aW9uJywgJ2Nhc3VhbCddO1xuICBjdHhCYWRnZS5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBjb25zdCBjdXJyZW50ID0gY29udGV4dE92ZXJyaWRlID8/IGRldGVjdGVkQ29udGV4dFR3aW47XG4gICAgY29uc3QgaWR4ID0gQ09OVEVYVF9DWUNMRS5pbmRleE9mKGN1cnJlbnQpO1xuICAgIGNvbnRleHRPdmVycmlkZSA9IENPTlRFWFRfQ1lDTEVbKGlkeCArIDEpICUgQ09OVEVYVF9DWUNMRS5sZW5ndGhdO1xuICAgIGNvbnN0IGxhYmVsID0gY29udGV4dE92ZXJyaWRlLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgY29udGV4dE92ZXJyaWRlLnNsaWNlKDEpO1xuICAgIGN0eEJhZGdlLnRleHRDb250ZW50ID0gbGFiZWw7XG4gICAgc2VuZFRvQmFja2dyb3VuZCh7XG4gICAgICB0eXBlOiAnQ09OVEVYVF9PVkVSUklERScsXG4gICAgICBwYXlsb2FkOiB7XG4gICAgICAgIGRldGVjdGVkX2NvbnRleHQ6IGRldGVjdGVkQ29udGV4dFR3aW4sXG4gICAgICAgIHNlbGVjdGVkX2NvbnRleHQ6IGNvbnRleHRPdmVycmlkZSxcbiAgICAgICAgcGxhdGZvcm06ICdvdXRsb29rJyxcbiAgICAgIH0sXG4gICAgfSk7XG4gIH0pO1xuXG4gIC8vIFx1MjUwMFx1MjUwMCBQYW5lbCB0b2dnbGVzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuICBidG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgcGFuZWxPcGVuID0gIXBhbmVsT3BlbjtcbiAgICBpZiAocGFuZWxPcGVuKSB7IHZvaWNlUGFuZWxPcGVuID0gZmFsc2U7IHZvaWNlUGFuZWwuY2xhc3NMaXN0LnJlbW92ZSgnb3BlbicpOyB9XG4gICAgcGFuZWwuY2xhc3NMaXN0LnRvZ2dsZSgnb3BlbicsIHBhbmVsT3Blbik7XG4gICAgaWYgKHBhbmVsT3BlbikgcG9zaXRpb25QYW5lbChidG4sIHBhbmVsKTtcbiAgfSk7XG5cbiAgbWljQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgIHZvaWNlUGFuZWxPcGVuID0gIXZvaWNlUGFuZWxPcGVuO1xuICAgIGlmICh2b2ljZVBhbmVsT3BlbikgeyBwYW5lbE9wZW4gPSBmYWxzZTsgcGFuZWwuY2xhc3NMaXN0LnJlbW92ZSgnb3BlbicpOyB9XG4gICAgdm9pY2VQYW5lbC5jbGFzc0xpc3QudG9nZ2xlKCdvcGVuJywgdm9pY2VQYW5lbE9wZW4pO1xuICAgIGlmICh2b2ljZVBhbmVsT3BlbikgcG9zaXRpb25QYW5lbChtaWNCdG4sIHZvaWNlUGFuZWwpO1xuICB9KTtcblxuICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChlKSA9PiB7XG4gICAgaWYgKCFob3N0LmNvbnRhaW5zKGUudGFyZ2V0IGFzIE5vZGUpKSB7XG4gICAgICBwYW5lbE9wZW4gPSBmYWxzZTsgcGFuZWwuY2xhc3NMaXN0LnJlbW92ZSgnb3BlbicpO1xuICAgICAgdm9pY2VQYW5lbE9wZW4gPSBmYWxzZTsgdm9pY2VQYW5lbC5jbGFzc0xpc3QucmVtb3ZlKCdvcGVuJyk7XG4gICAgfVxuICB9LCB0cnVlKTtcblxuICBmdW5jdGlvbiBwb3NpdGlvblBhbmVsKGFuY2hvcjogSFRNTEVsZW1lbnQsIHA6IEhUTUxEaXZFbGVtZW50KTogdm9pZCB7XG4gICAgY29uc3QgcmVjdCA9IGFuY2hvci5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICBjb25zdCBwYW5lbFdpZHRoID0gcGFyc2VJbnQocC5zdHlsZS53aWR0aCB8fCAnMjYwJyk7XG4gICAgcC5zdHlsZS5ib3R0b20gPSBgJHt3aW5kb3cuaW5uZXJIZWlnaHQgLSByZWN0LnRvcCArIDZ9cHhgO1xuICAgIHAuc3R5bGUubGVmdCAgID0gYCR7TWF0aC5taW4ocmVjdC5sZWZ0LCB3aW5kb3cuaW5uZXJXaWR0aCAtIHBhbmVsV2lkdGggLSAyMCl9cHhgO1xuICB9XG5cbiAgLy8gXHUyNTAwXHUyNTAwIFJld3JpdGUgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4gIHJld3JpdGVCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFzZWxlY3RlZFRvbmUpIHJldHVybjtcbiAgICBjb25zdCB0ZXh0ID0gcmVhZENvbXBvc2UoY29tcG9zZUJvZHkpO1xuICAgIGlmICghdGV4dCkgeyBzZXRTdGF0dXMoJ1dyaXRlIHNvbWV0aGluZyBmaXJzdC4nLCAnZXJyb3InKTsgcmV0dXJuOyB9XG5cbiAgICBvcmlnaW5hbFRleHQgPSB0ZXh0O1xuICAgIGJ0bi5kaXNhYmxlZCA9IHRydWU7IHJld3JpdGVCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICAgIHNldFN0YXR1cygnUmV3cml0aW5nXHUyMDI2Jyk7IGFjdGlvbnNFbC5jbGFzc0xpc3QucmVtb3ZlKCd2aXNpYmxlJyk7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgYmFzZUN0eCA9IGJ1aWxkT3V0bG9va0NvbnRleHQoY29tcG9zZUJvZHkpO1xuICAgICAgY29uc3QgcmVzcCA9IGF3YWl0IHNlbmRUb0JhY2tncm91bmQ8eyByZXN1bHQ6IFJld3JpdGVSZXNwb25zZSB9IHwgeyBlcnJvcjogc3RyaW5nIH0+KHtcbiAgICAgICAgdHlwZTogJ0hVTUFOSVpFJyxcbiAgICAgICAgcGF5bG9hZDogeyB0ZXh0LCB0b25lOiBzZWxlY3RlZFRvbmUsIGN0eDogeyAuLi5iYXNlQ3R4LCBjb250ZXh0X3R3aW5fb3ZlcnJpZGU6IGNvbnRleHRPdmVycmlkZSB9IH0sXG4gICAgICB9KTtcbiAgICAgIGlmICgnZXJyb3InIGluIHJlc3ApIHRocm93IG5ldyBFcnJvcihTdHJpbmcocmVzcC5lcnJvcikpO1xuICAgICAgbGFzdFJld3JpdGVJZCA9IHJlc3AucmVzdWx0LmlkO1xuICAgICAgd3JpdGVDb21wb3NlKGNvbXBvc2VCb2R5IGFzIEhUTUxFbGVtZW50LCByZXNwLnJlc3VsdC5vdXRwdXRfdGV4dCk7XG4gICAgICBzZXRTdGF0dXMoJ0RvbmUgXHUyNzEzJywgJ3N1Y2Nlc3MnKTtcbiAgICAgIGFjdGlvbnNFbC5jbGFzc0xpc3QuYWRkKCd2aXNpYmxlJyk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zdCBtc2cgPSBlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogJ0ZhaWxlZCc7XG4gICAgICBpZiAobXNnLnN0YXJ0c1dpdGgoJ0xJTUlUX1JFQUNIRUQ6JykpIHtcbiAgICAgICAgbGltaXRFbC5jbGFzc0xpc3QuYWRkKCd2aXNpYmxlJyk7IHNldFN0YXR1cygnJyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRTdGF0dXMobXNnLCAnZXJyb3InKTtcbiAgICAgIH1cbiAgICB9IGZpbmFsbHkge1xuICAgICAgYnRuLmRpc2FibGVkID0gZmFsc2U7XG4gICAgICByZXdyaXRlQnRuLmRpc2FibGVkID0gc2VsZWN0ZWRUb25lID09PSBudWxsO1xuICAgIH1cbiAgfSk7XG5cbiAgYWNjZXB0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgIGlmIChsYXN0UmV3cml0ZUlkKSBzZW5kVG9CYWNrZ3JvdW5kKHsgdHlwZTogJ0ZFRURCQUNLJywgcGF5bG9hZDogeyByZXdyaXRlSWQ6IGxhc3RSZXdyaXRlSWQsIGFjdGlvbjogJ2FjY2VwdGVkJyB9IH0pO1xuICAgIGFjdGlvbnNFbC5jbGFzc0xpc3QucmVtb3ZlKCd2aXNpYmxlJyk7XG4gICAgcGFuZWxPcGVuID0gZmFsc2U7IHBhbmVsLmNsYXNzTGlzdC5yZW1vdmUoJ29wZW4nKTtcbiAgICBzZXRTdGF0dXMoJycpO1xuICB9KTtcblxuICByZWplY3RCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgaWYgKG9yaWdpbmFsVGV4dCkgd3JpdGVDb21wb3NlKGNvbXBvc2VCb2R5IGFzIEhUTUxFbGVtZW50LCBvcmlnaW5hbFRleHQpO1xuICAgIGlmIChsYXN0UmV3cml0ZUlkKSBzZW5kVG9CYWNrZ3JvdW5kKHsgdHlwZTogJ0ZFRURCQUNLJywgcGF5bG9hZDogeyByZXdyaXRlSWQ6IGxhc3RSZXdyaXRlSWQsIGFjdGlvbjogJ3JlamVjdGVkJyB9IH0pO1xuICAgIGFjdGlvbnNFbC5jbGFzc0xpc3QucmVtb3ZlKCd2aXNpYmxlJyk7XG4gICAgc2V0U3RhdHVzKCdSZXZlcnRlZC4nLCAnc3VjY2VzcycpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0U3RhdHVzKCcnKSwgMjAwMCk7XG4gIH0pO1xuXG4gIGZ1bmN0aW9uIHNldFN0YXR1cyhtc2c6IHN0cmluZywgY2xzID0gJycpOiB2b2lkIHtcbiAgICBzdGF0dXNFbC50ZXh0Q29udGVudCA9IG1zZzsgc3RhdHVzRWwuY2xhc3NOYW1lID0gY2xzO1xuICB9XG5cbiAgLy8gXHUyNTAwXHUyNTAwIFJlY29yZGluZyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbiAgcmVjb3JkQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICAgIGlmICghcmVjb3JkaW5nKSBhd2FpdCBzdGFydFJlY29yZGluZygpOyBlbHNlIHN0b3BSZWNvcmRpbmcoKTtcbiAgfSk7XG5cbiAgYXN5bmMgZnVuY3Rpb24gc3RhcnRSZWNvcmRpbmcoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHN0cmVhbSA9IGF3YWl0IG5hdmlnYXRvci5tZWRpYURldmljZXMuZ2V0VXNlck1lZGlhKHsgYXVkaW86IHRydWUgfSk7XG4gICAgICBhdWRpb0NodW5rcyA9IFtdO1xuICAgICAgcmVjb3JkZXIgPSBuZXcgTWVkaWFSZWNvcmRlcihzdHJlYW0sIHsgbWltZVR5cGU6ICdhdWRpby93ZWJtJyB9KTtcbiAgICAgIHJlY29yZGVyLm9uZGF0YWF2YWlsYWJsZSA9IChlKSA9PiB7IGlmIChlLmRhdGEuc2l6ZSA+IDApIGF1ZGlvQ2h1bmtzLnB1c2goZS5kYXRhKTsgfTtcbiAgICAgIHJlY29yZGVyLm9uc3RvcCA9IGFzeW5jICgpID0+IHtcbiAgICAgICAgc3RyZWFtLmdldFRyYWNrcygpLmZvckVhY2godCA9PiB0LnN0b3AoKSk7XG4gICAgICAgIGF3YWl0IHN1Ym1pdFZvaWNlKG5ldyBCbG9iKGF1ZGlvQ2h1bmtzLCB7IHR5cGU6ICdhdWRpby93ZWJtJyB9KSk7XG4gICAgICB9O1xuICAgICAgcmVjb3JkZXIuc3RhcnQoKTtcbiAgICAgIHJlY29yZGluZyA9IHRydWU7XG4gICAgICBtaWNCdG4uY2xhc3NMaXN0LmFkZCgncmVjb3JkaW5nJyk7XG4gICAgICByZWNvcmRCdG4uY2xhc3NMaXN0LmFkZCgncmVjb3JkaW5nJyk7XG4gICAgICByZWNvcmRCdG4udGV4dENvbnRlbnQgPSAnXHUyM0Y5IFN0b3AgcmVjb3JkaW5nJztcbiAgICAgIHNldFZvaWNlU3RhdHVzKCdSZWNvcmRpbmdcdTIwMjYnKTtcbiAgICAgIHZBY3Rpb25zRWwuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiB7IGlmIChyZWNvcmRpbmcpIHN0b3BSZWNvcmRpbmcoKTsgfSwgNjBfMDAwKTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHNldFZvaWNlU3RhdHVzKCdNaWNyb3Bob25lIGFjY2VzcyBkZW5pZWQuJywgJ2Vycm9yJyk7XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gc3RvcFJlY29yZGluZygpOiB2b2lkIHtcbiAgICBpZiAocmVjb3JkZXIgJiYgcmVjb3JkaW5nKSB7XG4gICAgICByZWNvcmRlci5zdG9wKCk7XG4gICAgICByZWNvcmRpbmcgPSBmYWxzZTtcbiAgICAgIG1pY0J0bi5jbGFzc0xpc3QucmVtb3ZlKCdyZWNvcmRpbmcnKTtcbiAgICAgIHJlY29yZEJ0bi5jbGFzc0xpc3QucmVtb3ZlKCdyZWNvcmRpbmcnKTtcbiAgICAgIHJlY29yZEJ0bi50ZXh0Q29udGVudCA9ICdcdUQ4M0NcdURGOTkgU3RhcnQgcmVjb3JkaW5nJztcbiAgICAgIHJlY29yZEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gICAgICBzZXRWb2ljZVN0YXR1cygnRHJhZnRpbmdcdTIwMjYnKTtcbiAgICB9XG4gIH1cblxuICBhc3luYyBmdW5jdGlvbiBzdWJtaXRWb2ljZShibG9iOiBCbG9iKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGFiID0gYXdhaXQgYmxvYi5hcnJheUJ1ZmZlcigpO1xuICAgICAgY29uc3QgdTggPSBuZXcgVWludDhBcnJheShhYik7XG4gICAgICBsZXQgYmluID0gJyc7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHU4Lmxlbmd0aDsgaSsrKSBiaW4gKz0gU3RyaW5nLmZyb21DaGFyQ29kZSh1OFtpXSk7XG4gICAgICBjb25zdCBhdWRpb0RhdGEgPSBidG9hKGJpbik7XG5cbiAgICAgIG9yaWdpbmFsVm9pY2VUZXh0ID0gcmVhZENvbXBvc2UoY29tcG9zZUJvZHkpO1xuXG4gICAgICBjb25zdCByZXNwID0gYXdhaXQgc2VuZFRvQmFja2dyb3VuZDx7IHJlc3VsdDogVm9pY2VEcmFmdFJlc3BvbnNlIH0gfCB7IGVycm9yOiBzdHJpbmcgfT4oe1xuICAgICAgICB0eXBlOiAnVk9JQ0VfRFJBRlQnLFxuICAgICAgICBwYXlsb2FkOiB7IGF1ZGlvRGF0YSwgbWltZVR5cGU6ICdhdWRpby93ZWJtJywgb3V0cHV0VHlwZTogc2VsZWN0ZWRPdXRwdXRUeXBlIH0sXG4gICAgICB9KTtcbiAgICAgIGlmICgnZXJyb3InIGluIHJlc3ApIHRocm93IG5ldyBFcnJvcihTdHJpbmcocmVzcC5lcnJvcikpO1xuXG4gICAgICBsYXN0Vm9pY2VTZXNzaW9uSWQgPSByZXNwLnJlc3VsdC5pZDtcbiAgICAgIHdyaXRlQ29tcG9zZShjb21wb3NlQm9keSBhcyBIVE1MRWxlbWVudCwgcmVzcC5yZXN1bHQuZHJhZnQpO1xuICAgICAgc2V0Vm9pY2VTdGF0dXMoJ0RvbmUgXHUyNzEzJyk7XG4gICAgICB2QWN0aW9uc0VsLmNsYXNzTGlzdC5hZGQoJ3Zpc2libGUnKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldFZvaWNlU3RhdHVzKGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiAnRmFpbGVkJywgJ2Vycm9yJyk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHJlY29yZEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICAgIH1cbiAgfVxuXG4gIHZLZWVwQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgIGlmIChsYXN0Vm9pY2VTZXNzaW9uSWQpIHNlbmRUb0JhY2tncm91bmQoeyB0eXBlOiAnVk9JQ0VfRkVFREJBQ0snLCBwYXlsb2FkOiB7IHNlc3Npb25JZDogbGFzdFZvaWNlU2Vzc2lvbklkLCBhY2NlcHRlZDogdHJ1ZSwgZWRpdGVkRHJhZnQ6IG51bGwgfSB9KTtcbiAgICB2QWN0aW9uc0VsLmNsYXNzTGlzdC5yZW1vdmUoJ3Zpc2libGUnKTtcbiAgICB2b2ljZVBhbmVsT3BlbiA9IGZhbHNlOyB2b2ljZVBhbmVsLmNsYXNzTGlzdC5yZW1vdmUoJ29wZW4nKTtcbiAgICBzZXRWb2ljZVN0YXR1cygnJyk7XG4gIH0pO1xuXG4gIHZVbmRvQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgIGlmIChvcmlnaW5hbFZvaWNlVGV4dCkgd3JpdGVDb21wb3NlKGNvbXBvc2VCb2R5IGFzIEhUTUxFbGVtZW50LCBvcmlnaW5hbFZvaWNlVGV4dCk7XG4gICAgaWYgKGxhc3RWb2ljZVNlc3Npb25JZCkgc2VuZFRvQmFja2dyb3VuZCh7IHR5cGU6ICdWT0lDRV9GRUVEQkFDSycsIHBheWxvYWQ6IHsgc2Vzc2lvbklkOiBsYXN0Vm9pY2VTZXNzaW9uSWQsIGFjY2VwdGVkOiBmYWxzZSwgZWRpdGVkRHJhZnQ6IG51bGwgfSB9KTtcbiAgICB2QWN0aW9uc0VsLmNsYXNzTGlzdC5yZW1vdmUoJ3Zpc2libGUnKTtcbiAgICBzZXRWb2ljZVN0YXR1cygnUmV2ZXJ0ZWQuJywgJ3N1Y2Nlc3MnKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHNldFZvaWNlU3RhdHVzKCcnKSwgMjAwMCk7XG4gIH0pO1xuXG4gIGZ1bmN0aW9uIHNldFZvaWNlU3RhdHVzKG1zZzogc3RyaW5nLCBjbHMgPSAnJyk6IHZvaWQge1xuICAgIHZTdGF0dXNFbC50ZXh0Q29udGVudCA9IG1zZzsgdlN0YXR1c0VsLmNsYXNzTmFtZSA9IGNscztcbiAgfVxuXG4gIC8vIEluc2VydCBvdXIgaG9zdCByaWdodCBiZWZvcmUgdGhlIFNlbmQgYnV0dG9uIGluIHRoZSB0b29sYmFyXG4gIHRvb2xiYXIuaW5zZXJ0QmVmb3JlKGhvc3QsIHNlbmRCdG4pO1xufVxuXG4vLyBcdTI1MDBcdTI1MDAgSGVscGVycyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuLyoqXG4gKiBXYWxrIHVwIGZyb20gdGhlIGNvbXBvc2UgYm9keSB0byBmaW5kIHRoZSBTZW5kIGJ1dHRvbi5cbiAqIE91dGxvb2sgbmVzdHMgdGhlIHRvb2xiYXIgaW4gYSBzaWJsaW5nIHN1YnRyZWUsIHNvIHdlIHdhbGsgdXAgdG8gYSBjb21tb25cbiAqIGFuY2VzdG9yICh1cCB0byAzMCBsZXZlbHMpIGFuZCBzZWFyY2ggZG93biBmb3IgdGhlIFNlbmQgYnV0dG9uIGZyb20gdGhlcmUuXG4gKi9cbmZ1bmN0aW9uIGZpbmRTZW5kQnV0dG9uKGNvbXBvc2VCb2R5OiBFbGVtZW50KTogRWxlbWVudCB8IG51bGwge1xuICBsZXQgZWw6IEVsZW1lbnQgfCBudWxsID0gY29tcG9zZUJvZHk7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgMzA7IGkrKykge1xuICAgIGlmICghZWwpIGJyZWFrO1xuICAgIGNvbnN0IHNlbmQgPSBlbC5xdWVyeVNlbGVjdG9yKFNFTkRfQlVUVE9OX1NFTCk7XG4gICAgaWYgKHNlbmQpIHJldHVybiBzZW5kO1xuICAgIGVsID0gZWwucGFyZW50RWxlbWVudDtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuZnVuY3Rpb24gcmVhZENvbXBvc2UoZWw6IEVsZW1lbnQpOiBzdHJpbmcge1xuICByZXR1cm4gKGVsIGFzIEhUTUxFbGVtZW50KS5pbm5lclRleHQudHJpbSgpO1xufVxuXG5mdW5jdGlvbiB3cml0ZUNvbXBvc2UoZWw6IEhUTUxFbGVtZW50LCB0ZXh0OiBzdHJpbmcpOiB2b2lkIHtcbiAgZWwuZm9jdXMoKTtcbiAgLy8gU2VsZWN0IGFsbCArIGRlbGV0ZSB2aWEgZXhlY0NvbW1hbmQgKHdvcmtzIGluIE91dGxvb2sgY29udGVudGVkaXRhYmxlKVxuICBkb2N1bWVudC5leGVjQ29tbWFuZCgnc2VsZWN0QWxsJywgZmFsc2UsIHVuZGVmaW5lZCk7XG4gIGRvY3VtZW50LmV4ZWNDb21tYW5kKCdkZWxldGUnLCBmYWxzZSwgdW5kZWZpbmVkKTtcbiAgY29uc3QgbGluZXMgPSB0ZXh0LnNwbGl0KCdcXG4nKTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBsaW5lcy5sZW5ndGg7IGkrKykge1xuICAgIGlmIChsaW5lc1tpXSkgZG9jdW1lbnQuZXhlY0NvbW1hbmQoJ2luc2VydFRleHQnLCBmYWxzZSwgbGluZXNbaV0pO1xuICAgIGlmIChpIDwgbGluZXMubGVuZ3RoIC0gMSkgZG9jdW1lbnQuZXhlY0NvbW1hbmQoJ2luc2VydFBhcmFncmFwaCcsIGZhbHNlLCB1bmRlZmluZWQpO1xuICB9XG59XG5cbmZ1bmN0aW9uIHNlbmRUb0JhY2tncm91bmQ8VD4obWVzc2FnZTogb2JqZWN0KTogUHJvbWlzZTxUPiB7XG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKG1lc3NhZ2UsIHJlc29sdmUpO1xuICB9KTtcbn1cblxuLy8gXHUyNTAwXHUyNTAwIE9ic2VydmVyICsgcG9sbGluZyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuY29uc3Qgc2VlbiA9IG5ldyBXZWFrU2V0PEVsZW1lbnQ+KCk7XG5cbmZ1bmN0aW9uIHRyeUluamVjdChyb290OiBFbGVtZW50IHwgRG9jdW1lbnQpOiB2b2lkIHtcbiAgcm9vdC5xdWVyeVNlbGVjdG9yQWxsPEVsZW1lbnQ+KENPTVBPU0VfQk9EWV9TRUwpLmZvckVhY2goKGJvZHkpID0+IHtcbiAgICAvLyBTa2lwIHRoZSBnbG9iYWwgcmVhZGluZyBwYW5lIFx1MjAxNCB3ZSBvbmx5IHdhbnQgYWN0aXZlIGNvbXBvc2Ugd2luZG93c1xuICAgIGlmICghZmluZFNlbmRCdXR0b24oYm9keSkpIHJldHVybjtcbiAgICBpZiAoIXNlZW4uaGFzKGJvZHkpKSB7XG4gICAgICBzZWVuLmFkZChib2R5KTtcbiAgICAgIGluamVjdChib2R5KTtcbiAgICB9XG4gIH0pO1xufVxuXG4vLyBNdXRhdGlvbk9ic2VydmVyIFx1MjAxNCBPdXRsb29rJ3MgUmVhY3QgdHJlZSBtdXRhdGVzIGRlZXBseVxuY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgTXV0YXRpb25PYnNlcnZlcigoKSA9PiB0cnlJbmplY3QoZG9jdW1lbnQpKTtcbm9ic2VydmVyLm9ic2VydmUoZG9jdW1lbnQuYm9keSwgeyBjaGlsZExpc3Q6IHRydWUsIHN1YnRyZWU6IHRydWUgfSk7XG5cbi8vIFBvbGxpbmcgZmFsbGJhY2sgXHUyMDE0IGNhdGNoZXMgY2FzZXMgd2hlcmUgbXV0YXRpb25zIGZpcmUgYmVmb3JlIFJlYWN0IGZpbmlzaGVzIHJlbmRlcmluZ1xuLy8gKGUuZy4gY29tcG9zZSB3aW5kb3cgb3BlbmVkIGJ1dCB0b29sYmFyIG5vdCB5ZXQgaW4gRE9NIHdoZW4gb2JzZXJ2ZXIgZmlyZXMpXG5zZXRJbnRlcnZhbCgoKSA9PiB0cnlJbmplY3QoZG9jdW1lbnQpLCAxMDAwKTtcblxuLy8gSGFuZGxlIGNvbXBvc2Ugd2luZG93cyBhbHJlYWR5IGluIERPTSBvbiBsb2FkXG50cnlJbmplY3QoZG9jdW1lbnQpO1xuXG4vLyBcdTI1MDBcdTI1MDAgS2V5Ym9hcmQgc2hvcnRjdXRzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgKGUpID0+IHtcbiAgaWYgKCEoZS5jdHJsS2V5IHx8IGUubWV0YUtleSkgfHwgIWUuc2hpZnRLZXkpIHJldHVybjtcblxuICBjb25zdCB0b29sYmFyRWwgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGBbJHtIT1NUX0FUVFJ9XWApO1xuICBpZiAoIXRvb2xiYXJFbCkgcmV0dXJuO1xuICBjb25zdCBob3N0cyA9IEFycmF5LmZyb20odG9vbGJhckVsLmNoaWxkcmVuKS5maWx0ZXIoYyA9PiBjLnNoYWRvd1Jvb3QpIGFzIEhUTUxFbGVtZW50W107XG5cbiAgaWYgKGUua2V5ID09PSAnSCcpIHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgKGhvc3RzWzBdPy5zaGFkb3dSb290Py5nZXRFbGVtZW50QnlJZCgnd3QtYnRuJykgYXMgSFRNTEJ1dHRvbkVsZW1lbnQgfCBudWxsKT8uY2xpY2soKTtcbiAgfVxuICBpZiAoZS5rZXkgPT09ICdWJykge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAoaG9zdHNbMF0/LnNoYWRvd1Jvb3Q/LmdldEVsZW1lbnRCeUlkKCd3dC1taWMtYnRuJykgYXMgSFRNTEJ1dHRvbkVsZW1lbnQgfCBudWxsKT8uY2xpY2soKTtcbiAgfVxufSk7XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7QUFhQSxNQUFNLG1CQUFtQjtBQUFBLElBQ3ZCO0FBQUEsSUFDQTtBQUFBLEVBQ0YsRUFBRSxLQUFLLElBQUk7QUFJWCxNQUFNLGtCQUFrQjtBQUFBLElBQ3RCO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFDRixFQUFFLEtBQUssSUFBSTtBQUVYLE1BQU0sWUFBWTtBQUlsQixNQUFNLFFBQXVEO0FBQUEsSUFDM0QsRUFBRSxLQUFLLGdCQUFnQixPQUFPLGdCQUFnQixPQUFPLFVBQVU7QUFBQSxJQUMvRCxFQUFFLEtBQUssVUFBZ0IsT0FBTyxVQUFnQixPQUFPLFVBQVU7QUFBQSxJQUMvRCxFQUFFLEtBQUssWUFBZ0IsT0FBTyxZQUFnQixPQUFPLFVBQVU7QUFBQSxJQUMvRCxFQUFFLEtBQUssVUFBZ0IsT0FBTyxVQUFnQixPQUFPLFVBQVU7QUFBQSxJQUMvRCxFQUFFLEtBQUssY0FBZ0IsT0FBTyxjQUFnQixPQUFPLFVBQVU7QUFBQSxJQUMvRCxFQUFFLEtBQUssYUFBZ0IsT0FBTyxhQUFnQixPQUFPLFVBQVU7QUFBQSxFQUNqRTtBQUlBLE1BQU0scUJBQWdFO0FBQUEsSUFDcEUsRUFBRSxLQUFLLFNBQW9CLE9BQU8sUUFBUTtBQUFBLElBQzFDLEVBQUUsS0FBSyxTQUFvQixPQUFPLFFBQVE7QUFBQSxJQUMxQyxFQUFFLEtBQUssbUJBQW9CLE9BQU8sa0JBQWtCO0FBQUEsSUFDcEQsRUFBRSxLQUFLLGVBQW9CLE9BQU8sY0FBYztBQUFBLElBQ2hELEVBQUUsS0FBSyxvQkFBb0IsT0FBTyxjQUFjO0FBQUEsRUFDbEQ7QUFJQSxNQUFNLFdBQVc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQTZIakIsV0FBUyxvQkFBb0IsYUFBdUM7QUFFbEUsUUFBSSxLQUFxQjtBQUN6QixRQUFJLFlBQTRCO0FBQ2hDLGFBQVMsSUFBSSxHQUFHLElBQUksSUFBSSxLQUFLO0FBQzNCLFVBQUksQ0FBQyxHQUFJO0FBRVQsVUFBSSxHQUFHLGNBQWMsOERBQThELEdBQUc7QUFDcEYsb0JBQVk7QUFBSTtBQUFBLE1BQ2xCO0FBQ0EsV0FBSyxHQUFHO0FBQUEsSUFDVjtBQUVBLFFBQUk7QUFDSixRQUFJO0FBRUosUUFBSSxXQUFXO0FBRWIsWUFBTSxPQUFPLFVBQVU7QUFBQSxRQUNyQjtBQUFBLE1BQ0Y7QUFDQSxVQUFJLE1BQU07QUFDUixjQUFNLFFBQ0osS0FBSyxhQUFhLFlBQVksS0FDOUIsS0FBSyxhQUFhLE9BQU8sS0FDekIsS0FBSyxhQUFhLFlBQVksS0FBSztBQUNyQyxZQUFJLE1BQU0sU0FBUyxHQUFHLEVBQUcsbUJBQWtCLE1BQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQyxFQUFFLE1BQU0sR0FBRyxFQUFFLENBQUMsRUFBRSxZQUFZLEVBQUUsS0FBSztBQUFBLE1BQ2xHO0FBR0EsWUFBTSxZQUFZLFVBQVU7QUFBQSxRQUMxQjtBQUFBLE1BQ0Y7QUFDQSxVQUFJLFdBQVcsTUFBTyxpQkFBZ0IsVUFBVTtBQUFBLElBQ2xEO0FBRUEsV0FBTyxFQUFFLFVBQVUsV0FBVyxrQkFBa0IsaUJBQWlCLGdCQUFnQixjQUFjO0FBQUEsRUFDakc7QUFJQSxXQUFTLE9BQU8sYUFBNEI7QUFDMUMsVUFBTSxVQUFVLGVBQWUsV0FBVztBQUMxQyxRQUFJLENBQUMsUUFBUztBQUdkLFVBQU0sVUFDSixRQUFRLFFBQVEsa0JBQWtCLEtBQ2xDLFFBQVEsUUFBUSxnQkFBZ0IsS0FDaEMsUUFBUTtBQUNWLFFBQUksQ0FBQyxXQUFXLFFBQVEsYUFBYSxTQUFTLEVBQUc7QUFFakQsWUFBUSxhQUFhLFdBQVcsR0FBRztBQUVuQyxVQUFNLE9BQU8sU0FBUyxjQUFjLE1BQU07QUFDMUMsVUFBTSxTQUFTLEtBQUssYUFBYSxFQUFFLE1BQU0sT0FBTyxDQUFDO0FBRWpELFFBQUksZUFBNEI7QUFDaEMsUUFBSSxnQkFBK0I7QUFDbkMsUUFBSSxZQUFZO0FBQ2hCLFFBQUksaUJBQWlCO0FBQ3JCLFFBQUkscUJBQXNDO0FBQzFDLFFBQUksc0JBQXNCO0FBQzFCLFFBQUk7QUFDSixRQUFJLFdBQWlDO0FBQ3JDLFFBQUksWUFBWTtBQUNoQixRQUFJLGNBQTBCLENBQUM7QUFDL0IsUUFBSSxxQkFBb0M7QUFDeEMsUUFBSSxlQUFlO0FBQ25CLFFBQUksb0JBQW9CO0FBRXhCLFdBQU8sWUFBWTtBQUFBLGFBQ1IsUUFBUTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWtCWCxNQUFNLElBQUksT0FBSyxzQ0FBc0MsRUFBRSxHQUFHLGlCQUFpQixFQUFFLEtBQUssS0FBSyxFQUFFLEtBQUssV0FBVyxFQUFFLEtBQUssRUFBRSxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBa0JuSCxtQkFBbUI7QUFBQSxNQUFJLENBQUMsR0FBRyxNQUMzQiwwQkFBMEIsTUFBTSxJQUFJLFlBQVksRUFBRSxnQkFBZ0IsRUFBRSxHQUFHLEtBQUssRUFBRSxLQUFLO0FBQUEsSUFDckYsRUFBRSxLQUFLLEVBQUUsQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVloQixVQUFNLE1BQWEsT0FBTyxlQUFlLFFBQVE7QUFDakQsVUFBTSxXQUFhLE9BQU8sZUFBZSxjQUFjO0FBQ3ZELFVBQU0sU0FBYSxPQUFPLGVBQWUsWUFBWTtBQUNyRCxVQUFNLFFBQWEsT0FBTyxlQUFlLFVBQVU7QUFDbkQsVUFBTSxhQUFhLE9BQU8sZUFBZSxnQkFBZ0I7QUFDekQsVUFBTSxhQUFhLE9BQU8sZUFBZSxZQUFZO0FBQ3JELFVBQU0sV0FBYSxPQUFPLGVBQWUsV0FBVztBQUNwRCxVQUFNLFVBQWEsT0FBTyxlQUFlLFVBQVU7QUFDbkQsVUFBTSxZQUFhLE9BQU8sZUFBZSxZQUFZO0FBQ3JELFVBQU0sWUFBYSxPQUFPLGVBQWUsV0FBVztBQUNwRCxVQUFNLFlBQWEsT0FBTyxlQUFlLFdBQVc7QUFDcEQsVUFBTSxZQUFhLE9BQU8sZUFBZSxlQUFlO0FBQ3hELFVBQU0sWUFBYSxPQUFPLGVBQWUsaUJBQWlCO0FBQzFELFVBQU0sYUFBYSxPQUFPLGVBQWUsa0JBQWtCO0FBQzNELFVBQU0sV0FBYSxPQUFPLGVBQWUsWUFBWTtBQUNyRCxVQUFNLFdBQWEsT0FBTyxlQUFlLFlBQVk7QUFHckQsV0FBTyxpQkFBb0MsVUFBVSxFQUFFLFFBQVEsUUFBTTtBQUNuRSxTQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDakMsZUFBTyxpQkFBaUIsVUFBVSxFQUFFLFFBQVEsT0FBSyxFQUFFLFVBQVUsT0FBTyxRQUFRLENBQUM7QUFDN0UsV0FBRyxVQUFVLElBQUksUUFBUTtBQUN6QixXQUFHLE1BQU0sYUFBZ0IsR0FBRyxRQUFRLFNBQVM7QUFDN0MsV0FBRyxNQUFNLGNBQWdCLEdBQUcsUUFBUSxTQUFTO0FBQzdDLHVCQUFlLEdBQUcsUUFBUTtBQUMxQixtQkFBVyxXQUFXO0FBQ3RCLGtCQUFVLEVBQUU7QUFBRyxnQkFBUSxVQUFVLE9BQU8sU0FBUztBQUNqRCxrQkFBVSxVQUFVLE9BQU8sU0FBUztBQUFBLE1BQ3RDLENBQUM7QUFBQSxJQUNILENBQUM7QUFHRCxXQUFPLGlCQUFvQyxXQUFXLEVBQUUsUUFBUSxRQUFNO0FBQ3BFLFNBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUNqQyxlQUFPLGlCQUFpQixXQUFXLEVBQUUsUUFBUSxPQUFLLEVBQUUsVUFBVSxPQUFPLFFBQVEsQ0FBQztBQUM5RSxXQUFHLFVBQVUsSUFBSSxRQUFRO0FBQ3pCLDZCQUFxQixHQUFHLFFBQVE7QUFBQSxNQUNsQyxDQUFDO0FBQUEsSUFDSCxDQUFDO0FBR0QsZUFBVyxNQUFNO0FBQ2YsWUFBTSxNQUFNLG9CQUFvQixXQUFXO0FBQzNDLHVCQUE0RTtBQUFBLFFBQzFFLE1BQU07QUFBQSxRQUNOLFNBQVM7QUFBQSxNQUNYLENBQUMsRUFBRSxLQUFLLENBQUMsU0FBUztBQUNoQixZQUFJLFlBQVksUUFBUSxLQUFLLFFBQVEsY0FBYztBQUNqRCxnQ0FBc0IsS0FBSyxPQUFPO0FBQ2xDLGdCQUFNLFFBQVEsb0JBQW9CLE9BQU8sQ0FBQyxFQUFFLFlBQVksSUFBSSxvQkFBb0IsTUFBTSxDQUFDO0FBQ3ZGLG1CQUFTLGNBQWM7QUFDdkIsbUJBQVMsVUFBVSxPQUFPLFFBQVE7QUFBQSxRQUNwQztBQUFBLE1BQ0YsQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUFBLE1BQUMsQ0FBQztBQUFBLElBQ25CLEdBQUcsR0FBRztBQUVOLFVBQU0sZ0JBQWdCLENBQUMsZ0JBQWdCLFlBQVksYUFBYSxjQUFjLFFBQVE7QUFDdEYsYUFBUyxpQkFBaUIsU0FBUyxNQUFNO0FBQ3ZDLFlBQU0sVUFBVSxtQkFBbUI7QUFDbkMsWUFBTSxNQUFNLGNBQWMsUUFBUSxPQUFPO0FBQ3pDLHdCQUFrQixlQUFlLE1BQU0sS0FBSyxjQUFjLE1BQU07QUFDaEUsWUFBTSxRQUFRLGdCQUFnQixPQUFPLENBQUMsRUFBRSxZQUFZLElBQUksZ0JBQWdCLE1BQU0sQ0FBQztBQUMvRSxlQUFTLGNBQWM7QUFDdkIsdUJBQWlCO0FBQUEsUUFDZixNQUFNO0FBQUEsUUFDTixTQUFTO0FBQUEsVUFDUCxrQkFBa0I7QUFBQSxVQUNsQixrQkFBa0I7QUFBQSxVQUNsQixVQUFVO0FBQUEsUUFDWjtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUdELFFBQUksaUJBQWlCLFNBQVMsTUFBTTtBQUNsQyxrQkFBWSxDQUFDO0FBQ2IsVUFBSSxXQUFXO0FBQUUseUJBQWlCO0FBQU8sbUJBQVcsVUFBVSxPQUFPLE1BQU07QUFBQSxNQUFHO0FBQzlFLFlBQU0sVUFBVSxPQUFPLFFBQVEsU0FBUztBQUN4QyxVQUFJLFVBQVcsZUFBYyxLQUFLLEtBQUs7QUFBQSxJQUN6QyxDQUFDO0FBRUQsV0FBTyxpQkFBaUIsU0FBUyxNQUFNO0FBQ3JDLHVCQUFpQixDQUFDO0FBQ2xCLFVBQUksZ0JBQWdCO0FBQUUsb0JBQVk7QUFBTyxjQUFNLFVBQVUsT0FBTyxNQUFNO0FBQUEsTUFBRztBQUN6RSxpQkFBVyxVQUFVLE9BQU8sUUFBUSxjQUFjO0FBQ2xELFVBQUksZUFBZ0IsZUFBYyxRQUFRLFVBQVU7QUFBQSxJQUN0RCxDQUFDO0FBRUQsYUFBUyxpQkFBaUIsU0FBUyxDQUFDLE1BQU07QUFDeEMsVUFBSSxDQUFDLEtBQUssU0FBUyxFQUFFLE1BQWMsR0FBRztBQUNwQyxvQkFBWTtBQUFPLGNBQU0sVUFBVSxPQUFPLE1BQU07QUFDaEQseUJBQWlCO0FBQU8sbUJBQVcsVUFBVSxPQUFPLE1BQU07QUFBQSxNQUM1RDtBQUFBLElBQ0YsR0FBRyxJQUFJO0FBRVAsYUFBUyxjQUFjLFFBQXFCLEdBQXlCO0FBQ25FLFlBQU0sT0FBTyxPQUFPLHNCQUFzQjtBQUMxQyxZQUFNLGFBQWEsU0FBUyxFQUFFLE1BQU0sU0FBUyxLQUFLO0FBQ2xELFFBQUUsTUFBTSxTQUFTLEdBQUcsT0FBTyxjQUFjLEtBQUssTUFBTSxDQUFDO0FBQ3JELFFBQUUsTUFBTSxPQUFTLEdBQUcsS0FBSyxJQUFJLEtBQUssTUFBTSxPQUFPLGFBQWEsYUFBYSxFQUFFLENBQUM7QUFBQSxJQUM5RTtBQUdBLGVBQVcsaUJBQWlCLFNBQVMsWUFBWTtBQUMvQyxVQUFJLENBQUMsYUFBYztBQUNuQixZQUFNLE9BQU8sWUFBWSxXQUFXO0FBQ3BDLFVBQUksQ0FBQyxNQUFNO0FBQUUsa0JBQVUsMEJBQTBCLE9BQU87QUFBRztBQUFBLE1BQVE7QUFFbkUscUJBQWU7QUFDZixVQUFJLFdBQVc7QUFBTSxpQkFBVyxXQUFXO0FBQzNDLGdCQUFVLGlCQUFZO0FBQUcsZ0JBQVUsVUFBVSxPQUFPLFNBQVM7QUFFN0QsVUFBSTtBQUNGLGNBQU0sVUFBVSxvQkFBb0IsV0FBVztBQUMvQyxjQUFNLE9BQU8sTUFBTSxpQkFBa0U7QUFBQSxVQUNuRixNQUFNO0FBQUEsVUFDTixTQUFTLEVBQUUsTUFBTSxNQUFNLGNBQWMsS0FBSyxFQUFFLEdBQUcsU0FBUyx1QkFBdUIsZ0JBQWdCLEVBQUU7QUFBQSxRQUNuRyxDQUFDO0FBQ0QsWUFBSSxXQUFXLEtBQU0sT0FBTSxJQUFJLE1BQU0sT0FBTyxLQUFLLEtBQUssQ0FBQztBQUN2RCx3QkFBZ0IsS0FBSyxPQUFPO0FBQzVCLHFCQUFhLGFBQTRCLEtBQUssT0FBTyxXQUFXO0FBQ2hFLGtCQUFVLGVBQVUsU0FBUztBQUM3QixrQkFBVSxVQUFVLElBQUksU0FBUztBQUFBLE1BQ25DLFNBQVMsS0FBSztBQUNaLGNBQU0sTUFBTSxlQUFlLFFBQVEsSUFBSSxVQUFVO0FBQ2pELFlBQUksSUFBSSxXQUFXLGdCQUFnQixHQUFHO0FBQ3BDLGtCQUFRLFVBQVUsSUFBSSxTQUFTO0FBQUcsb0JBQVUsRUFBRTtBQUFBLFFBQ2hELE9BQU87QUFDTCxvQkFBVSxLQUFLLE9BQU87QUFBQSxRQUN4QjtBQUFBLE1BQ0YsVUFBRTtBQUNBLFlBQUksV0FBVztBQUNmLG1CQUFXLFdBQVcsaUJBQWlCO0FBQUEsTUFDekM7QUFBQSxJQUNGLENBQUM7QUFFRCxjQUFVLGlCQUFpQixTQUFTLE1BQU07QUFDeEMsVUFBSSxjQUFlLGtCQUFpQixFQUFFLE1BQU0sWUFBWSxTQUFTLEVBQUUsV0FBVyxlQUFlLFFBQVEsV0FBVyxFQUFFLENBQUM7QUFDbkgsZ0JBQVUsVUFBVSxPQUFPLFNBQVM7QUFDcEMsa0JBQVk7QUFBTyxZQUFNLFVBQVUsT0FBTyxNQUFNO0FBQ2hELGdCQUFVLEVBQUU7QUFBQSxJQUNkLENBQUM7QUFFRCxjQUFVLGlCQUFpQixTQUFTLE1BQU07QUFDeEMsVUFBSSxhQUFjLGNBQWEsYUFBNEIsWUFBWTtBQUN2RSxVQUFJLGNBQWUsa0JBQWlCLEVBQUUsTUFBTSxZQUFZLFNBQVMsRUFBRSxXQUFXLGVBQWUsUUFBUSxXQUFXLEVBQUUsQ0FBQztBQUNuSCxnQkFBVSxVQUFVLE9BQU8sU0FBUztBQUNwQyxnQkFBVSxhQUFhLFNBQVM7QUFDaEMsaUJBQVcsTUFBTSxVQUFVLEVBQUUsR0FBRyxHQUFJO0FBQUEsSUFDdEMsQ0FBQztBQUVELGFBQVMsVUFBVSxLQUFhLE1BQU0sSUFBVTtBQUM5QyxlQUFTLGNBQWM7QUFBSyxlQUFTLFlBQVk7QUFBQSxJQUNuRDtBQUdBLGNBQVUsaUJBQWlCLFNBQVMsWUFBWTtBQUM5QyxVQUFJLENBQUMsVUFBVyxPQUFNLGVBQWU7QUFBQSxVQUFRLGVBQWM7QUFBQSxJQUM3RCxDQUFDO0FBRUQsbUJBQWUsaUJBQWdDO0FBQzdDLFVBQUk7QUFDRixjQUFNLFNBQVMsTUFBTSxVQUFVLGFBQWEsYUFBYSxFQUFFLE9BQU8sS0FBSyxDQUFDO0FBQ3hFLHNCQUFjLENBQUM7QUFDZixtQkFBVyxJQUFJLGNBQWMsUUFBUSxFQUFFLFVBQVUsYUFBYSxDQUFDO0FBQy9ELGlCQUFTLGtCQUFrQixDQUFDLE1BQU07QUFBRSxjQUFJLEVBQUUsS0FBSyxPQUFPLEVBQUcsYUFBWSxLQUFLLEVBQUUsSUFBSTtBQUFBLFFBQUc7QUFDbkYsaUJBQVMsU0FBUyxZQUFZO0FBQzVCLGlCQUFPLFVBQVUsRUFBRSxRQUFRLE9BQUssRUFBRSxLQUFLLENBQUM7QUFDeEMsZ0JBQU0sWUFBWSxJQUFJLEtBQUssYUFBYSxFQUFFLE1BQU0sYUFBYSxDQUFDLENBQUM7QUFBQSxRQUNqRTtBQUNBLGlCQUFTLE1BQU07QUFDZixvQkFBWTtBQUNaLGVBQU8sVUFBVSxJQUFJLFdBQVc7QUFDaEMsa0JBQVUsVUFBVSxJQUFJLFdBQVc7QUFDbkMsa0JBQVUsY0FBYztBQUN4Qix1QkFBZSxpQkFBWTtBQUMzQixtQkFBVyxVQUFVLE9BQU8sU0FBUztBQUNyQyxtQkFBVyxNQUFNO0FBQUUsY0FBSSxVQUFXLGVBQWM7QUFBQSxRQUFHLEdBQUcsR0FBTTtBQUFBLE1BQzlELFFBQVE7QUFDTix1QkFBZSw2QkFBNkIsT0FBTztBQUFBLE1BQ3JEO0FBQUEsSUFDRjtBQUVBLGFBQVMsZ0JBQXNCO0FBQzdCLFVBQUksWUFBWSxXQUFXO0FBQ3pCLGlCQUFTLEtBQUs7QUFDZCxvQkFBWTtBQUNaLGVBQU8sVUFBVSxPQUFPLFdBQVc7QUFDbkMsa0JBQVUsVUFBVSxPQUFPLFdBQVc7QUFDdEMsa0JBQVUsY0FBYztBQUN4QixrQkFBVSxXQUFXO0FBQ3JCLHVCQUFlLGdCQUFXO0FBQUEsTUFDNUI7QUFBQSxJQUNGO0FBRUEsbUJBQWUsWUFBWSxNQUEyQjtBQUNwRCxVQUFJO0FBQ0YsY0FBTSxLQUFLLE1BQU0sS0FBSyxZQUFZO0FBQ2xDLGNBQU0sS0FBSyxJQUFJLFdBQVcsRUFBRTtBQUM1QixZQUFJLE1BQU07QUFDVixpQkFBUyxJQUFJLEdBQUcsSUFBSSxHQUFHLFFBQVEsSUFBSyxRQUFPLE9BQU8sYUFBYSxHQUFHLENBQUMsQ0FBQztBQUNwRSxjQUFNLFlBQVksS0FBSyxHQUFHO0FBRTFCLDRCQUFvQixZQUFZLFdBQVc7QUFFM0MsY0FBTSxPQUFPLE1BQU0saUJBQXFFO0FBQUEsVUFDdEYsTUFBTTtBQUFBLFVBQ04sU0FBUyxFQUFFLFdBQVcsVUFBVSxjQUFjLFlBQVksbUJBQW1CO0FBQUEsUUFDL0UsQ0FBQztBQUNELFlBQUksV0FBVyxLQUFNLE9BQU0sSUFBSSxNQUFNLE9BQU8sS0FBSyxLQUFLLENBQUM7QUFFdkQsNkJBQXFCLEtBQUssT0FBTztBQUNqQyxxQkFBYSxhQUE0QixLQUFLLE9BQU8sS0FBSztBQUMxRCx1QkFBZSxhQUFRO0FBQ3ZCLG1CQUFXLFVBQVUsSUFBSSxTQUFTO0FBQUEsTUFDcEMsU0FBUyxLQUFLO0FBQ1osdUJBQWUsZUFBZSxRQUFRLElBQUksVUFBVSxVQUFVLE9BQU87QUFBQSxNQUN2RSxVQUFFO0FBQ0Esa0JBQVUsV0FBVztBQUFBLE1BQ3ZCO0FBQUEsSUFDRjtBQUVBLGFBQVMsaUJBQWlCLFNBQVMsTUFBTTtBQUN2QyxVQUFJLG1CQUFvQixrQkFBaUIsRUFBRSxNQUFNLGtCQUFrQixTQUFTLEVBQUUsV0FBVyxvQkFBb0IsVUFBVSxNQUFNLGFBQWEsS0FBSyxFQUFFLENBQUM7QUFDbEosaUJBQVcsVUFBVSxPQUFPLFNBQVM7QUFDckMsdUJBQWlCO0FBQU8saUJBQVcsVUFBVSxPQUFPLE1BQU07QUFDMUQscUJBQWUsRUFBRTtBQUFBLElBQ25CLENBQUM7QUFFRCxhQUFTLGlCQUFpQixTQUFTLE1BQU07QUFDdkMsVUFBSSxrQkFBbUIsY0FBYSxhQUE0QixpQkFBaUI7QUFDakYsVUFBSSxtQkFBb0Isa0JBQWlCLEVBQUUsTUFBTSxrQkFBa0IsU0FBUyxFQUFFLFdBQVcsb0JBQW9CLFVBQVUsT0FBTyxhQUFhLEtBQUssRUFBRSxDQUFDO0FBQ25KLGlCQUFXLFVBQVUsT0FBTyxTQUFTO0FBQ3JDLHFCQUFlLGFBQWEsU0FBUztBQUNyQyxpQkFBVyxNQUFNLGVBQWUsRUFBRSxHQUFHLEdBQUk7QUFBQSxJQUMzQyxDQUFDO0FBRUQsYUFBUyxlQUFlLEtBQWEsTUFBTSxJQUFVO0FBQ25ELGdCQUFVLGNBQWM7QUFBSyxnQkFBVSxZQUFZO0FBQUEsSUFDckQ7QUFHQSxZQUFRLGFBQWEsTUFBTSxPQUFPO0FBQUEsRUFDcEM7QUFTQSxXQUFTLGVBQWUsYUFBc0M7QUFDNUQsUUFBSSxLQUFxQjtBQUN6QixhQUFTLElBQUksR0FBRyxJQUFJLElBQUksS0FBSztBQUMzQixVQUFJLENBQUMsR0FBSTtBQUNULFlBQU0sT0FBTyxHQUFHLGNBQWMsZUFBZTtBQUM3QyxVQUFJLEtBQU0sUUFBTztBQUNqQixXQUFLLEdBQUc7QUFBQSxJQUNWO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFFQSxXQUFTLFlBQVksSUFBcUI7QUFDeEMsV0FBUSxHQUFtQixVQUFVLEtBQUs7QUFBQSxFQUM1QztBQUVBLFdBQVMsYUFBYSxJQUFpQixNQUFvQjtBQUN6RCxPQUFHLE1BQU07QUFFVCxhQUFTLFlBQVksYUFBYSxPQUFPLE1BQVM7QUFDbEQsYUFBUyxZQUFZLFVBQVUsT0FBTyxNQUFTO0FBQy9DLFVBQU0sUUFBUSxLQUFLLE1BQU0sSUFBSTtBQUM3QixhQUFTLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLO0FBQ3JDLFVBQUksTUFBTSxDQUFDLEVBQUcsVUFBUyxZQUFZLGNBQWMsT0FBTyxNQUFNLENBQUMsQ0FBQztBQUNoRSxVQUFJLElBQUksTUFBTSxTQUFTLEVBQUcsVUFBUyxZQUFZLG1CQUFtQixPQUFPLE1BQVM7QUFBQSxJQUNwRjtBQUFBLEVBQ0Y7QUFFQSxXQUFTLGlCQUFvQixTQUE2QjtBQUN4RCxXQUFPLElBQUksUUFBUSxDQUFDLFlBQVk7QUFDOUIsYUFBTyxRQUFRLFlBQVksU0FBUyxPQUFPO0FBQUEsSUFDN0MsQ0FBQztBQUFBLEVBQ0g7QUFJQSxNQUFNLE9BQU8sb0JBQUksUUFBaUI7QUFFbEMsV0FBUyxVQUFVLE1BQWdDO0FBQ2pELFNBQUssaUJBQTBCLGdCQUFnQixFQUFFLFFBQVEsQ0FBQyxTQUFTO0FBRWpFLFVBQUksQ0FBQyxlQUFlLElBQUksRUFBRztBQUMzQixVQUFJLENBQUMsS0FBSyxJQUFJLElBQUksR0FBRztBQUNuQixhQUFLLElBQUksSUFBSTtBQUNiLGVBQU8sSUFBSTtBQUFBLE1BQ2I7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBR0EsTUFBTSxXQUFXLElBQUksaUJBQWlCLE1BQU0sVUFBVSxRQUFRLENBQUM7QUFDL0QsV0FBUyxRQUFRLFNBQVMsTUFBTSxFQUFFLFdBQVcsTUFBTSxTQUFTLEtBQUssQ0FBQztBQUlsRSxjQUFZLE1BQU0sVUFBVSxRQUFRLEdBQUcsR0FBSTtBQUczQyxZQUFVLFFBQVE7QUFJbEIsV0FBUyxpQkFBaUIsV0FBVyxDQUFDLE1BQU07QUFDMUMsUUFBSSxFQUFFLEVBQUUsV0FBVyxFQUFFLFlBQVksQ0FBQyxFQUFFLFNBQVU7QUFFOUMsVUFBTSxZQUFZLFNBQVMsY0FBYyxJQUFJLFNBQVMsR0FBRztBQUN6RCxRQUFJLENBQUMsVUFBVztBQUNoQixVQUFNLFFBQVEsTUFBTSxLQUFLLFVBQVUsUUFBUSxFQUFFLE9BQU8sT0FBSyxFQUFFLFVBQVU7QUFFckUsUUFBSSxFQUFFLFFBQVEsS0FBSztBQUNqQixRQUFFLGVBQWU7QUFDakIsTUFBQyxNQUFNLENBQUMsR0FBRyxZQUFZLGVBQWUsUUFBUSxHQUFnQyxNQUFNO0FBQUEsSUFDdEY7QUFDQSxRQUFJLEVBQUUsUUFBUSxLQUFLO0FBQ2pCLFFBQUUsZUFBZTtBQUNqQixNQUFDLE1BQU0sQ0FBQyxHQUFHLFlBQVksZUFBZSxZQUFZLEdBQWdDLE1BQU07QUFBQSxJQUMxRjtBQUFBLEVBQ0YsQ0FBQzsiLAogICJuYW1lcyI6IFtdCn0K
