"use strict";(()=>{var ne=['div[role="textbox"][aria-multiline="true"]','div[contenteditable="true"][aria-multiline="true"]'].join(", "),oe=['button[aria-label^="Send"]','button[aria-label*=" (Ctrl+Enter)"]','button[aria-label*=" (\u2318+Enter)"]','button[data-testid*="sendButton" i]'].join(", "),O="data-wt-ol-injected",ie=[{key:"professional",label:"Professional",color:"#4F46E5"},{key:"casual",label:"Casual",color:"#06B6D4"},{key:"friendly",label:"Friendly",color:"#F59E0B"},{key:"direct",label:"Direct",color:"#DC2626"},{key:"diplomatic",label:"Diplomatic",color:"#7C3AED"},{key:"executive",label:"Executive",color:"#0F172A"}],re=[{key:"reply",label:"Reply"},{key:"email",label:"Email"},{key:"customer_update",label:"Customer Update"},{key:"jira_ticket",label:"Jira Ticket"},{key:"technical_report",label:"Tech Report"}],ae=`
  :host { display: inline-flex; align-items: center; margin: 0 4px; }

  /* \u2500\u2500 Humanize button \u2500\u2500 */
  #wt-btn {
    display: inline-flex; align-items: center; gap: 5px;
    height: 26px; padding: 0 11px; border-radius: 9999px; border: none;
    background: #4F46E5; color: #fff;
    font: 500 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer; white-space: nowrap; transition: background 0.15s, box-shadow 0.15s;
  }
  #wt-btn:hover  { background: #3F37C9; box-shadow: 0 0 0 3px rgba(79,70,229,0.25); }
  #wt-btn:disabled { opacity: 0.6; cursor: default; box-shadow: none; }

  /* \u2500\u2500 Mic button \u2500\u2500 */
  #wt-mic-btn {
    display: inline-flex; align-items: center; justify-content: center;
    width: 26px; height: 26px; border-radius: 9999px; border: none;
    background: transparent; color: #323130; cursor: pointer;
    font-size: 14px; line-height: 1; margin-left: 3px;
    transition: background 0.15s;
  }
  #wt-mic-btn:hover { background: rgba(0,0,0,0.06); }
  #wt-mic-btn.recording {
    background: #FEE2E2; color: #DC2626;
    animation: wt-pulse 1.2s ease-in-out infinite;
  }
  @keyframes wt-pulse {
    0%, 100% { box-shadow: 0 0 0 0 rgba(220,38,38,0.4); }
    50%       { box-shadow: 0 0 0 5px rgba(220,38,38,0); }
  }

  /* \u2500\u2500 Shared panel \u2500\u2500 */
  .wt-panel {
    position: fixed; z-index: 100000;
    background: #fff; border: 1px solid #EDEBE9; border-radius: 10px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.18);
    padding: 14px 16px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: none;
  }
  .wt-panel.open { display: block; }

  /* \u2500\u2500 Humanize panel \u2500\u2500 */
  #wt-panel { width: 260px; }
  .wt-title {
    font-size: 12px; font-weight: 600; color: #323130; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase;
  }
  .wt-tones { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 12px; }
  .wt-tone {
    padding: 4px 10px; border-radius: 9999px; border: 1.5px solid #EDEBE9;
    background: #fff; font-size: 12px; font-weight: 500; color: #323130; cursor: pointer;
    transition: all 0.1s;
  }
  .wt-tone.active { color: #fff; border-color: transparent; }
  .wt-tone:hover:not(.active) { border-color: #9BA0FF; }

  #wt-rewrite {
    width: 100%; height: 32px; border-radius: 8px; border: none;
    background: #4F46E5; color: #fff;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer;
  }
  #wt-rewrite:disabled { opacity: 0.45; cursor: default; }

  #wt-status {
    margin-top: 8px; font-size: 11px; text-align: center; min-height: 14px;
  }
  #wt-status.error   { color: #A4262C; }
  #wt-status.success { color: #107C10; }

  #wt-limit {
    display: none; margin-top: 10px; padding: 10px 12px; border-radius: 8px;
    background: #FFF8F1; border: 1px solid #FED7AA; text-align: center;
  }
  #wt-limit.visible { display: block; }
  #wt-limit p { font-size: 11px; color: #92400E; margin: 0 0 8px; line-height: 1.4; }
  #wt-limit a {
    display: inline-block; padding: 5px 14px; border-radius: 9999px;
    background: #F59E0B; color: #fff; font-size: 11px; font-weight: 600;
    text-decoration: none;
  }

  #wt-actions { display: none; gap: 6px; margin-top: 8px; }
  #wt-actions.visible { display: flex; }
  .wt-action {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #EDEBE9;
    background: #fff; font-size: 12px; font-weight: 500; color: #323130; cursor: pointer;
  }
  .wt-action.accept { border-color: #107C10; color: #107C10; }
  .wt-action.reject { border-color: #A4262C; color: #A4262C; }

  /* \u2500\u2500 Voice panel \u2500\u2500 */
  #wt-voice-panel { width: 280px; }
  .wt-vt { font-size: 12px; font-weight: 600; color: #323130; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase; }
  .wt-otype-label { font-size: 11px; color: #605E5C; margin-bottom: 4px; }
  .wt-otypes { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 10px; }
  .wt-otype {
    padding: 3px 9px; border-radius: 9999px; border: 1.5px solid #EDEBE9;
    background: #fff; font-size: 11px; color: #323130; cursor: pointer; transition: all 0.1s;
  }
  .wt-otype.active { background: #4F46E5; color: #fff; border-color: #4F46E5; }
  #wt-record-btn {
    width: 100%; height: 32px; border-radius: 8px; border: none;
    background: #DC2626; color: #fff; cursor: pointer; margin-bottom: 10px;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }
  #wt-record-btn.recording { background: #7F1D1D; }
  #wt-record-btn:disabled  { opacity: 0.5; cursor: default; }
  #wt-voice-status { font-size: 11px; text-align: center; min-height: 14px; color: #605E5C; }
  #wt-voice-status.error { color: #A4262C; }
  #wt-voice-actions { display: none; gap: 6px; margin-top: 8px; }
  #wt-voice-actions.visible { display: flex; }
  .wt-va {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #EDEBE9;
    background: #fff; font-size: 12px; font-weight: 500; color: #323130; cursor: pointer;
  }
  .wt-va.accept { border-color: #107C10; color: #107C10; }
  .wt-va.reject { border-color: #A4262C; color: #A4262C; }
`;function K(n){let o=n,r=null;for(let l=0;l<25&&o;l++){if(o.querySelector('[role="list"][aria-label*="To" i], input[aria-label*="To" i]')){r=o;break}o=o.parentElement}let a,i;if(r){let l=r.querySelector('[data-email], [title*="@"], [aria-label*="@"]');if(l){let c=l.getAttribute("data-email")??l.getAttribute("title")??l.getAttribute("aria-label")??"";c.includes("@")&&(a=c.split("@")[1].split(">")[0].toLowerCase().trim())}let p=r.querySelector('input[aria-label*="Subject" i], input[placeholder*="Subject" i]');p?.value&&(i=p.value)}return{platform:"outlook",recipient_domain:a,thread_subject:i}}function se(n){let o=Y(n);if(!o)return;let r=o.closest('[role="toolbar"]')??o.closest('[role="group"]')??o.parentElement;if(!r||r.hasAttribute(O))return;r.setAttribute(O,"1");let a=document.createElement("span"),i=a.attachShadow({mode:"open"}),l=null,p=null,c=!1,u=!1,z="reply",E="professional",w,g=null,x=!1,I=[],v=null,A="",F="";i.innerHTML=`
    <style>${ae}
    #wt-ctx-badge {
      display: inline-flex; align-items: center;
      height: 18px; padding: 0 7px; border-radius: 9999px;
      background: #EEF2FF; color: #4338CA; font-size: 10px; font-weight: 600;
      margin-left: 4px; cursor: pointer; white-space: nowrap; transition: background 0.1s;
    }
    #wt-ctx-badge:hover { background: #E0E7FF; }
    #wt-ctx-badge.hidden { display: none; }
    </style>

    <button id="wt-btn" title="Humanize with Writing Twin AI (Ctrl+Shift+H)">\u2728 Humanize</button>
    <span id="wt-ctx-badge" class="hidden" title="Detected context \u2014 click to override"></span>
    <button id="wt-mic-btn" title="Voice Twin \u2014 speak your email (Ctrl+Shift+V)">\u{1F399}</button>

    <div id="wt-panel" class="wt-panel">
      <p class="wt-title">Rewrite tone</p>
      <div class="wt-tones">
        ${ie.map(e=>`<button class="wt-tone" data-tone="${e.key}" data-color="${e.color}">${e.label}</button>`).join("")}
      </div>
      <button id="wt-rewrite" disabled>Rewrite \u2192</button>
      <div id="wt-status"></div>
      <div id="wt-limit">
        <p>You've used all your free rewrites this month.</p>
        <a href="https://writingtwinai.com/pricing" target="_blank" rel="noopener">Upgrade to Pro \u2014 $5/mo</a>
      </div>
      <div id="wt-actions">
        <button class="wt-action accept" id="wt-accept">\u2713 Keep it</button>
        <button class="wt-action reject" id="wt-reject">\u2717 Undo</button>
      </div>
    </div>

    <div id="wt-voice-panel" class="wt-panel">
      <p class="wt-vt">Voice Twin</p>
      <div class="wt-otype-label">Output type</div>
      <div class="wt-otypes">
        ${re.map((e,t)=>`<button class="wt-otype${t===0?" active":""}" data-type="${e.key}">${e.label}</button>`).join("")}
      </div>
      <button id="wt-record-btn">\u{1F399} Start recording</button>
      <div id="wt-voice-status"></div>
      <div id="wt-voice-actions">
        <button class="wt-va accept" id="wt-va-keep">\u2713 Keep it</button>
        <button class="wt-va reject" id="wt-va-undo">\u2717 Undo</button>
      </div>
    </div>
  `;let k=i.getElementById("wt-btn"),L=i.getElementById("wt-ctx-badge"),C=i.getElementById("wt-mic-btn"),y=i.getElementById("wt-panel"),h=i.getElementById("wt-voice-panel"),B=i.getElementById("wt-rewrite"),V=i.getElementById("wt-status"),U=i.getElementById("wt-limit"),T=i.getElementById("wt-actions"),X=i.getElementById("wt-accept"),J=i.getElementById("wt-reject"),b=i.getElementById("wt-record-btn"),P=i.getElementById("wt-voice-status"),S=i.getElementById("wt-voice-actions"),Z=i.getElementById("wt-va-keep"),G=i.getElementById("wt-va-undo");i.querySelectorAll(".wt-tone").forEach(e=>{e.addEventListener("click",()=>{i.querySelectorAll(".wt-tone").forEach(t=>t.classList.remove("active")),e.classList.add("active"),e.style.background=e.dataset.color??"#4F46E5",e.style.borderColor=e.dataset.color??"#4F46E5",l=e.dataset.tone,B.disabled=!1,d(""),U.classList.remove("visible"),T.classList.remove("visible")})}),i.querySelectorAll(".wt-otype").forEach(e=>{e.addEventListener("click",()=>{i.querySelectorAll(".wt-otype").forEach(t=>t.classList.remove("active")),e.classList.add("active"),z=e.dataset.type})}),setTimeout(()=>{let e=K(n);f({type:"DETECT_CONTEXT",payload:e}).then(t=>{if("result"in t&&t.result?.context_twin){E=t.result.context_twin;let s=E.charAt(0).toUpperCase()+E.slice(1);L.textContent=s,L.classList.remove("hidden")}}).catch(()=>{})},800);let R=["professional","customer","technical","escalation","casual"];L.addEventListener("click",()=>{let e=w??E,t=R.indexOf(e);w=R[(t+1)%R.length];let s=w.charAt(0).toUpperCase()+w.slice(1);L.textContent=s,f({type:"CONTEXT_OVERRIDE",payload:{detected_context:E,selected_context:w,platform:"outlook"}})}),k.addEventListener("click",()=>{c=!c,c&&(u=!1,h.classList.remove("open")),y.classList.toggle("open",c),c&&$(k,y)}),C.addEventListener("click",()=>{u=!u,u&&(c=!1,y.classList.remove("open")),h.classList.toggle("open",u),u&&$(C,h)}),document.addEventListener("click",e=>{a.contains(e.target)||(c=!1,y.classList.remove("open"),u=!1,h.classList.remove("open"))},!0);function $(e,t){let s=e.getBoundingClientRect(),D=parseInt(t.style.width||"260");t.style.bottom=`${window.innerHeight-s.top+6}px`,t.style.left=`${Math.min(s.left,window.innerWidth-D-20)}px`}B.addEventListener("click",async()=>{if(!l)return;let e=N(n);if(!e){d("Write something first.","error");return}A=e,k.disabled=!0,B.disabled=!0,d("Rewriting\u2026"),T.classList.remove("visible");try{let t=K(n),s=await f({type:"HUMANIZE",payload:{text:e,tone:l,ctx:{...t,context_twin_override:w}}});if("error"in s)throw new Error(String(s.error));p=s.result.id,H(n,s.result.output_text),d("Done \u2713","success"),T.classList.add("visible")}catch(t){let s=t instanceof Error?t.message:"Failed";s.startsWith("LIMIT_REACHED:")?(U.classList.add("visible"),d("")):d(s,"error")}finally{k.disabled=!1,B.disabled=l===null}}),X.addEventListener("click",()=>{p&&f({type:"FEEDBACK",payload:{rewriteId:p,action:"accepted"}}),T.classList.remove("visible"),c=!1,y.classList.remove("open"),d("")}),J.addEventListener("click",()=>{A&&H(n,A),p&&f({type:"FEEDBACK",payload:{rewriteId:p,action:"rejected"}}),T.classList.remove("visible"),d("Reverted.","success"),setTimeout(()=>d(""),2e3)});function d(e,t=""){V.textContent=e,V.className=t}b.addEventListener("click",async()=>{x?q():await Q()});async function Q(){try{let e=await navigator.mediaDevices.getUserMedia({audio:!0});I=[],g=new MediaRecorder(e,{mimeType:"audio/webm"}),g.ondataavailable=t=>{t.data.size>0&&I.push(t.data)},g.onstop=async()=>{e.getTracks().forEach(t=>t.stop()),await ee(new Blob(I,{type:"audio/webm"}))},g.start(),x=!0,C.classList.add("recording"),b.classList.add("recording"),b.textContent="\u23F9 Stop recording",m("Recording\u2026"),S.classList.remove("visible"),setTimeout(()=>{x&&q()},6e4)}catch{m("Microphone access denied.","error")}}function q(){g&&x&&(g.stop(),x=!1,C.classList.remove("recording"),b.classList.remove("recording"),b.textContent="\u{1F399} Start recording",b.disabled=!0,m("Drafting\u2026"))}async function ee(e){try{let t=await e.arrayBuffer(),s=new Uint8Array(t),D="";for(let _=0;_<s.length;_++)D+=String.fromCharCode(s[_]);let te=btoa(D);F=N(n);let M=await f({type:"VOICE_DRAFT",payload:{audioData:te,mimeType:"audio/webm",outputType:z}});if("error"in M)throw new Error(String(M.error));v=M.result.id,H(n,M.result.draft),m("Done \u2713"),S.classList.add("visible")}catch(t){m(t instanceof Error?t.message:"Failed","error")}finally{b.disabled=!1}}Z.addEventListener("click",()=>{v&&f({type:"VOICE_FEEDBACK",payload:{sessionId:v,accepted:!0,editedDraft:null}}),S.classList.remove("visible"),u=!1,h.classList.remove("open"),m("")}),G.addEventListener("click",()=>{F&&H(n,F),v&&f({type:"VOICE_FEEDBACK",payload:{sessionId:v,accepted:!1,editedDraft:null}}),S.classList.remove("visible"),m("Reverted.","success"),setTimeout(()=>m(""),2e3)});function m(e,t=""){P.textContent=e,P.className=t}r.insertBefore(a,o)}function Y(n){let o=n;for(let r=0;r<30&&o;r++){let a=o.querySelector(oe);if(a)return a;o=o.parentElement}return null}function N(n){return n.innerText.trim()}function H(n,o){n.focus(),document.execCommand("selectAll",!1,void 0),document.execCommand("delete",!1,void 0);let r=o.split(`
`);for(let a=0;a<r.length;a++)r[a]&&document.execCommand("insertText",!1,r[a]),a<r.length-1&&document.execCommand("insertParagraph",!1,void 0)}function f(n){return new Promise(o=>{chrome.runtime.sendMessage(n,o)})}var W=new WeakSet;function j(n){n.querySelectorAll(ne).forEach(o=>{Y(o)&&(W.has(o)||(W.add(o),se(o)))})}var le=new MutationObserver(()=>j(document));le.observe(document.body,{childList:!0,subtree:!0});setInterval(()=>j(document),1e3);j(document);document.addEventListener("keydown",n=>{if(!(n.ctrlKey||n.metaKey)||!n.shiftKey)return;let o=document.querySelector(`[${O}]`);if(!o)return;let r=Array.from(o.children).filter(a=>a.shadowRoot);n.key==="H"&&(n.preventDefault(),r[0]?.shadowRoot?.getElementById("wt-btn")?.click()),n.key==="V"&&(n.preventDefault(),r[0]?.shadowRoot?.getElementById("wt-mic-btn")?.click())});})();
