"use strict";(()=>{var G=['div[role="textbox"][aria-multiline="true"]','div[contenteditable="true"][aria-multiline="true"]'].join(", "),Q=['button[aria-label^="Send"]','button[aria-label*=" (Ctrl+Enter)"]','button[aria-label*=" (\u2318+Enter)"]','button[data-testid*="sendButton" i]'].join(", "),A="data-wt-ol-injected",X=[{key:"professional",label:"Professional",color:"#4F46E5"},{key:"casual",label:"Casual",color:"#06B6D4"},{key:"friendly",label:"Friendly",color:"#F59E0B"},{key:"direct",label:"Direct",color:"#DC2626"},{key:"diplomatic",label:"Diplomatic",color:"#7C3AED"},{key:"executive",label:"Executive",color:"#0F172A"}],ee=[{key:"reply",label:"Reply"},{key:"email",label:"Email"},{key:"customer_update",label:"Customer Update"},{key:"jira_ticket",label:"Jira Ticket"},{key:"technical_report",label:"Tech Report"}],te=`
  :host { display: inline-flex; align-items: center; margin: 0 4px; }

  /* \u2500\u2500 Humanize button \u2500\u2500 */
  #wt-btn {
    display: inline-flex; align-items: center; gap: 5px;
    height: 26px; padding: 0 11px; border-radius: 9999px; border: none;
    background: #4F46E5; color: #fff;
    font: 500 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer; white-space: nowrap; transition: background 0.15s, box-shadow 0.15s;
  }
  #wt-btn:hover  { background: #3F37C9; box-shadow: 0 0 0 3px rgba(79,70,229,0.25); }
  #wt-btn:disabled { opacity: 0.6; cursor: default; box-shadow: none; }

  /* \u2500\u2500 Mic button \u2500\u2500 */
  #wt-mic-btn {
    display: inline-flex; align-items: center; justify-content: center;
    width: 26px; height: 26px; border-radius: 9999px; border: none;
    background: transparent; color: #323130; cursor: pointer;
    font-size: 14px; line-height: 1; margin-left: 3px;
    transition: background 0.15s;
  }
  #wt-mic-btn:hover { background: rgba(0,0,0,0.06); }
  #wt-mic-btn.recording {
    background: #FEE2E2; color: #DC2626;
    animation: wt-pulse 1.2s ease-in-out infinite;
  }
  @keyframes wt-pulse {
    0%, 100% { box-shadow: 0 0 0 0 rgba(220,38,38,0.4); }
    50%       { box-shadow: 0 0 0 5px rgba(220,38,38,0); }
  }

  /* \u2500\u2500 Shared panel \u2500\u2500 */
  .wt-panel {
    position: fixed; z-index: 100000;
    background: #fff; border: 1px solid #EDEBE9; border-radius: 10px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.18);
    padding: 14px 16px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: none;
  }
  .wt-panel.open { display: block; }

  /* \u2500\u2500 Humanize panel \u2500\u2500 */
  #wt-panel { width: 260px; }
  .wt-title {
    font-size: 12px; font-weight: 600; color: #323130; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase;
  }
  .wt-tones { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 12px; }
  .wt-tone {
    padding: 4px 10px; border-radius: 9999px; border: 1.5px solid #EDEBE9;
    background: #fff; font-size: 12px; font-weight: 500; color: #323130; cursor: pointer;
    transition: all 0.1s;
  }
  .wt-tone.active { color: #fff; border-color: transparent; }
  .wt-tone:hover:not(.active) { border-color: #9BA0FF; }

  #wt-rewrite {
    width: 100%; height: 32px; border-radius: 8px; border: none;
    background: #4F46E5; color: #fff;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer;
  }
  #wt-rewrite:disabled { opacity: 0.45; cursor: default; }

  #wt-status {
    margin-top: 8px; font-size: 11px; text-align: center; min-height: 14px;
  }
  #wt-status.error   { color: #A4262C; }
  #wt-status.success { color: #107C10; }

  #wt-limit {
    display: none; margin-top: 10px; padding: 10px 12px; border-radius: 8px;
    background: #FFF8F1; border: 1px solid #FED7AA; text-align: center;
  }
  #wt-limit.visible { display: block; }
  #wt-limit p { font-size: 11px; color: #92400E; margin: 0 0 8px; line-height: 1.4; }
  #wt-limit a {
    display: inline-block; padding: 5px 14px; border-radius: 9999px;
    background: #F59E0B; color: #fff; font-size: 11px; font-weight: 600;
    text-decoration: none;
  }

  #wt-actions { display: none; gap: 6px; margin-top: 8px; }
  #wt-actions.visible { display: flex; }
  .wt-action {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #EDEBE9;
    background: #fff; font-size: 12px; font-weight: 500; color: #323130; cursor: pointer;
  }
  .wt-action.accept { border-color: #107C10; color: #107C10; }
  .wt-action.reject { border-color: #A4262C; color: #A4262C; }

  /* \u2500\u2500 Voice panel \u2500\u2500 */
  #wt-voice-panel { width: 280px; }
  .wt-vt { font-size: 12px; font-weight: 600; color: #323130; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase; }
  .wt-otype-label { font-size: 11px; color: #605E5C; margin-bottom: 4px; }
  .wt-otypes { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 10px; }
  .wt-otype {
    padding: 3px 9px; border-radius: 9999px; border: 1.5px solid #EDEBE9;
    background: #fff; font-size: 11px; color: #323130; cursor: pointer; transition: all 0.1s;
  }
  .wt-otype.active { background: #4F46E5; color: #fff; border-color: #4F46E5; }
  #wt-record-btn {
    width: 100%; height: 32px; border-radius: 8px; border: none;
    background: #DC2626; color: #fff; cursor: pointer; margin-bottom: 10px;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }
  #wt-record-btn.recording { background: #7F1D1D; }
  #wt-record-btn:disabled  { opacity: 0.5; cursor: default; }
  #wt-voice-status { font-size: 11px; text-align: center; min-height: 14px; color: #605E5C; }
  #wt-voice-status.error { color: #A4262C; }
  #wt-voice-actions { display: none; gap: 6px; margin-top: 8px; }
  #wt-voice-actions.visible { display: flex; }
  .wt-va {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #EDEBE9;
    background: #fff; font-size: 12px; font-weight: 500; color: #323130; cursor: pointer;
  }
  .wt-va.accept { border-color: #107C10; color: #107C10; }
  .wt-va.reject { border-color: #A4262C; color: #A4262C; }
`;function oe(o){let n=$(o);if(!n)return;let r=n.closest('[role="toolbar"]')??n.closest('[role="group"]')??n.parentElement;if(!r||r.hasAttribute(A))return;r.setAttribute(A,"1");let a=document.createElement("span"),i=a.attachShadow({mode:"open"}),x=null,b=null,l=!1,c=!1,R="reply",m=null,w=!1,D=[],g=null,S="",H="";i.innerHTML=`
    <style>${te}</style>

    <button id="wt-btn" title="Humanize with Writing Twin AI (Ctrl+Shift+H)">\u2728 Humanize</button>
    <button id="wt-mic-btn" title="Voice Twin \u2014 speak your email (Ctrl+Shift+V)">\u{1F399}</button>

    <div id="wt-panel" class="wt-panel">
      <p class="wt-title">Rewrite tone</p>
      <div class="wt-tones">
        ${X.map(e=>`<button class="wt-tone" data-tone="${e.key}" data-color="${e.color}">${e.label}</button>`).join("")}
      </div>
      <button id="wt-rewrite" disabled>Rewrite \u2192</button>
      <div id="wt-status"></div>
      <div id="wt-limit">
        <p>You've used all your free rewrites this month.</p>
        <a href="https://writingtwinai.com/pricing" target="_blank" rel="noopener">Upgrade to Pro \u2014 $5/mo</a>
      </div>
      <div id="wt-actions">
        <button class="wt-action accept" id="wt-accept">\u2713 Keep it</button>
        <button class="wt-action reject" id="wt-reject">\u2717 Undo</button>
      </div>
    </div>

    <div id="wt-voice-panel" class="wt-panel">
      <p class="wt-vt">Voice Twin</p>
      <div class="wt-otype-label">Output type</div>
      <div class="wt-otypes">
        ${ee.map((e,t)=>`<button class="wt-otype${t===0?" active":""}" data-type="${e.key}">${e.label}</button>`).join("")}
      </div>
      <button id="wt-record-btn">\u{1F399} Start recording</button>
      <div id="wt-voice-status"></div>
      <div id="wt-voice-actions">
        <button class="wt-va accept" id="wt-va-keep">\u2713 Keep it</button>
        <button class="wt-va reject" id="wt-va-undo">\u2717 Undo</button>
      </div>
    </div>
  `;let h=i.getElementById("wt-btn"),L=i.getElementById("wt-mic-btn"),E=i.getElementById("wt-panel"),v=i.getElementById("wt-voice-panel"),k=i.getElementById("wt-rewrite"),O=i.getElementById("wt-status"),V=i.getElementById("wt-limit"),y=i.getElementById("wt-actions"),K=i.getElementById("wt-accept"),q=i.getElementById("wt-reject"),u=i.getElementById("wt-record-btn"),j=i.getElementById("wt-voice-status"),T=i.getElementById("wt-voice-actions"),N=i.getElementById("wt-va-keep"),W=i.getElementById("wt-va-undo");i.querySelectorAll(".wt-tone").forEach(e=>{e.addEventListener("click",()=>{i.querySelectorAll(".wt-tone").forEach(t=>t.classList.remove("active")),e.classList.add("active"),e.style.background=e.dataset.color??"#4F46E5",e.style.borderColor=e.dataset.color??"#4F46E5",x=e.dataset.tone,k.disabled=!1,s(""),V.classList.remove("visible"),y.classList.remove("visible")})}),i.querySelectorAll(".wt-otype").forEach(e=>{e.addEventListener("click",()=>{i.querySelectorAll(".wt-otype").forEach(t=>t.classList.remove("active")),e.classList.add("active"),R=e.dataset.type})}),h.addEventListener("click",()=>{l=!l,l&&(c=!1,v.classList.remove("open")),E.classList.toggle("open",l),l&&z(h,E)}),L.addEventListener("click",()=>{c=!c,c&&(l=!1,E.classList.remove("open")),v.classList.toggle("open",c),c&&z(L,v)}),document.addEventListener("click",e=>{a.contains(e.target)||(l=!1,E.classList.remove("open"),c=!1,v.classList.remove("open"))},!0);function z(e,t){let p=e.getBoundingClientRect(),B=parseInt(t.style.width||"260");t.style.bottom=`${window.innerHeight-p.top+6}px`,t.style.left=`${Math.min(p.left,window.innerWidth-B-20)}px`}k.addEventListener("click",async()=>{if(!x)return;let e=U(o);if(!e){s("Write something first.","error");return}S=e,h.disabled=!0,k.disabled=!0,s("Rewriting\u2026"),y.classList.remove("visible");try{let t=await f({type:"HUMANIZE",payload:{text:e,tone:x}});if("error"in t)throw new Error(String(t.error));b=t.result.id,M(o,t.result.output_text),s("Done \u2713","success"),y.classList.add("visible")}catch(t){let p=t instanceof Error?t.message:"Failed";p.startsWith("LIMIT_REACHED:")?(V.classList.add("visible"),s("")):s(p,"error")}finally{h.disabled=!1,k.disabled=x===null}}),K.addEventListener("click",()=>{b&&f({type:"FEEDBACK",payload:{rewriteId:b,action:"accepted"}}),y.classList.remove("visible"),l=!1,E.classList.remove("open"),s("")}),q.addEventListener("click",()=>{S&&M(o,S),b&&f({type:"FEEDBACK",payload:{rewriteId:b,action:"rejected"}}),y.classList.remove("visible"),s("Reverted.","success"),setTimeout(()=>s(""),2e3)});function s(e,t=""){O.textContent=e,O.className=t}u.addEventListener("click",async()=>{w?_():await Y()});async function Y(){try{let e=await navigator.mediaDevices.getUserMedia({audio:!0});D=[],m=new MediaRecorder(e,{mimeType:"audio/webm"}),m.ondataavailable=t=>{t.data.size>0&&D.push(t.data)},m.onstop=async()=>{e.getTracks().forEach(t=>t.stop()),await J(new Blob(D,{type:"audio/webm"}))},m.start(),w=!0,L.classList.add("recording"),u.classList.add("recording"),u.textContent="\u23F9 Stop recording",d("Recording\u2026"),T.classList.remove("visible"),setTimeout(()=>{w&&_()},6e4)}catch{d("Microphone access denied.","error")}}function _(){m&&w&&(m.stop(),w=!1,L.classList.remove("recording"),u.classList.remove("recording"),u.textContent="\u{1F399} Start recording",u.disabled=!0,d("Drafting\u2026"))}async function J(e){try{let t=await e.arrayBuffer(),p=new Uint8Array(t),B="";for(let I=0;I<p.length;I++)B+=String.fromCharCode(p[I]);let Z=btoa(B);H=U(o);let C=await f({type:"VOICE_DRAFT",payload:{audioData:Z,mimeType:"audio/webm",outputType:R}});if("error"in C)throw new Error(String(C.error));g=C.result.id,M(o,C.result.draft),d("Done \u2713"),T.classList.add("visible")}catch(t){d(t instanceof Error?t.message:"Failed","error")}finally{u.disabled=!1}}N.addEventListener("click",()=>{g&&f({type:"VOICE_FEEDBACK",payload:{sessionId:g,accepted:!0,editedDraft:null}}),T.classList.remove("visible"),c=!1,v.classList.remove("open"),d("")}),W.addEventListener("click",()=>{H&&M(o,H),g&&f({type:"VOICE_FEEDBACK",payload:{sessionId:g,accepted:!1,editedDraft:null}}),T.classList.remove("visible"),d("Reverted.","success"),setTimeout(()=>d(""),2e3)});function d(e,t=""){j.textContent=e,j.className=t}r.insertBefore(a,n)}function $(o){let n=o;for(let r=0;r<30&&n;r++){let a=n.querySelector(Q);if(a)return a;n=n.parentElement}return null}function U(o){return o.innerText.trim()}function M(o,n){o.focus(),document.execCommand("selectAll",!1,void 0),document.execCommand("delete",!1,void 0);let r=n.split(`
`);for(let a=0;a<r.length;a++)r[a]&&document.execCommand("insertText",!1,r[a]),a<r.length-1&&document.execCommand("insertParagraph",!1,void 0)}function f(o){return new Promise(n=>{chrome.runtime.sendMessage(o,n)})}var P=new WeakSet;function F(o){o.querySelectorAll(G).forEach(n=>{$(n)&&(P.has(n)||(P.add(n),oe(n)))})}var ne=new MutationObserver(()=>F(document));ne.observe(document.body,{childList:!0,subtree:!0});setInterval(()=>F(document),1e3);F(document);document.addEventListener("keydown",o=>{if(!(o.ctrlKey||o.metaKey)||!o.shiftKey)return;let n=document.querySelector(`[${A}]`);if(!n)return;let r=Array.from(n.children).filter(a=>a.shadowRoot);o.key==="H"&&(o.preventDefault(),r[0]?.shadowRoot?.getElementById("wt-btn")?.click()),o.key==="V"&&(o.preventDefault(),r[0]?.shadowRoot?.getElementById("wt-mic-btn")?.click())});})();
