"use strict";
(() => {
  // src/content/outlook.ts
  var COMPOSE_BODY_SEL = [
    'div[role="textbox"][aria-multiline="true"]',
    'div[contenteditable="true"][aria-multiline="true"]'
  ].join(", ");
  var SEND_BUTTON_SEL = [
    'button[aria-label^="Send"]',
    'button[aria-label*=" (Ctrl+Enter)"]',
    'button[aria-label*=" (\u2318+Enter)"]',
    'button[data-testid*="sendButton" i]'
  ].join(", ");
  var HOST_ATTR = "data-wt-ol-injected";
  var TONES = [
    { key: "professional", label: "Professional", color: "#4F46E5" },
    { key: "casual", label: "Casual", color: "#06B6D4" },
    { key: "friendly", label: "Friendly", color: "#F59E0B" },
    { key: "direct", label: "Direct", color: "#DC2626" },
    { key: "diplomatic", label: "Diplomatic", color: "#7C3AED" },
    { key: "executive", label: "Executive", color: "#0F172A" }
  ];
  var VOICE_OUTPUT_TYPES = [
    { key: "reply", label: "Reply" },
    { key: "email", label: "Email" },
    { key: "customer_update", label: "Customer Update" },
    { key: "jira_ticket", label: "Jira Ticket" },
    { key: "technical_report", label: "Tech Report" }
  ];
  var BASE_CSS = `
  :host { display: inline-flex; align-items: center; margin: 0 4px; }

  /* \u2500\u2500 Humanize button \u2500\u2500 */
  #wt-btn {
    display: inline-flex; align-items: center; gap: 5px;
    height: 26px; padding: 0 11px; border-radius: 9999px; border: none;
    background: #4F46E5; color: #fff;
    font: 500 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer; white-space: nowrap; transition: background 0.15s, box-shadow 0.15s;
  }
  #wt-btn:hover  { background: #3F37C9; box-shadow: 0 0 0 3px rgba(79,70,229,0.25); }
  #wt-btn:disabled { opacity: 0.6; cursor: default; box-shadow: none; }

  /* \u2500\u2500 Mic button \u2500\u2500 */
  #wt-mic-btn {
    display: inline-flex; align-items: center; justify-content: center;
    width: 26px; height: 26px; border-radius: 9999px; border: none;
    background: transparent; color: #323130; cursor: pointer;
    font-size: 14px; line-height: 1; margin-left: 3px;
    transition: background 0.15s;
  }
  #wt-mic-btn:hover { background: rgba(0,0,0,0.06); }
  #wt-mic-btn.recording {
    background: #FEE2E2; color: #DC2626;
    animation: wt-pulse 1.2s ease-in-out infinite;
  }
  @keyframes wt-pulse {
    0%, 100% { box-shadow: 0 0 0 0 rgba(220,38,38,0.4); }
    50%       { box-shadow: 0 0 0 5px rgba(220,38,38,0); }
  }

  /* \u2500\u2500 Shared panel \u2500\u2500 */
  .wt-panel {
    position: fixed; z-index: 100000;
    background: #fff; border: 1px solid #EDEBE9; border-radius: 10px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.18);
    padding: 14px 16px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    display: none;
  }
  .wt-panel.open { display: block; }

  /* \u2500\u2500 Humanize panel \u2500\u2500 */
  #wt-panel { width: 260px; }
  .wt-title {
    font-size: 12px; font-weight: 600; color: #323130; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase;
  }
  .wt-tones { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 12px; }
  .wt-tone {
    padding: 4px 10px; border-radius: 9999px; border: 1.5px solid #EDEBE9;
    background: #fff; font-size: 12px; font-weight: 500; color: #323130; cursor: pointer;
    transition: all 0.1s;
  }
  .wt-tone.active { color: #fff; border-color: transparent; }
  .wt-tone:hover:not(.active) { border-color: #9BA0FF; }

  #wt-rewrite {
    width: 100%; height: 32px; border-radius: 8px; border: none;
    background: #4F46E5; color: #fff;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer;
  }
  #wt-rewrite:disabled { opacity: 0.45; cursor: default; }

  #wt-status {
    margin-top: 8px; font-size: 11px; text-align: center; min-height: 14px;
  }
  #wt-status.error   { color: #A4262C; }
  #wt-status.success { color: #107C10; }

  #wt-limit {
    display: none; margin-top: 10px; padding: 10px 12px; border-radius: 8px;
    background: #FFF8F1; border: 1px solid #FED7AA; text-align: center;
  }
  #wt-limit.visible { display: block; }
  #wt-limit p { font-size: 11px; color: #92400E; margin: 0 0 8px; line-height: 1.4; }
  #wt-limit a {
    display: inline-block; padding: 5px 14px; border-radius: 9999px;
    background: #F59E0B; color: #fff; font-size: 11px; font-weight: 600;
    text-decoration: none;
  }

  #wt-actions { display: none; gap: 6px; margin-top: 8px; }
  #wt-actions.visible { display: flex; }
  .wt-action {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #EDEBE9;
    background: #fff; font-size: 12px; font-weight: 500; color: #323130; cursor: pointer;
  }
  .wt-action.accept { border-color: #107C10; color: #107C10; }
  .wt-action.reject { border-color: #A4262C; color: #A4262C; }

  /* \u2500\u2500 Voice panel \u2500\u2500 */
  #wt-voice-panel { width: 280px; }
  .wt-vt { font-size: 12px; font-weight: 600; color: #323130; margin: 0 0 10px;
    letter-spacing: 0.04em; text-transform: uppercase; }
  .wt-otype-label { font-size: 11px; color: #605E5C; margin-bottom: 4px; }
  .wt-otypes { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 10px; }
  .wt-otype {
    padding: 3px 9px; border-radius: 9999px; border: 1.5px solid #EDEBE9;
    background: #fff; font-size: 11px; color: #323130; cursor: pointer; transition: all 0.1s;
  }
  .wt-otype.active { background: #4F46E5; color: #fff; border-color: #4F46E5; }
  #wt-record-btn {
    width: 100%; height: 32px; border-radius: 8px; border: none;
    background: #DC2626; color: #fff; cursor: pointer; margin-bottom: 10px;
    font: 600 13px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }
  #wt-record-btn.recording { background: #7F1D1D; }
  #wt-record-btn:disabled  { opacity: 0.5; cursor: default; }
  #wt-voice-status { font-size: 11px; text-align: center; min-height: 14px; color: #605E5C; }
  #wt-voice-status.error { color: #A4262C; }
  #wt-voice-actions { display: none; gap: 6px; margin-top: 8px; }
  #wt-voice-actions.visible { display: flex; }
  .wt-va {
    flex: 1; height: 28px; border-radius: 8px; border: 1.5px solid #EDEBE9;
    background: #fff; font-size: 12px; font-weight: 500; color: #323130; cursor: pointer;
  }
  .wt-va.accept { border-color: #107C10; color: #107C10; }
  .wt-va.reject { border-color: #A4262C; color: #A4262C; }
`;
  function inject(composeBody) {
    const sendBtn = findSendButton(composeBody);
    if (!sendBtn) return;
    const toolbar = sendBtn.closest('[role="toolbar"]') ?? sendBtn.closest('[role="group"]') ?? sendBtn.parentElement;
    if (!toolbar || toolbar.hasAttribute(HOST_ATTR)) return;
    toolbar.setAttribute(HOST_ATTR, "1");
    const host = document.createElement("span");
    const shadow = host.attachShadow({ mode: "open" });
    let selectedTone = null;
    let lastRewriteId = null;
    let panelOpen = false;
    let voicePanelOpen = false;
    let selectedOutputType = "reply";
    let recorder = null;
    let recording = false;
    let audioChunks = [];
    let lastVoiceSessionId = null;
    let originalText = "";
    let originalVoiceText = "";
    shadow.innerHTML = `
    <style>${BASE_CSS}</style>

    <button id="wt-btn" title="Humanize with Writing Twin AI (Ctrl+Shift+H)">\u2728 Humanize</button>
    <button id="wt-mic-btn" title="Voice Twin \u2014 speak your email (Ctrl+Shift+V)">\u{1F399}</button>

    <div id="wt-panel" class="wt-panel">
      <p class="wt-title">Rewrite tone</p>
      <div class="wt-tones">
        ${TONES.map((t) => `<button class="wt-tone" data-tone="${t.key}" data-color="${t.color}">${t.label}</button>`).join("")}
      </div>
      <button id="wt-rewrite" disabled>Rewrite \u2192</button>
      <div id="wt-status"></div>
      <div id="wt-limit">
        <p>You've used all your free rewrites this month.</p>
        <a href="https://writingtwinai.com/pricing" target="_blank" rel="noopener">Upgrade to Pro \u2014 $5/mo</a>
      </div>
      <div id="wt-actions">
        <button class="wt-action accept" id="wt-accept">\u2713 Keep it</button>
        <button class="wt-action reject" id="wt-reject">\u2717 Undo</button>
      </div>
    </div>

    <div id="wt-voice-panel" class="wt-panel">
      <p class="wt-vt">Voice Twin</p>
      <div class="wt-otype-label">Output type</div>
      <div class="wt-otypes">
        ${VOICE_OUTPUT_TYPES.map(
      (o, i) => `<button class="wt-otype${i === 0 ? " active" : ""}" data-type="${o.key}">${o.label}</button>`
    ).join("")}
      </div>
      <button id="wt-record-btn">\u{1F399} Start recording</button>
      <div id="wt-voice-status"></div>
      <div id="wt-voice-actions">
        <button class="wt-va accept" id="wt-va-keep">\u2713 Keep it</button>
        <button class="wt-va reject" id="wt-va-undo">\u2717 Undo</button>
      </div>
    </div>
  `;
    const btn = shadow.getElementById("wt-btn");
    const micBtn = shadow.getElementById("wt-mic-btn");
    const panel = shadow.getElementById("wt-panel");
    const voicePanel = shadow.getElementById("wt-voice-panel");
    const rewriteBtn = shadow.getElementById("wt-rewrite");
    const statusEl = shadow.getElementById("wt-status");
    const limitEl = shadow.getElementById("wt-limit");
    const actionsEl = shadow.getElementById("wt-actions");
    const acceptBtn = shadow.getElementById("wt-accept");
    const rejectBtn = shadow.getElementById("wt-reject");
    const recordBtn = shadow.getElementById("wt-record-btn");
    const vStatusEl = shadow.getElementById("wt-voice-status");
    const vActionsEl = shadow.getElementById("wt-voice-actions");
    const vKeepBtn = shadow.getElementById("wt-va-keep");
    const vUndoBtn = shadow.getElementById("wt-va-undo");
    shadow.querySelectorAll(".wt-tone").forEach((tb) => {
      tb.addEventListener("click", () => {
        shadow.querySelectorAll(".wt-tone").forEach((b) => b.classList.remove("active"));
        tb.classList.add("active");
        tb.style.background = tb.dataset.color ?? "#4F46E5";
        tb.style.borderColor = tb.dataset.color ?? "#4F46E5";
        selectedTone = tb.dataset.tone;
        rewriteBtn.disabled = false;
        setStatus("");
        limitEl.classList.remove("visible");
        actionsEl.classList.remove("visible");
      });
    });
    shadow.querySelectorAll(".wt-otype").forEach((ob) => {
      ob.addEventListener("click", () => {
        shadow.querySelectorAll(".wt-otype").forEach((b) => b.classList.remove("active"));
        ob.classList.add("active");
        selectedOutputType = ob.dataset.type;
      });
    });
    btn.addEventListener("click", () => {
      panelOpen = !panelOpen;
      if (panelOpen) {
        voicePanelOpen = false;
        voicePanel.classList.remove("open");
      }
      panel.classList.toggle("open", panelOpen);
      if (panelOpen) positionPanel(btn, panel);
    });
    micBtn.addEventListener("click", () => {
      voicePanelOpen = !voicePanelOpen;
      if (voicePanelOpen) {
        panelOpen = false;
        panel.classList.remove("open");
      }
      voicePanel.classList.toggle("open", voicePanelOpen);
      if (voicePanelOpen) positionPanel(micBtn, voicePanel);
    });
    document.addEventListener("click", (e) => {
      if (!host.contains(e.target)) {
        panelOpen = false;
        panel.classList.remove("open");
        voicePanelOpen = false;
        voicePanel.classList.remove("open");
      }
    }, true);
    function positionPanel(anchor, p) {
      const rect = anchor.getBoundingClientRect();
      const panelWidth = parseInt(p.style.width || "260");
      p.style.bottom = `${window.innerHeight - rect.top + 6}px`;
      p.style.left = `${Math.min(rect.left, window.innerWidth - panelWidth - 20)}px`;
    }
    rewriteBtn.addEventListener("click", async () => {
      if (!selectedTone) return;
      const text = readCompose(composeBody);
      if (!text) {
        setStatus("Write something first.", "error");
        return;
      }
      originalText = text;
      btn.disabled = true;
      rewriteBtn.disabled = true;
      setStatus("Rewriting\u2026");
      actionsEl.classList.remove("visible");
      try {
        const resp = await sendToBackground({
          type: "HUMANIZE",
          payload: { text, tone: selectedTone }
        });
        if ("error" in resp) throw new Error(String(resp.error));
        lastRewriteId = resp.result.id;
        writeCompose(composeBody, resp.result.output_text);
        setStatus("Done \u2713", "success");
        actionsEl.classList.add("visible");
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Failed";
        if (msg.startsWith("LIMIT_REACHED:")) {
          limitEl.classList.add("visible");
          setStatus("");
        } else {
          setStatus(msg, "error");
        }
      } finally {
        btn.disabled = false;
        rewriteBtn.disabled = selectedTone === null;
      }
    });
    acceptBtn.addEventListener("click", () => {
      if (lastRewriteId) sendToBackground({ type: "FEEDBACK", payload: { rewriteId: lastRewriteId, action: "accepted" } });
      actionsEl.classList.remove("visible");
      panelOpen = false;
      panel.classList.remove("open");
      setStatus("");
    });
    rejectBtn.addEventListener("click", () => {
      if (originalText) writeCompose(composeBody, originalText);
      if (lastRewriteId) sendToBackground({ type: "FEEDBACK", payload: { rewriteId: lastRewriteId, action: "rejected" } });
      actionsEl.classList.remove("visible");
      setStatus("Reverted.", "success");
      setTimeout(() => setStatus(""), 2e3);
    });
    function setStatus(msg, cls = "") {
      statusEl.textContent = msg;
      statusEl.className = cls;
    }
    recordBtn.addEventListener("click", async () => {
      if (!recording) await startRecording();
      else stopRecording();
    });
    async function startRecording() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        audioChunks = [];
        recorder = new MediaRecorder(stream, { mimeType: "audio/webm" });
        recorder.ondataavailable = (e) => {
          if (e.data.size > 0) audioChunks.push(e.data);
        };
        recorder.onstop = async () => {
          stream.getTracks().forEach((t) => t.stop());
          await submitVoice(new Blob(audioChunks, { type: "audio/webm" }));
        };
        recorder.start();
        recording = true;
        micBtn.classList.add("recording");
        recordBtn.classList.add("recording");
        recordBtn.textContent = "\u23F9 Stop recording";
        setVoiceStatus("Recording\u2026");
        vActionsEl.classList.remove("visible");
        setTimeout(() => {
          if (recording) stopRecording();
        }, 6e4);
      } catch {
        setVoiceStatus("Microphone access denied.", "error");
      }
    }
    function stopRecording() {
      if (recorder && recording) {
        recorder.stop();
        recording = false;
        micBtn.classList.remove("recording");
        recordBtn.classList.remove("recording");
        recordBtn.textContent = "\u{1F399} Start recording";
        recordBtn.disabled = true;
        setVoiceStatus("Drafting\u2026");
      }
    }
    async function submitVoice(blob) {
      try {
        const ab = await blob.arrayBuffer();
        const u8 = new Uint8Array(ab);
        let bin = "";
        for (let i = 0; i < u8.length; i++) bin += String.fromCharCode(u8[i]);
        const audioData = btoa(bin);
        originalVoiceText = readCompose(composeBody);
        const resp = await sendToBackground({
          type: "VOICE_DRAFT",
          payload: { audioData, mimeType: "audio/webm", outputType: selectedOutputType }
        });
        if ("error" in resp) throw new Error(String(resp.error));
        lastVoiceSessionId = resp.result.id;
        writeCompose(composeBody, resp.result.draft);
        setVoiceStatus("Done \u2713");
        vActionsEl.classList.add("visible");
      } catch (err) {
        setVoiceStatus(err instanceof Error ? err.message : "Failed", "error");
      } finally {
        recordBtn.disabled = false;
      }
    }
    vKeepBtn.addEventListener("click", () => {
      if (lastVoiceSessionId) sendToBackground({ type: "VOICE_FEEDBACK", payload: { sessionId: lastVoiceSessionId, accepted: true, editedDraft: null } });
      vActionsEl.classList.remove("visible");
      voicePanelOpen = false;
      voicePanel.classList.remove("open");
      setVoiceStatus("");
    });
    vUndoBtn.addEventListener("click", () => {
      if (originalVoiceText) writeCompose(composeBody, originalVoiceText);
      if (lastVoiceSessionId) sendToBackground({ type: "VOICE_FEEDBACK", payload: { sessionId: lastVoiceSessionId, accepted: false, editedDraft: null } });
      vActionsEl.classList.remove("visible");
      setVoiceStatus("Reverted.", "success");
      setTimeout(() => setVoiceStatus(""), 2e3);
    });
    function setVoiceStatus(msg, cls = "") {
      vStatusEl.textContent = msg;
      vStatusEl.className = cls;
    }
    toolbar.insertBefore(host, sendBtn);
  }
  function findSendButton(composeBody) {
    let el = composeBody;
    for (let i = 0; i < 30; i++) {
      if (!el) break;
      const send = el.querySelector(SEND_BUTTON_SEL);
      if (send) return send;
      el = el.parentElement;
    }
    return null;
  }
  function readCompose(el) {
    return el.innerText.trim();
  }
  function writeCompose(el, text) {
    el.focus();
    document.execCommand("selectAll", false, void 0);
    document.execCommand("delete", false, void 0);
    const lines = text.split("\n");
    for (let i = 0; i < lines.length; i++) {
      if (lines[i]) document.execCommand("insertText", false, lines[i]);
      if (i < lines.length - 1) document.execCommand("insertParagraph", false, void 0);
    }
  }
  function sendToBackground(message) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(message, resolve);
    });
  }
  var seen = /* @__PURE__ */ new WeakSet();
  function tryInject(root) {
    root.querySelectorAll(COMPOSE_BODY_SEL).forEach((body) => {
      if (!findSendButton(body)) return;
      if (!seen.has(body)) {
        seen.add(body);
        inject(body);
      }
    });
  }
  var observer = new MutationObserver(() => tryInject(document));
  observer.observe(document.body, { childList: true, subtree: true });
  setInterval(() => tryInject(document), 1e3);
  tryInject(document);
  document.addEventListener("keydown", (e) => {
    if (!(e.ctrlKey || e.metaKey) || !e.shiftKey) return;
    const toolbarEl = document.querySelector(`[${HOST_ATTR}]`);
    if (!toolbarEl) return;
    const hosts = Array.from(toolbarEl.children).filter((c) => c.shadowRoot);
    if (e.key === "H") {
      e.preventDefault();
      hosts[0]?.shadowRoot?.getElementById("wt-btn")?.click();
    }
    if (e.key === "V") {
      e.preventDefault();
      hosts[0]?.shadowRoot?.getElementById("wt-mic-btn")?.click();
    }
  });
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vc3JjL2NvbnRlbnQvb3V0bG9vay50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLyoqXG4gKiBPdXRsb29rIFdlYiBBcHAgY29udGVudCBzY3JpcHQgXHUyMDE0IGluamVjdHMgXHUyNzI4IEh1bWFuaXplICsgXHVEODNDXHVERjk5IFZvaWNlIFR3aW5cbiAqIGludG8gY29tcG9zZSB3aW5kb3dzIG9uIG91dGxvb2subGl2ZS5jb20gYW5kIG91dGxvb2sub2ZmaWNlLmNvbS5cbiAqXG4gKiBPdXRsb29rIHVzZXMgUmVhY3Qgc28gdGhlIERPTSBtdXRhdGVzIGhlYXZpbHkgYW5kIGFzeW5jaHJvbm91c2x5LlxuICogU3RyYXRlZ3k6IE11dGF0aW9uT2JzZXJ2ZXIgKHByaW1hcnkpICsgMSBzIHBvbGxpbmcgaW50ZXJ2YWwgKGZhbGxiYWNrKS5cbiAqL1xuaW1wb3J0IHR5cGUgeyBUb25lLCBSZXdyaXRlUmVzcG9uc2UsIFZvaWNlT3V0cHV0VHlwZSwgVm9pY2VEcmFmdFJlc3BvbnNlIH0gZnJvbSAnLi4vbGliL2FwaSc7XG5cbi8vIFx1MjUwMFx1MjUwMCBTZWxlY3RvcnMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4vL1xuLy8gT3V0bG9vayBhbHdheXMgZ2l2ZXMgdGhlIGNvbXBvc2UgYm9keSByb2xlPVwidGV4dGJveFwiICsgYXJpYS1tdWx0aWxpbmU9XCJ0cnVlXCIuXG4vLyBXZSBtYXRjaCBicm9hZGx5IHNvIGxvY2FsZSB2YXJpYW50cyAoXCJNZXNzYWdlIGJvZHlcIiwgXCJDb3JwbyBkbyBlbWFpbFwiLCBldGMuKSBhbGwgd29yay5cbmNvbnN0IENPTVBPU0VfQk9EWV9TRUwgPSBbXG4gICdkaXZbcm9sZT1cInRleHRib3hcIl1bYXJpYS1tdWx0aWxpbmU9XCJ0cnVlXCJdJyxcbiAgJ2Rpdltjb250ZW50ZWRpdGFibGU9XCJ0cnVlXCJdW2FyaWEtbXVsdGlsaW5lPVwidHJ1ZVwiXScsXG5dLmpvaW4oJywgJyk7XG5cbi8vIFNlbmQgYnV0dG9uIFx1MjAxNCBPdXRsb29rIHN1cmZhY2VzIGFyaWEtbGFiZWwgd2l0aCBvcHRpb25hbCBrZXlib2FyZC1zaG9ydGN1dCBzdWZmaXhcbi8vIGUuZy4gXCJTZW5kXCIsIFwiU2VuZCAoQ3RybCtFbnRlcilcIiwgXCJWZXJ6ZW5kZW4gKEN0cmwrRW50ZXIpXCJcbmNvbnN0IFNFTkRfQlVUVE9OX1NFTCA9IFtcbiAgJ2J1dHRvblthcmlhLWxhYmVsXj1cIlNlbmRcIl0nLFxuICAnYnV0dG9uW2FyaWEtbGFiZWwqPVwiIChDdHJsK0VudGVyKVwiXScsXG4gICdidXR0b25bYXJpYS1sYWJlbCo9XCIgKFx1MjMxOCtFbnRlcilcIl0nLFxuICAnYnV0dG9uW2RhdGEtdGVzdGlkKj1cInNlbmRCdXR0b25cIiBpXScsXG5dLmpvaW4oJywgJyk7XG5cbmNvbnN0IEhPU1RfQVRUUiA9ICdkYXRhLXd0LW9sLWluamVjdGVkJztcblxuLy8gXHUyNTAwXHUyNTAwIFRvbmVzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5jb25zdCBUT05FUzogeyBrZXk6IFRvbmU7IGxhYmVsOiBzdHJpbmc7IGNvbG9yOiBzdHJpbmcgfVtdID0gW1xuICB7IGtleTogJ3Byb2Zlc3Npb25hbCcsIGxhYmVsOiAnUHJvZmVzc2lvbmFsJywgY29sb3I6ICcjNEY0NkU1JyB9LFxuICB7IGtleTogJ2Nhc3VhbCcsICAgICAgIGxhYmVsOiAnQ2FzdWFsJywgICAgICAgY29sb3I6ICcjMDZCNkQ0JyB9LFxuICB7IGtleTogJ2ZyaWVuZGx5JywgICAgIGxhYmVsOiAnRnJpZW5kbHknLCAgICAgY29sb3I6ICcjRjU5RTBCJyB9LFxuICB7IGtleTogJ2RpcmVjdCcsICAgICAgIGxhYmVsOiAnRGlyZWN0JywgICAgICAgY29sb3I6ICcjREMyNjI2JyB9LFxuICB7IGtleTogJ2RpcGxvbWF0aWMnLCAgIGxhYmVsOiAnRGlwbG9tYXRpYycsICAgY29sb3I6ICcjN0MzQUVEJyB9LFxuICB7IGtleTogJ2V4ZWN1dGl2ZScsICAgIGxhYmVsOiAnRXhlY3V0aXZlJywgICAgY29sb3I6ICcjMEYxNzJBJyB9LFxuXTtcblxuLy8gXHUyNTAwXHUyNTAwIFZvaWNlIG91dHB1dCB0eXBlcyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuY29uc3QgVk9JQ0VfT1VUUFVUX1RZUEVTOiB7IGtleTogVm9pY2VPdXRwdXRUeXBlOyBsYWJlbDogc3RyaW5nIH1bXSA9IFtcbiAgeyBrZXk6ICdyZXBseScsICAgICAgICAgICAgbGFiZWw6ICdSZXBseScgfSxcbiAgeyBrZXk6ICdlbWFpbCcsICAgICAgICAgICAgbGFiZWw6ICdFbWFpbCcgfSxcbiAgeyBrZXk6ICdjdXN0b21lcl91cGRhdGUnLCAgbGFiZWw6ICdDdXN0b21lciBVcGRhdGUnIH0sXG4gIHsga2V5OiAnamlyYV90aWNrZXQnLCAgICAgIGxhYmVsOiAnSmlyYSBUaWNrZXQnIH0sXG4gIHsga2V5OiAndGVjaG5pY2FsX3JlcG9ydCcsIGxhYmVsOiAnVGVjaCBSZXBvcnQnIH0sXG5dO1xuXG4vLyBcdTI1MDBcdTI1MDAgU2hhZG93IERPTSBDU1MgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmNvbnN0IEJBU0VfQ1NTID0gYFxuICA6aG9zdCB7IGRpc3BsYXk6IGlubGluZS1mbGV4OyBhbGlnbi1pdGVtczogY2VudGVyOyBtYXJnaW46IDAgNHB4OyB9XG5cbiAgLyogXHUyNTAwXHUyNTAwIEh1bWFuaXplIGJ1dHRvbiBcdTI1MDBcdTI1MDAgKi9cbiAgI3d0LWJ0biB7XG4gICAgZGlzcGxheTogaW5saW5lLWZsZXg7IGFsaWduLWl0ZW1zOiBjZW50ZXI7IGdhcDogNXB4O1xuICAgIGhlaWdodDogMjZweDsgcGFkZGluZzogMCAxMXB4OyBib3JkZXItcmFkaXVzOiA5OTk5cHg7IGJvcmRlcjogbm9uZTtcbiAgICBiYWNrZ3JvdW5kOiAjNEY0NkU1OyBjb2xvcjogI2ZmZjtcbiAgICBmb250OiA1MDAgMTJweC8xIC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgXCJTZWdvZSBVSVwiLCBSb2JvdG8sIHNhbnMtc2VyaWY7XG4gICAgY3Vyc29yOiBwb2ludGVyOyB3aGl0ZS1zcGFjZTogbm93cmFwOyB0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kIDAuMTVzLCBib3gtc2hhZG93IDAuMTVzO1xuICB9XG4gICN3dC1idG46aG92ZXIgIHsgYmFja2dyb3VuZDogIzNGMzdDOTsgYm94LXNoYWRvdzogMCAwIDAgM3B4IHJnYmEoNzksNzAsMjI5LDAuMjUpOyB9XG4gICN3dC1idG46ZGlzYWJsZWQgeyBvcGFjaXR5OiAwLjY7IGN1cnNvcjogZGVmYXVsdDsgYm94LXNoYWRvdzogbm9uZTsgfVxuXG4gIC8qIFx1MjUwMFx1MjUwMCBNaWMgYnV0dG9uIFx1MjUwMFx1MjUwMCAqL1xuICAjd3QtbWljLWJ0biB7XG4gICAgZGlzcGxheTogaW5saW5lLWZsZXg7IGFsaWduLWl0ZW1zOiBjZW50ZXI7IGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIHdpZHRoOiAyNnB4OyBoZWlnaHQ6IDI2cHg7IGJvcmRlci1yYWRpdXM6IDk5OTlweDsgYm9yZGVyOiBub25lO1xuICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50OyBjb2xvcjogIzMyMzEzMDsgY3Vyc29yOiBwb2ludGVyO1xuICAgIGZvbnQtc2l6ZTogMTRweDsgbGluZS1oZWlnaHQ6IDE7IG1hcmdpbi1sZWZ0OiAzcHg7XG4gICAgdHJhbnNpdGlvbjogYmFja2dyb3VuZCAwLjE1cztcbiAgfVxuICAjd3QtbWljLWJ0bjpob3ZlciB7IGJhY2tncm91bmQ6IHJnYmEoMCwwLDAsMC4wNik7IH1cbiAgI3d0LW1pYy1idG4ucmVjb3JkaW5nIHtcbiAgICBiYWNrZ3JvdW5kOiAjRkVFMkUyOyBjb2xvcjogI0RDMjYyNjtcbiAgICBhbmltYXRpb246IHd0LXB1bHNlIDEuMnMgZWFzZS1pbi1vdXQgaW5maW5pdGU7XG4gIH1cbiAgQGtleWZyYW1lcyB3dC1wdWxzZSB7XG4gICAgMCUsIDEwMCUgeyBib3gtc2hhZG93OiAwIDAgMCAwIHJnYmEoMjIwLDM4LDM4LDAuNCk7IH1cbiAgICA1MCUgICAgICAgeyBib3gtc2hhZG93OiAwIDAgMCA1cHggcmdiYSgyMjAsMzgsMzgsMCk7IH1cbiAgfVxuXG4gIC8qIFx1MjUwMFx1MjUwMCBTaGFyZWQgcGFuZWwgXHUyNTAwXHUyNTAwICovXG4gIC53dC1wYW5lbCB7XG4gICAgcG9zaXRpb246IGZpeGVkOyB6LWluZGV4OiAxMDAwMDA7XG4gICAgYmFja2dyb3VuZDogI2ZmZjsgYm9yZGVyOiAxcHggc29saWQgI0VERUJFOTsgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICBib3gtc2hhZG93OiAwIDhweCAzMnB4IHJnYmEoMCwwLDAsMC4xOCk7XG4gICAgcGFkZGluZzogMTRweCAxNnB4O1xuICAgIGZvbnQtZmFtaWx5OiAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsIFwiU2Vnb2UgVUlcIiwgUm9ib3RvLCBzYW5zLXNlcmlmO1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH1cbiAgLnd0LXBhbmVsLm9wZW4geyBkaXNwbGF5OiBibG9jazsgfVxuXG4gIC8qIFx1MjUwMFx1MjUwMCBIdW1hbml6ZSBwYW5lbCBcdTI1MDBcdTI1MDAgKi9cbiAgI3d0LXBhbmVsIHsgd2lkdGg6IDI2MHB4OyB9XG4gIC53dC10aXRsZSB7XG4gICAgZm9udC1zaXplOiAxMnB4OyBmb250LXdlaWdodDogNjAwOyBjb2xvcjogIzMyMzEzMDsgbWFyZ2luOiAwIDAgMTBweDtcbiAgICBsZXR0ZXItc3BhY2luZzogMC4wNGVtOyB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICB9XG4gIC53dC10b25lcyB7IGRpc3BsYXk6IGZsZXg7IGZsZXgtd3JhcDogd3JhcDsgZ2FwOiA2cHg7IG1hcmdpbi1ib3R0b206IDEycHg7IH1cbiAgLnd0LXRvbmUge1xuICAgIHBhZGRpbmc6IDRweCAxMHB4OyBib3JkZXItcmFkaXVzOiA5OTk5cHg7IGJvcmRlcjogMS41cHggc29saWQgI0VERUJFOTtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmOyBmb250LXNpemU6IDEycHg7IGZvbnQtd2VpZ2h0OiA1MDA7IGNvbG9yOiAjMzIzMTMwOyBjdXJzb3I6IHBvaW50ZXI7XG4gICAgdHJhbnNpdGlvbjogYWxsIDAuMXM7XG4gIH1cbiAgLnd0LXRvbmUuYWN0aXZlIHsgY29sb3I6ICNmZmY7IGJvcmRlci1jb2xvcjogdHJhbnNwYXJlbnQ7IH1cbiAgLnd0LXRvbmU6aG92ZXI6bm90KC5hY3RpdmUpIHsgYm9yZGVyLWNvbG9yOiAjOUJBMEZGOyB9XG5cbiAgI3d0LXJld3JpdGUge1xuICAgIHdpZHRoOiAxMDAlOyBoZWlnaHQ6IDMycHg7IGJvcmRlci1yYWRpdXM6IDhweDsgYm9yZGVyOiBub25lO1xuICAgIGJhY2tncm91bmQ6ICM0RjQ2RTU7IGNvbG9yOiAjZmZmO1xuICAgIGZvbnQ6IDYwMCAxM3B4LzEgLWFwcGxlLXN5c3RlbSwgQmxpbmtNYWNTeXN0ZW1Gb250LCBcIlNlZ29lIFVJXCIsIFJvYm90bywgc2Fucy1zZXJpZjtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cbiAgI3d0LXJld3JpdGU6ZGlzYWJsZWQgeyBvcGFjaXR5OiAwLjQ1OyBjdXJzb3I6IGRlZmF1bHQ7IH1cblxuICAjd3Qtc3RhdHVzIHtcbiAgICBtYXJnaW4tdG9wOiA4cHg7IGZvbnQtc2l6ZTogMTFweDsgdGV4dC1hbGlnbjogY2VudGVyOyBtaW4taGVpZ2h0OiAxNHB4O1xuICB9XG4gICN3dC1zdGF0dXMuZXJyb3IgICB7IGNvbG9yOiAjQTQyNjJDOyB9XG4gICN3dC1zdGF0dXMuc3VjY2VzcyB7IGNvbG9yOiAjMTA3QzEwOyB9XG5cbiAgI3d0LWxpbWl0IHtcbiAgICBkaXNwbGF5OiBub25lOyBtYXJnaW4tdG9wOiAxMHB4OyBwYWRkaW5nOiAxMHB4IDEycHg7IGJvcmRlci1yYWRpdXM6IDhweDtcbiAgICBiYWNrZ3JvdW5kOiAjRkZGOEYxOyBib3JkZXI6IDFweCBzb2xpZCAjRkVEN0FBOyB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIH1cbiAgI3d0LWxpbWl0LnZpc2libGUgeyBkaXNwbGF5OiBibG9jazsgfVxuICAjd3QtbGltaXQgcCB7IGZvbnQtc2l6ZTogMTFweDsgY29sb3I6ICM5MjQwMEU7IG1hcmdpbjogMCAwIDhweDsgbGluZS1oZWlnaHQ6IDEuNDsgfVxuICAjd3QtbGltaXQgYSB7XG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrOyBwYWRkaW5nOiA1cHggMTRweDsgYm9yZGVyLXJhZGl1czogOTk5OXB4O1xuICAgIGJhY2tncm91bmQ6ICNGNTlFMEI7IGNvbG9yOiAjZmZmOyBmb250LXNpemU6IDExcHg7IGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xuICB9XG5cbiAgI3d0LWFjdGlvbnMgeyBkaXNwbGF5OiBub25lOyBnYXA6IDZweDsgbWFyZ2luLXRvcDogOHB4OyB9XG4gICN3dC1hY3Rpb25zLnZpc2libGUgeyBkaXNwbGF5OiBmbGV4OyB9XG4gIC53dC1hY3Rpb24ge1xuICAgIGZsZXg6IDE7IGhlaWdodDogMjhweDsgYm9yZGVyLXJhZGl1czogOHB4OyBib3JkZXI6IDEuNXB4IHNvbGlkICNFREVCRTk7XG4gICAgYmFja2dyb3VuZDogI2ZmZjsgZm9udC1zaXplOiAxMnB4OyBmb250LXdlaWdodDogNTAwOyBjb2xvcjogIzMyMzEzMDsgY3Vyc29yOiBwb2ludGVyO1xuICB9XG4gIC53dC1hY3Rpb24uYWNjZXB0IHsgYm9yZGVyLWNvbG9yOiAjMTA3QzEwOyBjb2xvcjogIzEwN0MxMDsgfVxuICAud3QtYWN0aW9uLnJlamVjdCB7IGJvcmRlci1jb2xvcjogI0E0MjYyQzsgY29sb3I6ICNBNDI2MkM7IH1cblxuICAvKiBcdTI1MDBcdTI1MDAgVm9pY2UgcGFuZWwgXHUyNTAwXHUyNTAwICovXG4gICN3dC12b2ljZS1wYW5lbCB7IHdpZHRoOiAyODBweDsgfVxuICAud3QtdnQgeyBmb250LXNpemU6IDEycHg7IGZvbnQtd2VpZ2h0OiA2MDA7IGNvbG9yOiAjMzIzMTMwOyBtYXJnaW46IDAgMCAxMHB4O1xuICAgIGxldHRlci1zcGFjaW5nOiAwLjA0ZW07IHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7IH1cbiAgLnd0LW90eXBlLWxhYmVsIHsgZm9udC1zaXplOiAxMXB4OyBjb2xvcjogIzYwNUU1QzsgbWFyZ2luLWJvdHRvbTogNHB4OyB9XG4gIC53dC1vdHlwZXMgeyBkaXNwbGF5OiBmbGV4OyBmbGV4LXdyYXA6IHdyYXA7IGdhcDogNXB4OyBtYXJnaW4tYm90dG9tOiAxMHB4OyB9XG4gIC53dC1vdHlwZSB7XG4gICAgcGFkZGluZzogM3B4IDlweDsgYm9yZGVyLXJhZGl1czogOTk5OXB4OyBib3JkZXI6IDEuNXB4IHNvbGlkICNFREVCRTk7XG4gICAgYmFja2dyb3VuZDogI2ZmZjsgZm9udC1zaXplOiAxMXB4OyBjb2xvcjogIzMyMzEzMDsgY3Vyc29yOiBwb2ludGVyOyB0cmFuc2l0aW9uOiBhbGwgMC4xcztcbiAgfVxuICAud3Qtb3R5cGUuYWN0aXZlIHsgYmFja2dyb3VuZDogIzRGNDZFNTsgY29sb3I6ICNmZmY7IGJvcmRlci1jb2xvcjogIzRGNDZFNTsgfVxuICAjd3QtcmVjb3JkLWJ0biB7XG4gICAgd2lkdGg6IDEwMCU7IGhlaWdodDogMzJweDsgYm9yZGVyLXJhZGl1czogOHB4OyBib3JkZXI6IG5vbmU7XG4gICAgYmFja2dyb3VuZDogI0RDMjYyNjsgY29sb3I6ICNmZmY7IGN1cnNvcjogcG9pbnRlcjsgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICBmb250OiA2MDAgMTNweC8xIC1hcHBsZS1zeXN0ZW0sIEJsaW5rTWFjU3lzdGVtRm9udCwgXCJTZWdvZSBVSVwiLCBSb2JvdG8sIHNhbnMtc2VyaWY7XG4gIH1cbiAgI3d0LXJlY29yZC1idG4ucmVjb3JkaW5nIHsgYmFja2dyb3VuZDogIzdGMUQxRDsgfVxuICAjd3QtcmVjb3JkLWJ0bjpkaXNhYmxlZCAgeyBvcGFjaXR5OiAwLjU7IGN1cnNvcjogZGVmYXVsdDsgfVxuICAjd3Qtdm9pY2Utc3RhdHVzIHsgZm9udC1zaXplOiAxMXB4OyB0ZXh0LWFsaWduOiBjZW50ZXI7IG1pbi1oZWlnaHQ6IDE0cHg7IGNvbG9yOiAjNjA1RTVDOyB9XG4gICN3dC12b2ljZS1zdGF0dXMuZXJyb3IgeyBjb2xvcjogI0E0MjYyQzsgfVxuICAjd3Qtdm9pY2UtYWN0aW9ucyB7IGRpc3BsYXk6IG5vbmU7IGdhcDogNnB4OyBtYXJnaW4tdG9wOiA4cHg7IH1cbiAgI3d0LXZvaWNlLWFjdGlvbnMudmlzaWJsZSB7IGRpc3BsYXk6IGZsZXg7IH1cbiAgLnd0LXZhIHtcbiAgICBmbGV4OiAxOyBoZWlnaHQ6IDI4cHg7IGJvcmRlci1yYWRpdXM6IDhweDsgYm9yZGVyOiAxLjVweCBzb2xpZCAjRURFQkU5O1xuICAgIGJhY2tncm91bmQ6ICNmZmY7IGZvbnQtc2l6ZTogMTJweDsgZm9udC13ZWlnaHQ6IDUwMDsgY29sb3I6ICMzMjMxMzA7IGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuICAud3QtdmEuYWNjZXB0IHsgYm9yZGVyLWNvbG9yOiAjMTA3QzEwOyBjb2xvcjogIzEwN0MxMDsgfVxuICAud3QtdmEucmVqZWN0IHsgYm9yZGVyLWNvbG9yOiAjQTQyNjJDOyBjb2xvcjogI0E0MjYyQzsgfVxuYDtcblxuLy8gXHUyNTAwXHUyNTAwIE1haW4gaW5qZWN0aW9uIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5mdW5jdGlvbiBpbmplY3QoY29tcG9zZUJvZHk6IEVsZW1lbnQpOiB2b2lkIHtcbiAgY29uc3Qgc2VuZEJ0biA9IGZpbmRTZW5kQnV0dG9uKGNvbXBvc2VCb2R5KTtcbiAgaWYgKCFzZW5kQnRuKSByZXR1cm47XG5cbiAgLy8gVXNlIHRoZSBzZW5kIGJ1dHRvbidzIGNsb3Nlc3QgdG9vbGJhciwgb3IgZmFsbCBiYWNrIHRvIGl0cyBwYXJlbnRcbiAgY29uc3QgdG9vbGJhciA9XG4gICAgc2VuZEJ0bi5jbG9zZXN0KCdbcm9sZT1cInRvb2xiYXJcIl0nKSA/P1xuICAgIHNlbmRCdG4uY2xvc2VzdCgnW3JvbGU9XCJncm91cFwiXScpID8/XG4gICAgc2VuZEJ0bi5wYXJlbnRFbGVtZW50O1xuICBpZiAoIXRvb2xiYXIgfHwgdG9vbGJhci5oYXNBdHRyaWJ1dGUoSE9TVF9BVFRSKSkgcmV0dXJuO1xuXG4gIHRvb2xiYXIuc2V0QXR0cmlidXRlKEhPU1RfQVRUUiwgJzEnKTtcblxuICBjb25zdCBob3N0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3BhbicpO1xuICBjb25zdCBzaGFkb3cgPSBob3N0LmF0dGFjaFNoYWRvdyh7IG1vZGU6ICdvcGVuJyB9KTtcblxuICBsZXQgc2VsZWN0ZWRUb25lOiBUb25lIHwgbnVsbCA9IG51bGw7XG4gIGxldCBsYXN0UmV3cml0ZUlkOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcbiAgbGV0IHBhbmVsT3BlbiA9IGZhbHNlO1xuICBsZXQgdm9pY2VQYW5lbE9wZW4gPSBmYWxzZTtcbiAgbGV0IHNlbGVjdGVkT3V0cHV0VHlwZTogVm9pY2VPdXRwdXRUeXBlID0gJ3JlcGx5JztcbiAgbGV0IHJlY29yZGVyOiBNZWRpYVJlY29yZGVyIHwgbnVsbCA9IG51bGw7XG4gIGxldCByZWNvcmRpbmcgPSBmYWxzZTtcbiAgbGV0IGF1ZGlvQ2h1bmtzOiBCbG9iUGFydFtdID0gW107XG4gIGxldCBsYXN0Vm9pY2VTZXNzaW9uSWQ6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuICBsZXQgb3JpZ2luYWxUZXh0ID0gJyc7XG4gIGxldCBvcmlnaW5hbFZvaWNlVGV4dCA9ICcnO1xuXG4gIHNoYWRvdy5pbm5lckhUTUwgPSBgXG4gICAgPHN0eWxlPiR7QkFTRV9DU1N9PC9zdHlsZT5cblxuICAgIDxidXR0b24gaWQ9XCJ3dC1idG5cIiB0aXRsZT1cIkh1bWFuaXplIHdpdGggV3JpdGluZyBUd2luIEFJIChDdHJsK1NoaWZ0K0gpXCI+XHUyNzI4IEh1bWFuaXplPC9idXR0b24+XG4gICAgPGJ1dHRvbiBpZD1cInd0LW1pYy1idG5cIiB0aXRsZT1cIlZvaWNlIFR3aW4gXHUyMDE0IHNwZWFrIHlvdXIgZW1haWwgKEN0cmwrU2hpZnQrVilcIj5cdUQ4M0NcdURGOTk8L2J1dHRvbj5cblxuICAgIDxkaXYgaWQ9XCJ3dC1wYW5lbFwiIGNsYXNzPVwid3QtcGFuZWxcIj5cbiAgICAgIDxwIGNsYXNzPVwid3QtdGl0bGVcIj5SZXdyaXRlIHRvbmU8L3A+XG4gICAgICA8ZGl2IGNsYXNzPVwid3QtdG9uZXNcIj5cbiAgICAgICAgJHtUT05FUy5tYXAodCA9PiBgPGJ1dHRvbiBjbGFzcz1cInd0LXRvbmVcIiBkYXRhLXRvbmU9XCIke3Qua2V5fVwiIGRhdGEtY29sb3I9XCIke3QuY29sb3J9XCI+JHt0LmxhYmVsfTwvYnV0dG9uPmApLmpvaW4oJycpfVxuICAgICAgPC9kaXY+XG4gICAgICA8YnV0dG9uIGlkPVwid3QtcmV3cml0ZVwiIGRpc2FibGVkPlJld3JpdGUgXHUyMTkyPC9idXR0b24+XG4gICAgICA8ZGl2IGlkPVwid3Qtc3RhdHVzXCI+PC9kaXY+XG4gICAgICA8ZGl2IGlkPVwid3QtbGltaXRcIj5cbiAgICAgICAgPHA+WW91J3ZlIHVzZWQgYWxsIHlvdXIgZnJlZSByZXdyaXRlcyB0aGlzIG1vbnRoLjwvcD5cbiAgICAgICAgPGEgaHJlZj1cImh0dHBzOi8vd3JpdGluZ3R3aW5haS5jb20vcHJpY2luZ1wiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vb3BlbmVyXCI+VXBncmFkZSB0byBQcm8gXHUyMDE0ICQ1L21vPC9hPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGlkPVwid3QtYWN0aW9uc1wiPlxuICAgICAgICA8YnV0dG9uIGNsYXNzPVwid3QtYWN0aW9uIGFjY2VwdFwiIGlkPVwid3QtYWNjZXB0XCI+XHUyNzEzIEtlZXAgaXQ8L2J1dHRvbj5cbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cInd0LWFjdGlvbiByZWplY3RcIiBpZD1cInd0LXJlamVjdFwiPlx1MjcxNyBVbmRvPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cblxuICAgIDxkaXYgaWQ9XCJ3dC12b2ljZS1wYW5lbFwiIGNsYXNzPVwid3QtcGFuZWxcIj5cbiAgICAgIDxwIGNsYXNzPVwid3QtdnRcIj5Wb2ljZSBUd2luPC9wPlxuICAgICAgPGRpdiBjbGFzcz1cInd0LW90eXBlLWxhYmVsXCI+T3V0cHV0IHR5cGU8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3M9XCJ3dC1vdHlwZXNcIj5cbiAgICAgICAgJHtWT0lDRV9PVVRQVVRfVFlQRVMubWFwKChvLCBpKSA9PlxuICAgICAgICAgIGA8YnV0dG9uIGNsYXNzPVwid3Qtb3R5cGUke2kgPT09IDAgPyAnIGFjdGl2ZScgOiAnJ31cIiBkYXRhLXR5cGU9XCIke28ua2V5fVwiPiR7by5sYWJlbH08L2J1dHRvbj5gXG4gICAgICAgICkuam9pbignJyl9XG4gICAgICA8L2Rpdj5cbiAgICAgIDxidXR0b24gaWQ9XCJ3dC1yZWNvcmQtYnRuXCI+XHVEODNDXHVERjk5IFN0YXJ0IHJlY29yZGluZzwvYnV0dG9uPlxuICAgICAgPGRpdiBpZD1cInd0LXZvaWNlLXN0YXR1c1wiPjwvZGl2PlxuICAgICAgPGRpdiBpZD1cInd0LXZvaWNlLWFjdGlvbnNcIj5cbiAgICAgICAgPGJ1dHRvbiBjbGFzcz1cInd0LXZhIGFjY2VwdFwiIGlkPVwid3QtdmEta2VlcFwiPlx1MjcxMyBLZWVwIGl0PC9idXR0b24+XG4gICAgICAgIDxidXR0b24gY2xhc3M9XCJ3dC12YSByZWplY3RcIiBpZD1cInd0LXZhLXVuZG9cIj5cdTI3MTcgVW5kbzwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIGA7XG5cbiAgLy8gXHUyNTAwXHUyNTAwIEVsZW1lbnQgcmVmcyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbiAgY29uc3QgYnRuICAgICAgICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtYnRuJykgICAgICAgIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICBjb25zdCBtaWNCdG4gICAgID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC1taWMtYnRuJykgICAgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG4gIGNvbnN0IHBhbmVsICAgICAgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LXBhbmVsJykgICAgICBhcyBIVE1MRGl2RWxlbWVudDtcbiAgY29uc3Qgdm9pY2VQYW5lbCA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3Qtdm9pY2UtcGFuZWwnKSBhcyBIVE1MRGl2RWxlbWVudDtcbiAgY29uc3QgcmV3cml0ZUJ0biA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtcmV3cml0ZScpICAgIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICBjb25zdCBzdGF0dXNFbCAgID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC1zdGF0dXMnKSAgICAgYXMgSFRNTERpdkVsZW1lbnQ7XG4gIGNvbnN0IGxpbWl0RWwgICAgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LWxpbWl0JykgICAgICBhcyBIVE1MRGl2RWxlbWVudDtcbiAgY29uc3QgYWN0aW9uc0VsICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtYWN0aW9ucycpICAgIGFzIEhUTUxEaXZFbGVtZW50O1xuICBjb25zdCBhY2NlcHRCdG4gID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC1hY2NlcHQnKSAgICAgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG4gIGNvbnN0IHJlamVjdEJ0biAgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LXJlamVjdCcpICAgICBhcyBIVE1MQnV0dG9uRWxlbWVudDtcbiAgY29uc3QgcmVjb3JkQnRuICA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3QtcmVjb3JkLWJ0bicpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuICBjb25zdCB2U3RhdHVzRWwgID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC12b2ljZS1zdGF0dXMnKSBhcyBIVE1MRGl2RWxlbWVudDtcbiAgY29uc3QgdkFjdGlvbnNFbCA9IHNoYWRvdy5nZXRFbGVtZW50QnlJZCgnd3Qtdm9pY2UtYWN0aW9ucycpIGFzIEhUTUxEaXZFbGVtZW50O1xuICBjb25zdCB2S2VlcEJ0biAgID0gc2hhZG93LmdldEVsZW1lbnRCeUlkKCd3dC12YS1rZWVwJykgICAgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG4gIGNvbnN0IHZVbmRvQnRuICAgPSBzaGFkb3cuZ2V0RWxlbWVudEJ5SWQoJ3d0LXZhLXVuZG8nKSAgICBhcyBIVE1MQnV0dG9uRWxlbWVudDtcblxuICAvLyBcdTI1MDBcdTI1MDAgVG9uZSBzZWxlY3RvciBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbiAgc2hhZG93LnF1ZXJ5U2VsZWN0b3JBbGw8SFRNTEJ1dHRvbkVsZW1lbnQ+KCcud3QtdG9uZScpLmZvckVhY2godGIgPT4ge1xuICAgIHRiLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgICAgc2hhZG93LnF1ZXJ5U2VsZWN0b3JBbGwoJy53dC10b25lJykuZm9yRWFjaChiID0+IGIuY2xhc3NMaXN0LnJlbW92ZSgnYWN0aXZlJykpO1xuICAgICAgdGIuY2xhc3NMaXN0LmFkZCgnYWN0aXZlJyk7XG4gICAgICB0Yi5zdHlsZS5iYWNrZ3JvdW5kICAgID0gdGIuZGF0YXNldC5jb2xvciA/PyAnIzRGNDZFNSc7XG4gICAgICB0Yi5zdHlsZS5ib3JkZXJDb2xvciAgID0gdGIuZGF0YXNldC5jb2xvciA/PyAnIzRGNDZFNSc7XG4gICAgICBzZWxlY3RlZFRvbmUgPSB0Yi5kYXRhc2V0LnRvbmUgYXMgVG9uZTtcbiAgICAgIHJld3JpdGVCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgICAgIHNldFN0YXR1cygnJyk7IGxpbWl0RWwuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xuICAgICAgYWN0aW9uc0VsLmNsYXNzTGlzdC5yZW1vdmUoJ3Zpc2libGUnKTtcbiAgICB9KTtcbiAgfSk7XG5cbiAgLy8gXHUyNTAwXHUyNTAwIFZvaWNlIG91dHB1dCB0eXBlIHNlbGVjdG9yIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuICBzaGFkb3cucXVlcnlTZWxlY3RvckFsbDxIVE1MQnV0dG9uRWxlbWVudD4oJy53dC1vdHlwZScpLmZvckVhY2gob2IgPT4ge1xuICAgIG9iLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgICAgc2hhZG93LnF1ZXJ5U2VsZWN0b3JBbGwoJy53dC1vdHlwZScpLmZvckVhY2goYiA9PiBiLmNsYXNzTGlzdC5yZW1vdmUoJ2FjdGl2ZScpKTtcbiAgICAgIG9iLmNsYXNzTGlzdC5hZGQoJ2FjdGl2ZScpO1xuICAgICAgc2VsZWN0ZWRPdXRwdXRUeXBlID0gb2IuZGF0YXNldC50eXBlIGFzIFZvaWNlT3V0cHV0VHlwZTtcbiAgICB9KTtcbiAgfSk7XG5cbiAgLy8gXHUyNTAwXHUyNTAwIFBhbmVsIHRvZ2dsZXMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4gIGJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBwYW5lbE9wZW4gPSAhcGFuZWxPcGVuO1xuICAgIGlmIChwYW5lbE9wZW4pIHsgdm9pY2VQYW5lbE9wZW4gPSBmYWxzZTsgdm9pY2VQYW5lbC5jbGFzc0xpc3QucmVtb3ZlKCdvcGVuJyk7IH1cbiAgICBwYW5lbC5jbGFzc0xpc3QudG9nZ2xlKCdvcGVuJywgcGFuZWxPcGVuKTtcbiAgICBpZiAocGFuZWxPcGVuKSBwb3NpdGlvblBhbmVsKGJ0biwgcGFuZWwpO1xuICB9KTtcblxuICBtaWNCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgdm9pY2VQYW5lbE9wZW4gPSAhdm9pY2VQYW5lbE9wZW47XG4gICAgaWYgKHZvaWNlUGFuZWxPcGVuKSB7IHBhbmVsT3BlbiA9IGZhbHNlOyBwYW5lbC5jbGFzc0xpc3QucmVtb3ZlKCdvcGVuJyk7IH1cbiAgICB2b2ljZVBhbmVsLmNsYXNzTGlzdC50b2dnbGUoJ29wZW4nLCB2b2ljZVBhbmVsT3Blbik7XG4gICAgaWYgKHZvaWNlUGFuZWxPcGVuKSBwb3NpdGlvblBhbmVsKG1pY0J0biwgdm9pY2VQYW5lbCk7XG4gIH0pO1xuXG4gIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGUpID0+IHtcbiAgICBpZiAoIWhvc3QuY29udGFpbnMoZS50YXJnZXQgYXMgTm9kZSkpIHtcbiAgICAgIHBhbmVsT3BlbiA9IGZhbHNlOyBwYW5lbC5jbGFzc0xpc3QucmVtb3ZlKCdvcGVuJyk7XG4gICAgICB2b2ljZVBhbmVsT3BlbiA9IGZhbHNlOyB2b2ljZVBhbmVsLmNsYXNzTGlzdC5yZW1vdmUoJ29wZW4nKTtcbiAgICB9XG4gIH0sIHRydWUpO1xuXG4gIGZ1bmN0aW9uIHBvc2l0aW9uUGFuZWwoYW5jaG9yOiBIVE1MRWxlbWVudCwgcDogSFRNTERpdkVsZW1lbnQpOiB2b2lkIHtcbiAgICBjb25zdCByZWN0ID0gYW5jaG9yLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIGNvbnN0IHBhbmVsV2lkdGggPSBwYXJzZUludChwLnN0eWxlLndpZHRoIHx8ICcyNjAnKTtcbiAgICBwLnN0eWxlLmJvdHRvbSA9IGAke3dpbmRvdy5pbm5lckhlaWdodCAtIHJlY3QudG9wICsgNn1weGA7XG4gICAgcC5zdHlsZS5sZWZ0ICAgPSBgJHtNYXRoLm1pbihyZWN0LmxlZnQsIHdpbmRvdy5pbm5lcldpZHRoIC0gcGFuZWxXaWR0aCAtIDIwKX1weGA7XG4gIH1cblxuICAvLyBcdTI1MDBcdTI1MDAgUmV3cml0ZSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbiAgcmV3cml0ZUJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgICBpZiAoIXNlbGVjdGVkVG9uZSkgcmV0dXJuO1xuICAgIGNvbnN0IHRleHQgPSByZWFkQ29tcG9zZShjb21wb3NlQm9keSk7XG4gICAgaWYgKCF0ZXh0KSB7IHNldFN0YXR1cygnV3JpdGUgc29tZXRoaW5nIGZpcnN0LicsICdlcnJvcicpOyByZXR1cm47IH1cblxuICAgIG9yaWdpbmFsVGV4dCA9IHRleHQ7XG4gICAgYnRuLmRpc2FibGVkID0gdHJ1ZTsgcmV3cml0ZUJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gICAgc2V0U3RhdHVzKCdSZXdyaXRpbmdcdTIwMjYnKTsgYWN0aW9uc0VsLmNsYXNzTGlzdC5yZW1vdmUoJ3Zpc2libGUnKTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwID0gYXdhaXQgc2VuZFRvQmFja2dyb3VuZDx7IHJlc3VsdDogUmV3cml0ZVJlc3BvbnNlIH0gfCB7IGVycm9yOiBzdHJpbmcgfT4oe1xuICAgICAgICB0eXBlOiAnSFVNQU5JWkUnLFxuICAgICAgICBwYXlsb2FkOiB7IHRleHQsIHRvbmU6IHNlbGVjdGVkVG9uZSB9LFxuICAgICAgfSk7XG4gICAgICBpZiAoJ2Vycm9yJyBpbiByZXNwKSB0aHJvdyBuZXcgRXJyb3IoU3RyaW5nKHJlc3AuZXJyb3IpKTtcbiAgICAgIGxhc3RSZXdyaXRlSWQgPSByZXNwLnJlc3VsdC5pZDtcbiAgICAgIHdyaXRlQ29tcG9zZShjb21wb3NlQm9keSBhcyBIVE1MRWxlbWVudCwgcmVzcC5yZXN1bHQub3V0cHV0X3RleHQpO1xuICAgICAgc2V0U3RhdHVzKCdEb25lIFx1MjcxMycsICdzdWNjZXNzJyk7XG4gICAgICBhY3Rpb25zRWwuY2xhc3NMaXN0LmFkZCgndmlzaWJsZScpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc3QgbXNnID0gZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6ICdGYWlsZWQnO1xuICAgICAgaWYgKG1zZy5zdGFydHNXaXRoKCdMSU1JVF9SRUFDSEVEOicpKSB7XG4gICAgICAgIGxpbWl0RWwuY2xhc3NMaXN0LmFkZCgndmlzaWJsZScpOyBzZXRTdGF0dXMoJycpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2V0U3RhdHVzKG1zZywgJ2Vycm9yJyk7XG4gICAgICB9XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIGJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICAgICAgcmV3cml0ZUJ0bi5kaXNhYmxlZCA9IHNlbGVjdGVkVG9uZSA9PT0gbnVsbDtcbiAgICB9XG4gIH0pO1xuXG4gIGFjY2VwdEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBpZiAobGFzdFJld3JpdGVJZCkgc2VuZFRvQmFja2dyb3VuZCh7IHR5cGU6ICdGRUVEQkFDSycsIHBheWxvYWQ6IHsgcmV3cml0ZUlkOiBsYXN0UmV3cml0ZUlkLCBhY3Rpb246ICdhY2NlcHRlZCcgfSB9KTtcbiAgICBhY3Rpb25zRWwuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xuICAgIHBhbmVsT3BlbiA9IGZhbHNlOyBwYW5lbC5jbGFzc0xpc3QucmVtb3ZlKCdvcGVuJyk7XG4gICAgc2V0U3RhdHVzKCcnKTtcbiAgfSk7XG5cbiAgcmVqZWN0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgIGlmIChvcmlnaW5hbFRleHQpIHdyaXRlQ29tcG9zZShjb21wb3NlQm9keSBhcyBIVE1MRWxlbWVudCwgb3JpZ2luYWxUZXh0KTtcbiAgICBpZiAobGFzdFJld3JpdGVJZCkgc2VuZFRvQmFja2dyb3VuZCh7IHR5cGU6ICdGRUVEQkFDSycsIHBheWxvYWQ6IHsgcmV3cml0ZUlkOiBsYXN0UmV3cml0ZUlkLCBhY3Rpb246ICdyZWplY3RlZCcgfSB9KTtcbiAgICBhY3Rpb25zRWwuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xuICAgIHNldFN0YXR1cygnUmV2ZXJ0ZWQuJywgJ3N1Y2Nlc3MnKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHNldFN0YXR1cygnJyksIDIwMDApO1xuICB9KTtcblxuICBmdW5jdGlvbiBzZXRTdGF0dXMobXNnOiBzdHJpbmcsIGNscyA9ICcnKTogdm9pZCB7XG4gICAgc3RhdHVzRWwudGV4dENvbnRlbnQgPSBtc2c7IHN0YXR1c0VsLmNsYXNzTmFtZSA9IGNscztcbiAgfVxuXG4gIC8vIFx1MjUwMFx1MjUwMCBSZWNvcmRpbmcgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4gIHJlY29yZEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcbiAgICBpZiAoIXJlY29yZGluZykgYXdhaXQgc3RhcnRSZWNvcmRpbmcoKTsgZWxzZSBzdG9wUmVjb3JkaW5nKCk7XG4gIH0pO1xuXG4gIGFzeW5jIGZ1bmN0aW9uIHN0YXJ0UmVjb3JkaW5nKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBzdHJlYW0gPSBhd2FpdCBuYXZpZ2F0b3IubWVkaWFEZXZpY2VzLmdldFVzZXJNZWRpYSh7IGF1ZGlvOiB0cnVlIH0pO1xuICAgICAgYXVkaW9DaHVua3MgPSBbXTtcbiAgICAgIHJlY29yZGVyID0gbmV3IE1lZGlhUmVjb3JkZXIoc3RyZWFtLCB7IG1pbWVUeXBlOiAnYXVkaW8vd2VibScgfSk7XG4gICAgICByZWNvcmRlci5vbmRhdGFhdmFpbGFibGUgPSAoZSkgPT4geyBpZiAoZS5kYXRhLnNpemUgPiAwKSBhdWRpb0NodW5rcy5wdXNoKGUuZGF0YSk7IH07XG4gICAgICByZWNvcmRlci5vbnN0b3AgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIHN0cmVhbS5nZXRUcmFja3MoKS5mb3JFYWNoKHQgPT4gdC5zdG9wKCkpO1xuICAgICAgICBhd2FpdCBzdWJtaXRWb2ljZShuZXcgQmxvYihhdWRpb0NodW5rcywgeyB0eXBlOiAnYXVkaW8vd2VibScgfSkpO1xuICAgICAgfTtcbiAgICAgIHJlY29yZGVyLnN0YXJ0KCk7XG4gICAgICByZWNvcmRpbmcgPSB0cnVlO1xuICAgICAgbWljQnRuLmNsYXNzTGlzdC5hZGQoJ3JlY29yZGluZycpO1xuICAgICAgcmVjb3JkQnRuLmNsYXNzTGlzdC5hZGQoJ3JlY29yZGluZycpO1xuICAgICAgcmVjb3JkQnRuLnRleHRDb250ZW50ID0gJ1x1MjNGOSBTdG9wIHJlY29yZGluZyc7XG4gICAgICBzZXRWb2ljZVN0YXR1cygnUmVjb3JkaW5nXHUyMDI2Jyk7XG4gICAgICB2QWN0aW9uc0VsLmNsYXNzTGlzdC5yZW1vdmUoJ3Zpc2libGUnKTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4geyBpZiAocmVjb3JkaW5nKSBzdG9wUmVjb3JkaW5nKCk7IH0sIDYwXzAwMCk7XG4gICAgfSBjYXRjaCB7XG4gICAgICBzZXRWb2ljZVN0YXR1cygnTWljcm9waG9uZSBhY2Nlc3MgZGVuaWVkLicsICdlcnJvcicpO1xuICAgIH1cbiAgfVxuXG4gIGZ1bmN0aW9uIHN0b3BSZWNvcmRpbmcoKTogdm9pZCB7XG4gICAgaWYgKHJlY29yZGVyICYmIHJlY29yZGluZykge1xuICAgICAgcmVjb3JkZXIuc3RvcCgpO1xuICAgICAgcmVjb3JkaW5nID0gZmFsc2U7XG4gICAgICBtaWNCdG4uY2xhc3NMaXN0LnJlbW92ZSgncmVjb3JkaW5nJyk7XG4gICAgICByZWNvcmRCdG4uY2xhc3NMaXN0LnJlbW92ZSgncmVjb3JkaW5nJyk7XG4gICAgICByZWNvcmRCdG4udGV4dENvbnRlbnQgPSAnXHVEODNDXHVERjk5IFN0YXJ0IHJlY29yZGluZyc7XG4gICAgICByZWNvcmRCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICAgICAgc2V0Vm9pY2VTdGF0dXMoJ0RyYWZ0aW5nXHUyMDI2Jyk7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgZnVuY3Rpb24gc3VibWl0Vm9pY2UoYmxvYjogQmxvYik6IFByb21pc2U8dm9pZD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBhYiA9IGF3YWl0IGJsb2IuYXJyYXlCdWZmZXIoKTtcbiAgICAgIGNvbnN0IHU4ID0gbmV3IFVpbnQ4QXJyYXkoYWIpO1xuICAgICAgbGV0IGJpbiA9ICcnO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCB1OC5sZW5ndGg7IGkrKykgYmluICs9IFN0cmluZy5mcm9tQ2hhckNvZGUodThbaV0pO1xuICAgICAgY29uc3QgYXVkaW9EYXRhID0gYnRvYShiaW4pO1xuXG4gICAgICBvcmlnaW5hbFZvaWNlVGV4dCA9IHJlYWRDb21wb3NlKGNvbXBvc2VCb2R5KTtcblxuICAgICAgY29uc3QgcmVzcCA9IGF3YWl0IHNlbmRUb0JhY2tncm91bmQ8eyByZXN1bHQ6IFZvaWNlRHJhZnRSZXNwb25zZSB9IHwgeyBlcnJvcjogc3RyaW5nIH0+KHtcbiAgICAgICAgdHlwZTogJ1ZPSUNFX0RSQUZUJyxcbiAgICAgICAgcGF5bG9hZDogeyBhdWRpb0RhdGEsIG1pbWVUeXBlOiAnYXVkaW8vd2VibScsIG91dHB1dFR5cGU6IHNlbGVjdGVkT3V0cHV0VHlwZSB9LFxuICAgICAgfSk7XG4gICAgICBpZiAoJ2Vycm9yJyBpbiByZXNwKSB0aHJvdyBuZXcgRXJyb3IoU3RyaW5nKHJlc3AuZXJyb3IpKTtcblxuICAgICAgbGFzdFZvaWNlU2Vzc2lvbklkID0gcmVzcC5yZXN1bHQuaWQ7XG4gICAgICB3cml0ZUNvbXBvc2UoY29tcG9zZUJvZHkgYXMgSFRNTEVsZW1lbnQsIHJlc3AucmVzdWx0LmRyYWZ0KTtcbiAgICAgIHNldFZvaWNlU3RhdHVzKCdEb25lIFx1MjcxMycpO1xuICAgICAgdkFjdGlvbnNFbC5jbGFzc0xpc3QuYWRkKCd2aXNpYmxlJyk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRWb2ljZVN0YXR1cyhlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogJ0ZhaWxlZCcsICdlcnJvcicpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICByZWNvcmRCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgICB9XG4gIH1cblxuICB2S2VlcEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBpZiAobGFzdFZvaWNlU2Vzc2lvbklkKSBzZW5kVG9CYWNrZ3JvdW5kKHsgdHlwZTogJ1ZPSUNFX0ZFRURCQUNLJywgcGF5bG9hZDogeyBzZXNzaW9uSWQ6IGxhc3RWb2ljZVNlc3Npb25JZCwgYWNjZXB0ZWQ6IHRydWUsIGVkaXRlZERyYWZ0OiBudWxsIH0gfSk7XG4gICAgdkFjdGlvbnNFbC5jbGFzc0xpc3QucmVtb3ZlKCd2aXNpYmxlJyk7XG4gICAgdm9pY2VQYW5lbE9wZW4gPSBmYWxzZTsgdm9pY2VQYW5lbC5jbGFzc0xpc3QucmVtb3ZlKCdvcGVuJyk7XG4gICAgc2V0Vm9pY2VTdGF0dXMoJycpO1xuICB9KTtcblxuICB2VW5kb0J0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICBpZiAob3JpZ2luYWxWb2ljZVRleHQpIHdyaXRlQ29tcG9zZShjb21wb3NlQm9keSBhcyBIVE1MRWxlbWVudCwgb3JpZ2luYWxWb2ljZVRleHQpO1xuICAgIGlmIChsYXN0Vm9pY2VTZXNzaW9uSWQpIHNlbmRUb0JhY2tncm91bmQoeyB0eXBlOiAnVk9JQ0VfRkVFREJBQ0snLCBwYXlsb2FkOiB7IHNlc3Npb25JZDogbGFzdFZvaWNlU2Vzc2lvbklkLCBhY2NlcHRlZDogZmFsc2UsIGVkaXRlZERyYWZ0OiBudWxsIH0gfSk7XG4gICAgdkFjdGlvbnNFbC5jbGFzc0xpc3QucmVtb3ZlKCd2aXNpYmxlJyk7XG4gICAgc2V0Vm9pY2VTdGF0dXMoJ1JldmVydGVkLicsICdzdWNjZXNzJyk7XG4gICAgc2V0VGltZW91dCgoKSA9PiBzZXRWb2ljZVN0YXR1cygnJyksIDIwMDApO1xuICB9KTtcblxuICBmdW5jdGlvbiBzZXRWb2ljZVN0YXR1cyhtc2c6IHN0cmluZywgY2xzID0gJycpOiB2b2lkIHtcbiAgICB2U3RhdHVzRWwudGV4dENvbnRlbnQgPSBtc2c7IHZTdGF0dXNFbC5jbGFzc05hbWUgPSBjbHM7XG4gIH1cblxuICAvLyBJbnNlcnQgb3VyIGhvc3QgcmlnaHQgYmVmb3JlIHRoZSBTZW5kIGJ1dHRvbiBpbiB0aGUgdG9vbGJhclxuICB0b29sYmFyLmluc2VydEJlZm9yZShob3N0LCBzZW5kQnRuKTtcbn1cblxuLy8gXHUyNTAwXHUyNTAwIEhlbHBlcnMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbi8qKlxuICogV2FsayB1cCBmcm9tIHRoZSBjb21wb3NlIGJvZHkgdG8gZmluZCB0aGUgU2VuZCBidXR0b24uXG4gKiBPdXRsb29rIG5lc3RzIHRoZSB0b29sYmFyIGluIGEgc2libGluZyBzdWJ0cmVlLCBzbyB3ZSB3YWxrIHVwIHRvIGEgY29tbW9uXG4gKiBhbmNlc3RvciAodXAgdG8gMzAgbGV2ZWxzKSBhbmQgc2VhcmNoIGRvd24gZm9yIHRoZSBTZW5kIGJ1dHRvbiBmcm9tIHRoZXJlLlxuICovXG5mdW5jdGlvbiBmaW5kU2VuZEJ1dHRvbihjb21wb3NlQm9keTogRWxlbWVudCk6IEVsZW1lbnQgfCBudWxsIHtcbiAgbGV0IGVsOiBFbGVtZW50IHwgbnVsbCA9IGNvbXBvc2VCb2R5O1xuICBmb3IgKGxldCBpID0gMDsgaSA8IDMwOyBpKyspIHtcbiAgICBpZiAoIWVsKSBicmVhaztcbiAgICBjb25zdCBzZW5kID0gZWwucXVlcnlTZWxlY3RvcihTRU5EX0JVVFRPTl9TRUwpO1xuICAgIGlmIChzZW5kKSByZXR1cm4gc2VuZDtcbiAgICBlbCA9IGVsLnBhcmVudEVsZW1lbnQ7XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbmZ1bmN0aW9uIHJlYWRDb21wb3NlKGVsOiBFbGVtZW50KTogc3RyaW5nIHtcbiAgcmV0dXJuIChlbCBhcyBIVE1MRWxlbWVudCkuaW5uZXJUZXh0LnRyaW0oKTtcbn1cblxuZnVuY3Rpb24gd3JpdGVDb21wb3NlKGVsOiBIVE1MRWxlbWVudCwgdGV4dDogc3RyaW5nKTogdm9pZCB7XG4gIGVsLmZvY3VzKCk7XG4gIC8vIFNlbGVjdCBhbGwgKyBkZWxldGUgdmlhIGV4ZWNDb21tYW5kICh3b3JrcyBpbiBPdXRsb29rIGNvbnRlbnRlZGl0YWJsZSlcbiAgZG9jdW1lbnQuZXhlY0NvbW1hbmQoJ3NlbGVjdEFsbCcsIGZhbHNlLCB1bmRlZmluZWQpO1xuICBkb2N1bWVudC5leGVjQ29tbWFuZCgnZGVsZXRlJywgZmFsc2UsIHVuZGVmaW5lZCk7XG4gIGNvbnN0IGxpbmVzID0gdGV4dC5zcGxpdCgnXFxuJyk7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbGluZXMubGVuZ3RoOyBpKyspIHtcbiAgICBpZiAobGluZXNbaV0pIGRvY3VtZW50LmV4ZWNDb21tYW5kKCdpbnNlcnRUZXh0JywgZmFsc2UsIGxpbmVzW2ldKTtcbiAgICBpZiAoaSA8IGxpbmVzLmxlbmd0aCAtIDEpIGRvY3VtZW50LmV4ZWNDb21tYW5kKCdpbnNlcnRQYXJhZ3JhcGgnLCBmYWxzZSwgdW5kZWZpbmVkKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBzZW5kVG9CYWNrZ3JvdW5kPFQ+KG1lc3NhZ2U6IG9iamVjdCk6IFByb21pc2U8VD4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZShtZXNzYWdlLCByZXNvbHZlKTtcbiAgfSk7XG59XG5cbi8vIFx1MjUwMFx1MjUwMCBPYnNlcnZlciArIHBvbGxpbmcgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmNvbnN0IHNlZW4gPSBuZXcgV2Vha1NldDxFbGVtZW50PigpO1xuXG5mdW5jdGlvbiB0cnlJbmplY3Qocm9vdDogRWxlbWVudCB8IERvY3VtZW50KTogdm9pZCB7XG4gIHJvb3QucXVlcnlTZWxlY3RvckFsbDxFbGVtZW50PihDT01QT1NFX0JPRFlfU0VMKS5mb3JFYWNoKChib2R5KSA9PiB7XG4gICAgLy8gU2tpcCB0aGUgZ2xvYmFsIHJlYWRpbmcgcGFuZSBcdTIwMTQgd2Ugb25seSB3YW50IGFjdGl2ZSBjb21wb3NlIHdpbmRvd3NcbiAgICBpZiAoIWZpbmRTZW5kQnV0dG9uKGJvZHkpKSByZXR1cm47XG4gICAgaWYgKCFzZWVuLmhhcyhib2R5KSkge1xuICAgICAgc2Vlbi5hZGQoYm9keSk7XG4gICAgICBpbmplY3QoYm9keSk7XG4gICAgfVxuICB9KTtcbn1cblxuLy8gTXV0YXRpb25PYnNlcnZlciBcdTIwMTQgT3V0bG9vaydzIFJlYWN0IHRyZWUgbXV0YXRlcyBkZWVwbHlcbmNvbnN0IG9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoKCkgPT4gdHJ5SW5qZWN0KGRvY3VtZW50KSk7XG5vYnNlcnZlci5vYnNlcnZlKGRvY3VtZW50LmJvZHksIHsgY2hpbGRMaXN0OiB0cnVlLCBzdWJ0cmVlOiB0cnVlIH0pO1xuXG4vLyBQb2xsaW5nIGZhbGxiYWNrIFx1MjAxNCBjYXRjaGVzIGNhc2VzIHdoZXJlIG11dGF0aW9ucyBmaXJlIGJlZm9yZSBSZWFjdCBmaW5pc2hlcyByZW5kZXJpbmdcbi8vIChlLmcuIGNvbXBvc2Ugd2luZG93IG9wZW5lZCBidXQgdG9vbGJhciBub3QgeWV0IGluIERPTSB3aGVuIG9ic2VydmVyIGZpcmVzKVxuc2V0SW50ZXJ2YWwoKCkgPT4gdHJ5SW5qZWN0KGRvY3VtZW50KSwgMTAwMCk7XG5cbi8vIEhhbmRsZSBjb21wb3NlIHdpbmRvd3MgYWxyZWFkeSBpbiBET00gb24gbG9hZFxudHJ5SW5qZWN0KGRvY3VtZW50KTtcblxuLy8gXHUyNTAwXHUyNTAwIEtleWJvYXJkIHNob3J0Y3V0cyBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIChlKSA9PiB7XG4gIGlmICghKGUuY3RybEtleSB8fCBlLm1ldGFLZXkpIHx8ICFlLnNoaWZ0S2V5KSByZXR1cm47XG5cbiAgY29uc3QgdG9vbGJhckVsID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihgWyR7SE9TVF9BVFRSfV1gKTtcbiAgaWYgKCF0b29sYmFyRWwpIHJldHVybjtcbiAgY29uc3QgaG9zdHMgPSBBcnJheS5mcm9tKHRvb2xiYXJFbC5jaGlsZHJlbikuZmlsdGVyKGMgPT4gYy5zaGFkb3dSb290KSBhcyBIVE1MRWxlbWVudFtdO1xuXG4gIGlmIChlLmtleSA9PT0gJ0gnKSB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIChob3N0c1swXT8uc2hhZG93Um9vdD8uZ2V0RWxlbWVudEJ5SWQoJ3d0LWJ0bicpIGFzIEhUTUxCdXR0b25FbGVtZW50IHwgbnVsbCk/LmNsaWNrKCk7XG4gIH1cbiAgaWYgKGUua2V5ID09PSAnVicpIHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgKGhvc3RzWzBdPy5zaGFkb3dSb290Py5nZXRFbGVtZW50QnlJZCgnd3QtbWljLWJ0bicpIGFzIEhUTUxCdXR0b25FbGVtZW50IHwgbnVsbCk/LmNsaWNrKCk7XG4gIH1cbn0pO1xuIl0sCiAgIm1hcHBpbmdzIjogIjs7O0FBYUEsTUFBTSxtQkFBbUI7QUFBQSxJQUN2QjtBQUFBLElBQ0E7QUFBQSxFQUNGLEVBQUUsS0FBSyxJQUFJO0FBSVgsTUFBTSxrQkFBa0I7QUFBQSxJQUN0QjtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0YsRUFBRSxLQUFLLElBQUk7QUFFWCxNQUFNLFlBQVk7QUFJbEIsTUFBTSxRQUF1RDtBQUFBLElBQzNELEVBQUUsS0FBSyxnQkFBZ0IsT0FBTyxnQkFBZ0IsT0FBTyxVQUFVO0FBQUEsSUFDL0QsRUFBRSxLQUFLLFVBQWdCLE9BQU8sVUFBZ0IsT0FBTyxVQUFVO0FBQUEsSUFDL0QsRUFBRSxLQUFLLFlBQWdCLE9BQU8sWUFBZ0IsT0FBTyxVQUFVO0FBQUEsSUFDL0QsRUFBRSxLQUFLLFVBQWdCLE9BQU8sVUFBZ0IsT0FBTyxVQUFVO0FBQUEsSUFDL0QsRUFBRSxLQUFLLGNBQWdCLE9BQU8sY0FBZ0IsT0FBTyxVQUFVO0FBQUEsSUFDL0QsRUFBRSxLQUFLLGFBQWdCLE9BQU8sYUFBZ0IsT0FBTyxVQUFVO0FBQUEsRUFDakU7QUFJQSxNQUFNLHFCQUFnRTtBQUFBLElBQ3BFLEVBQUUsS0FBSyxTQUFvQixPQUFPLFFBQVE7QUFBQSxJQUMxQyxFQUFFLEtBQUssU0FBb0IsT0FBTyxRQUFRO0FBQUEsSUFDMUMsRUFBRSxLQUFLLG1CQUFvQixPQUFPLGtCQUFrQjtBQUFBLElBQ3BELEVBQUUsS0FBSyxlQUFvQixPQUFPLGNBQWM7QUFBQSxJQUNoRCxFQUFFLEtBQUssb0JBQW9CLE9BQU8sY0FBYztBQUFBLEVBQ2xEO0FBSUEsTUFBTSxXQUFXO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUE2SGpCLFdBQVMsT0FBTyxhQUE0QjtBQUMxQyxVQUFNLFVBQVUsZUFBZSxXQUFXO0FBQzFDLFFBQUksQ0FBQyxRQUFTO0FBR2QsVUFBTSxVQUNKLFFBQVEsUUFBUSxrQkFBa0IsS0FDbEMsUUFBUSxRQUFRLGdCQUFnQixLQUNoQyxRQUFRO0FBQ1YsUUFBSSxDQUFDLFdBQVcsUUFBUSxhQUFhLFNBQVMsRUFBRztBQUVqRCxZQUFRLGFBQWEsV0FBVyxHQUFHO0FBRW5DLFVBQU0sT0FBTyxTQUFTLGNBQWMsTUFBTTtBQUMxQyxVQUFNLFNBQVMsS0FBSyxhQUFhLEVBQUUsTUFBTSxPQUFPLENBQUM7QUFFakQsUUFBSSxlQUE0QjtBQUNoQyxRQUFJLGdCQUErQjtBQUNuQyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxpQkFBaUI7QUFDckIsUUFBSSxxQkFBc0M7QUFDMUMsUUFBSSxXQUFpQztBQUNyQyxRQUFJLFlBQVk7QUFDaEIsUUFBSSxjQUEwQixDQUFDO0FBQy9CLFFBQUkscUJBQW9DO0FBQ3hDLFFBQUksZUFBZTtBQUNuQixRQUFJLG9CQUFvQjtBQUV4QixXQUFPLFlBQVk7QUFBQSxhQUNSLFFBQVE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUVgsTUFBTSxJQUFJLE9BQUssc0NBQXNDLEVBQUUsR0FBRyxpQkFBaUIsRUFBRSxLQUFLLEtBQUssRUFBRSxLQUFLLFdBQVcsRUFBRSxLQUFLLEVBQUUsQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWtCbkgsbUJBQW1CO0FBQUEsTUFBSSxDQUFDLEdBQUcsTUFDM0IsMEJBQTBCLE1BQU0sSUFBSSxZQUFZLEVBQUUsZ0JBQWdCLEVBQUUsR0FBRyxLQUFLLEVBQUUsS0FBSztBQUFBLElBQ3JGLEVBQUUsS0FBSyxFQUFFLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFZaEIsVUFBTSxNQUFhLE9BQU8sZUFBZSxRQUFRO0FBQ2pELFVBQU0sU0FBYSxPQUFPLGVBQWUsWUFBWTtBQUNyRCxVQUFNLFFBQWEsT0FBTyxlQUFlLFVBQVU7QUFDbkQsVUFBTSxhQUFhLE9BQU8sZUFBZSxnQkFBZ0I7QUFDekQsVUFBTSxhQUFhLE9BQU8sZUFBZSxZQUFZO0FBQ3JELFVBQU0sV0FBYSxPQUFPLGVBQWUsV0FBVztBQUNwRCxVQUFNLFVBQWEsT0FBTyxlQUFlLFVBQVU7QUFDbkQsVUFBTSxZQUFhLE9BQU8sZUFBZSxZQUFZO0FBQ3JELFVBQU0sWUFBYSxPQUFPLGVBQWUsV0FBVztBQUNwRCxVQUFNLFlBQWEsT0FBTyxlQUFlLFdBQVc7QUFDcEQsVUFBTSxZQUFhLE9BQU8sZUFBZSxlQUFlO0FBQ3hELFVBQU0sWUFBYSxPQUFPLGVBQWUsaUJBQWlCO0FBQzFELFVBQU0sYUFBYSxPQUFPLGVBQWUsa0JBQWtCO0FBQzNELFVBQU0sV0FBYSxPQUFPLGVBQWUsWUFBWTtBQUNyRCxVQUFNLFdBQWEsT0FBTyxlQUFlLFlBQVk7QUFHckQsV0FBTyxpQkFBb0MsVUFBVSxFQUFFLFFBQVEsUUFBTTtBQUNuRSxTQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDakMsZUFBTyxpQkFBaUIsVUFBVSxFQUFFLFFBQVEsT0FBSyxFQUFFLFVBQVUsT0FBTyxRQUFRLENBQUM7QUFDN0UsV0FBRyxVQUFVLElBQUksUUFBUTtBQUN6QixXQUFHLE1BQU0sYUFBZ0IsR0FBRyxRQUFRLFNBQVM7QUFDN0MsV0FBRyxNQUFNLGNBQWdCLEdBQUcsUUFBUSxTQUFTO0FBQzdDLHVCQUFlLEdBQUcsUUFBUTtBQUMxQixtQkFBVyxXQUFXO0FBQ3RCLGtCQUFVLEVBQUU7QUFBRyxnQkFBUSxVQUFVLE9BQU8sU0FBUztBQUNqRCxrQkFBVSxVQUFVLE9BQU8sU0FBUztBQUFBLE1BQ3RDLENBQUM7QUFBQSxJQUNILENBQUM7QUFHRCxXQUFPLGlCQUFvQyxXQUFXLEVBQUUsUUFBUSxRQUFNO0FBQ3BFLFNBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUNqQyxlQUFPLGlCQUFpQixXQUFXLEVBQUUsUUFBUSxPQUFLLEVBQUUsVUFBVSxPQUFPLFFBQVEsQ0FBQztBQUM5RSxXQUFHLFVBQVUsSUFBSSxRQUFRO0FBQ3pCLDZCQUFxQixHQUFHLFFBQVE7QUFBQSxNQUNsQyxDQUFDO0FBQUEsSUFDSCxDQUFDO0FBR0QsUUFBSSxpQkFBaUIsU0FBUyxNQUFNO0FBQ2xDLGtCQUFZLENBQUM7QUFDYixVQUFJLFdBQVc7QUFBRSx5QkFBaUI7QUFBTyxtQkFBVyxVQUFVLE9BQU8sTUFBTTtBQUFBLE1BQUc7QUFDOUUsWUFBTSxVQUFVLE9BQU8sUUFBUSxTQUFTO0FBQ3hDLFVBQUksVUFBVyxlQUFjLEtBQUssS0FBSztBQUFBLElBQ3pDLENBQUM7QUFFRCxXQUFPLGlCQUFpQixTQUFTLE1BQU07QUFDckMsdUJBQWlCLENBQUM7QUFDbEIsVUFBSSxnQkFBZ0I7QUFBRSxvQkFBWTtBQUFPLGNBQU0sVUFBVSxPQUFPLE1BQU07QUFBQSxNQUFHO0FBQ3pFLGlCQUFXLFVBQVUsT0FBTyxRQUFRLGNBQWM7QUFDbEQsVUFBSSxlQUFnQixlQUFjLFFBQVEsVUFBVTtBQUFBLElBQ3RELENBQUM7QUFFRCxhQUFTLGlCQUFpQixTQUFTLENBQUMsTUFBTTtBQUN4QyxVQUFJLENBQUMsS0FBSyxTQUFTLEVBQUUsTUFBYyxHQUFHO0FBQ3BDLG9CQUFZO0FBQU8sY0FBTSxVQUFVLE9BQU8sTUFBTTtBQUNoRCx5QkFBaUI7QUFBTyxtQkFBVyxVQUFVLE9BQU8sTUFBTTtBQUFBLE1BQzVEO0FBQUEsSUFDRixHQUFHLElBQUk7QUFFUCxhQUFTLGNBQWMsUUFBcUIsR0FBeUI7QUFDbkUsWUFBTSxPQUFPLE9BQU8sc0JBQXNCO0FBQzFDLFlBQU0sYUFBYSxTQUFTLEVBQUUsTUFBTSxTQUFTLEtBQUs7QUFDbEQsUUFBRSxNQUFNLFNBQVMsR0FBRyxPQUFPLGNBQWMsS0FBSyxNQUFNLENBQUM7QUFDckQsUUFBRSxNQUFNLE9BQVMsR0FBRyxLQUFLLElBQUksS0FBSyxNQUFNLE9BQU8sYUFBYSxhQUFhLEVBQUUsQ0FBQztBQUFBLElBQzlFO0FBR0EsZUFBVyxpQkFBaUIsU0FBUyxZQUFZO0FBQy9DLFVBQUksQ0FBQyxhQUFjO0FBQ25CLFlBQU0sT0FBTyxZQUFZLFdBQVc7QUFDcEMsVUFBSSxDQUFDLE1BQU07QUFBRSxrQkFBVSwwQkFBMEIsT0FBTztBQUFHO0FBQUEsTUFBUTtBQUVuRSxxQkFBZTtBQUNmLFVBQUksV0FBVztBQUFNLGlCQUFXLFdBQVc7QUFDM0MsZ0JBQVUsaUJBQVk7QUFBRyxnQkFBVSxVQUFVLE9BQU8sU0FBUztBQUU3RCxVQUFJO0FBQ0YsY0FBTSxPQUFPLE1BQU0saUJBQWtFO0FBQUEsVUFDbkYsTUFBTTtBQUFBLFVBQ04sU0FBUyxFQUFFLE1BQU0sTUFBTSxhQUFhO0FBQUEsUUFDdEMsQ0FBQztBQUNELFlBQUksV0FBVyxLQUFNLE9BQU0sSUFBSSxNQUFNLE9BQU8sS0FBSyxLQUFLLENBQUM7QUFDdkQsd0JBQWdCLEtBQUssT0FBTztBQUM1QixxQkFBYSxhQUE0QixLQUFLLE9BQU8sV0FBVztBQUNoRSxrQkFBVSxlQUFVLFNBQVM7QUFDN0Isa0JBQVUsVUFBVSxJQUFJLFNBQVM7QUFBQSxNQUNuQyxTQUFTLEtBQUs7QUFDWixjQUFNLE1BQU0sZUFBZSxRQUFRLElBQUksVUFBVTtBQUNqRCxZQUFJLElBQUksV0FBVyxnQkFBZ0IsR0FBRztBQUNwQyxrQkFBUSxVQUFVLElBQUksU0FBUztBQUFHLG9CQUFVLEVBQUU7QUFBQSxRQUNoRCxPQUFPO0FBQ0wsb0JBQVUsS0FBSyxPQUFPO0FBQUEsUUFDeEI7QUFBQSxNQUNGLFVBQUU7QUFDQSxZQUFJLFdBQVc7QUFDZixtQkFBVyxXQUFXLGlCQUFpQjtBQUFBLE1BQ3pDO0FBQUEsSUFDRixDQUFDO0FBRUQsY0FBVSxpQkFBaUIsU0FBUyxNQUFNO0FBQ3hDLFVBQUksY0FBZSxrQkFBaUIsRUFBRSxNQUFNLFlBQVksU0FBUyxFQUFFLFdBQVcsZUFBZSxRQUFRLFdBQVcsRUFBRSxDQUFDO0FBQ25ILGdCQUFVLFVBQVUsT0FBTyxTQUFTO0FBQ3BDLGtCQUFZO0FBQU8sWUFBTSxVQUFVLE9BQU8sTUFBTTtBQUNoRCxnQkFBVSxFQUFFO0FBQUEsSUFDZCxDQUFDO0FBRUQsY0FBVSxpQkFBaUIsU0FBUyxNQUFNO0FBQ3hDLFVBQUksYUFBYyxjQUFhLGFBQTRCLFlBQVk7QUFDdkUsVUFBSSxjQUFlLGtCQUFpQixFQUFFLE1BQU0sWUFBWSxTQUFTLEVBQUUsV0FBVyxlQUFlLFFBQVEsV0FBVyxFQUFFLENBQUM7QUFDbkgsZ0JBQVUsVUFBVSxPQUFPLFNBQVM7QUFDcEMsZ0JBQVUsYUFBYSxTQUFTO0FBQ2hDLGlCQUFXLE1BQU0sVUFBVSxFQUFFLEdBQUcsR0FBSTtBQUFBLElBQ3RDLENBQUM7QUFFRCxhQUFTLFVBQVUsS0FBYSxNQUFNLElBQVU7QUFDOUMsZUFBUyxjQUFjO0FBQUssZUFBUyxZQUFZO0FBQUEsSUFDbkQ7QUFHQSxjQUFVLGlCQUFpQixTQUFTLFlBQVk7QUFDOUMsVUFBSSxDQUFDLFVBQVcsT0FBTSxlQUFlO0FBQUEsVUFBUSxlQUFjO0FBQUEsSUFDN0QsQ0FBQztBQUVELG1CQUFlLGlCQUFnQztBQUM3QyxVQUFJO0FBQ0YsY0FBTSxTQUFTLE1BQU0sVUFBVSxhQUFhLGFBQWEsRUFBRSxPQUFPLEtBQUssQ0FBQztBQUN4RSxzQkFBYyxDQUFDO0FBQ2YsbUJBQVcsSUFBSSxjQUFjLFFBQVEsRUFBRSxVQUFVLGFBQWEsQ0FBQztBQUMvRCxpQkFBUyxrQkFBa0IsQ0FBQyxNQUFNO0FBQUUsY0FBSSxFQUFFLEtBQUssT0FBTyxFQUFHLGFBQVksS0FBSyxFQUFFLElBQUk7QUFBQSxRQUFHO0FBQ25GLGlCQUFTLFNBQVMsWUFBWTtBQUM1QixpQkFBTyxVQUFVLEVBQUUsUUFBUSxPQUFLLEVBQUUsS0FBSyxDQUFDO0FBQ3hDLGdCQUFNLFlBQVksSUFBSSxLQUFLLGFBQWEsRUFBRSxNQUFNLGFBQWEsQ0FBQyxDQUFDO0FBQUEsUUFDakU7QUFDQSxpQkFBUyxNQUFNO0FBQ2Ysb0JBQVk7QUFDWixlQUFPLFVBQVUsSUFBSSxXQUFXO0FBQ2hDLGtCQUFVLFVBQVUsSUFBSSxXQUFXO0FBQ25DLGtCQUFVLGNBQWM7QUFDeEIsdUJBQWUsaUJBQVk7QUFDM0IsbUJBQVcsVUFBVSxPQUFPLFNBQVM7QUFDckMsbUJBQVcsTUFBTTtBQUFFLGNBQUksVUFBVyxlQUFjO0FBQUEsUUFBRyxHQUFHLEdBQU07QUFBQSxNQUM5RCxRQUFRO0FBQ04sdUJBQWUsNkJBQTZCLE9BQU87QUFBQSxNQUNyRDtBQUFBLElBQ0Y7QUFFQSxhQUFTLGdCQUFzQjtBQUM3QixVQUFJLFlBQVksV0FBVztBQUN6QixpQkFBUyxLQUFLO0FBQ2Qsb0JBQVk7QUFDWixlQUFPLFVBQVUsT0FBTyxXQUFXO0FBQ25DLGtCQUFVLFVBQVUsT0FBTyxXQUFXO0FBQ3RDLGtCQUFVLGNBQWM7QUFDeEIsa0JBQVUsV0FBVztBQUNyQix1QkFBZSxnQkFBVztBQUFBLE1BQzVCO0FBQUEsSUFDRjtBQUVBLG1CQUFlLFlBQVksTUFBMkI7QUFDcEQsVUFBSTtBQUNGLGNBQU0sS0FBSyxNQUFNLEtBQUssWUFBWTtBQUNsQyxjQUFNLEtBQUssSUFBSSxXQUFXLEVBQUU7QUFDNUIsWUFBSSxNQUFNO0FBQ1YsaUJBQVMsSUFBSSxHQUFHLElBQUksR0FBRyxRQUFRLElBQUssUUFBTyxPQUFPLGFBQWEsR0FBRyxDQUFDLENBQUM7QUFDcEUsY0FBTSxZQUFZLEtBQUssR0FBRztBQUUxQiw0QkFBb0IsWUFBWSxXQUFXO0FBRTNDLGNBQU0sT0FBTyxNQUFNLGlCQUFxRTtBQUFBLFVBQ3RGLE1BQU07QUFBQSxVQUNOLFNBQVMsRUFBRSxXQUFXLFVBQVUsY0FBYyxZQUFZLG1CQUFtQjtBQUFBLFFBQy9FLENBQUM7QUFDRCxZQUFJLFdBQVcsS0FBTSxPQUFNLElBQUksTUFBTSxPQUFPLEtBQUssS0FBSyxDQUFDO0FBRXZELDZCQUFxQixLQUFLLE9BQU87QUFDakMscUJBQWEsYUFBNEIsS0FBSyxPQUFPLEtBQUs7QUFDMUQsdUJBQWUsYUFBUTtBQUN2QixtQkFBVyxVQUFVLElBQUksU0FBUztBQUFBLE1BQ3BDLFNBQVMsS0FBSztBQUNaLHVCQUFlLGVBQWUsUUFBUSxJQUFJLFVBQVUsVUFBVSxPQUFPO0FBQUEsTUFDdkUsVUFBRTtBQUNBLGtCQUFVLFdBQVc7QUFBQSxNQUN2QjtBQUFBLElBQ0Y7QUFFQSxhQUFTLGlCQUFpQixTQUFTLE1BQU07QUFDdkMsVUFBSSxtQkFBb0Isa0JBQWlCLEVBQUUsTUFBTSxrQkFBa0IsU0FBUyxFQUFFLFdBQVcsb0JBQW9CLFVBQVUsTUFBTSxhQUFhLEtBQUssRUFBRSxDQUFDO0FBQ2xKLGlCQUFXLFVBQVUsT0FBTyxTQUFTO0FBQ3JDLHVCQUFpQjtBQUFPLGlCQUFXLFVBQVUsT0FBTyxNQUFNO0FBQzFELHFCQUFlLEVBQUU7QUFBQSxJQUNuQixDQUFDO0FBRUQsYUFBUyxpQkFBaUIsU0FBUyxNQUFNO0FBQ3ZDLFVBQUksa0JBQW1CLGNBQWEsYUFBNEIsaUJBQWlCO0FBQ2pGLFVBQUksbUJBQW9CLGtCQUFpQixFQUFFLE1BQU0sa0JBQWtCLFNBQVMsRUFBRSxXQUFXLG9CQUFvQixVQUFVLE9BQU8sYUFBYSxLQUFLLEVBQUUsQ0FBQztBQUNuSixpQkFBVyxVQUFVLE9BQU8sU0FBUztBQUNyQyxxQkFBZSxhQUFhLFNBQVM7QUFDckMsaUJBQVcsTUFBTSxlQUFlLEVBQUUsR0FBRyxHQUFJO0FBQUEsSUFDM0MsQ0FBQztBQUVELGFBQVMsZUFBZSxLQUFhLE1BQU0sSUFBVTtBQUNuRCxnQkFBVSxjQUFjO0FBQUssZ0JBQVUsWUFBWTtBQUFBLElBQ3JEO0FBR0EsWUFBUSxhQUFhLE1BQU0sT0FBTztBQUFBLEVBQ3BDO0FBU0EsV0FBUyxlQUFlLGFBQXNDO0FBQzVELFFBQUksS0FBcUI7QUFDekIsYUFBUyxJQUFJLEdBQUcsSUFBSSxJQUFJLEtBQUs7QUFDM0IsVUFBSSxDQUFDLEdBQUk7QUFDVCxZQUFNLE9BQU8sR0FBRyxjQUFjLGVBQWU7QUFDN0MsVUFBSSxLQUFNLFFBQU87QUFDakIsV0FBSyxHQUFHO0FBQUEsSUFDVjtBQUNBLFdBQU87QUFBQSxFQUNUO0FBRUEsV0FBUyxZQUFZLElBQXFCO0FBQ3hDLFdBQVEsR0FBbUIsVUFBVSxLQUFLO0FBQUEsRUFDNUM7QUFFQSxXQUFTLGFBQWEsSUFBaUIsTUFBb0I7QUFDekQsT0FBRyxNQUFNO0FBRVQsYUFBUyxZQUFZLGFBQWEsT0FBTyxNQUFTO0FBQ2xELGFBQVMsWUFBWSxVQUFVLE9BQU8sTUFBUztBQUMvQyxVQUFNLFFBQVEsS0FBSyxNQUFNLElBQUk7QUFDN0IsYUFBUyxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSztBQUNyQyxVQUFJLE1BQU0sQ0FBQyxFQUFHLFVBQVMsWUFBWSxjQUFjLE9BQU8sTUFBTSxDQUFDLENBQUM7QUFDaEUsVUFBSSxJQUFJLE1BQU0sU0FBUyxFQUFHLFVBQVMsWUFBWSxtQkFBbUIsT0FBTyxNQUFTO0FBQUEsSUFDcEY7QUFBQSxFQUNGO0FBRUEsV0FBUyxpQkFBb0IsU0FBNkI7QUFDeEQsV0FBTyxJQUFJLFFBQVEsQ0FBQyxZQUFZO0FBQzlCLGFBQU8sUUFBUSxZQUFZLFNBQVMsT0FBTztBQUFBLElBQzdDLENBQUM7QUFBQSxFQUNIO0FBSUEsTUFBTSxPQUFPLG9CQUFJLFFBQWlCO0FBRWxDLFdBQVMsVUFBVSxNQUFnQztBQUNqRCxTQUFLLGlCQUEwQixnQkFBZ0IsRUFBRSxRQUFRLENBQUMsU0FBUztBQUVqRSxVQUFJLENBQUMsZUFBZSxJQUFJLEVBQUc7QUFDM0IsVUFBSSxDQUFDLEtBQUssSUFBSSxJQUFJLEdBQUc7QUFDbkIsYUFBSyxJQUFJLElBQUk7QUFDYixlQUFPLElBQUk7QUFBQSxNQUNiO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUdBLE1BQU0sV0FBVyxJQUFJLGlCQUFpQixNQUFNLFVBQVUsUUFBUSxDQUFDO0FBQy9ELFdBQVMsUUFBUSxTQUFTLE1BQU0sRUFBRSxXQUFXLE1BQU0sU0FBUyxLQUFLLENBQUM7QUFJbEUsY0FBWSxNQUFNLFVBQVUsUUFBUSxHQUFHLEdBQUk7QUFHM0MsWUFBVSxRQUFRO0FBSWxCLFdBQVMsaUJBQWlCLFdBQVcsQ0FBQyxNQUFNO0FBQzFDLFFBQUksRUFBRSxFQUFFLFdBQVcsRUFBRSxZQUFZLENBQUMsRUFBRSxTQUFVO0FBRTlDLFVBQU0sWUFBWSxTQUFTLGNBQWMsSUFBSSxTQUFTLEdBQUc7QUFDekQsUUFBSSxDQUFDLFVBQVc7QUFDaEIsVUFBTSxRQUFRLE1BQU0sS0FBSyxVQUFVLFFBQVEsRUFBRSxPQUFPLE9BQUssRUFBRSxVQUFVO0FBRXJFLFFBQUksRUFBRSxRQUFRLEtBQUs7QUFDakIsUUFBRSxlQUFlO0FBQ2pCLE1BQUMsTUFBTSxDQUFDLEdBQUcsWUFBWSxlQUFlLFFBQVEsR0FBZ0MsTUFBTTtBQUFBLElBQ3RGO0FBQ0EsUUFBSSxFQUFFLFFBQVEsS0FBSztBQUNqQixRQUFFLGVBQWU7QUFDakIsTUFBQyxNQUFNLENBQUMsR0FBRyxZQUFZLGVBQWUsWUFBWSxHQUFnQyxNQUFNO0FBQUEsSUFDMUY7QUFBQSxFQUNGLENBQUM7IiwKICAibmFtZXMiOiBbXQp9Cg==
