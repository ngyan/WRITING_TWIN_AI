"use strict";
(() => {
  // src/popup/popup.ts
  var viewLogin = document.getElementById("view-login");
  var viewRegister = document.getElementById("view-register");
  var viewDnaSetup = document.getElementById("view-dna-setup");
  var viewLoggedIn = document.getElementById("view-logged-in");
  var googleLoginBtn = document.getElementById("google-login-btn");
  var googleLoginError = document.getElementById("google-login-error");
  var googleRegisterBtn = document.getElementById("google-register-btn");
  var googleRegisterError = document.getElementById("google-register-error");
  var loginForm = document.getElementById("login-form");
  var loginBtn = document.getElementById("login-btn");
  var loginError = document.getElementById("login-error");
  var registerForm = document.getElementById("register-form");
  var registerBtn = document.getElementById("register-btn");
  var registerError = document.getElementById("register-error");
  var dnaTextarea = document.getElementById("dna-textarea");
  var dnaSampleCount = document.getElementById("dna-sample-count");
  var dnaSubmitBtn = document.getElementById("dna-submit-btn");
  var dnaSkipBtn = document.getElementById("dna-skip-btn");
  var dnaError = document.getElementById("dna-error");
  var dnaSuccess = document.getElementById("dna-success");
  var accountEmail = document.getElementById("account-email");
  var avatarEl = document.getElementById("avatar-initial");
  var logoutBtn = document.getElementById("logout-btn");
  var dnaPromptBox = document.getElementById("dna-prompt-box");
  var dnaTrainedBox = document.getElementById("dna-trained-box");
  var setupDnaBtn = document.getElementById("setup-dna-btn");
  function showView(view) {
    viewLogin.classList.toggle("hidden", view !== "login");
    viewRegister.classList.toggle("hidden", view !== "register");
    viewDnaSetup.classList.toggle("hidden", view !== "dna-setup");
    viewLoggedIn.classList.toggle("hidden", view !== "logged-in");
  }
  function showLoggedIn(email, hasDna) {
    accountEmail.textContent = email;
    avatarEl.textContent = email[0].toUpperCase();
    dnaPromptBox.classList.toggle("hidden", hasDna);
    dnaTrainedBox.classList.toggle("hidden", !hasDna);
    showView("logged-in");
  }
  function parseSamples(raw) {
    return raw.split(/^---$/m).map((s) => s.trim()).filter((s) => s.length >= 10);
  }
  dnaTextarea.addEventListener("input", () => {
    const count = parseSamples(dnaTextarea.value).length;
    dnaSampleCount.textContent = count > 0 ? `${count} sample${count !== 1 ? "s" : ""} detected` : "";
  });
  chrome.runtime.sendMessage({ type: "GET_AUTH_STATE" }, (resp) => {
    if (!resp?.authenticated) {
      showView("login");
      return;
    }
    const email = resp.tokens.email;
    chrome.runtime.sendMessage({ type: "GET_DNA_STATUS" }, (dnaResp) => {
      const profile = dnaResp?.dnaProfile;
      const hasDna = profile !== null && profile !== void 0 && profile.extraction_status !== void 0;
      showLoggedIn(email, hasDna);
    });
  });
  loginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    loginError.textContent = "";
    loginBtn.disabled = true;
    loginBtn.textContent = "Logging in\u2026";
    chrome.runtime.sendMessage({ type: "LOGIN", payload: { email, password } }, (resp) => {
      loginBtn.disabled = false;
      loginBtn.textContent = "Log in";
      if (resp?.error) {
        loginError.textContent = resp.error;
      } else if (resp?.success) {
        chrome.runtime.sendMessage({ type: "GET_DNA_STATUS" }, (dnaResp) => {
          const profile = dnaResp?.dnaProfile;
          const hasDna = profile !== null && profile !== void 0 && profile.extraction_status !== void 0;
          showLoggedIn(email, hasDna);
        });
      }
    });
  });
  registerForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("reg-email").value.trim();
    const password = document.getElementById("reg-password").value;
    if (password.length < 8) {
      registerError.textContent = "Password must be at least 8 characters.";
      return;
    }
    registerError.textContent = "";
    registerBtn.disabled = true;
    registerBtn.textContent = "Creating account\u2026";
    chrome.runtime.sendMessage({ type: "REGISTER", payload: { email, password } }, (resp) => {
      registerBtn.disabled = false;
      registerBtn.textContent = "Create account";
      if (resp?.error) {
        registerError.textContent = resp.error;
      } else if (resp?.success) {
        accountEmail.textContent = email;
        avatarEl.textContent = email[0].toUpperCase();
        showView("dna-setup");
      }
    });
  });
  dnaSubmitBtn.addEventListener("click", () => {
    const samples = parseSamples(dnaTextarea.value);
    if (samples.length === 0) {
      dnaError.textContent = "Paste at least one writing sample (10+ characters).";
      return;
    }
    dnaError.textContent = "";
    dnaSubmitBtn.disabled = true;
    dnaSubmitBtn.textContent = "Training\u2026";
    chrome.runtime.sendMessage({ type: "SUBMIT_DNA", payload: { samples } }, (resp) => {
      dnaSubmitBtn.disabled = false;
      dnaSubmitBtn.textContent = "Train Writing Twin";
      if (resp?.error) {
        dnaError.textContent = resp.error;
      } else if (resp?.success) {
        dnaSuccess.classList.remove("hidden");
        dnaSubmitBtn.classList.add("hidden");
        dnaSkipBtn.textContent = "Done";
      }
    });
  });
  dnaSkipBtn.addEventListener("click", () => {
    const email = accountEmail.textContent || "";
    const trainingStarted = !dnaSuccess.classList.contains("hidden");
    showLoggedIn(email, trainingStarted);
  });
  setupDnaBtn.addEventListener("click", () => {
    dnaTextarea.value = "";
    dnaSampleCount.textContent = "";
    dnaError.textContent = "";
    dnaSuccess.classList.add("hidden");
    dnaSubmitBtn.classList.remove("hidden");
    dnaSkipBtn.textContent = "Skip for now";
    showView("dna-setup");
  });
  function handleGoogleAuth(errorEl, btn) {
    errorEl.textContent = "";
    btn.disabled = true;
    btn.textContent = "Connecting\u2026";
    chrome.runtime.sendMessage({ type: "GOOGLE_AUTH_EXTENSION" }, (resp) => {
      btn.disabled = false;
      btn.textContent = "Continue with Google";
      if (resp?.error) {
        errorEl.textContent = resp.error;
      } else if (resp?.success) {
        const email = resp.tokens?.email || "";
        chrome.runtime.sendMessage({ type: "GET_DNA_STATUS" }, (dnaResp) => {
          const profile = dnaResp?.dnaProfile;
          const hasDna = profile !== null && profile !== void 0 && profile.extraction_status !== void 0;
          if (!hasDna) {
            accountEmail.textContent = email;
            avatarEl.textContent = email ? email[0].toUpperCase() : "?";
            showView("dna-setup");
          } else {
            showLoggedIn(email, hasDna);
          }
        });
      }
    });
  }
  googleLoginBtn.addEventListener("click", () => handleGoogleAuth(googleLoginError, googleLoginBtn));
  googleRegisterBtn.addEventListener("click", () => handleGoogleAuth(googleRegisterError, googleRegisterBtn));
  document.getElementById("go-register").addEventListener("click", (e) => {
    e.preventDefault();
    showView("register");
  });
  document.getElementById("go-login").addEventListener("click", (e) => {
    e.preventDefault();
    showView("login");
  });
  logoutBtn.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "LOGOUT" }, () => {
      showView("login");
    });
  });
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vc3JjL3BvcHVwL3BvcHVwLnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIvLyBQb3B1cCBsb2dpYyBcdTIwMTQgbG9naW4gLyByZWdpc3RlciAvIGxvZ291dCAvIEROQSBzZXR1cFxuXG5jb25zdCB2aWV3TG9naW4gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndmlldy1sb2dpbicpITtcbmNvbnN0IHZpZXdSZWdpc3RlciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd2aWV3LXJlZ2lzdGVyJykhO1xuY29uc3Qgdmlld0RuYVNldHVwID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3ZpZXctZG5hLXNldHVwJykhO1xuY29uc3Qgdmlld0xvZ2dlZEluID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3ZpZXctbG9nZ2VkLWluJykhO1xuXG5jb25zdCBnb29nbGVMb2dpbkJ0biA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdnb29nbGUtbG9naW4tYnRuJykgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG5jb25zdCBnb29nbGVMb2dpbkVycm9yID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2dvb2dsZS1sb2dpbi1lcnJvcicpITtcbmNvbnN0IGdvb2dsZVJlZ2lzdGVyQnRuID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2dvb2dsZS1yZWdpc3Rlci1idG4nKSBhcyBIVE1MQnV0dG9uRWxlbWVudDtcbmNvbnN0IGdvb2dsZVJlZ2lzdGVyRXJyb3IgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZ29vZ2xlLXJlZ2lzdGVyLWVycm9yJykhO1xuXG5jb25zdCBsb2dpbkZvcm0gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbG9naW4tZm9ybScpIGFzIEhUTUxGb3JtRWxlbWVudDtcbmNvbnN0IGxvZ2luQnRuID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2xvZ2luLWJ0bicpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuY29uc3QgbG9naW5FcnJvciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdsb2dpbi1lcnJvcicpITtcblxuY29uc3QgcmVnaXN0ZXJGb3JtID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3JlZ2lzdGVyLWZvcm0nKSBhcyBIVE1MRm9ybUVsZW1lbnQ7XG5jb25zdCByZWdpc3RlckJ0biA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyZWdpc3Rlci1idG4nKSBhcyBIVE1MQnV0dG9uRWxlbWVudDtcbmNvbnN0IHJlZ2lzdGVyRXJyb3IgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncmVnaXN0ZXItZXJyb3InKSE7XG5cbmNvbnN0IGRuYVRleHRhcmVhID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2RuYS10ZXh0YXJlYScpIGFzIEhUTUxUZXh0QXJlYUVsZW1lbnQ7XG5jb25zdCBkbmFTYW1wbGVDb3VudCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdkbmEtc2FtcGxlLWNvdW50JykhO1xuY29uc3QgZG5hU3VibWl0QnRuID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2RuYS1zdWJtaXQtYnRuJykgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG5jb25zdCBkbmFTa2lwQnRuID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2RuYS1za2lwLWJ0bicpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuY29uc3QgZG5hRXJyb3IgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZG5hLWVycm9yJykhO1xuY29uc3QgZG5hU3VjY2VzcyA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdkbmEtc3VjY2VzcycpITtcblxuY29uc3QgYWNjb3VudEVtYWlsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2FjY291bnQtZW1haWwnKSE7XG5jb25zdCBhdmF0YXJFbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdhdmF0YXItaW5pdGlhbCcpITtcbmNvbnN0IGxvZ291dEJ0biA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdsb2dvdXQtYnRuJykgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG5jb25zdCBkbmFQcm9tcHRCb3ggPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZG5hLXByb21wdC1ib3gnKSE7XG5jb25zdCBkbmFUcmFpbmVkQm94ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2RuYS10cmFpbmVkLWJveCcpITtcbmNvbnN0IHNldHVwRG5hQnRuID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3NldHVwLWRuYS1idG4nKSBhcyBIVE1MQnV0dG9uRWxlbWVudDtcblxudHlwZSBWaWV3ID0gJ2xvZ2luJyB8ICdyZWdpc3RlcicgfCAnZG5hLXNldHVwJyB8ICdsb2dnZWQtaW4nO1xuXG5mdW5jdGlvbiBzaG93Vmlldyh2aWV3OiBWaWV3KTogdm9pZCB7XG4gIHZpZXdMb2dpbi5jbGFzc0xpc3QudG9nZ2xlKCdoaWRkZW4nLCB2aWV3ICE9PSAnbG9naW4nKTtcbiAgdmlld1JlZ2lzdGVyLmNsYXNzTGlzdC50b2dnbGUoJ2hpZGRlbicsIHZpZXcgIT09ICdyZWdpc3RlcicpO1xuICB2aWV3RG5hU2V0dXAuY2xhc3NMaXN0LnRvZ2dsZSgnaGlkZGVuJywgdmlldyAhPT0gJ2RuYS1zZXR1cCcpO1xuICB2aWV3TG9nZ2VkSW4uY2xhc3NMaXN0LnRvZ2dsZSgnaGlkZGVuJywgdmlldyAhPT0gJ2xvZ2dlZC1pbicpO1xufVxuXG5mdW5jdGlvbiBzaG93TG9nZ2VkSW4oZW1haWw6IHN0cmluZywgaGFzRG5hOiBib29sZWFuKTogdm9pZCB7XG4gIGFjY291bnRFbWFpbC50ZXh0Q29udGVudCA9IGVtYWlsO1xuICBhdmF0YXJFbC50ZXh0Q29udGVudCA9IGVtYWlsWzBdLnRvVXBwZXJDYXNlKCk7XG4gIGRuYVByb21wdEJveC5jbGFzc0xpc3QudG9nZ2xlKCdoaWRkZW4nLCBoYXNEbmEpO1xuICBkbmFUcmFpbmVkQm94LmNsYXNzTGlzdC50b2dnbGUoJ2hpZGRlbicsICFoYXNEbmEpO1xuICBzaG93VmlldygnbG9nZ2VkLWluJyk7XG59XG5cbmZ1bmN0aW9uIHBhcnNlU2FtcGxlcyhyYXc6IHN0cmluZyk6IHN0cmluZ1tdIHtcbiAgcmV0dXJuIHJhd1xuICAgIC5zcGxpdCgvXi0tLSQvbSlcbiAgICAubWFwKChzKSA9PiBzLnRyaW0oKSlcbiAgICAuZmlsdGVyKChzKSA9PiBzLmxlbmd0aCA+PSAxMCk7XG59XG5cbi8vIFVwZGF0ZSBzYW1wbGUgY291bnQgbGFiZWwgYXMgdXNlciB0eXBlc1xuZG5hVGV4dGFyZWEuYWRkRXZlbnRMaXN0ZW5lcignaW5wdXQnLCAoKSA9PiB7XG4gIGNvbnN0IGNvdW50ID0gcGFyc2VTYW1wbGVzKGRuYVRleHRhcmVhLnZhbHVlKS5sZW5ndGg7XG4gIGRuYVNhbXBsZUNvdW50LnRleHRDb250ZW50ID0gY291bnQgPiAwID8gYCR7Y291bnR9IHNhbXBsZSR7Y291bnQgIT09IDEgPyAncycgOiAnJ30gZGV0ZWN0ZWRgIDogJyc7XG59KTtcblxuLy8gQ2hlY2sgYXV0aCBzdGF0ZSBvbiBwb3B1cCBvcGVuXG5jaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6ICdHRVRfQVVUSF9TVEFURScgfSwgKHJlc3ApID0+IHtcbiAgaWYgKCFyZXNwPy5hdXRoZW50aWNhdGVkKSB7XG4gICAgc2hvd1ZpZXcoJ2xvZ2luJyk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IGVtYWlsOiBzdHJpbmcgPSByZXNwLnRva2Vucy5lbWFpbDtcbiAgLy8gQ2hlY2sgRE5BIHN0YXR1c1xuICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6ICdHRVRfRE5BX1NUQVRVUycgfSwgKGRuYVJlc3ApID0+IHtcbiAgICBjb25zdCBwcm9maWxlID0gZG5hUmVzcD8uZG5hUHJvZmlsZTtcbiAgICBjb25zdCBoYXNEbmEgPSBwcm9maWxlICE9PSBudWxsICYmIHByb2ZpbGUgIT09IHVuZGVmaW5lZCAmJiBwcm9maWxlLmV4dHJhY3Rpb25fc3RhdHVzICE9PSB1bmRlZmluZWQ7XG4gICAgc2hvd0xvZ2dlZEluKGVtYWlsLCBoYXNEbmEpO1xuICB9KTtcbn0pO1xuXG4vLyBMb2dpbiBmb3JtXG5sb2dpbkZvcm0uYWRkRXZlbnRMaXN0ZW5lcignc3VibWl0JywgKGUpID0+IHtcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICBjb25zdCBlbWFpbCA9IChkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZW1haWwnKSBhcyBIVE1MSW5wdXRFbGVtZW50KS52YWx1ZS50cmltKCk7XG4gIGNvbnN0IHBhc3N3b3JkID0gKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdwYXNzd29yZCcpIGFzIEhUTUxJbnB1dEVsZW1lbnQpLnZhbHVlO1xuXG4gIGxvZ2luRXJyb3IudGV4dENvbnRlbnQgPSAnJztcbiAgbG9naW5CdG4uZGlzYWJsZWQgPSB0cnVlO1xuICBsb2dpbkJ0bi50ZXh0Q29udGVudCA9ICdMb2dnaW5nIGluXHUyMDI2JztcblxuICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6ICdMT0dJTicsIHBheWxvYWQ6IHsgZW1haWwsIHBhc3N3b3JkIH0gfSwgKHJlc3ApID0+IHtcbiAgICBsb2dpbkJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICAgIGxvZ2luQnRuLnRleHRDb250ZW50ID0gJ0xvZyBpbic7XG4gICAgaWYgKHJlc3A/LmVycm9yKSB7XG4gICAgICBsb2dpbkVycm9yLnRleHRDb250ZW50ID0gcmVzcC5lcnJvcjtcbiAgICB9IGVsc2UgaWYgKHJlc3A/LnN1Y2Nlc3MpIHtcbiAgICAgIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogJ0dFVF9ETkFfU1RBVFVTJyB9LCAoZG5hUmVzcCkgPT4ge1xuICAgICAgICBjb25zdCBwcm9maWxlID0gZG5hUmVzcD8uZG5hUHJvZmlsZTtcbiAgICAgICAgY29uc3QgaGFzRG5hID0gcHJvZmlsZSAhPT0gbnVsbCAmJiBwcm9maWxlICE9PSB1bmRlZmluZWQgJiYgcHJvZmlsZS5leHRyYWN0aW9uX3N0YXR1cyAhPT0gdW5kZWZpbmVkO1xuICAgICAgICBzaG93TG9nZ2VkSW4oZW1haWwsIGhhc0RuYSk7XG4gICAgICB9KTtcbiAgICB9XG4gIH0pO1xufSk7XG5cbi8vIFJlZ2lzdGVyIGZvcm1cbnJlZ2lzdGVyRm9ybS5hZGRFdmVudExpc3RlbmVyKCdzdWJtaXQnLCAoZSkgPT4ge1xuICBlLnByZXZlbnREZWZhdWx0KCk7XG4gIGNvbnN0IGVtYWlsID0gKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyZWctZW1haWwnKSBhcyBIVE1MSW5wdXRFbGVtZW50KS52YWx1ZS50cmltKCk7XG4gIGNvbnN0IHBhc3N3b3JkID0gKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyZWctcGFzc3dvcmQnKSBhcyBIVE1MSW5wdXRFbGVtZW50KS52YWx1ZTtcblxuICBpZiAocGFzc3dvcmQubGVuZ3RoIDwgOCkge1xuICAgIHJlZ2lzdGVyRXJyb3IudGV4dENvbnRlbnQgPSAnUGFzc3dvcmQgbXVzdCBiZSBhdCBsZWFzdCA4IGNoYXJhY3RlcnMuJztcbiAgICByZXR1cm47XG4gIH1cblxuICByZWdpc3RlckVycm9yLnRleHRDb250ZW50ID0gJyc7XG4gIHJlZ2lzdGVyQnRuLmRpc2FibGVkID0gdHJ1ZTtcbiAgcmVnaXN0ZXJCdG4udGV4dENvbnRlbnQgPSAnQ3JlYXRpbmcgYWNjb3VudFx1MjAyNic7XG5cbiAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnUkVHSVNURVInLCBwYXlsb2FkOiB7IGVtYWlsLCBwYXNzd29yZCB9IH0sIChyZXNwKSA9PiB7XG4gICAgcmVnaXN0ZXJCdG4uZGlzYWJsZWQgPSBmYWxzZTtcbiAgICByZWdpc3RlckJ0bi50ZXh0Q29udGVudCA9ICdDcmVhdGUgYWNjb3VudCc7XG4gICAgaWYgKHJlc3A/LmVycm9yKSB7XG4gICAgICByZWdpc3RlckVycm9yLnRleHRDb250ZW50ID0gcmVzcC5lcnJvcjtcbiAgICB9IGVsc2UgaWYgKHJlc3A/LnN1Y2Nlc3MpIHtcbiAgICAgIC8vIE5ldyB1c2VyIFx1MjAxNCBnbyBzdHJhaWdodCB0byBETkEgc2V0dXBcbiAgICAgIGFjY291bnRFbWFpbC50ZXh0Q29udGVudCA9IGVtYWlsO1xuICAgICAgYXZhdGFyRWwudGV4dENvbnRlbnQgPSBlbWFpbFswXS50b1VwcGVyQ2FzZSgpO1xuICAgICAgc2hvd1ZpZXcoJ2RuYS1zZXR1cCcpO1xuICAgIH1cbiAgfSk7XG59KTtcblxuLy8gRE5BIHNldHVwIHN1Ym1pdFxuZG5hU3VibWl0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICBjb25zdCBzYW1wbGVzID0gcGFyc2VTYW1wbGVzKGRuYVRleHRhcmVhLnZhbHVlKTtcbiAgaWYgKHNhbXBsZXMubGVuZ3RoID09PSAwKSB7XG4gICAgZG5hRXJyb3IudGV4dENvbnRlbnQgPSAnUGFzdGUgYXQgbGVhc3Qgb25lIHdyaXRpbmcgc2FtcGxlICgxMCsgY2hhcmFjdGVycykuJztcbiAgICByZXR1cm47XG4gIH1cblxuICBkbmFFcnJvci50ZXh0Q29udGVudCA9ICcnO1xuICBkbmFTdWJtaXRCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICBkbmFTdWJtaXRCdG4udGV4dENvbnRlbnQgPSAnVHJhaW5pbmdcdTIwMjYnO1xuXG4gIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogJ1NVQk1JVF9ETkEnLCBwYXlsb2FkOiB7IHNhbXBsZXMgfSB9LCAocmVzcCkgPT4ge1xuICAgIGRuYVN1Ym1pdEJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICAgIGRuYVN1Ym1pdEJ0bi50ZXh0Q29udGVudCA9ICdUcmFpbiBXcml0aW5nIFR3aW4nO1xuICAgIGlmIChyZXNwPy5lcnJvcikge1xuICAgICAgZG5hRXJyb3IudGV4dENvbnRlbnQgPSByZXNwLmVycm9yO1xuICAgIH0gZWxzZSBpZiAocmVzcD8uc3VjY2Vzcykge1xuICAgICAgZG5hU3VjY2Vzcy5jbGFzc0xpc3QucmVtb3ZlKCdoaWRkZW4nKTtcbiAgICAgIGRuYVN1Ym1pdEJ0bi5jbGFzc0xpc3QuYWRkKCdoaWRkZW4nKTtcbiAgICAgIGRuYVNraXBCdG4udGV4dENvbnRlbnQgPSAnRG9uZSc7XG4gICAgfVxuICB9KTtcbn0pO1xuXG4vLyBETkEgc2tpcCAvIGRvbmVcbmRuYVNraXBCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIGNvbnN0IGVtYWlsID0gYWNjb3VudEVtYWlsLnRleHRDb250ZW50IHx8ICcnO1xuICBjb25zdCB0cmFpbmluZ1N0YXJ0ZWQgPSAhZG5hU3VjY2Vzcy5jbGFzc0xpc3QuY29udGFpbnMoJ2hpZGRlbicpO1xuICBzaG93TG9nZ2VkSW4oZW1haWwsIHRyYWluaW5nU3RhcnRlZCk7XG59KTtcblxuLy8gU2V0dXAgRE5BIGZyb20gbG9nZ2VkLWluIHZpZXdcbnNldHVwRG5hQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICBkbmFUZXh0YXJlYS52YWx1ZSA9ICcnO1xuICBkbmFTYW1wbGVDb3VudC50ZXh0Q29udGVudCA9ICcnO1xuICBkbmFFcnJvci50ZXh0Q29udGVudCA9ICcnO1xuICBkbmFTdWNjZXNzLmNsYXNzTGlzdC5hZGQoJ2hpZGRlbicpO1xuICBkbmFTdWJtaXRCdG4uY2xhc3NMaXN0LnJlbW92ZSgnaGlkZGVuJyk7XG4gIGRuYVNraXBCdG4udGV4dENvbnRlbnQgPSAnU2tpcCBmb3Igbm93JztcbiAgc2hvd1ZpZXcoJ2RuYS1zZXR1cCcpO1xufSk7XG5cbmZ1bmN0aW9uIGhhbmRsZUdvb2dsZUF1dGgoZXJyb3JFbDogSFRNTEVsZW1lbnQsIGJ0bjogSFRNTEJ1dHRvbkVsZW1lbnQpOiB2b2lkIHtcbiAgZXJyb3JFbC50ZXh0Q29udGVudCA9ICcnO1xuICBidG4uZGlzYWJsZWQgPSB0cnVlO1xuICBidG4udGV4dENvbnRlbnQgPSAnQ29ubmVjdGluZ1x1MjAyNic7XG5cbiAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnR09PR0xFX0FVVEhfRVhURU5TSU9OJyB9LCAocmVzcCkgPT4ge1xuICAgIGJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICAgIGJ0bi50ZXh0Q29udGVudCA9ICdDb250aW51ZSB3aXRoIEdvb2dsZSc7XG4gICAgaWYgKHJlc3A/LmVycm9yKSB7XG4gICAgICBlcnJvckVsLnRleHRDb250ZW50ID0gcmVzcC5lcnJvcjtcbiAgICB9IGVsc2UgaWYgKHJlc3A/LnN1Y2Nlc3MpIHtcbiAgICAgIGNvbnN0IGVtYWlsID0gcmVzcC50b2tlbnM/LmVtYWlsIHx8ICcnO1xuICAgICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnR0VUX0ROQV9TVEFUVVMnIH0sIChkbmFSZXNwKSA9PiB7XG4gICAgICAgIGNvbnN0IHByb2ZpbGUgPSBkbmFSZXNwPy5kbmFQcm9maWxlO1xuICAgICAgICBjb25zdCBoYXNEbmEgPSBwcm9maWxlICE9PSBudWxsICYmIHByb2ZpbGUgIT09IHVuZGVmaW5lZCAmJiBwcm9maWxlLmV4dHJhY3Rpb25fc3RhdHVzICE9PSB1bmRlZmluZWQ7XG4gICAgICAgIGlmICghaGFzRG5hKSB7XG4gICAgICAgICAgYWNjb3VudEVtYWlsLnRleHRDb250ZW50ID0gZW1haWw7XG4gICAgICAgICAgYXZhdGFyRWwudGV4dENvbnRlbnQgPSBlbWFpbCA/IGVtYWlsWzBdLnRvVXBwZXJDYXNlKCkgOiAnPyc7XG4gICAgICAgICAgc2hvd1ZpZXcoJ2RuYS1zZXR1cCcpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHNob3dMb2dnZWRJbihlbWFpbCwgaGFzRG5hKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9KTtcbn1cblxuZ29vZ2xlTG9naW5CdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiBoYW5kbGVHb29nbGVBdXRoKGdvb2dsZUxvZ2luRXJyb3IsIGdvb2dsZUxvZ2luQnRuKSk7XG5nb29nbGVSZWdpc3RlckJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IGhhbmRsZUdvb2dsZUF1dGgoZ29vZ2xlUmVnaXN0ZXJFcnJvciwgZ29vZ2xlUmVnaXN0ZXJCdG4pKTtcblxuLy8gVmlldyBzd2l0Y2hlc1xuZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2dvLXJlZ2lzdGVyJykhLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGUpID0+IHtcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICBzaG93VmlldygncmVnaXN0ZXInKTtcbn0pO1xuZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2dvLWxvZ2luJykhLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGUpID0+IHtcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICBzaG93VmlldygnbG9naW4nKTtcbn0pO1xuXG4vLyBMb2dvdXRcbmxvZ291dEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnTE9HT1VUJyB9LCAoKSA9PiB7XG4gICAgc2hvd1ZpZXcoJ2xvZ2luJyk7XG4gIH0pO1xufSk7XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7QUFFQSxNQUFNLFlBQVksU0FBUyxlQUFlLFlBQVk7QUFDdEQsTUFBTSxlQUFlLFNBQVMsZUFBZSxlQUFlO0FBQzVELE1BQU0sZUFBZSxTQUFTLGVBQWUsZ0JBQWdCO0FBQzdELE1BQU0sZUFBZSxTQUFTLGVBQWUsZ0JBQWdCO0FBRTdELE1BQU0saUJBQWlCLFNBQVMsZUFBZSxrQkFBa0I7QUFDakUsTUFBTSxtQkFBbUIsU0FBUyxlQUFlLG9CQUFvQjtBQUNyRSxNQUFNLG9CQUFvQixTQUFTLGVBQWUscUJBQXFCO0FBQ3ZFLE1BQU0sc0JBQXNCLFNBQVMsZUFBZSx1QkFBdUI7QUFFM0UsTUFBTSxZQUFZLFNBQVMsZUFBZSxZQUFZO0FBQ3RELE1BQU0sV0FBVyxTQUFTLGVBQWUsV0FBVztBQUNwRCxNQUFNLGFBQWEsU0FBUyxlQUFlLGFBQWE7QUFFeEQsTUFBTSxlQUFlLFNBQVMsZUFBZSxlQUFlO0FBQzVELE1BQU0sY0FBYyxTQUFTLGVBQWUsY0FBYztBQUMxRCxNQUFNLGdCQUFnQixTQUFTLGVBQWUsZ0JBQWdCO0FBRTlELE1BQU0sY0FBYyxTQUFTLGVBQWUsY0FBYztBQUMxRCxNQUFNLGlCQUFpQixTQUFTLGVBQWUsa0JBQWtCO0FBQ2pFLE1BQU0sZUFBZSxTQUFTLGVBQWUsZ0JBQWdCO0FBQzdELE1BQU0sYUFBYSxTQUFTLGVBQWUsY0FBYztBQUN6RCxNQUFNLFdBQVcsU0FBUyxlQUFlLFdBQVc7QUFDcEQsTUFBTSxhQUFhLFNBQVMsZUFBZSxhQUFhO0FBRXhELE1BQU0sZUFBZSxTQUFTLGVBQWUsZUFBZTtBQUM1RCxNQUFNLFdBQVcsU0FBUyxlQUFlLGdCQUFnQjtBQUN6RCxNQUFNLFlBQVksU0FBUyxlQUFlLFlBQVk7QUFDdEQsTUFBTSxlQUFlLFNBQVMsZUFBZSxnQkFBZ0I7QUFDN0QsTUFBTSxnQkFBZ0IsU0FBUyxlQUFlLGlCQUFpQjtBQUMvRCxNQUFNLGNBQWMsU0FBUyxlQUFlLGVBQWU7QUFJM0QsV0FBUyxTQUFTLE1BQWtCO0FBQ2xDLGNBQVUsVUFBVSxPQUFPLFVBQVUsU0FBUyxPQUFPO0FBQ3JELGlCQUFhLFVBQVUsT0FBTyxVQUFVLFNBQVMsVUFBVTtBQUMzRCxpQkFBYSxVQUFVLE9BQU8sVUFBVSxTQUFTLFdBQVc7QUFDNUQsaUJBQWEsVUFBVSxPQUFPLFVBQVUsU0FBUyxXQUFXO0FBQUEsRUFDOUQ7QUFFQSxXQUFTLGFBQWEsT0FBZSxRQUF1QjtBQUMxRCxpQkFBYSxjQUFjO0FBQzNCLGFBQVMsY0FBYyxNQUFNLENBQUMsRUFBRSxZQUFZO0FBQzVDLGlCQUFhLFVBQVUsT0FBTyxVQUFVLE1BQU07QUFDOUMsa0JBQWMsVUFBVSxPQUFPLFVBQVUsQ0FBQyxNQUFNO0FBQ2hELGFBQVMsV0FBVztBQUFBLEVBQ3RCO0FBRUEsV0FBUyxhQUFhLEtBQXVCO0FBQzNDLFdBQU8sSUFDSixNQUFNLFFBQVEsRUFDZCxJQUFJLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxFQUNuQixPQUFPLENBQUMsTUFBTSxFQUFFLFVBQVUsRUFBRTtBQUFBLEVBQ2pDO0FBR0EsY0FBWSxpQkFBaUIsU0FBUyxNQUFNO0FBQzFDLFVBQU0sUUFBUSxhQUFhLFlBQVksS0FBSyxFQUFFO0FBQzlDLG1CQUFlLGNBQWMsUUFBUSxJQUFJLEdBQUcsS0FBSyxVQUFVLFVBQVUsSUFBSSxNQUFNLEVBQUUsY0FBYztBQUFBLEVBQ2pHLENBQUM7QUFHRCxTQUFPLFFBQVEsWUFBWSxFQUFFLE1BQU0saUJBQWlCLEdBQUcsQ0FBQyxTQUFTO0FBQy9ELFFBQUksQ0FBQyxNQUFNLGVBQWU7QUFDeEIsZUFBUyxPQUFPO0FBQ2hCO0FBQUEsSUFDRjtBQUNBLFVBQU0sUUFBZ0IsS0FBSyxPQUFPO0FBRWxDLFdBQU8sUUFBUSxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsR0FBRyxDQUFDLFlBQVk7QUFDbEUsWUFBTSxVQUFVLFNBQVM7QUFDekIsWUFBTSxTQUFTLFlBQVksUUFBUSxZQUFZLFVBQWEsUUFBUSxzQkFBc0I7QUFDMUYsbUJBQWEsT0FBTyxNQUFNO0FBQUEsSUFDNUIsQ0FBQztBQUFBLEVBQ0gsQ0FBQztBQUdELFlBQVUsaUJBQWlCLFVBQVUsQ0FBQyxNQUFNO0FBQzFDLE1BQUUsZUFBZTtBQUNqQixVQUFNLFFBQVMsU0FBUyxlQUFlLE9BQU8sRUFBdUIsTUFBTSxLQUFLO0FBQ2hGLFVBQU0sV0FBWSxTQUFTLGVBQWUsVUFBVSxFQUF1QjtBQUUzRSxlQUFXLGNBQWM7QUFDekIsYUFBUyxXQUFXO0FBQ3BCLGFBQVMsY0FBYztBQUV2QixXQUFPLFFBQVEsWUFBWSxFQUFFLE1BQU0sU0FBUyxTQUFTLEVBQUUsT0FBTyxTQUFTLEVBQUUsR0FBRyxDQUFDLFNBQVM7QUFDcEYsZUFBUyxXQUFXO0FBQ3BCLGVBQVMsY0FBYztBQUN2QixVQUFJLE1BQU0sT0FBTztBQUNmLG1CQUFXLGNBQWMsS0FBSztBQUFBLE1BQ2hDLFdBQVcsTUFBTSxTQUFTO0FBQ3hCLGVBQU8sUUFBUSxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsR0FBRyxDQUFDLFlBQVk7QUFDbEUsZ0JBQU0sVUFBVSxTQUFTO0FBQ3pCLGdCQUFNLFNBQVMsWUFBWSxRQUFRLFlBQVksVUFBYSxRQUFRLHNCQUFzQjtBQUMxRix1QkFBYSxPQUFPLE1BQU07QUFBQSxRQUM1QixDQUFDO0FBQUEsTUFDSDtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsQ0FBQztBQUdELGVBQWEsaUJBQWlCLFVBQVUsQ0FBQyxNQUFNO0FBQzdDLE1BQUUsZUFBZTtBQUNqQixVQUFNLFFBQVMsU0FBUyxlQUFlLFdBQVcsRUFBdUIsTUFBTSxLQUFLO0FBQ3BGLFVBQU0sV0FBWSxTQUFTLGVBQWUsY0FBYyxFQUF1QjtBQUUvRSxRQUFJLFNBQVMsU0FBUyxHQUFHO0FBQ3ZCLG9CQUFjLGNBQWM7QUFDNUI7QUFBQSxJQUNGO0FBRUEsa0JBQWMsY0FBYztBQUM1QixnQkFBWSxXQUFXO0FBQ3ZCLGdCQUFZLGNBQWM7QUFFMUIsV0FBTyxRQUFRLFlBQVksRUFBRSxNQUFNLFlBQVksU0FBUyxFQUFFLE9BQU8sU0FBUyxFQUFFLEdBQUcsQ0FBQyxTQUFTO0FBQ3ZGLGtCQUFZLFdBQVc7QUFDdkIsa0JBQVksY0FBYztBQUMxQixVQUFJLE1BQU0sT0FBTztBQUNmLHNCQUFjLGNBQWMsS0FBSztBQUFBLE1BQ25DLFdBQVcsTUFBTSxTQUFTO0FBRXhCLHFCQUFhLGNBQWM7QUFDM0IsaUJBQVMsY0FBYyxNQUFNLENBQUMsRUFBRSxZQUFZO0FBQzVDLGlCQUFTLFdBQVc7QUFBQSxNQUN0QjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsQ0FBQztBQUdELGVBQWEsaUJBQWlCLFNBQVMsTUFBTTtBQUMzQyxVQUFNLFVBQVUsYUFBYSxZQUFZLEtBQUs7QUFDOUMsUUFBSSxRQUFRLFdBQVcsR0FBRztBQUN4QixlQUFTLGNBQWM7QUFDdkI7QUFBQSxJQUNGO0FBRUEsYUFBUyxjQUFjO0FBQ3ZCLGlCQUFhLFdBQVc7QUFDeEIsaUJBQWEsY0FBYztBQUUzQixXQUFPLFFBQVEsWUFBWSxFQUFFLE1BQU0sY0FBYyxTQUFTLEVBQUUsUUFBUSxFQUFFLEdBQUcsQ0FBQyxTQUFTO0FBQ2pGLG1CQUFhLFdBQVc7QUFDeEIsbUJBQWEsY0FBYztBQUMzQixVQUFJLE1BQU0sT0FBTztBQUNmLGlCQUFTLGNBQWMsS0FBSztBQUFBLE1BQzlCLFdBQVcsTUFBTSxTQUFTO0FBQ3hCLG1CQUFXLFVBQVUsT0FBTyxRQUFRO0FBQ3BDLHFCQUFhLFVBQVUsSUFBSSxRQUFRO0FBQ25DLG1CQUFXLGNBQWM7QUFBQSxNQUMzQjtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0gsQ0FBQztBQUdELGFBQVcsaUJBQWlCLFNBQVMsTUFBTTtBQUN6QyxVQUFNLFFBQVEsYUFBYSxlQUFlO0FBQzFDLFVBQU0sa0JBQWtCLENBQUMsV0FBVyxVQUFVLFNBQVMsUUFBUTtBQUMvRCxpQkFBYSxPQUFPLGVBQWU7QUFBQSxFQUNyQyxDQUFDO0FBR0QsY0FBWSxpQkFBaUIsU0FBUyxNQUFNO0FBQzFDLGdCQUFZLFFBQVE7QUFDcEIsbUJBQWUsY0FBYztBQUM3QixhQUFTLGNBQWM7QUFDdkIsZUFBVyxVQUFVLElBQUksUUFBUTtBQUNqQyxpQkFBYSxVQUFVLE9BQU8sUUFBUTtBQUN0QyxlQUFXLGNBQWM7QUFDekIsYUFBUyxXQUFXO0FBQUEsRUFDdEIsQ0FBQztBQUVELFdBQVMsaUJBQWlCLFNBQXNCLEtBQThCO0FBQzVFLFlBQVEsY0FBYztBQUN0QixRQUFJLFdBQVc7QUFDZixRQUFJLGNBQWM7QUFFbEIsV0FBTyxRQUFRLFlBQVksRUFBRSxNQUFNLHdCQUF3QixHQUFHLENBQUMsU0FBUztBQUN0RSxVQUFJLFdBQVc7QUFDZixVQUFJLGNBQWM7QUFDbEIsVUFBSSxNQUFNLE9BQU87QUFDZixnQkFBUSxjQUFjLEtBQUs7QUFBQSxNQUM3QixXQUFXLE1BQU0sU0FBUztBQUN4QixjQUFNLFFBQVEsS0FBSyxRQUFRLFNBQVM7QUFDcEMsZUFBTyxRQUFRLFlBQVksRUFBRSxNQUFNLGlCQUFpQixHQUFHLENBQUMsWUFBWTtBQUNsRSxnQkFBTSxVQUFVLFNBQVM7QUFDekIsZ0JBQU0sU0FBUyxZQUFZLFFBQVEsWUFBWSxVQUFhLFFBQVEsc0JBQXNCO0FBQzFGLGNBQUksQ0FBQyxRQUFRO0FBQ1gseUJBQWEsY0FBYztBQUMzQixxQkFBUyxjQUFjLFFBQVEsTUFBTSxDQUFDLEVBQUUsWUFBWSxJQUFJO0FBQ3hELHFCQUFTLFdBQVc7QUFBQSxVQUN0QixPQUFPO0FBQ0wseUJBQWEsT0FBTyxNQUFNO0FBQUEsVUFDNUI7QUFBQSxRQUNGLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUVBLGlCQUFlLGlCQUFpQixTQUFTLE1BQU0saUJBQWlCLGtCQUFrQixjQUFjLENBQUM7QUFDakcsb0JBQWtCLGlCQUFpQixTQUFTLE1BQU0saUJBQWlCLHFCQUFxQixpQkFBaUIsQ0FBQztBQUcxRyxXQUFTLGVBQWUsYUFBYSxFQUFHLGlCQUFpQixTQUFTLENBQUMsTUFBTTtBQUN2RSxNQUFFLGVBQWU7QUFDakIsYUFBUyxVQUFVO0FBQUEsRUFDckIsQ0FBQztBQUNELFdBQVMsZUFBZSxVQUFVLEVBQUcsaUJBQWlCLFNBQVMsQ0FBQyxNQUFNO0FBQ3BFLE1BQUUsZUFBZTtBQUNqQixhQUFTLE9BQU87QUFBQSxFQUNsQixDQUFDO0FBR0QsWUFBVSxpQkFBaUIsU0FBUyxNQUFNO0FBQ3hDLFdBQU8sUUFBUSxZQUFZLEVBQUUsTUFBTSxTQUFTLEdBQUcsTUFBTTtBQUNuRCxlQUFTLE9BQU87QUFBQSxJQUNsQixDQUFDO0FBQUEsRUFDSCxDQUFDOyIsCiAgIm5hbWVzIjogW10KfQo=
