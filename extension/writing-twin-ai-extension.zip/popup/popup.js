"use strict";
(() => {
  // src/popup/popup.ts
  var viewLogin = document.getElementById("view-login");
  var viewRegister = document.getElementById("view-register");
  var viewDnaSetup = document.getElementById("view-dna-setup");
  var viewLoggedIn = document.getElementById("view-logged-in");
  var loginForm = document.getElementById("login-form");
  var loginBtn = document.getElementById("login-btn");
  var loginError = document.getElementById("login-error");
  var registerForm = document.getElementById("register-form");
  var registerBtn = document.getElementById("register-btn");
  var registerError = document.getElementById("register-error");
  var dnaTextarea = document.getElementById("dna-textarea");
  var dnaSampleCount = document.getElementById("dna-sample-count");
  var dnaSubmitBtn = document.getElementById("dna-submit-btn");
  var dnaSkipBtn = document.getElementById("dna-skip-btn");
  var dnaError = document.getElementById("dna-error");
  var dnaSuccess = document.getElementById("dna-success");
  var accountEmail = document.getElementById("account-email");
  var avatarEl = document.getElementById("avatar-initial");
  var logoutBtn = document.getElementById("logout-btn");
  var dnaPromptBox = document.getElementById("dna-prompt-box");
  var dnaTrainedBox = document.getElementById("dna-trained-box");
  var setupDnaBtn = document.getElementById("setup-dna-btn");
  function showView(view) {
    viewLogin.classList.toggle("hidden", view !== "login");
    viewRegister.classList.toggle("hidden", view !== "register");
    viewDnaSetup.classList.toggle("hidden", view !== "dna-setup");
    viewLoggedIn.classList.toggle("hidden", view !== "logged-in");
  }
  function showLoggedIn(email, hasDna) {
    accountEmail.textContent = email;
    avatarEl.textContent = email[0].toUpperCase();
    dnaPromptBox.classList.toggle("hidden", hasDna);
    dnaTrainedBox.classList.toggle("hidden", !hasDna);
    showView("logged-in");
  }
  function parseSamples(raw) {
    return raw.split(/^---$/m).map((s) => s.trim()).filter((s) => s.length >= 10);
  }
  dnaTextarea.addEventListener("input", () => {
    const count = parseSamples(dnaTextarea.value).length;
    dnaSampleCount.textContent = count > 0 ? `${count} sample${count !== 1 ? "s" : ""} detected` : "";
  });
  chrome.runtime.sendMessage({ type: "GET_AUTH_STATE" }, (resp) => {
    if (!resp?.authenticated || !resp.tokens?.email) {
      showView("login");
      return;
    }
    const email = resp.tokens.email;
    chrome.runtime.sendMessage({ type: "GET_DNA_STATUS" }, (dnaResp) => {
      const profile = dnaResp?.dnaProfile;
      const hasDna = profile !== null && profile !== void 0 && profile.extraction_status !== void 0;
      showLoggedIn(email, hasDna);
    });
  });
  loginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    loginError.textContent = "";
    loginBtn.disabled = true;
    loginBtn.textContent = "Logging in\u2026";
    chrome.runtime.sendMessage({ type: "LOGIN", payload: { email, password } }, (resp) => {
      loginBtn.disabled = false;
      loginBtn.textContent = "Log in";
      if (resp?.error) {
        loginError.textContent = resp.error;
      } else if (resp?.success) {
        chrome.runtime.sendMessage({ type: "GET_DNA_STATUS" }, (dnaResp) => {
          const profile = dnaResp?.dnaProfile;
          const hasDna = profile !== null && profile !== void 0 && profile.extraction_status !== void 0;
          showLoggedIn(email, hasDna);
        });
      }
    });
  });
  registerForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = document.getElementById("reg-email").value.trim();
    const password = document.getElementById("reg-password").value;
    if (password.length < 8) {
      registerError.textContent = "Password must be at least 8 characters.";
      return;
    }
    registerError.textContent = "";
    registerBtn.disabled = true;
    registerBtn.textContent = "Creating account\u2026";
    chrome.runtime.sendMessage({ type: "REGISTER", payload: { email, password } }, (resp) => {
      registerBtn.disabled = false;
      registerBtn.textContent = "Create account";
      if (resp?.error) {
        registerError.textContent = resp.error;
      } else if (resp?.success) {
        accountEmail.textContent = email;
        avatarEl.textContent = email[0].toUpperCase();
        showView("dna-setup");
      }
    });
  });
  dnaSubmitBtn.addEventListener("click", () => {
    const samples = parseSamples(dnaTextarea.value);
    if (samples.length === 0) {
      dnaError.textContent = "Paste at least one writing sample (10+ characters).";
      return;
    }
    dnaError.textContent = "";
    dnaSubmitBtn.disabled = true;
    dnaSubmitBtn.textContent = "Training\u2026";
    chrome.runtime.sendMessage({ type: "SUBMIT_DNA", payload: { samples } }, (resp) => {
      dnaSubmitBtn.disabled = false;
      dnaSubmitBtn.textContent = "Train Writing Twin";
      if (resp?.error) {
        dnaError.textContent = resp.error;
      } else if (resp?.success) {
        dnaSuccess.classList.remove("hidden");
        dnaSubmitBtn.classList.add("hidden");
        dnaSkipBtn.textContent = "Done";
      }
    });
  });
  dnaSkipBtn.addEventListener("click", () => {
    const email = accountEmail.textContent || "";
    const trainingStarted = !dnaSuccess.classList.contains("hidden");
    showLoggedIn(email, trainingStarted);
  });
  setupDnaBtn.addEventListener("click", () => {
    dnaTextarea.value = "";
    dnaSampleCount.textContent = "";
    dnaError.textContent = "";
    dnaSuccess.classList.add("hidden");
    dnaSubmitBtn.classList.remove("hidden");
    dnaSkipBtn.textContent = "Skip for now";
    showView("dna-setup");
  });
  document.getElementById("go-register").addEventListener("click", (e) => {
    e.preventDefault();
    showView("register");
  });
  document.getElementById("go-login").addEventListener("click", (e) => {
    e.preventDefault();
    showView("login");
  });
  logoutBtn.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "LOGOUT" }, () => {
      showView("login");
    });
  });
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vLi4vc3JjL3BvcHVwL3BvcHVwLnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIvLyBQb3B1cCBsb2dpYyBcdTIwMTQgbG9naW4gLyByZWdpc3RlciAvIGxvZ291dCAvIEROQSBzZXR1cFxuXG5jb25zdCB2aWV3TG9naW4gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndmlldy1sb2dpbicpITtcbmNvbnN0IHZpZXdSZWdpc3RlciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd2aWV3LXJlZ2lzdGVyJykhO1xuY29uc3Qgdmlld0RuYVNldHVwID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3ZpZXctZG5hLXNldHVwJykhO1xuY29uc3Qgdmlld0xvZ2dlZEluID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3ZpZXctbG9nZ2VkLWluJykhO1xuXG5jb25zdCBsb2dpbkZvcm0gPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbG9naW4tZm9ybScpIGFzIEhUTUxGb3JtRWxlbWVudDtcbmNvbnN0IGxvZ2luQnRuID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2xvZ2luLWJ0bicpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuY29uc3QgbG9naW5FcnJvciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdsb2dpbi1lcnJvcicpITtcblxuY29uc3QgcmVnaXN0ZXJGb3JtID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3JlZ2lzdGVyLWZvcm0nKSBhcyBIVE1MRm9ybUVsZW1lbnQ7XG5jb25zdCByZWdpc3RlckJ0biA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyZWdpc3Rlci1idG4nKSBhcyBIVE1MQnV0dG9uRWxlbWVudDtcbmNvbnN0IHJlZ2lzdGVyRXJyb3IgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncmVnaXN0ZXItZXJyb3InKSE7XG5cbmNvbnN0IGRuYVRleHRhcmVhID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2RuYS10ZXh0YXJlYScpIGFzIEhUTUxUZXh0QXJlYUVsZW1lbnQ7XG5jb25zdCBkbmFTYW1wbGVDb3VudCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdkbmEtc2FtcGxlLWNvdW50JykhO1xuY29uc3QgZG5hU3VibWl0QnRuID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2RuYS1zdWJtaXQtYnRuJykgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG5jb25zdCBkbmFTa2lwQnRuID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2RuYS1za2lwLWJ0bicpIGFzIEhUTUxCdXR0b25FbGVtZW50O1xuY29uc3QgZG5hRXJyb3IgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZG5hLWVycm9yJykhO1xuY29uc3QgZG5hU3VjY2VzcyA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdkbmEtc3VjY2VzcycpITtcblxuY29uc3QgYWNjb3VudEVtYWlsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2FjY291bnQtZW1haWwnKSE7XG5jb25zdCBhdmF0YXJFbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdhdmF0YXItaW5pdGlhbCcpITtcbmNvbnN0IGxvZ291dEJ0biA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdsb2dvdXQtYnRuJykgYXMgSFRNTEJ1dHRvbkVsZW1lbnQ7XG5jb25zdCBkbmFQcm9tcHRCb3ggPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnZG5hLXByb21wdC1ib3gnKSE7XG5jb25zdCBkbmFUcmFpbmVkQm94ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2RuYS10cmFpbmVkLWJveCcpITtcbmNvbnN0IHNldHVwRG5hQnRuID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3NldHVwLWRuYS1idG4nKSBhcyBIVE1MQnV0dG9uRWxlbWVudDtcblxudHlwZSBWaWV3ID0gJ2xvZ2luJyB8ICdyZWdpc3RlcicgfCAnZG5hLXNldHVwJyB8ICdsb2dnZWQtaW4nO1xuXG5mdW5jdGlvbiBzaG93Vmlldyh2aWV3OiBWaWV3KTogdm9pZCB7XG4gIHZpZXdMb2dpbi5jbGFzc0xpc3QudG9nZ2xlKCdoaWRkZW4nLCB2aWV3ICE9PSAnbG9naW4nKTtcbiAgdmlld1JlZ2lzdGVyLmNsYXNzTGlzdC50b2dnbGUoJ2hpZGRlbicsIHZpZXcgIT09ICdyZWdpc3RlcicpO1xuICB2aWV3RG5hU2V0dXAuY2xhc3NMaXN0LnRvZ2dsZSgnaGlkZGVuJywgdmlldyAhPT0gJ2RuYS1zZXR1cCcpO1xuICB2aWV3TG9nZ2VkSW4uY2xhc3NMaXN0LnRvZ2dsZSgnaGlkZGVuJywgdmlldyAhPT0gJ2xvZ2dlZC1pbicpO1xufVxuXG5mdW5jdGlvbiBzaG93TG9nZ2VkSW4oZW1haWw6IHN0cmluZywgaGFzRG5hOiBib29sZWFuKTogdm9pZCB7XG4gIGFjY291bnRFbWFpbC50ZXh0Q29udGVudCA9IGVtYWlsO1xuICBhdmF0YXJFbC50ZXh0Q29udGVudCA9IGVtYWlsWzBdLnRvVXBwZXJDYXNlKCk7XG4gIGRuYVByb21wdEJveC5jbGFzc0xpc3QudG9nZ2xlKCdoaWRkZW4nLCBoYXNEbmEpO1xuICBkbmFUcmFpbmVkQm94LmNsYXNzTGlzdC50b2dnbGUoJ2hpZGRlbicsICFoYXNEbmEpO1xuICBzaG93VmlldygnbG9nZ2VkLWluJyk7XG59XG5cbmZ1bmN0aW9uIHBhcnNlU2FtcGxlcyhyYXc6IHN0cmluZyk6IHN0cmluZ1tdIHtcbiAgcmV0dXJuIHJhd1xuICAgIC5zcGxpdCgvXi0tLSQvbSlcbiAgICAubWFwKChzKSA9PiBzLnRyaW0oKSlcbiAgICAuZmlsdGVyKChzKSA9PiBzLmxlbmd0aCA+PSAxMCk7XG59XG5cbi8vIFVwZGF0ZSBzYW1wbGUgY291bnQgbGFiZWwgYXMgdXNlciB0eXBlc1xuZG5hVGV4dGFyZWEuYWRkRXZlbnRMaXN0ZW5lcignaW5wdXQnLCAoKSA9PiB7XG4gIGNvbnN0IGNvdW50ID0gcGFyc2VTYW1wbGVzKGRuYVRleHRhcmVhLnZhbHVlKS5sZW5ndGg7XG4gIGRuYVNhbXBsZUNvdW50LnRleHRDb250ZW50ID0gY291bnQgPiAwID8gYCR7Y291bnR9IHNhbXBsZSR7Y291bnQgIT09IDEgPyAncycgOiAnJ30gZGV0ZWN0ZWRgIDogJyc7XG59KTtcblxuLy8gQ2hlY2sgYXV0aCBzdGF0ZSBvbiBwb3B1cCBvcGVuXG5jaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6ICdHRVRfQVVUSF9TVEFURScgfSwgKHJlc3ApID0+IHtcbiAgaWYgKCFyZXNwPy5hdXRoZW50aWNhdGVkIHx8ICFyZXNwLnRva2Vucz8uZW1haWwpIHtcbiAgICBzaG93VmlldygnbG9naW4nKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgZW1haWw6IHN0cmluZyA9IHJlc3AudG9rZW5zLmVtYWlsO1xuICAvLyBDaGVjayBETkEgc3RhdHVzXG4gIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogJ0dFVF9ETkFfU1RBVFVTJyB9LCAoZG5hUmVzcCkgPT4ge1xuICAgIGNvbnN0IHByb2ZpbGUgPSBkbmFSZXNwPy5kbmFQcm9maWxlO1xuICAgIGNvbnN0IGhhc0RuYSA9IHByb2ZpbGUgIT09IG51bGwgJiYgcHJvZmlsZSAhPT0gdW5kZWZpbmVkICYmIHByb2ZpbGUuZXh0cmFjdGlvbl9zdGF0dXMgIT09IHVuZGVmaW5lZDtcbiAgICBzaG93TG9nZ2VkSW4oZW1haWwsIGhhc0RuYSk7XG4gIH0pO1xufSk7XG5cbi8vIExvZ2luIGZvcm1cbmxvZ2luRm9ybS5hZGRFdmVudExpc3RlbmVyKCdzdWJtaXQnLCAoZSkgPT4ge1xuICBlLnByZXZlbnREZWZhdWx0KCk7XG4gIGNvbnN0IGVtYWlsID0gKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdlbWFpbCcpIGFzIEhUTUxJbnB1dEVsZW1lbnQpLnZhbHVlLnRyaW0oKTtcbiAgY29uc3QgcGFzc3dvcmQgPSAoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Bhc3N3b3JkJykgYXMgSFRNTElucHV0RWxlbWVudCkudmFsdWU7XG5cbiAgbG9naW5FcnJvci50ZXh0Q29udGVudCA9ICcnO1xuICBsb2dpbkJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gIGxvZ2luQnRuLnRleHRDb250ZW50ID0gJ0xvZ2dpbmcgaW5cdTIwMjYnO1xuXG4gIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogJ0xPR0lOJywgcGF5bG9hZDogeyBlbWFpbCwgcGFzc3dvcmQgfSB9LCAocmVzcCkgPT4ge1xuICAgIGxvZ2luQnRuLmRpc2FibGVkID0gZmFsc2U7XG4gICAgbG9naW5CdG4udGV4dENvbnRlbnQgPSAnTG9nIGluJztcbiAgICBpZiAocmVzcD8uZXJyb3IpIHtcbiAgICAgIGxvZ2luRXJyb3IudGV4dENvbnRlbnQgPSByZXNwLmVycm9yO1xuICAgIH0gZWxzZSBpZiAocmVzcD8uc3VjY2Vzcykge1xuICAgICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnR0VUX0ROQV9TVEFUVVMnIH0sIChkbmFSZXNwKSA9PiB7XG4gICAgICAgIGNvbnN0IHByb2ZpbGUgPSBkbmFSZXNwPy5kbmFQcm9maWxlO1xuICAgICAgICBjb25zdCBoYXNEbmEgPSBwcm9maWxlICE9PSBudWxsICYmIHByb2ZpbGUgIT09IHVuZGVmaW5lZCAmJiBwcm9maWxlLmV4dHJhY3Rpb25fc3RhdHVzICE9PSB1bmRlZmluZWQ7XG4gICAgICAgIHNob3dMb2dnZWRJbihlbWFpbCwgaGFzRG5hKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfSk7XG59KTtcblxuLy8gUmVnaXN0ZXIgZm9ybVxucmVnaXN0ZXJGb3JtLmFkZEV2ZW50TGlzdGVuZXIoJ3N1Ym1pdCcsIChlKSA9PiB7XG4gIGUucHJldmVudERlZmF1bHQoKTtcbiAgY29uc3QgZW1haWwgPSAoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3JlZy1lbWFpbCcpIGFzIEhUTUxJbnB1dEVsZW1lbnQpLnZhbHVlLnRyaW0oKTtcbiAgY29uc3QgcGFzc3dvcmQgPSAoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3JlZy1wYXNzd29yZCcpIGFzIEhUTUxJbnB1dEVsZW1lbnQpLnZhbHVlO1xuXG4gIGlmIChwYXNzd29yZC5sZW5ndGggPCA4KSB7XG4gICAgcmVnaXN0ZXJFcnJvci50ZXh0Q29udGVudCA9ICdQYXNzd29yZCBtdXN0IGJlIGF0IGxlYXN0IDggY2hhcmFjdGVycy4nO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIHJlZ2lzdGVyRXJyb3IudGV4dENvbnRlbnQgPSAnJztcbiAgcmVnaXN0ZXJCdG4uZGlzYWJsZWQgPSB0cnVlO1xuICByZWdpc3RlckJ0bi50ZXh0Q29udGVudCA9ICdDcmVhdGluZyBhY2NvdW50XHUyMDI2JztcblxuICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7IHR5cGU6ICdSRUdJU1RFUicsIHBheWxvYWQ6IHsgZW1haWwsIHBhc3N3b3JkIH0gfSwgKHJlc3ApID0+IHtcbiAgICByZWdpc3RlckJ0bi5kaXNhYmxlZCA9IGZhbHNlO1xuICAgIHJlZ2lzdGVyQnRuLnRleHRDb250ZW50ID0gJ0NyZWF0ZSBhY2NvdW50JztcbiAgICBpZiAocmVzcD8uZXJyb3IpIHtcbiAgICAgIHJlZ2lzdGVyRXJyb3IudGV4dENvbnRlbnQgPSByZXNwLmVycm9yO1xuICAgIH0gZWxzZSBpZiAocmVzcD8uc3VjY2Vzcykge1xuICAgICAgLy8gTmV3IHVzZXIgXHUyMDE0IGdvIHN0cmFpZ2h0IHRvIEROQSBzZXR1cFxuICAgICAgYWNjb3VudEVtYWlsLnRleHRDb250ZW50ID0gZW1haWw7XG4gICAgICBhdmF0YXJFbC50ZXh0Q29udGVudCA9IGVtYWlsWzBdLnRvVXBwZXJDYXNlKCk7XG4gICAgICBzaG93VmlldygnZG5hLXNldHVwJyk7XG4gICAgfVxuICB9KTtcbn0pO1xuXG4vLyBETkEgc2V0dXAgc3VibWl0XG5kbmFTdWJtaXRCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIGNvbnN0IHNhbXBsZXMgPSBwYXJzZVNhbXBsZXMoZG5hVGV4dGFyZWEudmFsdWUpO1xuICBpZiAoc2FtcGxlcy5sZW5ndGggPT09IDApIHtcbiAgICBkbmFFcnJvci50ZXh0Q29udGVudCA9ICdQYXN0ZSBhdCBsZWFzdCBvbmUgd3JpdGluZyBzYW1wbGUgKDEwKyBjaGFyYWN0ZXJzKS4nO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGRuYUVycm9yLnRleHRDb250ZW50ID0gJyc7XG4gIGRuYVN1Ym1pdEJ0bi5kaXNhYmxlZCA9IHRydWU7XG4gIGRuYVN1Ym1pdEJ0bi50ZXh0Q29udGVudCA9ICdUcmFpbmluZ1x1MjAyNic7XG5cbiAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnU1VCTUlUX0ROQScsIHBheWxvYWQ6IHsgc2FtcGxlcyB9IH0sIChyZXNwKSA9PiB7XG4gICAgZG5hU3VibWl0QnRuLmRpc2FibGVkID0gZmFsc2U7XG4gICAgZG5hU3VibWl0QnRuLnRleHRDb250ZW50ID0gJ1RyYWluIFdyaXRpbmcgVHdpbic7XG4gICAgaWYgKHJlc3A/LmVycm9yKSB7XG4gICAgICBkbmFFcnJvci50ZXh0Q29udGVudCA9IHJlc3AuZXJyb3I7XG4gICAgfSBlbHNlIGlmIChyZXNwPy5zdWNjZXNzKSB7XG4gICAgICBkbmFTdWNjZXNzLmNsYXNzTGlzdC5yZW1vdmUoJ2hpZGRlbicpO1xuICAgICAgZG5hU3VibWl0QnRuLmNsYXNzTGlzdC5hZGQoJ2hpZGRlbicpO1xuICAgICAgZG5hU2tpcEJ0bi50ZXh0Q29udGVudCA9ICdEb25lJztcbiAgICB9XG4gIH0pO1xufSk7XG5cbi8vIEROQSBza2lwIC8gZG9uZVxuZG5hU2tpcEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgY29uc3QgZW1haWwgPSBhY2NvdW50RW1haWwudGV4dENvbnRlbnQgfHwgJyc7XG4gIGNvbnN0IHRyYWluaW5nU3RhcnRlZCA9ICFkbmFTdWNjZXNzLmNsYXNzTGlzdC5jb250YWlucygnaGlkZGVuJyk7XG4gIHNob3dMb2dnZWRJbihlbWFpbCwgdHJhaW5pbmdTdGFydGVkKTtcbn0pO1xuXG4vLyBTZXR1cCBETkEgZnJvbSBsb2dnZWQtaW4gdmlld1xuc2V0dXBEbmFCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gIGRuYVRleHRhcmVhLnZhbHVlID0gJyc7XG4gIGRuYVNhbXBsZUNvdW50LnRleHRDb250ZW50ID0gJyc7XG4gIGRuYUVycm9yLnRleHRDb250ZW50ID0gJyc7XG4gIGRuYVN1Y2Nlc3MuY2xhc3NMaXN0LmFkZCgnaGlkZGVuJyk7XG4gIGRuYVN1Ym1pdEJ0bi5jbGFzc0xpc3QucmVtb3ZlKCdoaWRkZW4nKTtcbiAgZG5hU2tpcEJ0bi50ZXh0Q29udGVudCA9ICdTa2lwIGZvciBub3cnO1xuICBzaG93VmlldygnZG5hLXNldHVwJyk7XG59KTtcblxuLy8gVmlldyBzd2l0Y2hlc1xuZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2dvLXJlZ2lzdGVyJykhLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGUpID0+IHtcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICBzaG93VmlldygncmVnaXN0ZXInKTtcbn0pO1xuZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2dvLWxvZ2luJykhLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGUpID0+IHtcbiAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICBzaG93VmlldygnbG9naW4nKTtcbn0pO1xuXG4vLyBMb2dvdXRcbmxvZ291dEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiAnTE9HT1VUJyB9LCAoKSA9PiB7XG4gICAgc2hvd1ZpZXcoJ2xvZ2luJyk7XG4gIH0pO1xufSk7XG4iXSwKICAibWFwcGluZ3MiOiAiOzs7QUFFQSxNQUFNLFlBQVksU0FBUyxlQUFlLFlBQVk7QUFDdEQsTUFBTSxlQUFlLFNBQVMsZUFBZSxlQUFlO0FBQzVELE1BQU0sZUFBZSxTQUFTLGVBQWUsZ0JBQWdCO0FBQzdELE1BQU0sZUFBZSxTQUFTLGVBQWUsZ0JBQWdCO0FBRTdELE1BQU0sWUFBWSxTQUFTLGVBQWUsWUFBWTtBQUN0RCxNQUFNLFdBQVcsU0FBUyxlQUFlLFdBQVc7QUFDcEQsTUFBTSxhQUFhLFNBQVMsZUFBZSxhQUFhO0FBRXhELE1BQU0sZUFBZSxTQUFTLGVBQWUsZUFBZTtBQUM1RCxNQUFNLGNBQWMsU0FBUyxlQUFlLGNBQWM7QUFDMUQsTUFBTSxnQkFBZ0IsU0FBUyxlQUFlLGdCQUFnQjtBQUU5RCxNQUFNLGNBQWMsU0FBUyxlQUFlLGNBQWM7QUFDMUQsTUFBTSxpQkFBaUIsU0FBUyxlQUFlLGtCQUFrQjtBQUNqRSxNQUFNLGVBQWUsU0FBUyxlQUFlLGdCQUFnQjtBQUM3RCxNQUFNLGFBQWEsU0FBUyxlQUFlLGNBQWM7QUFDekQsTUFBTSxXQUFXLFNBQVMsZUFBZSxXQUFXO0FBQ3BELE1BQU0sYUFBYSxTQUFTLGVBQWUsYUFBYTtBQUV4RCxNQUFNLGVBQWUsU0FBUyxlQUFlLGVBQWU7QUFDNUQsTUFBTSxXQUFXLFNBQVMsZUFBZSxnQkFBZ0I7QUFDekQsTUFBTSxZQUFZLFNBQVMsZUFBZSxZQUFZO0FBQ3RELE1BQU0sZUFBZSxTQUFTLGVBQWUsZ0JBQWdCO0FBQzdELE1BQU0sZ0JBQWdCLFNBQVMsZUFBZSxpQkFBaUI7QUFDL0QsTUFBTSxjQUFjLFNBQVMsZUFBZSxlQUFlO0FBSTNELFdBQVMsU0FBUyxNQUFrQjtBQUNsQyxjQUFVLFVBQVUsT0FBTyxVQUFVLFNBQVMsT0FBTztBQUNyRCxpQkFBYSxVQUFVLE9BQU8sVUFBVSxTQUFTLFVBQVU7QUFDM0QsaUJBQWEsVUFBVSxPQUFPLFVBQVUsU0FBUyxXQUFXO0FBQzVELGlCQUFhLFVBQVUsT0FBTyxVQUFVLFNBQVMsV0FBVztBQUFBLEVBQzlEO0FBRUEsV0FBUyxhQUFhLE9BQWUsUUFBdUI7QUFDMUQsaUJBQWEsY0FBYztBQUMzQixhQUFTLGNBQWMsTUFBTSxDQUFDLEVBQUUsWUFBWTtBQUM1QyxpQkFBYSxVQUFVLE9BQU8sVUFBVSxNQUFNO0FBQzlDLGtCQUFjLFVBQVUsT0FBTyxVQUFVLENBQUMsTUFBTTtBQUNoRCxhQUFTLFdBQVc7QUFBQSxFQUN0QjtBQUVBLFdBQVMsYUFBYSxLQUF1QjtBQUMzQyxXQUFPLElBQ0osTUFBTSxRQUFRLEVBQ2QsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsRUFDbkIsT0FBTyxDQUFDLE1BQU0sRUFBRSxVQUFVLEVBQUU7QUFBQSxFQUNqQztBQUdBLGNBQVksaUJBQWlCLFNBQVMsTUFBTTtBQUMxQyxVQUFNLFFBQVEsYUFBYSxZQUFZLEtBQUssRUFBRTtBQUM5QyxtQkFBZSxjQUFjLFFBQVEsSUFBSSxHQUFHLEtBQUssVUFBVSxVQUFVLElBQUksTUFBTSxFQUFFLGNBQWM7QUFBQSxFQUNqRyxDQUFDO0FBR0QsU0FBTyxRQUFRLFlBQVksRUFBRSxNQUFNLGlCQUFpQixHQUFHLENBQUMsU0FBUztBQUMvRCxRQUFJLENBQUMsTUFBTSxpQkFBaUIsQ0FBQyxLQUFLLFFBQVEsT0FBTztBQUMvQyxlQUFTLE9BQU87QUFDaEI7QUFBQSxJQUNGO0FBQ0EsVUFBTSxRQUFnQixLQUFLLE9BQU87QUFFbEMsV0FBTyxRQUFRLFlBQVksRUFBRSxNQUFNLGlCQUFpQixHQUFHLENBQUMsWUFBWTtBQUNsRSxZQUFNLFVBQVUsU0FBUztBQUN6QixZQUFNLFNBQVMsWUFBWSxRQUFRLFlBQVksVUFBYSxRQUFRLHNCQUFzQjtBQUMxRixtQkFBYSxPQUFPLE1BQU07QUFBQSxJQUM1QixDQUFDO0FBQUEsRUFDSCxDQUFDO0FBR0QsWUFBVSxpQkFBaUIsVUFBVSxDQUFDLE1BQU07QUFDMUMsTUFBRSxlQUFlO0FBQ2pCLFVBQU0sUUFBUyxTQUFTLGVBQWUsT0FBTyxFQUF1QixNQUFNLEtBQUs7QUFDaEYsVUFBTSxXQUFZLFNBQVMsZUFBZSxVQUFVLEVBQXVCO0FBRTNFLGVBQVcsY0FBYztBQUN6QixhQUFTLFdBQVc7QUFDcEIsYUFBUyxjQUFjO0FBRXZCLFdBQU8sUUFBUSxZQUFZLEVBQUUsTUFBTSxTQUFTLFNBQVMsRUFBRSxPQUFPLFNBQVMsRUFBRSxHQUFHLENBQUMsU0FBUztBQUNwRixlQUFTLFdBQVc7QUFDcEIsZUFBUyxjQUFjO0FBQ3ZCLFVBQUksTUFBTSxPQUFPO0FBQ2YsbUJBQVcsY0FBYyxLQUFLO0FBQUEsTUFDaEMsV0FBVyxNQUFNLFNBQVM7QUFDeEIsZUFBTyxRQUFRLFlBQVksRUFBRSxNQUFNLGlCQUFpQixHQUFHLENBQUMsWUFBWTtBQUNsRSxnQkFBTSxVQUFVLFNBQVM7QUFDekIsZ0JBQU0sU0FBUyxZQUFZLFFBQVEsWUFBWSxVQUFhLFFBQVEsc0JBQXNCO0FBQzFGLHVCQUFhLE9BQU8sTUFBTTtBQUFBLFFBQzVCLENBQUM7QUFBQSxNQUNIO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxDQUFDO0FBR0QsZUFBYSxpQkFBaUIsVUFBVSxDQUFDLE1BQU07QUFDN0MsTUFBRSxlQUFlO0FBQ2pCLFVBQU0sUUFBUyxTQUFTLGVBQWUsV0FBVyxFQUF1QixNQUFNLEtBQUs7QUFDcEYsVUFBTSxXQUFZLFNBQVMsZUFBZSxjQUFjLEVBQXVCO0FBRS9FLFFBQUksU0FBUyxTQUFTLEdBQUc7QUFDdkIsb0JBQWMsY0FBYztBQUM1QjtBQUFBLElBQ0Y7QUFFQSxrQkFBYyxjQUFjO0FBQzVCLGdCQUFZLFdBQVc7QUFDdkIsZ0JBQVksY0FBYztBQUUxQixXQUFPLFFBQVEsWUFBWSxFQUFFLE1BQU0sWUFBWSxTQUFTLEVBQUUsT0FBTyxTQUFTLEVBQUUsR0FBRyxDQUFDLFNBQVM7QUFDdkYsa0JBQVksV0FBVztBQUN2QixrQkFBWSxjQUFjO0FBQzFCLFVBQUksTUFBTSxPQUFPO0FBQ2Ysc0JBQWMsY0FBYyxLQUFLO0FBQUEsTUFDbkMsV0FBVyxNQUFNLFNBQVM7QUFFeEIscUJBQWEsY0FBYztBQUMzQixpQkFBUyxjQUFjLE1BQU0sQ0FBQyxFQUFFLFlBQVk7QUFDNUMsaUJBQVMsV0FBVztBQUFBLE1BQ3RCO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxDQUFDO0FBR0QsZUFBYSxpQkFBaUIsU0FBUyxNQUFNO0FBQzNDLFVBQU0sVUFBVSxhQUFhLFlBQVksS0FBSztBQUM5QyxRQUFJLFFBQVEsV0FBVyxHQUFHO0FBQ3hCLGVBQVMsY0FBYztBQUN2QjtBQUFBLElBQ0Y7QUFFQSxhQUFTLGNBQWM7QUFDdkIsaUJBQWEsV0FBVztBQUN4QixpQkFBYSxjQUFjO0FBRTNCLFdBQU8sUUFBUSxZQUFZLEVBQUUsTUFBTSxjQUFjLFNBQVMsRUFBRSxRQUFRLEVBQUUsR0FBRyxDQUFDLFNBQVM7QUFDakYsbUJBQWEsV0FBVztBQUN4QixtQkFBYSxjQUFjO0FBQzNCLFVBQUksTUFBTSxPQUFPO0FBQ2YsaUJBQVMsY0FBYyxLQUFLO0FBQUEsTUFDOUIsV0FBVyxNQUFNLFNBQVM7QUFDeEIsbUJBQVcsVUFBVSxPQUFPLFFBQVE7QUFDcEMscUJBQWEsVUFBVSxJQUFJLFFBQVE7QUFDbkMsbUJBQVcsY0FBYztBQUFBLE1BQzNCO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSCxDQUFDO0FBR0QsYUFBVyxpQkFBaUIsU0FBUyxNQUFNO0FBQ3pDLFVBQU0sUUFBUSxhQUFhLGVBQWU7QUFDMUMsVUFBTSxrQkFBa0IsQ0FBQyxXQUFXLFVBQVUsU0FBUyxRQUFRO0FBQy9ELGlCQUFhLE9BQU8sZUFBZTtBQUFBLEVBQ3JDLENBQUM7QUFHRCxjQUFZLGlCQUFpQixTQUFTLE1BQU07QUFDMUMsZ0JBQVksUUFBUTtBQUNwQixtQkFBZSxjQUFjO0FBQzdCLGFBQVMsY0FBYztBQUN2QixlQUFXLFVBQVUsSUFBSSxRQUFRO0FBQ2pDLGlCQUFhLFVBQVUsT0FBTyxRQUFRO0FBQ3RDLGVBQVcsY0FBYztBQUN6QixhQUFTLFdBQVc7QUFBQSxFQUN0QixDQUFDO0FBR0QsV0FBUyxlQUFlLGFBQWEsRUFBRyxpQkFBaUIsU0FBUyxDQUFDLE1BQU07QUFDdkUsTUFBRSxlQUFlO0FBQ2pCLGFBQVMsVUFBVTtBQUFBLEVBQ3JCLENBQUM7QUFDRCxXQUFTLGVBQWUsVUFBVSxFQUFHLGlCQUFpQixTQUFTLENBQUMsTUFBTTtBQUNwRSxNQUFFLGVBQWU7QUFDakIsYUFBUyxPQUFPO0FBQUEsRUFDbEIsQ0FBQztBQUdELFlBQVUsaUJBQWlCLFNBQVMsTUFBTTtBQUN4QyxXQUFPLFFBQVEsWUFBWSxFQUFFLE1BQU0sU0FBUyxHQUFHLE1BQU07QUFDbkQsZUFBUyxPQUFPO0FBQUEsSUFDbEIsQ0FBQztBQUFBLEVBQ0gsQ0FBQzsiLAogICJuYW1lcyI6IFtdCn0K
